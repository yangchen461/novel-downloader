const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const fixtureSource = fs.readFileSync(path.join(__dirname, 'test-qidian-v19-resilience.cjs'), 'utf8');
const fixtureContext = { require, __dirname, console, AbortController };
vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('\nconst tests=[];')) + '\nthis.fixture = fixture;', fixtureContext);
const status = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
function setup(plans) {
  const f = fixtureContext.fixture(plans.map((_, id) => ({id, vip:true, paid:true})));
  const order = [], commits = [], latest = new Map(), calls = plans.map(() => 0);
  // Every attempt decodes the same source positions. Fewer unknown glyphs
  // replace placeholders with recognized Han instead of deleting body text.
  const glyphSlots = new Map(f.chapters.map((chapter, id) => [chapter.chapterUrl,
    Math.max(0, ...plans[id].map(instruction => typeof instruction === 'number'
      ? instruction : instruction && typeof instruction === 'object' ? instruction.unknown : 0))]));
  f.window.qidianCheckpointSession = {};
  f.ctx.qidianCheckpointSave = async (_session, chapter) => {
    const record = { text:chapter.contentText, metadata:JSON.stringify(chapter.options.qidianGlyphTolerance) };
    latest.set(chapter.chapterUrl, record); commits.push(chapter.chapterUrl); return true;
  };
  function result(chapter, options, unknown = 0, distinct = 1) {
    const resolvedSlots = glyphSlots.get(chapter.chapterUrl) - unknown;
    assert(resolvedSlots >= 0, 'fixture source reserves every glyph position');
    const body = '正文'.repeat(1000) + '文'.repeat(resolvedSlots) + '□'.repeat(unknown);
    options.qidianBodyText = body;
    options.qidianBodyLength = body.length;
    options.qidianGlyphTolerance = unknown ? {
      schema:1, placeholder:'□', mode:'distinct', limit:10, distinctCount:distinct, occurrenceCount:unknown,
      bodyDigest:f.ctx.qidianCheckpointDigest(body),
      glyphs:Array.from({length:distinct}, (_, i) => ({
        sourceCodepoint:`U+${(0x4e00 + i).toString(16).toUpperCase()}`,
        positions:Array.from({length:unknown}, (_, j) => 2000+resolvedSlots+j).filter((_, j) => j % distinct === i),
        occurrences:Array.from({length:unknown}, (_, j) => j).filter(j => j % distinct === i).length
      }))
    } : null;
    return {chapterName:chapter.chapterName, contentText:body, contentHTML:{}, contentImages:[]};
  }
  f.chapters.forEach((chapter, id) => {
    chapter.chapterParse = async (_url, _name, _vip, _paid, _charset, options) => {
      const call = calls[id]++; order.push(id);
      const instruction = plans[id][Math.min(call, plans[id].length - 1)];
      if (instruction === 'fail') { const error = new Error('isolated glyph failure'); error.name='QidianGlyphError'; throw error; }
      if (instruction === 'unsubscribed') { const error = new Error('subscription gate'); error.name='QidianUnsubscribedError'; throw error; }
      if (instruction === 'stop') { f.window.stopController.abort(); return result(chapter, options, 0); }
      if (instruction === 'short') { return {chapterName:chapter.chapterName, contentText:'短', contentHTML:{}, contentImages:[]}; }
      const unknown = typeof instruction === 'number' ? instruction : instruction.unknown;
      return result(chapter, options, unknown, instruction.distinct || 1);
    };
  });
  return Object.assign(f, {order, commits, latest, calls});
}
const tests = [];
const test = (name, run) => tests.push({name,run});
test('full traversal precedes glyph repair; canonical chapters are replaced without duplicate saves or counts', async () => {
  const f = setup([[2,0],[0],[1,0]]), originals = [...f.chapters];
  await f.run();
  assert.deepEqual(f.order, [0,1,2,0,2]);
  assert.equal(f.book.chapters.length,3);
  originals.forEach((chapter, i) => assert.equal(f.book.chapters[i],chapter));
  assert(f.chapters.every(c => c.status===status.saved && !c.contentText.includes('□')));
  assert.equal(f.progress.finishedChapterNumber,3);
  assert.equal(f.commits.length,5);
});
test('missing chapters precede optional glyph repair, even if their catalogue position is later', async () => {
  const f = setup([[1,0],[0],['fail',0]]);
  await f.run();
  assert.deepEqual(f.order,[0,1,2,2,0]);
  assert.equal(f.progress.finishedChapterNumber,3);
});
test('failed repair preserves accepted text, metadata, saved status and checkpoint through both rounds', async () => {
  const f = setup([[3,'fail'],[0]]);
  await f.run();
  const chapter=f.chapters[0];
  assert.deepEqual(f.order,[0,1,0,0]);
  assert.equal(chapter.status,status.saved);
  assert.equal(chapter.options.qidianGlyphTolerance.occurrenceCount,3);
  assert.equal(f.latest.get(chapter.chapterUrl).text,chapter.contentText);
  assert.equal(f.commits.length,2);
  assert.equal(f.progress.finishedChapterNumber,2);
  assert.equal(chapter.qidianAttemptCount,3);
});
test('same or worse OCR result cannot replace the best version; fewer uncertain positions can', async () => {
  const f = setup([[5,2,4],[0]]);
  await f.run();
  assert.equal(f.chapters[0].options.qidianGlyphTolerance.occurrenceCount,2);
  assert.equal(f.chapters[0].contentText.length,2005,'recognizing three former placeholders must preserve all five source positions');
  assert.equal(f.commits.length,3);
  assert.equal(f.latest.get(f.chapters[0].chapterUrl).text,f.chapters[0].contentText);
  assert.equal(f.progress.finishedChapterNumber,2);
});
test('stopping a repair retains saved original and never saves the late candidate', async () => {
  const f = setup([[1,'stop'],[0]]);
  await f.run();
  assert(f.window.stopFlag.aborted);
  assert.equal(f.chapters[0].status,status.saved);
  assert.equal(f.chapters[0].options.qidianGlyphTolerance.occurrenceCount,1);
  assert.equal(f.commits.length,2);
  assert.equal(f.progress.finishedChapterNumber,2);
});
test('an invalid short candidate never replaces a length-validated saved body', async () => {
  const f = setup([[1,'short'],[0]]);
  await f.run();
  assert.equal(f.chapters[0].status,status.saved);
  assert.equal(f.chapters[0].contentText.length,2001);
  assert.equal(f.commits.length,2);
});
test('same chapter titles retain separate URL identities and each candidate replaces its own chapter', async () => {
  const f = setup([[2,0],[3,0]]);
  f.chapters.forEach(c => { c.chapterName = '同名章节'; });
  await f.run();
  assert.equal(f.latest.size,2);
  assert.equal(f.book.chapters.length,2);
  assert.equal(new Set(f.chapters.map(c => c.chapterUrl)).size,2);
  assert.equal(f.progress.finishedChapterNumber,2);
});
test('a subscription gate on optional repair preserves saved chapter and does not inflate skipped count', async () => {
  const f = setup([[1,'unsubscribed'],[0]]);
  await f.run();
  assert.equal(f.chapters[0].status,status.saved);
  assert.equal(f.progress.qidianSkippedChapterNumber,0);
  assert.equal(f.progress.finishedChapterNumber,2);
  assert.equal(f.calls[0],2);
  assert.equal(f.commits.length,2);
});
test('stop during repair save keeps original body and durable record', async () => {
  const f = setup([[1,0],[0]]);
  let saves=0;
  f.state.onSave = () => { if (++saves===3) f.window.stopController.abort(); };
  await f.run();
  assert.equal(f.chapters[0].options.qidianGlyphTolerance.occurrenceCount,1);
  assert.equal(f.commits.length,2);
  assert.equal(f.latest.get(f.chapters[0].chapterUrl).text,f.chapters[0].contentText);
});
test('stop during checkpoint persistence retains the already committed validated improvement', async () => {
  const f = setup([[1,0],[0]]), save = f.ctx.qidianCheckpointSave;
  f.ctx.qidianCheckpointSave = async (...args) => {
    const result = await save(...args);
    if(f.commits.length===3) f.window.stopController.abort();
    return result;
  };
  await f.run();
  assert.equal(f.chapters[0].options.qidianGlyphTolerance,null);
  assert.equal(f.commits.length,3);
  assert.equal(f.latest.get(f.chapters[0].chapterUrl).text,f.chapters[0].contentText);
  assert.equal(f.progress.finishedChapterNumber,2);
});
(async () => {
  let passed=0;
  for (const {name,run} of tests) { try { await run(); passed++; console.log('PASS '+name); } catch(e) { console.error('FAIL '+name,e); process.exitCode=1; } }
  console.log(`${passed}/${tests.length} deferred repair checks passed`);
})();
