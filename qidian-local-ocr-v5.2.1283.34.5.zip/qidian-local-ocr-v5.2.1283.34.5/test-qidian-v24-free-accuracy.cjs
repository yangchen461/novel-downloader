// Exercise the shipped free-body helpers against a DOM tree fixture. There is
// no HTML/OCR/network substitute in the coverage and source-selection logic.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const script = fs.readFileSync(process.env.QIDIAN_SCRIPT_PATH || path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const start = script.indexOf('// Local free-chapter body snapshot.');
const end = script.indexOf('// End local free-chapter body snapshot.', start);
const fragment = process.env.QIDIAN_FREE_HELPERS_PATH
  ? fs.readFileSync(process.env.QIDIAN_FREE_HELPERS_PATH, 'utf8')
  : (assert(start >= 0 && end > start, 'shipped free-body snapshot helpers are present'), script.slice(start, end));
const checkStart = script.indexOf('function qidianContentIsComplete(');
const checkEnd = script.indexOf('function qidianContentFailure(', checkStart);
assert(checkStart >= 0 && checkEnd > checkStart, 'shipped content checks are present');
const validation = script.slice(checkStart, checkEnd);
class TextNode {
  constructor(value) { this.nodeType = 3; this.nodeName = '#text'; this.nodeValue = value; this.parentNode = null; }
  get textContent() { return this.nodeValue; }
  set textContent(value) { this.nodeValue = String(value); }
  cloneNode() { const copy = new TextNode(this.nodeValue); copy.nodeType = this.nodeType; copy.nodeName = this.nodeName; return copy; }
  remove() { if (this.parentNode) this.parentNode.childNodes = this.parentNode.childNodes.filter(node => node !== this); this.parentNode = null; }
}
class ElementNode {
  constructor(name, attrs = {}) { this.nodeType = 1; this.nodeName = name.toUpperCase(); this.childNodes = []; this.attributes = {...attrs}; this.parentNode = null; this.baseURI = 'https://www.qidian.com/chapter/1/2/'; }
  appendChild(child) { if (typeof child === 'string') child = new TextNode(child); this.childNodes.push(child); child.parentNode = this; return child; }
  get textContent() { return this.childNodes.map(node => node.textContent).join(''); }
  set textContent(value) { this.childNodes = []; if (value) this.appendChild(String(value)); }
  getAttribute(name) { return Object.hasOwn(this.attributes, name) ? this.attributes[name] : null; }
  getAttributeNames() { return Object.keys(this.attributes); }
  setAttribute(name, value) { this.attributes[name] = String(value); }
  removeAttribute(name) { delete this.attributes[name]; }
  hasAttribute(name) { return Object.hasOwn(this.attributes, name); }
  get className() { return this.attributes.class || ''; }
  cloneNode(deep) { const copy = new ElementNode(this.nodeName, this.attributes); copy.baseURI = this.baseURI; if (deep) for (const node of this.childNodes) copy.appendChild(node.cloneNode(true)); return copy; }
  remove() { if (this.parentNode) this.parentNode.childNodes = this.parentNode.childNodes.filter(node => node !== this); this.parentNode = null; }
  querySelector(selector) { const walk = node => { for (const child of node.childNodes || []) { if (child.nodeType === 1 && selector === '.content-text' && child.className.split(/\s+/).includes('content-text')) return child; const found = walk(child); if (found) return found; } return null; }; return walk(this); }
}
const el = (name, attrs, ...children) => { const node = new ElementNode(name, attrs || {}); for (const child of children) node.appendChild(child); return node; };
const main = (...children) => el('main', {}, ...children);
const p = (...children) => el('p', {}, ...children);
const context = vm.createContext({URL,console});
vm.runInContext(validation + '\n' + fragment, context);
const capture = context.qidianCaptureFreeBody;
const select = context.qidianSelectFreeBody;
const tests = [];
const test = (name, fn) => tests.push({name,fn});
test('captures all paragraphs in DOM order and preserves BR line breaks', () => {
  const snapshot = capture(main(p('第一行', el('br'), '第二行'), p('后段')));
  assert.equal(snapshot.text, '第一行\n第二行\n\n后段');
  assert.equal(snapshot.paragraphCount, 2);
  assert.equal(snapshot.canonical, '第一行第二行后段');
});
test('preserves English inline word spacing instead of trimming each text node', () => {
  const snapshot = capture(main(p('Mr. ', el('strong', {}, 'John'), ' Smith ', el('em', {}, 'arrived'), '.')));
  assert.equal(snapshot.text, 'Mr. John Smith arrived.');
});
test('captures div-only and direct text surrounding paragraphs without losing either', () => {
  const snapshot = capture(main('开头裸文本', el('div', {}, '分段甲', el('span', {}, '乙')), p('中间段'), '末尾裸文本'));
  assert.equal(snapshot.canonical, '开头裸文本分段甲乙中间段末尾裸文本');
  assert(snapshot.text.indexOf('开头裸文本') < snapshot.text.indexOf('中间段'));
  assert(snapshot.text.indexOf('中间段') < snapshot.text.indexOf('末尾裸文本'));
});
test('scopes to content-text when present instead of including unrelated main paragraphs', () => {
  const snapshot = capture(main(p('外部导航文字'), el('div', {class:'wrapper content-text'}, p('正文')), p('外部尾部文字')));
  assert.equal(snapshot.text, '正文');
  assert.equal(snapshot.paragraphCount, 1);
});
test('removes script, style, review, author notes and controls from source body', () => {
  const root = main(p('正文', el('script', {}, 'SCRIPT'), el('span', {class:'review'}, 'REVIEW')));
  for (const tag of ['style','form','nav','aside','button','input','select','textarea','template','noscript']) root.appendChild(el(tag, {}, p('UNWANTED_' + tag)));
  root.appendChild(el('div', {class:'authorSay'}, p('AUTHOR')));
  root.appendChild(el('div', {id:'r-authorSay'}, p('AUTHOR2')));
  const snapshot = capture(root);
  assert.equal(snapshot.text, '正文');
  assert.equal(snapshot.paragraphCount, 1);
});
test('excludes explicit hidden attributes and inline display/visibility/content visibility rules', () => {
  const root = main(p('正文'));
  for (const attrs of [{hidden:''},{hidden:'false'},{'aria-hidden':'true'},{'aria-hidden':' TRUE '},
    {style:'display: none;'},{style:'DISPLAY: none ! important'},{style:'color:red; display: none !important; padding: 2px'},
    {style:'display/**/: none'},{style:'visibility: hidden'},{style:'visibility:collapse!important;'},
    {style:'content-visibility: hidden'}]) root.appendChild(el('div', attrs, p('HIDDEN')));
  root.appendChild(el('div', {'aria-hidden':'false',style:'display:block; visibility:visible'}, p('可见段')));
  assert.equal(capture(root).canonical, '正文可见段');
});
test('keeps legitimate headings but excludes the known chapter-title UI heading', () => {
  const snapshot = capture(main(el('h1', {class:'title'}, '章节标题界面'), el('h1', {}, '正文内标题'), p('正文')));
  assert.equal(snapshot.canonical, '正文内标题正文');
});
test('a hidden entire body remains empty and cannot be selected', () => {
  const root = main(p('中'.repeat(1000))); root.setAttribute('hidden','');
  const snapshot = capture(root);
  assert.equal(snapshot.text,'');
  assert.equal(select(snapshot,main(p('中'.repeat(1000))),'中'.repeat(1000),1000),null);
});
test('a content-text container inside a hidden requested main cannot restore hidden text', () => {
  const root = main(el('div', {class:'content-text'}, p('中'.repeat(1000)))); root.setAttribute('style','display:none');
  const snapshot = capture(root);
  assert.equal(snapshot.text,'');
  assert.equal(select(snapshot,root,root.textContent,1000),null);
});
test('capture leaves source nodes, attributes and text intact and retains independent copies', () => {
  const root = main(p('甲',el('span',{hidden:''},'隐藏'),el('b',{},'乙')));
  const before = JSON.stringify(root, (key,value) => key === 'parentNode' ? undefined : value);
  const snapshot = capture(root);
  assert.equal(JSON.stringify(root,(key,value) => key === 'parentNode' ? undefined : value),before);
  assert.equal(root.textContent,'甲隐藏乙');
  root.childNodes[0].textContent = '被后续cleanDOM修改';
  assert.equal(snapshot.text,'甲乙');
  assert.equal(snapshot.dom.textContent,'甲乙');
});
test('repairs ten-percent cleanup loss even when the 50-percent check passes', () => {
  const snapshot = capture(main(p('甲'.repeat(900)),p('乙'.repeat(100))));
  const cleaned = main(p('甲'.repeat(900)));
  assert.equal(context.qidianContentIsComplete(cleaned.textContent,1000,false),true);
  const selected = select(snapshot,cleaned,cleaned.textContent,1000);
  assert(selected); assert.equal(selected.bodyText,'甲'.repeat(900)+'\n\n'+'乙'.repeat(100));
  assert.equal(selected.quality.actualChars,1000); assert.equal(selected.replaced,true); assert.equal(selected.reason,'cleanup_text_mismatch');
});
test('repairs an equal-length paragraph reorder that a length check cannot detect', () => {
  const source = main(p('甲'.repeat(500)),p('乙'.repeat(500)));
  const cleaned = main(p('乙'.repeat(500)),p('甲'.repeat(500)));
  const selected = select(capture(source),cleaned,cleaned.textContent,1000);
  assert(selected); assert.equal(selected.replaced,true); assert.equal(selected.reason,'cleanup_text_mismatch');
  assert.equal(selected.bodyText,'甲'.repeat(500)+'\n\n'+'乙'.repeat(500));
});
test('uses source plain text when cleaned DOM is complete but exported text lost a segment', () => {
  const source = main(p('甲'.repeat(900)),p('乙'.repeat(100)));
  const selected = select(capture(source),source,'甲'.repeat(900),1000);
  assert.equal(selected.reason,'source_text_match'); assert.equal(selected.replaced,true);
  assert.equal(selected.bodyText.replace(/\s/g,''), '甲'.repeat(900)+'乙'.repeat(100));
});
test('Markdown URLs and formatting cannot make a short body pass completeness', () => {
  const source = main(p('中'.repeat(400)),el('img',{src:'https://images.invalid/'+'x'.repeat(1000)}));
  const markdown = '中'.repeat(400)+'![image](https://images.invalid/'+'x'.repeat(1000)+')';
  assert.equal(context.qidianContentIsComplete(markdown,1000,false),true);
  assert.equal(select(capture(source),source,markdown,1000),null);
});
test('hidden text padding cannot raise a genuinely short visible body above threshold', () => {
  const source = main(p('中'.repeat(400)),el('div',{style:'display:none'},p('中'.repeat(400))));
  assert.equal(context.qidianContentIsComplete(source.textContent,1000,false),true);
  assert.equal(select(capture(source),source,source.textContent,1000),null);
});
test('encoded private-use and replacement characters are never accepted as a recovered body', () => {
  for (const point of [0xe123,0xf0123,0x100123,0xfffd]) {
    const source = main(p('中'.repeat(1000)+String.fromCodePoint(point)));
    assert.equal(select(capture(source),source,source.textContent,1000),null);
  }
});
test('unchanged valid paragraphs retain exact plaintext and do not indicate cleanup loss', () => {
  const source = main(p('甲'.repeat(500)),p('乙'.repeat(500)));
  const snapshot = capture(source), selected = select(snapshot,source,snapshot.text,1000);
  assert(selected); assert.equal(selected.text,snapshot.text); assert.equal(selected.bodyText,snapshot.text);
  assert.equal(selected.replaced,false); assert.equal(selected.reason,'source_text_match');
  assert.equal(selected.quality.complete,true);
});
test('missing or uncloneable trees return no snapshot and do not throw', () => {
  assert.equal(capture(null),null);
  assert.equal(capture({textContent:'中'.repeat(1000)}),null);
  assert.equal(capture({childNodes:[],cloneNode(){throw new Error('DOM boundary failed');}}),null);
  assert.equal(select(null,null,'中'.repeat(1000),1000),null);
});
test('image links stay separate from body count, resolve locally, deduplicate and reject executable URLs', () => {
  const source = main(p('中'.repeat(1000)), el('img',{src:'/images/one.png',alt:'中'.repeat(1000)}),
    el('img',{src:'https://www.qidian.com/images/one.png'}), el('img',{'data-src':'//cdn.invalid/two.png',src:'https://cdn.invalid/placeholder.png'}),
    el('img',{src:'javascript:alert(1)'}), el('img',{src:'data:image/png;base64,FAKE'}),
    el('div',{hidden:''},el('img',{src:'https://images.invalid/hidden.png'})));
  const snapshot = capture(source), selected = select(snapshot,source,snapshot.text,1000);
  assert.deepEqual(Array.from(snapshot.imageLinks),['https://www.qidian.com/images/one.png','https://cdn.invalid/two.png']);
  assert.equal(selected.quality.actualChars,1000); assert.equal(selected.bodyText,'中'.repeat(1000));
  assert.equal(snapshot.dom.childNodes.filter(node=>node.nodeName==='IMG').length,5);
});
test('snapshot strips image-loading attributes after gathering links without touching source images', () => {
  const sourceImg = el('img', {src:'/images/original.png',srcset:'/images/large.png 2x',sizes:'100vw'});
  const sourceCandidate = el('source', {src:'/images/fallback.png',srcset:'/images/picture.png 2x',sizes:'100vw'});
  const source = main(p('中'.repeat(1000)),el('picture',{},sourceCandidate,sourceImg));
  const before = JSON.stringify(source,(key,value) => key === 'parentNode' ? undefined : value);
  const snapshot = capture(source);
  const clonedPicture = snapshot.dom.childNodes[1], clonedSource = clonedPicture.childNodes[0], clonedImg = clonedPicture.childNodes[1];
  assert.deepEqual(Array.from(snapshot.imageLinks),['https://www.qidian.com/images/original.png']);
  for (const node of [clonedImg,clonedSource]) for (const attr of ['src','srcset','sizes']) assert.equal(node.getAttribute(attr),null);
  assert.equal(clonedImg.getAttribute('data-original-src'),'/images/original.png');
  assert.equal(JSON.stringify(source,(key,value) => key === 'parentNode' ? undefined : value),before);
  assert.equal(sourceImg.getAttribute('src'),'/images/original.png');
  assert.equal(sourceImg.getAttribute('srcset'),'/images/large.png 2x');
  // Recapturing an already inert snapshot preserves the local export links.
  assert.deepEqual(Array.from(capture(snapshot.dom).imageLinks),Array.from(snapshot.imageLinks));
});
test('excludes active media, embedded frames and upstream ignored controls without losing adjacent body text', () => {
  const source = main(p('甲'.repeat(500)),p('乙'.repeat(500)));
  const ignored = ['iframe','embed','object','link','video','audio','canvas','fieldset','legend','label','datalist','map','meter','output','progress','slot','svg','wbr','option','optgroup'];
  for (const tag of ignored) source.appendChild(el(tag,{src:'https://resource.invalid/source',data:'https://resource.invalid/data',href:'https://resource.invalid/link',poster:'https://resource.invalid/poster',srcdoc:'<script>external()</script>'},'IGNORED_'+tag));
  const before = JSON.stringify(source,(key,value) => key === 'parentNode' ? undefined : value);
  const snapshot = capture(source);
  assert.equal(snapshot.canonical,'甲'.repeat(500)+'乙'.repeat(500));
  assert.equal(snapshot.dom.childNodes.length,2);
  assert.equal(JSON.stringify(source,(key,value) => key === 'parentNode' ? undefined : value),before);
});
test('matches every upstream cleanDOM IgnoreElements tag so widget fallback cannot inflate a body', () => {
  const upstream = script.match(/const IgnoreElements = \[([\s\S]*?)\n\];/);
  assert(upstream,'upstream HTML exclusion list is available');
  const tags = Array.from(upstream[1].matchAll(/"([#a-z]+)"/g),match => match[1]);
  const source = main(p('正文'));
  for (const tag of tags) {
    if (tag === '#comment') { const comment = new TextNode('COMMENT_NOT_BODY'); comment.nodeType = 8; comment.nodeName = '#comment'; source.appendChild(comment); }
    else source.appendChild(el(tag,{},'IGNORED_'+tag));
  }
  assert.equal(capture(source).text,'正文');
});
test('removes inline handlers, srcdoc and resource styles from retained clone while preserving genuine body text and source', () => {
  const source = main(p('甲',el('span',{onclick:'external()',onLOAD:'external()',onerror:'external()',srcdoc:'<script>external()</script>',style:'color:red;background-image:url(https://resource.invalid/bg.png)','data-note':'keep'},'乙'),el('b',{},'丙')));
  source.setAttribute('onmouseover','external()');
  source.setAttribute('style','background:url(https://resource.invalid/main.png)');
  const before = JSON.stringify(source,(key,value) => key === 'parentNode' ? undefined : value);
  const snapshot = capture(source), clonedSpan = snapshot.dom.childNodes[0].childNodes[1];
  assert.equal(snapshot.text,'甲乙丙');
  for (const name of ['onclick','onLOAD','onerror','srcdoc','style']) assert.equal(clonedSpan.getAttribute(name),null);
  assert.equal(clonedSpan.getAttribute('data-note'),'keep');
  assert.equal(snapshot.dom.getAttribute('onmouseover'),null);
  assert.equal(snapshot.dom.getAttribute('style'),null);
  assert.equal(JSON.stringify(source,(key,value) => key === 'parentNode' ? undefined : value),before);
});
test('legacy object-attribute DOM adapters receive the same handler and style sanitization', () => {
  class LegacyNode extends ElementNode {
    getAttributeNames = undefined;
    cloneNode(deep) { const copy = new LegacyNode(this.nodeName,this.attributes); copy.baseURI = this.baseURI; if (deep) for (const child of this.childNodes) copy.appendChild(child.cloneNode(true)); return copy; }
  }
  const legacy = new LegacyNode('span',{onclick:'external()',srcdoc:'<script>external()</script>',style:'background:url(https://resource.invalid/bg.png)'});
  legacy.appendChild('真实正文');
  const snapshot = capture(main(p(legacy))), cloned = snapshot.dom.childNodes[0].childNodes[0];
  assert.equal(snapshot.text,'真实正文');
  for (const name of ['onclick','srcdoc','style']) assert.equal(cloned.getAttribute(name),null);
  assert.equal(legacy.getAttribute('onclick'),'external()');
  assert.equal(legacy.getAttribute('style'),'background:url(https://resource.invalid/bg.png)');
});
let failures = 0;
for (const {name,fn} of tests) {
  try { fn(); console.log(`PASS ${name}`); }
  catch (error) { failures++; console.error(`FAIL ${name}\n${error.stack}`); }
}
console.log(`${tests.length-failures}/${tests.length} v24 free extraction accuracy checks passed`);
if (failures) process.exitCode = 1;
