const fs = require('node:fs');
const assert = require('node:assert/strict');
const vm = require('node:vm');
const script = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const globalHelpers = script.slice(script.indexOf('function qidianContentIsComplete('), script.indexOf('/******/ 	var __webpack_modules__'));

async function testPartialSave() {
  const marker = 'const failed = self.book.chapters.filter((chapter) =>';
  const loc = script.indexOf(marker);
  assert.ok(loc > 0);
  const start = script.lastIndexOf('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {', loc);
  const end = script.indexOf('      // Export lifecycle begins after per-chapter filtering.', loc);
  assert.ok(start > 0 && end > start);
  // Execute the real per-chapter filtering branch, then a fixture delivery
  // callback and the real nonblocking result notifier. The v26 full-run suite
  // separately exercises the instrumented export lifecycle and its ordering.
  // parseQidianChapterNumber is intentionally absent: it lives in another module.
  const diag = vm.runInNewContext(globalHelpers + '\n({ qidianContentIsComplete, qidianChapterContentCheck, qidianChapterGlyphTolerance, qidianChapterLengthWarning, qidianDebugEvent, qidianChapterDiagnostic, qidianChapterBodyText, qidianNotifyResult })', {});
  const run = new (Object.getPrototypeOf(async function(){}).constructor)(
    'self', 'document', 'main', 'qidianContentIsComplete',
    'loglevel_default', 'alert', 'save', 'saveBookObj', 'window', 'qidianDebugEvent', 'qidianChapterDiagnostic', 'qidianChapterBodyText', 'qidianNotifyResult', 'qidianChapterContentCheck', 'qidianChapterGlyphTolerance',
    'qidianChapterLengthWarning', 'let qidianCompletionMessage;\n'+script.slice(start, end)+
      '\nawait save(saveBookObj);\nif(qidianCompletionMessage)qidianNotifyResult(loglevel_default(),qidianCompletionMessage);'
  );
  const statuses = { saved: 'saved', failed: 'failed' };
  const chapters = Array.from({ length: 100 }, (_, i) => ({
    chapterName: `第${i + 1}章`, chapterNumber: i + 1,
    status: i < 95 ? 'saved' : 'failed',
    contentText: i < 95 ? '完整正文'.repeat(200) : null, options: {}, isVIP: i >= 60
  }));
  const book = { chapters };
  const notices = [];
  const saved = [];
  await run({ book }, { location: { hostname: 'www.qidian.com' } },
    { nW: statuses, K5: Error }, diag.qidianContentIsComplete,
    () => ({ warn: text => notices.push(text) }), text => notices.push(text),
    async () => saved.push(book.chapters.map(c => c.chapterNumber)), {}, { qidianPauseReason: '' }, diag.qidianDebugEvent, diag.qidianChapterDiagnostic, diag.qidianChapterBodyText, diag.qidianNotifyResult, diag.qidianChapterContentCheck, diag.qidianChapterGlyphTolerance, diag.qidianChapterLengthWarning);
  assert.deepEqual(saved, [Array.from({ length: 95 }, (_, i) => i + 1)]);
  assert.equal(book.chapters.length, 95);
  assert.ok(notices.some(x => x.includes('有 5 章')));
  assert.ok(notices.some(x => x.includes('第100章')));
  const pausedChapters = chapters.map((c, i) => ({...c, status: i < 40 ? 'saved' : 'failed', contentText: i < 40 ? '完整正文'.repeat(200) : null}));
  const pausedBook = {chapters: pausedChapters};
  const pausedNotices = [];
  await run({book: pausedBook}, {location: {hostname: 'www.qidian.com'}},
    {nW: statuses, K5: Error}, diag.qidianContentIsComplete,
    () => ({warn:text=>pausedNotices.push(text)}), text => pausedNotices.push(text), async () => {}, {},
    {qidianPauseReason: '起点返回访问拦截页'}, diag.qidianDebugEvent, diag.qidianChapterDiagnostic, diag.qidianChapterBodyText, diag.qidianNotifyResult, diag.qidianChapterContentCheck, diag.qidianChapterGlyphTolerance, diag.qidianChapterLengthWarning);
  assert.equal(pausedBook.chapters.length, 40);
  assert.ok(pausedNotices.some(x => x.includes('已保留 40 章正文')));
}

async function testBlockHandlingAndPace() {
  const start = script.indexOf('function qidianContentIsComplete(');
  const end = script.indexOf('/******/ \tvar __webpack_modules__', start);
  assert.ok(start > 0 && end > start);
  const flag = {aborted: false};
  const context = {window: {stopFlag: flag, stopController: {abort() {flag.aborted = true;}}}};
  vm.runInNewContext(script.slice(start, end), context);
  assert.equal(context.qidianPageIsBlocked({title: 'WAF拦截页面', body: {textContent: '403 您的请求已中断'}}), true);
  assert.equal(context.qidianPageIsBlocked({title: '第四十一章', body: {textContent: '正常章节正文'}}), false);
  const error = context.qidianPauseDownload('请求被拦截');
  assert.equal(error.name, 'QidianAccessError');
  assert.equal(flag.aborted, true);
  assert.equal(context.window.qidianPauseReason, '请求被拦截');

  const delayStart = script.indexOf('          const qidianChapter =', script.indexOf('let previousQidianFree = null;'));
  const delayEnd = script.indexOf('          const reqStart = Date.now();', delayStart);
  const waitStart = script.indexOf('      const qidianWait =', script.indexOf('let previousQidianFree = null;'));
  const waitEnd = script.indexOf('      const recoverable =', waitStart);
  assert.ok(delayStart > 0 && delayEnd > delayStart);
  assert.ok(waitStart > 0 && waitEnd > waitStart);
  const delayFn = new (Object.getPrototypeOf(async function(){}).constructor)(
    'self', 'chapteri', 'misc', 'document', 'window', 'main',
    'lastQidianRequestStart', 'qidianRemainingRequestWait', 'chapter', 'previousQidianFree',
    'remainingQidianFree', 'remainingQidianVIP', 'progress', 'qidianPageFailureCooldownUntil', 'qidianReportProgress', 'firstChapterDispatch', 'qidianAwaitAccessRecovery', 'Date',
    'let qidianStableSuccessCount=0, qidianFastPacingSuspended=false, qidianObservedAccessResumeAfter=0, usedFastPacing=false;\n' +
      script.slice(waitStart, waitEnd) + script.slice(delayStart, delayEnd)
  );
  const delays = [];
  let virtualNow = 1000;
  await delayFn({maxSleepTime: 1200, sleepTime: 250}, 40,
    {yy: async ms => { delays.push(ms); virtualNow += ms; }}, {location: {hostname: 'www.qidian.com'}},
    {stopFlag: {aborted: false}}, {K5: Error}, null, context.qidianRemainingRequestWait,
    {isVIP:true}, null, 0, 1, {vm:{}}, 0, () => {}, true, context.qidianAwaitAccessRecovery, {now:()=>virtualNow});
  assert.ok(delays.reduce((total,ms)=>total+ms,0) >= 10000);
  assert.ok(delays.every(ms=>ms<=1000));
  assert.equal(context.qidianRemainingRequestWait(10000, 1000, 8000), 3000);
  assert.equal(context.qidianRemainingRequestWait(10000, 1000, 12000), 0);
}

function testOldPresetMigration() {
  const start = script.indexOf('    // Replace the earlier 250/1200 ms preset');
  const end = script.indexOf('    setting.customDownload = GM_getValue(', start);
  assert.ok(start > 0 && end > start);
  const old = {customDownload: true, concurrencyLimit: 1, sleepTime: 250, maxSleepTime: 1200};
  const ctx = {
    document: {location: {hostname: 'www.qidian.com'}},
    GM_getValue: (key, fallback) => key in old ? old[key] : fallback,
    GM_setValue: (key, value) => {old[key] = value;}
  };
  vm.runInNewContext(script.slice(start, end), ctx);
  assert.equal(old.sleepTime, 8000);
  assert.equal(old.maxSleepTime, 20000);
  old.sleepTime = 30000;
  vm.runInNewContext(script.slice(start, end), ctx);
  assert.equal(old.sleepTime, 30000);
}

async function testIframeTimeout() {
  const start = script.indexOf('async function getFrameContentConditionWithWindow(');
  const end = script.indexOf('\n\n\n/***/', start);
  assert.ok(start > 0 && end > start);
  const deadlines = [];
  let removed = 0;
  const frame = {
    sandbox: { add() {} }, addEventListener() {}, remove() {removed++;},
    contentWindow: { document: {
      readyState: 'complete', title: '章节加载中', body: {},
      querySelector(selector) {
        return selector === 'main' ? {querySelectorAll() {return Array(3);}} : null;
      }
    }}
  };
  const context = {
    document: { createElement: () => frame, body: { appendChild() {} } },
    window: {
      setInterval() { return 1; }, clearInterval() {}, clearTimeout() {},
      setTimeout(fn, ms) { deadlines.push({ fn, ms }); return deadlines.length; }
    },
    _log__WEBPACK_IMPORTED_MODULE_0___default: () => ({ debug() {}, error() {} })
  };
  const getFrame = vm.runInNewContext(script.slice(start, end) + '\ngetFrameContentConditionWithWindow', context);
  const task = getFrame('https://www.qidian.com/chapter/example', () => false, undefined, 20000);
  assert.equal(deadlines[0].ms, 20000);
  deadlines[0].fn();
  await assert.rejects(task, error => {
    assert.match(error.message, /Frame Timeout!/);
    assert.equal(error.frameState.readyState, 'complete');
    assert.equal(error.frameState.mainParagraphs, 3);
    return true;
  });
  assert.equal(removed, 1);
}

async function testQidianPageTimeoutClassification() {
  const start = script.indexOf('  async chapterParse(chapterUrl, chapterName, isVIP, isPaid, charset, options, retryAttempt = 0) {');
  const end = script.indexOf('\n}\n\n\n/***/', start);
  assert.ok(start > 0 && end > start);
  const deadlines = [];
  const warnings = [];
  const parse = vm.runInNewContext(globalHelpers + '\n({' + script.slice(start, end) + '}).chapterParse', {
    window: {},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__: {Q2:async (url, predicate, sandbox, timeout) => {
      deadlines.push(timeout);
      const error = new Error('Frame Timeout!');
      error.frameState = {readyState:'loading', mainParagraphs:0};
      throw error;
    }},
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => ({warn: message => warnings.push(message)}),
  });
  const args = ['https://www.qidian.com/chapter/example','第97章',true,true,'UTF-8',{}];
  await assert.rejects(parse(...args,0), error => error.name==='QidianPageTimeoutError');
  await assert.rejects(parse(...args,1), error => error.name==='QidianPageTimeoutError');
  assert.deepEqual(deadlines,[20000,45000]);
  assert.ok(warnings.every(message => message.includes('readyState')));
}

(async () => {
  await testPartialSave();
  await testBlockHandlingAndPace();
  testOldPresetMigration();
  await testIframeTimeout();
  await testQidianPageTimeoutClassification();
  console.log('PASS: 部分保存、拦截即停、起点最短间隔及超时恢复诊断');
})().catch(error => { console.error(error); process.exitCode = 1; });
