const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const status = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
const log = {info(){}, debug(){}, warn(){}, error(){}, trace(){}};
const chapterSource = src.slice(src.indexOf('class ChapterAbortError'), src.indexOf('\n\n/***/ },', src.indexOf('class ChapterAbortError')));
const schedulerSource = src.slice(src.indexOf('  async initChapters(book,'), src.indexOf('\n  postHook()', src.indexOf('  async initChapters(book,')));
const globalHelpers = src.slice(src.indexOf('function qidianContentIsComplete'), src.indexOf('/******/ \tvar __webpack_modules__'));
const addChapterSource = src.slice(src.indexOf('  async addChapter(chapter) {', src.indexOf('class SaveBook')), src.indexOf('\n  async save()', src.indexOf('class SaveBook')));
// The real export lifecycle is covered by the v26 run suite. This historical
// fixture isolates per-chapter filtering and its retained-body report.
const finalValidation = src.slice(src.indexOf('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {', src.indexOf('await self.initChapters(self.book')), src.indexOf('      // Export lifecycle begins after per-chapter filtering.',src.indexOf('await self.initChapters(self.book')));
const window = {};
const state = { now:1000, waits:[], calls:[], onSleep:null, timers:new Map(), nextTimer:1 };
class ClockDate extends Date { static now() { return state.now; } }
const sleep = async (ms) => { state.waits.push(ms); state.now += ms; if (state.onSleep) state.onSleep(ms); };
const ctx = vm.createContext({
  window, unsafeWindow:{}, document: {location:{hostname:'www.qidian.com'}}, console:log, Date:ClockDate,
  _main__WEBPACK_IMPORTED_MODULE_3__:{nW:status}, main:{nW:status,K5:class ExpectError extends Error{}},
  _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log, loglevel_default:()=>log,
  _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:sleep}, misc:{yy:sleep},
  setting:{Zz:{value:false},Nw:{value:false},Jv:{value:true}},
  progress:{vm:{updateRequestTime(){}, updateQidianTiming(){}, finishedChapterNumber:0}},
  setTimeout:(fn,ms)=>{const id=state.nextTimer++;state.timers.set(id,{fn,ms});return id;},clearTimeout:(id)=>state.timers.delete(id),alert(){},log:{M6(){}}, AbortController, GM_getValue: (key, fallback) => fallback,
});
vm.runInContext(globalHelpers + chapterSource + '\nclass Rule {' + schedulerSource + '}\nclass Save {' + addChapterSource + '}\nthis.Chapter=Chapter;this.Rule=Rule;this.Save=Save;this.validate=(self)=>{let qidianCompletionMessage;'+ finalValidation + 'return self.book.chapters;};',ctx);
function reset(){window.stopController=new AbortController();window.stopFlag=window.stopController.signal;window.failedCount=0;window.qidianPauseReason='';state.now=1000;ctx.Date=ClockDate;state.calls=[];state.waits=[];state.onSleep=null;state.timers.clear();}
// These cases audit VIP pacing; free HTML routing has separate v17 coverage.
function chapter(i, impl){return new ctx.Chapter({chapterName:`第${i}章`,chapterNumber:i,chapterUrl:`https://www.qidian.com/chapter/1/${i}`,isVIP:true,options:{expectedChars:2000},chapterParse:async (...args)=>{state.calls.push(i);return impl?impl(...args):{chapterName:`第${i}章`,contentText:'正文'.repeat(1000),contentHTML:{},contentImages:[]};}});}
function rule(){const r=new ctx.Rule();r.concurrencyLimit=1;r.sleepTime=8000;r.maxSleepTime=20000;return r;}
(async()=>{
  reset();
  const book={chapters:Array.from({length:100},(_,i)=>chapter(i+1,i===40?()=>{throw ctx.qidianPauseDownload('blocked');}:null))};
  try { await rule().initChapters(book,new ctx.Save()); } catch(e) { assert.match(e.message,/停止/); }
  assert.equal(state.calls.length,41); assert.equal(state.calls.filter(n=>n===41).length,1);
  assert.equal(ctx.validate({book}).length,40);assert(book.chapters.every(c=>c.status===status.saved));
  console.log('PASS actual Chapter/initChapters/save validation: 40 successes → blocked chapter 41 once → retain 40, no 42 request');
  const resetStart=src.indexOf('        window.stopController = new AbortController();',src.indexOf('class BaseRuleClass'));
  const resetEnd=src.indexOf('        qidianAccessMonitorDispose = qidianStartAccessMonitor();',resetStart);
  assert(resetStart >= 0 && resetEnd > resetStart);
  vm.runInContext(src.slice(resetStart,resetEnd),ctx);
  assert.equal(window.stopFlag.aborted,false); assert.equal(window.failedCount,0); assert.equal(ctx.unsafeWindow.stopController,window.stopController);
  const retryBook={chapters:[chapter(42)]}; state.calls=[];
  await rule().initChapters(retryBook,new ctx.Save());
  assert.deepEqual(state.calls,[42]);
  console.log('PASS actual run reset: same-page restart receives a new signal and chapter 42 succeeds');
  reset();state.onSleep=()=>window.stopController.abort();
  await rule().initChapters({chapters:[chapter(1)]},new ctx.Save());
  assert.deepEqual(state.calls,[]);
  console.log('PASS stop during scheduling sleep: no chapter request');
  reset();let failOnce=true;
  state.onSleep=()=>window.stopController.abort();
  const ch=chapter(1,()=>{if(failOnce){failOnce=false;throw ctx.qidianContentFailure('empty body');}return {chapterName:'第1章',contentText:'正文'.repeat(1000),contentHTML:{},contentImages:[]};});
  await ch.init();assert.deepEqual(state.calls,[1]);assert.deepEqual(state.waits,[1000]);assert.equal(ch.status,status.aborted);
  console.log('PASS actual Chapter.parse: 10s retry wait, abort during wait prevents retry');
  state.calls=[]; await chapter(2).init(); assert.deepEqual(state.calls,[]);
  console.log('PASS actual Chapter.parse: already aborted skips initial request');
  reset();let retryOnce=true;let observedClearedRetryTimer=false;state.onSleep=()=>{assert.equal(state.timers.size,0,'settled attempt timer must be cleared before retry sleep');observedClearedRetryTimer=true;};const ch2=chapter(3,()=>{if(retryOnce){retryOnce=false;throw ctx.qidianContentFailure('empty');}return {chapterName:'第3章',contentText:'正文'.repeat(1000),contentHTML:{},contentImages:[]};});
  await ch2.init(); assert.deepEqual(state.calls,[3,3]);
  const retryWaitMs=state.waits.reduce((total,ms)=>total+ms,0);
  assert(retryWaitMs>=5000 && retryWaitMs<=15000,'normal content retry uses the sampled 10s +/-5s cooldown');
  assert(state.waits.every(ms=>ms>0 && ms<=1000),'retry countdown remains cancellable');
  assert.equal(observedClearedRetryTimer,true);
  console.log('PASS Qidian normal retry uses 5-15s; settled timer cleared before retry sleep');
  const pageTimeout=()=>{const error=ctx.qidianContentFailure('起点章节页面超时');error.name='QidianPageTimeoutError';return error;};
  reset();let transientTimeout=true;
  const recovering=chapter(97,()=>{if(transientTimeout){transientTimeout=false;throw pageTimeout();}return {chapterName:'第97章',contentText:'正文'.repeat(1000),contentHTML:{},contentImages:[]};});
  await rule().initChapters({chapters:[recovering,chapter(98)]},new ctx.Save());
  assert.deepEqual(state.calls,[97,97,98]);
  assert(state.waits.reduce((total,ms)=>total+ms,0)>=85000,'timeout cooldown retains its 85s lower bound, then continues');
  assert(state.waits.every(ms=>ms<=1000),'timeout and scheduler waits stay cancellable');
  assert.equal(window.stopFlag.aborted,false);
  assert.equal(recovering.status,status.saved);
  console.log('PASS transient Qidian page timeout: 90s cooldown, retry same chapter, then continue next');
  reset();let virtualNow=1000;
  ctx.Date={now:()=>virtualNow};
  ctx.Math=Object.assign(Object.create(Math),{random:()=>0});
  state.onSleep=ms=>{virtualNow+=ms;};
  const slowerVIP=chapter(74,()=>{virtualNow+=7000;return {chapterName:'第74章',contentText:'正文'.repeat(1000),contentHTML:{},contentImages:[]};});
  await rule().initChapters({chapters:[slowerVIP,chapter(75)]},new ctx.Save());
  assert.deepEqual(state.calls,[74,75]);
  assert.deepEqual(state.waits,Array(13).fill(1000), '7s VIP work counts toward the 10s start-to-start gap; waits are cancellable');
  ctx.Date=ClockDate;delete ctx.Math;
  console.log('PASS Qidian pacing: request starts stay 10s apart while OCR time counts toward the gap');
  reset();const persistent=chapter(97,()=>{throw pageTimeout();});
  try{await rule().initChapters({chapters:[persistent,chapter(98)]},new ctx.Save());}catch(e){assert.match(e.message,/停止/);}
  assert.deepEqual(state.calls,[97,97,98,97,97,97,97]);
  assert.equal(window.stopFlag.aborted,false);
  assert.match(persistent.errorMessage,/已记录缺章/);
  assert.equal(persistent.status,status.failed);
  console.log('PASS isolated persistent Qidian page timeout: record missing and process the following chapter');
  reset();state.onSleep=()=>window.stopController.abort();
  await chapter(97,()=>{throw pageTimeout();}).init();
  assert.deepEqual(state.calls,[97]);
  assert.equal(window.stopFlag.aborted,true);
  console.log('PASS user stop during Qidian timeout cooldown: no additional chapter request');
  reset();ctx.document.location.hostname='example.com'; let otherRetry=true;const other=chapter(4,()=>{if(otherRetry){otherRetry=false;throw new Error('transient');}return {chapterName:'第4章',contentText:'正文',contentHTML:{},contentImages:[]};});
  await other.init();assert.deepEqual(state.calls,[4,4]);assert.deepEqual(state.waits,[1500]);
  console.log('PASS other-site retry remains 1500ms');
  reset();ctx.document.location.hostname='www.qidian.com';
  const timedOut=chapter(5,()=>new Promise(()=>{}));
  const timeoutRun=timedOut.init();for(let turn=0;turn<20&&!state.calls.length;turn++)await Promise.resolve();const timeoutEntry=[...state.timers.values()].find(t=>t.ms===600000);assert(timeoutEntry);timeoutEntry.fn();await timeoutRun;
  assert.deepEqual(state.calls,[5]);assert.deepEqual(state.waits,[]);assert.equal(window.stopFlag.aborted,false);assert.equal(timedOut.retryTime,1);assert.equal(timedOut.status,status.failed);assert.equal(timedOut.qidianFailureKind,'local');assert.equal(timedOut.qidianNoAutoRetry,true);assert.equal(window.qidianPauseReason,'');
  await chapter(6).init();assert.deepEqual(state.calls,[5,6]);
  console.log('PASS actual Chapter.parse 10min timeout: isolated failed chapter, no immediate retry, next chapter continues');
  reset();ctx.document.location.hostname='example.com';let firstTimeout=true;
  const otherTimeout=chapter(7,()=>{if(firstTimeout){firstTimeout=false;return new Promise(()=>{});}return {chapterName:'第7章',contentText:'正文',contentHTML:{},contentImages:[]};});
  const otherTimeoutRun=otherTimeout.init();[...state.timers.values()].find(t=>t.ms===600000).fn();await otherTimeoutRun;assert.deepEqual(state.calls,[7,7]);assert.deepEqual(state.waits,[1500]);assert.equal(window.stopFlag.aborted,false);
  console.log('PASS other-site timeout keeps existing retry behavior');
})().catch(e=>{console.error(e);process.exitCode=1;});
