/* Actual checkpoint helper regression suite; all GM storage is a local Map. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const candidate = process.env.QIDIAN_SCRIPT_PATH || path.join(__dirname, 'novel-downloader-qidian-range.user.js');
let source = fs.existsSync(candidate) ? fs.readFileSync(candidate, 'utf8') : '';
if (!source.includes('// Local TXT checkpoints.')) source = fs.readFileSync(path.join(__dirname, 'qidian-checkpoint-v20.js.txt'), 'utf8');
const start = source.indexOf('// Local TXT checkpoints.');
const end = source.indexOf('// End local TXT checkpoint helpers.', start);
assert(start >= 0 && end > start, 'checkpoint helper markers present');
const fragment = source.slice(start, end);
const baselineCandidates = [candidate, path.join(__dirname, 'work-v19/novel-downloader-qidian-range.user.js'), path.join(__dirname, '../work-v19/novel-downloader-qidian-range.user.js')];
const originalPath = baselineCandidates.find(file => fs.existsSync(file) && fs.readFileSync(file, 'utf8').includes('function qidianContentIsComplete('));
assert(originalPath, 'actual content validation source found');
const original = fs.readFileSync(originalPath, 'utf8');
const complete = original.slice(original.indexOf('function qidianContentIsComplete('), original.indexOf('function qidianContentFailure('));
function harness(options = {}) {
  const storage = options.storage || new Map();
  const events = [];
  const copy = value => value == null ? value : structuredClone(value);
  const context = vm.createContext({ URL, Map, Math, Date, Promise, setTimeout, clearTimeout,
    GM_getValue: (key, fallback) => copy(storage.has(key) ? storage.get(key) : fallback),
    GM_setValue: (key, value) => { storage.set(key, copy(value)); },
    GM_deleteValue: key => storage.delete(key), ...options.globals });
  vm.runInContext(complete + fragment, context);
  const logger = (event, data) => events.push({ event, ...data });
  return { context, storage, events, logger };
}
const bookId = '1048193111';
const text = '完整正文，包含汉字，保证基础检查通过。\n'.repeat(100);
function chapter(id = '889651857', title = '第1章 西点军校', extra = {}) {
  return { bookUrl: `https://www.qidian.com/book/${bookId}/`,
    chapterUrl: `https://www.qidian.com/chapter/${bookId}/${id}/`,
    chapterNumber: 2, chapterName: title, qidianCatalogTitle: title,
    isVIP: false, contentText: text, options: { expectedChars: 1800, _csrfToken: 'DO_NOT_PERSIST' }, ...extra };
}
function book(chapters = [chapter()]) {
  return { bookUrl: `https://www.qidian.com/book/${bookId}/?source=tracking`, bookname: '测试书', author: '作者:测试者', chapters };
}
function txtMeta(b) {
  return `题名：${b.bookname}\n作者：${b.author}\n原始网址：${b.bookUrl}\n本文件由小说下载器生成，软件地址：https://github.com/404-novel-project/novel-downloader\n\n`;
}
let passed = 0;
async function test(name, fn) { await fn(); passed++; }
(async () => {
  await test('independent durable chapter and alias restore', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    assert(await h.context.qidianCheckpointSave(s, b.chapters[0]));
    const next = await h.context.qidianCheckpointOpen(b, h.logger);
    const record = await h.context.qidianCheckpointRestore(next, chapter(undefined, undefined, { chapterUrl: `https://vipreader.qidian.com/chapter/${bookId}/889651857/?foo=1` }));
    assert.equal(record.text, text);
    assert.equal(record.source, 'live');
    assert.equal(next.stats.restored, 1);
    assert(!JSON.stringify([...h.storage]).includes('DO_NOT_PERSIST'));
    assert(!JSON.stringify(h.events).includes(text.slice(0, 50)));
  });
  await test('parallel different chapter writes preserved', async () => {
    const h = harness(); const b = book([chapter(), chapter('889651826', '第2章 第二章')]);
    const s = await h.context.qidianCheckpointOpen(b, h.logger);
    assert((await Promise.all(b.chapters.map(c => h.context.qidianCheckpointSave(s, c)))).every(Boolean));
    const next = await h.context.qidianCheckpointOpen(b, h.logger);
    assert((await Promise.all(b.chapters.map(c => h.context.qidianCheckpointRestore(next, c)))).every(Boolean));
    assert.equal(h.storage.size, 2);
  });
  await test('cross-tab different chapter writes preserved', async () => {
    const h = harness(); const b = book([chapter(), chapter('889651826', '第2章 第二章')]);
    const sessions = await Promise.all([0, 1].map(() => h.context.qidianCheckpointOpen(b, h.logger)));
    await Promise.all(sessions.map((s, i) => h.context.qidianCheckpointSave(s, b.chapters[i])));
    assert.equal(h.storage.size, 2);
  });
  await test('same numbered title different URLs preserved', async () => {
    const h = harness(); const b = book([chapter('101', '第182章 第一部分'), chapter('102', '第182章 第二部分')]);
    const s = await h.context.qidianCheckpointOpen(b, h.logger);
    await Promise.all(b.chapters.map(c => h.context.qidianCheckpointSave(s, c)));
    assert.equal(h.storage.size, 2);
  });
  await test('corrupt one chapter does not affect others', async () => {
    const h = harness(); const b = book([chapter('101'), chapter('102', '第2章 继续')]);
    const s = await h.context.qidianCheckpointOpen(b, h.logger);
    for (const c of b.chapters) await h.context.qidianCheckpointSave(s, c);
    const key = h.context.qidianCheckpointRecordKey(s, '101');
    h.storage.get(key).text += '坏';
    assert.equal(await h.context.qidianCheckpointRestore(s, b.chapters[0]), null);
    assert(await h.context.qidianCheckpointRestore(s, b.chapters[1]));
    assert(h.events.some(e => e.reason === 'body_digest_mismatch'));
  });
  await test('metadata and access changes reject cache', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    await h.context.qidianCheckpointSave(s, chapter());
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter(undefined, '第1章 修改标题')), null);
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter(undefined, undefined, { isVIP: true })), null);
    const differentBook = await h.context.qidianCheckpointOpen({ ...book(), author: '别的作者' }, h.logger);
    assert.equal(await h.context.qidianCheckpointRestore(differentBook, chapter()), null);
  });
  await test('expected metadata rechecked against current length', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    await h.context.qidianCheckpointSave(s, chapter());
    assert(await h.context.qidianCheckpointRestore(s, chapter(undefined, undefined, { options: { expectedChars: 1700 } })));
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter(undefined, undefined, { options: { expectedChars: 10000 } })), null);
  });
  await test('parsed h1 title does not overwrite catalog identity', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    await h.context.qidianCheckpointSave(s, chapter(undefined, undefined, { chapterName: '阅读页名称稍有变化' }));
    const restored = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(restored.parsedTitle, '阅读页名称稍有变化');
  });
  await test('empty and truncated body never persisted', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter(undefined, undefined, { contentText: '' })), false);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter(undefined, undefined, { contentText: '缺字' })), false);
    assert.equal(h.storage.size, 0);
  });
  await test('wrong chapter book URL or hashed ID rejected', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter(undefined, undefined, { chapterUrl: 'https://www.qidian.com/chapter/999/101/' })), false);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter(undefined, undefined, { chapterUrl: 'https://read.qidian.com/chapter/abc/def/' })), false);
    assert.equal(h.storage.size, 0);
  });
  await test('clear invalidates old session and record', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    await h.context.qidianCheckpointSave(s, chapter());
    assert(await h.context.qidianCheckpointClear(b, h.logger));
    assert.equal(await h.context.qidianCheckpointSave(s, chapter()), false);
    const fresh = await h.context.qidianCheckpointOpen(b, h.logger);
    assert.equal(await h.context.qidianCheckpointRestore(fresh, chapter()), null);
    assert(await h.context.qidianCheckpointSave(fresh, chapter()));
    assert(await h.context.qidianCheckpointRestore(fresh, chapter()));
  });
  await test('clear race cannot resurrect retired generation', async () => {
    let release; let started;
    const startPromise = new Promise(resolve => started = resolve);
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    h.context.GM_setValue = (key, value) => key.endsWith(':generation')
      ? h.storage.set(key, structuredClone(value)) : new Promise(resolve => {
        started(); release = () => { h.storage.set(key, structuredClone(value)); resolve(); };
      });
    const pending = h.context.qidianCheckpointSave(s, chapter());
    await startPromise;
    await h.context.qidianCheckpointClear(b, h.logger);
    release();
    assert.equal(await pending, false);
    const fresh = await h.context.qidianCheckpointOpen(b, h.logger);
    assert.equal(await h.context.qidianCheckpointRestore(fresh, chapter()), null);
  });
  await test('storage errors stay local, next chapter still saves', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    let first = true;
    h.context.GM_setValue = (key, value) => {
      if (first) { first = false; const e = new Error('quota'); e.name = 'TransientStorageError'; throw e; }
      h.storage.set(key, structuredClone(value));
    };
    assert.equal(await h.context.qidianCheckpointSave(s, chapter('101')), false);
    assert(await h.context.qidianCheckpointSave(s, chapter('102')));
    assert.equal(s.stats.writeFailed, 1);
  });
  await test('hung storage timeout stays local', async () => {
    const h = harness({ globals: { setTimeout: callback => setTimeout(callback, 5) } });
    const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    h.context.GM_setValue = () => new Promise(() => {});
    assert.equal(await h.context.qidianCheckpointSave(s, chapter()), false);
    assert(h.events.some(e => e.errorName === 'QidianCheckpointStorageTimeout'));
    assert.equal(s.writeDisabled, true);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter('102')), false);
    assert.equal(s.stats.writeFailed, 1);
  });
  await test('per-chapter and session memory budget respected', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter(undefined, undefined, { contentText: '汉'.repeat(300000) })), false);
    s.usedBytes = 20 * 1024 * 1024;
    assert.equal(await h.context.qidianCheckpointSave(s, chapter()), false);
    assert.equal(h.storage.size, 0);
  });
  await test('promise GM modern API supported', async () => {
    const data = new Map(); const h = harness({ globals: { GM_getValue: undefined, GM_setValue: undefined, GM_deleteValue: undefined,
      GM: { getValue: async (k, d) => data.get(k) ?? d, setValue: async (k, v) => data.set(k, structuredClone(v)), deleteValue: async k => data.delete(k) } } });
    const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert(await h.context.qidianCheckpointSave(s, chapter()));
    assert(await h.context.qidianCheckpointRestore(s, chapter()));
  });
  await test('default TXT original titles imported', async () => {
    const h = harness(); const b = book([chapter('101'), chapter('102', '第2章 重返')]);
    const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const input = txtMeta(b) + b.chapters.map(c => `${'…'.repeat(30)}\n${c.chapterName}\n\n${text}\n\n`).join('\n') +
      '\n===== 未写入章节（含尚未处理的章节）=====\n第3章 尚缺：错误';
    const result = await h.context.qidianCheckpointImportTxt(s, b, input);
    assert.equal(result.imported, 2);
    assert.equal((await h.context.qidianCheckpointRestore(s, b.chapters[1])).text, text.trim());
  });
  await test('catalog position prefix stripped by exact title match', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const result = await h.context.qidianCheckpointImportTxt(s, b, txtMeta(b) + `${'…'.repeat(30)}\n第2章 ${chapter().chapterName}\n\n${text}\n`);
    assert.equal(result.imported, 1);
  });
  await test('custom txt_space format and CRLF BOM import', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const input = '\uFEFF' + (txtMeta(b) + `## ${chapter().chapterName}\n\n${text}\n`).replace(/\n/g, '\r\n');
    assert.equal((await h.context.qidianCheckpointImportTxt(s, b, input)).imported, 1);
  });
  await test('wrong book metadata and unsupported format rejected', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const input = txtMeta({ ...b, bookUrl: 'https://www.qidian.com/book/999/' }) + `${'…'.repeat(30)}\n${chapter().chapterName}\n\n${text}`;
    assert.equal((await h.context.qidianCheckpointImportTxt(s, b, input)).reason, 'txt_book_metadata_mismatch');
    assert.equal((await h.context.qidianCheckpointImportTxt(s, b, txtMeta(b) + chapter().chapterName + '\n' + text)).imported, 0);
  });
  await test('duplicate exact title cannot guess chapter URL', async () => {
    const h = harness(); const b = book([chapter('101'), chapter('102')]); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const result = await h.context.qidianCheckpointImportTxt(s, b, txtMeta(b) + `${'…'.repeat(30)}\n${chapter().chapterName}\n\n${text}`);
    assert.equal(result.imported, 0); assert.equal(result.ambiguous, 1);
  });
  await test('duplicate header cannot import mistaken text split', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const unit = `${'…'.repeat(30)}\n${chapter().chapterName}\n\n${text}`;
    const result = await h.context.qidianCheckpointImportTxt(s, b, txtMeta(b) + unit + '\n' + unit);
    assert.equal(result.imported, 0); assert.equal(result.ambiguous, 2);
  });
  await test('unknown following chapter never merged into known body', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const input = txtMeta(b) + `${'…'.repeat(30)}\n${chapter().chapterName}\n\n过短\n\n${'…'.repeat(30)}\n第999章 不在范围\n\n${text}`;
    const result = await h.context.qidianCheckpointImportTxt(s, b, input);
    assert.equal(result.imported, 0); assert.equal(result.incomplete, 1);
  });
  await test('generated section wrapper excluded while author note preserved', async () => {
    const h = harness(); const b = book([chapter('101'), chapter('102', '第2章 重返')]); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const noteBody = text + '\n----------\n作者留言。';
    const input = txtMeta(b) + `${'…'.repeat(30)}\n${chapter().chapterName}\n\n${noteBody}\n\n\n${'…'.repeat(20)}\n\n\n\n# 第二卷\n\n\n\n${'…'.repeat(20)}\n\n\n${'…'.repeat(30)}\n第2章 重返\n\n${text}`;
    const result = await h.context.qidianCheckpointImportTxt(s, b, input);
    assert.equal(result.imported, 2);
    const record = await h.context.qidianCheckpointRestore(s, b.chapters[0]);
    assert.equal(record.text, noteBody.trim());
    assert.equal(record.source, 'txt-import');
  });
  await test('quota disables writes but still reads existing checkpoints', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    await h.context.qidianCheckpointSave(s, chapter());
    h.context.GM_setValue = () => { const e = new Error('quota'); e.name = 'QuotaExceededError'; throw e; };
    assert.equal(await h.context.qidianCheckpointSave(s, chapter('101')), false);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter('102')), false);
    assert.equal(s.stats.writeFailed, 1);
    assert.equal(s.disabled, false);
    assert(await h.context.qidianCheckpointRestore(s, chapter()));
  });
  await test('restore timeout disables further reads in current session', async () => {
    const h = harness({ globals: { setTimeout: callback => setTimeout(callback, 5) } });
    const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    h.context.GM_getValue = () => new Promise(() => {});
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    assert.equal(s.disabled, true);
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter('102')), null);
    assert.equal(s.stats.rejected, 1);
  });
  await test('title with numeric second line imports original body boundary', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const result = await h.context.qidianCheckpointImportTxt(s, b, txtMeta(b) + `${'…'.repeat(30)}\n第2章 ${chapter().chapterName}\n23\n\n${text}`);
    assert.equal(result.imported, 1);
    assert((await h.context.qidianCheckpointRestore(s, chapter())).text.startsWith('23\n\n'));
  });
  console.log(`Qidian checkpoint helpers: ${passed}/${passed} passed`);
})().catch(error => { console.error(error); process.exitCode = 1; });
