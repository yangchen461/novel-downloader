// Shipped TXT export/import and in-memory checkpoint tests for retained short bodies.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'test-qidian-v34-glyph-tolerance.cjs'), 'utf8');
const end = source.search(/^const tests\s*=\s*\[\];/m);
assert(end > 0);
const { fixture } = vm.runInNewContext(source.slice(0, end) + '\n({fixture});',
  { require, __dirname, AbortController, URL, console, structuredClone, Blob, setTimeout, clearTimeout });
const LENGTH_LIST = '\n===== 字数待核验章节（已保留读取正文）=====\n';
const LENGTH_FOOTER = '\n===== 起点下载器字数待核验续传记录 v1 =====\n';
const GLYPH_LIST = '\n===== OCR占位章节（正文已保留）=====\n';
const GLYPH_FOOTER = '\n===== 起点下载器OCR占位续传记录 v2 =====\n';
const EMPTY_AUTHOR = '\n\n----------\n\n';
const tests = [];
const test = (name, run) => tests.push({ name, run });

async function exported({ glyph = false, tail = EMPTY_AUTHOR, body: givenBody } = {}) {
  const glyphCount = glyph === true ? 1 : Number(glyph);
  const f = fixture({ missing: glyphCount || 1 }), result = await f.ocr(), chapter = f.chapter(result);
  const body = givenBody ?? '正'.repeat(500) + '□'.repeat(glyphCount);
  const glyphMetadata = glyph ? structuredClone(result.qidianGlyphTolerance) : null;
  if (glyphMetadata) {
    const positions = Array.from(body.matchAll(/□/g), match => match.index);
    glyphMetadata.glyphs.forEach((item, index) => { item.positions = [positions[index]]; });
    glyphMetadata.bodyDigest = f.ctx.qidianCheckpointDigest(body);
  }
  const lengthMetadata = f.ctx.qidianCreateLengthWarning(body, 2000, true, glyphMetadata);
  assert(lengthMetadata);
  chapter.contentText = body + tail;
  chapter.options = { expectedChars: 2000, qidianBodyLength: body.length,
    qidianGlyphTolerance: glyphMetadata, qidianLengthWarning: lengthMetadata };
  f.export([chapter]);
  assert.equal(f.outputs.length, 1);
  return { f, chapter, body, lengthMetadata, glyphMetadata,
    output: (await f.outputs[0].blob.text()).replace(/\r\n?/g, '\n') };
}
async function imported(sample, input = sample.output, options = {}, existing = null) {
  const f = fixture({ missing: 0 });
  const chapter = { ...sample.chapter, contentText: null,
    options: { expectedChars: 2000, ...options } };
  f.book.chapters = [chapter];
  const session = await f.session();
  if (existing) assert.equal(await f.ctx.qidianCheckpointSave(session, existing), true);
  const result = await f.ctx.qidianCheckpointImportTxt(session, f.book, input);
  const record = await f.ctx.qidianCheckpointRestore(session, chapter);
  return { f, chapter, session, result, record };
}
function footerBounds(input, marker) {
  const start = input.lastIndexOf(marker);
  assert(start >= 0);
  const linesStart = start + marker.length;
  const following = [LENGTH_LIST, LENGTH_FOOTER, GLYPH_LIST, GLYPH_FOOTER]
    .map(next => input.indexOf(next, linesStart)).filter(index => index >= 0);
  return { start, linesStart, end: following.length ? Math.min(...following) : input.length };
}
function changeFooter(input, marker, mutate) {
  const { linesStart, end } = footerBounds(input, marker);
  const rows = input.slice(linesStart, end).trim().split('\n').map(line => JSON.parse(line));
  mutate(rows);
  return input.slice(0, linesStart) + rows.map(row => JSON.stringify(row)).join('\n') + '\n' + input.slice(end);
}
function rejected(value, reason) {
  assert.equal(value.result.imported, 0);
  assert.equal(value.record, null);
  if (reason) assert.equal(value.result.reason, reason);
  else { assert.equal(value.result.skipped, 1); assert.equal(value.result.incomplete, 1); }
}
function restoredQuality(value) {
  return value.f.ctx.qidianChapterContentCheck({ ...value.chapter, contentText: value.record.text,
    options: { ...value.chapter.options, qidianBodyLength: value.record.bodyLength,
      qidianGlyphTolerance: value.record.qidianGlyphTolerance, qidianLengthWarning: value.record.qidianLengthWarning } });
}
function priorChapter(sample, body, glyphMetadata = null) {
  return { ...sample.chapter, contentText: body, options: { expectedChars: 2000,
    qidianBodyLength: body.length, qidianGlyphTolerance: glyphMetadata,
    qidianLengthWarning: sample.f.ctx.qidianCreateLengthWarning(body, 2000, true, glyphMetadata) } };
}

test('short-body-only TXT round-trips with marked uncertainty and preserves empty or non-empty author text', async () => {
  for (const tail of ['', EMPTY_AUTHOR, EMPTY_AUTHOR + '测试作者留言']) {
    const sample = await exported({ tail }), value = await imported(sample);
    assert.match(sample.f.outputs[0].name, /字数待核验_1章/);
    assert.equal(value.result.imported, 1);
    assert.equal(value.record.text, sample.chapter.contentText.trim());
    assert.equal(value.record.bodyLength, sample.body.length);
    assert.equal(value.record.bodyBoundarySource, 'explicit');
    assert.equal(value.record.qidianLengthWarning.bodyDigest, sample.lengthMetadata.bodyDigest);
    assert.equal(restoredQuality(value).complete, false);
    assert.equal(restoredQuality(value).exportable, true);
    assert.equal(restoredQuality(value).lengthUncertain, true);
  }
});

test('length and glyph warnings coexist in actual exported order and their footer sections remain separate', async () => {
  const sample = await exported({ glyph: true }), value = await imported(sample);
  assert(sample.output.indexOf(sample.f.ctx.qidianLengthWarningText(sample.lengthMetadata)) <
    sample.output.indexOf(sample.f.ctx.qidianGlyphToleranceWarning(sample.glyphMetadata)));
  assert(sample.output.indexOf(LENGTH_FOOTER) < sample.output.indexOf(GLYPH_LIST));
  assert(sample.output.indexOf(GLYPH_LIST) < sample.output.indexOf(GLYPH_FOOTER));
  assert.equal(value.result.imported, 1);
  assert.equal(value.record.text, sample.chapter.contentText.trim());
  assert.equal(value.record.bodyLength, sample.body.length);
  assert.equal(value.record.qidianGlyphTolerance.occurrenceCount, 1);
  assert.equal(value.record.qidianLengthWarning.bodyDigest, value.record.qidianGlyphTolerance.bodyDigest);
  assert.equal(restoredQuality(value).exportable, true);
  assert.equal(restoredQuality(value).complete, false);
});

test('metadata preserves genuine embedded story dividers without counting trailing author notes', async () => {
  const sample = await exported({ glyph: true, body: '正'.repeat(250) + EMPTY_AUTHOR + '正'.repeat(250) + '□',
    tail: EMPTY_AUTHOR + '测试作者留言'.repeat(500) });
  const value = await imported(sample);
  assert.equal(value.result.imported, 1);
  assert.equal(value.record.text, sample.chapter.contentText.trim());
  assert.equal(value.record.bodyLength, sample.body.length);
  assert.equal(value.record.qidianLengthWarning.actualChars, sample.lengthMetadata.actualChars);
  assert.equal(restoredQuality(value).complete, false);
});

test('a visible length warning or inherited chapter options cannot replace missing footer metadata', async () => {
  const sample = await exported();
  rejected(await imported(sample, sample.output.slice(0, sample.output.indexOf(LENGTH_FOOTER))));
  const withoutWarnings = sample.output.slice(0, sample.output.indexOf(LENGTH_LIST))
    .replace(sample.f.ctx.qidianLengthWarningText(sample.lengthMetadata) + '\n', '');
  rejected(await imported(sample, withoutWarnings, { qidianLengthWarning: sample.lengthMetadata }));
});

test('length footer rejects duplicate sections, duplicate records, wrong chapter identity and malformed JSON', async () => {
  const sample = await exported({ glyph: true });
  const { start, end } = footerBounds(sample.output, LENGTH_FOOTER);
  const section = sample.output.slice(start, end);
  const invalidInputs = [
    sample.output + section,
    changeFooter(sample.output, LENGTH_FOOTER, rows => rows.push(structuredClone(rows[0]))),
    changeFooter(sample.output, LENGTH_FOOTER, rows => { rows[0].chapterUrl = 'https://www.qidian.com/chapter/124/456/'; }),
    changeFooter(sample.output, LENGTH_FOOTER, rows => { rows[0].catalogTitle = '第9章 不匹配'; }),
    sample.output.slice(0, start + LENGTH_FOOTER.length) + '{broken JSON}\n' + sample.output.slice(end)
  ];
  for (const input of invalidInputs) rejected(await imported(sample, input), 'txt_length_metadata_invalid');
});

test('length warning text, every metadata value and the current catalogue expectation must agree', async () => {
  const sample = await exported();
  rejected(await imported(sample, sample.output.replace('保留网页实际读取的 500 字', '保留网页实际读取的 501 字')));
  for (const key of ['schema', 'reason', 'expectedChars', 'actualChars', 'minimumChars', 'bodyDigest']) {
    const input = changeFooter(sample.output, LENGTH_FOOTER, rows => {
      const value = rows[0].qidianLengthWarning[key];
      rows[0].qidianLengthWarning[key] = typeof value === 'number' ? value + 1 : value + 'X';
    });
    rejected(await imported(sample, input));
  }
  rejected(await imported(sample, sample.output, { expectedChars: 2001 }));
});

test('both footer types must validate the same checked body and exact glyph warning', async () => {
  const sample = await exported({ glyph: true });
  for (const mutate of [
    rows => { rows[0].qidianGlyphTolerance.bodyDigest = sample.f.ctx.qidianCheckpointDigest(sample.body + '正'); },
    rows => { rows[0].qidianGlyphTolerance.glyphs[0].positions[0]--; },
    rows => { rows[0].qidianGlyphTolerance.occurrenceCount++; }
  ]) rejected(await imported(sample, changeFooter(sample.output, GLYPH_FOOTER, mutate)));
  rejected(await imported(sample, sample.output.replace('共 1 处', '共 2 处')));
});

test('footer-bound length recovery still rejects PUA, replacement text and bodies below structural minimum', async () => {
  const sample = await exported();
  for (const body of ['正'.repeat(500) + '\uE001', '正'.repeat(500) + '\uFFFD', '正'.repeat(10)]) {
    const metadata = { ...sample.lengthMetadata, actualChars: body.length,
      bodyDigest: sample.f.ctx.qidianCheckpointDigest(body) };
    let input = sample.output.replace(sample.body, body)
      .replace(sample.f.ctx.qidianLengthWarningText(sample.lengthMetadata), sample.f.ctx.qidianLengthWarningText(metadata));
    input = changeFooter(input, LENGTH_FOOTER, rows => { rows[0].qidianLengthWarning = metadata; });
    rejected(await imported(sample, input));
  }
});

test('explicit prefix recovery rejects unrecognized suffixes while preserving the full input text', async () => {
  for (const tail of ['\n----------', '\n\n-----------', '\n\n----------X', '\n\n测试正文残留']) {
    rejected(await imported(await exported({ tail })));
  }
});

test('JSON footer parsing stops at the next known section even when footer sections are reordered', async () => {
  const sample = await exported({ glyph: true });
  const lengthStart = sample.output.indexOf(LENGTH_LIST), glyphStart = sample.output.indexOf(GLYPH_LIST);
  const reordered = sample.output.slice(0, lengthStart) + sample.output.slice(glyphStart) +
    sample.output.slice(lengthStart, glyphStart);
  const value = await imported(sample, reordered);
  assert.equal(value.result.imported, 1);
  assert.equal(value.record.bodyLength, sample.body.length);
  assert(value.record.qidianGlyphTolerance); assert(value.record.qidianLengthWarning);
});

test('the authorized 50-percent boundary imports ordinary complete TXT while one character less remains marked', async () => {
  const sample = await exported({ body: '正'.repeat(999), tail: '' });
  const marked = await imported(sample);
  assert.equal(marked.result.imported, 1);
  assert.equal(restoredQuality(marked).complete, false);
  assert.equal(marked.record.qidianLengthWarning.minimumChars, 1000);
  const f = fixture({ missing: 0 }), chapter = { ...sample.chapter, contentText: '正'.repeat(1000),
    options: { expectedChars: 2000, qidianBodyLength: 1000, qidianLengthWarning: null, qidianGlyphTolerance: null } };
  assert.equal(f.ctx.qidianChapterContentCheck(chapter).complete, true);
  f.export([chapter]);
  const ordinary = await imported(sample, await f.outputs[0].blob.text());
  assert.equal(ordinary.result.imported, 1);
  assert.equal(restoredQuality(ordinary).complete, true);
  assert.equal(ordinary.record.qidianLengthWarning, null);
});

test('importing an older short TXT retains existing strict or longer retained text without a new write', async () => {
  const sample = await exported();
  for (const body of ['甲'.repeat(1500), '乙'.repeat(800)]) {
    const previous = priorChapter(sample, body);
    const value = await imported(sample, sample.output,
      { qidianBodyLength: 1, qidianGlyphTolerance: sample.glyphMetadata, qidianLengthWarning: sample.lengthMetadata }, previous);
    assert.equal(value.result.imported, 1); assert.equal(value.result.retainedExisting, 1);
    assert.equal(value.result.skipped, 0); assert.equal(value.result.incomplete, 0);
    assert.equal(value.record.text, body); assert.equal(value.record.bodyLength, body.length);
    assert.equal(value.session.stats.written, 1);
    assert.equal(restoredQuality(value).complete, body.length >= 1000);
  }
});

test('a shorter complete TXT cannot replace a longer complete checkpoint even with fewer glyphs', async () => {
  const sample = await exported({ glyph: true });
  const priorBody = '甲'.repeat(1499) + '□';
  const metadata = structuredClone(sample.glyphMetadata);
  metadata.glyphs[0].positions = [1499]; metadata.bodyDigest = sample.f.ctx.qidianCheckpointDigest(priorBody);
  const previous = priorChapter(sample, priorBody, metadata);
  const exporter = fixture({ missing: 0 });
  exporter.export([{ ...sample.chapter, contentText: '乙'.repeat(1000), options: { expectedChars: 2000,
    qidianBodyLength: 1000, qidianGlyphTolerance: null, qidianLengthWarning: null } }]);
  const value = await imported(sample, await exporter.outputs[0].blob.text(), {}, previous);
  assert.equal(value.result.imported, 1); assert.equal(value.result.retainedExisting, 1);
  assert.equal(value.record.text, priorBody); assert.equal(value.record.qidianGlyphTolerance.distinctCount, 1);
  assert.equal(value.session.stats.written, 1);
});

test('an older equal-length TXT with more unresolved glyphs retains the better existing checkpoint', async () => {
  const sample = await exported({ glyph: 2, tail: '' });
  const body = '甲'.repeat(501) + '□', metadata = structuredClone(sample.glyphMetadata);
  metadata.distinctCount = 1; metadata.occurrenceCount = 1;
  metadata.glyphs = [{ ...metadata.glyphs[0], positions: [501] }];
  metadata.bodyDigest = sample.f.ctx.qidianCheckpointDigest(body);
  const value = await imported(sample, sample.output, {}, priorChapter(sample, body, metadata));
  assert.equal(value.result.imported, 1); assert.equal(value.result.retainedExisting, 1);
  assert.equal(value.record.text, body); assert.equal(value.record.qidianGlyphTolerance.distinctCount, 1);
  assert.equal(value.record.qidianGlyphTolerance.occurrenceCount, 1);
  assert.equal(value.session.stats.written, 1);
});

test('empty storage imports normally and equal-quality equal-length TXT retains normal replacement behavior', async () => {
  const sample = await exported({ tail: '' }), fresh = await imported(sample);
  assert.equal(fresh.result.imported, 1); assert.equal(fresh.result.retainedExisting, 0);
  assert.equal(fresh.session.stats.written, 1);
  const value = await imported(sample, sample.output, {}, priorChapter(sample, '甲'.repeat(500)));
  assert.equal(value.result.imported, 1); assert.equal(value.result.retainedExisting, 0);
  assert.equal(value.record.text, sample.body); assert.equal(value.session.stats.written, 2);
});

test('an invalid existing checkpoint does not block saving a valid imported candidate', async () => {
  const sample = await exported(), value = await imported(sample);
  for (const [key, record] of value.f.storage) if (record?.chapterId === '456') {
    value.f.storage.set(key, { ...record, digest: 'invalid-existing-digest' });
  }
  assert.equal(await value.f.ctx.qidianCheckpointRestore(value.session, value.chapter), null);
  const result = await value.f.ctx.qidianCheckpointImportTxt(value.session, value.f.book, sample.output);
  assert.equal(result.imported, 1); assert.equal(result.retainedExisting, 0); assert.equal(result.storageFailed, 0);
  assert.equal((await value.f.ctx.qidianCheckpointRestore(value.session, value.chapter)).text, sample.chapter.contentText.trim());
  assert.equal(value.session.stats.written, 2);
});

(async () => {
  let passed = 0;
  for (const entry of tests) {
    try { await entry.run(); passed++; console.log('PASS ' + entry.name); }
    catch (error) { console.error('FAIL ' + entry.name); console.error(error); process.exitCode = 1; }
  }
  console.log(`${passed}/${tests.length} length-warning TXT import checks passed`);
})();
