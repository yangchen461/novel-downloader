// Shipped OCR, body validation, checkpoint and TXT round-trip checks. No network.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(start, end, from = 0) {
  const a = source.indexOf(start, from), b = source.indexOf(end, a);
  assert(a >= 0 && b > a, start);
  return source.slice(a, b);
}
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const ocrCode = take('async function ocrContent(', 'async function buildFontDecodeMap(');
const txtCode = take('class TXT extends Options', ';// ./src/save/raw.ts');
const parserCode = take('  async chapterParse(', '\n}\n\n\n/***/', source.indexOf('class Qidian extends'));
const log = { info() {}, warn() {}, error() {}, trace() {}, debug() {} };
function node() { return { style: {}, children: [], appendChild(child) { this.children.push(child); return child; }, textContent: '' }; }
class Options {
  genMetaDateTxt(book) { return `题名：${book.bookname}\n作者：${book.author}\n原始网址：${book.bookUrl}\n本文件由小说下载器生成，软件地址：https://github.com/404-novel-project/novel-downloader\n`; }
  getchapterName(chapter) { return chapter.chapterName; }
  genChapterText(name, text) { return '…'.repeat(30) + '\n' + name + '\n\n' + text + '\n'; }
  genSectionText() { return ''; }
  chapterSort(a, b) { return a.chapterNumber - b.chapterNumber; }
}
function fixture({ texts, missing = 1, repeats = 1, finished = true, buildError = false, mode } = {}) {
  const storage = new Map(), outputs = [], decoderMap = new Map([['甲', '正'], ['𠀀', '文']]);
  decoderMap.qidianLocalRecoveryFinished = finished;
  if (buildError) decoderMap.qidianBuildError = new Error('synthetic engine failure');
  const unknown = Array.from({ length: missing }, (_, index) => String.fromCodePoint(0xE001 + index));
  texts ??= ['甲'.repeat(2000) + unknown.join('').repeat(repeats)];
  const paragraphs = texts.map(text => ({ text }));
  const window = { stopController: new AbortController(), qidianTxtOnly: true };
  window.stopFlag = window.stopController.signal;
  const document = { location: { hostname: 'www.qidian.com' }, createElement: node };
  const ctx = vm.createContext({ window, document, URL, Date, Math, Map, Set, Promise, Blob, Options,
    AbortController, setTimeout, clearTimeout, structuredClone,
    GM_getValue: (key, fallback) => structuredClone(storage.get(key) ?? fallback),
    GM_setValue: (key, value) => storage.set(key, structuredClone(value)),
    GM_deleteValue: key => storage.delete(key),
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => log, loglevel_default: () => log,
    collectPseudoContentRules: () => [], extractRenderedText: paragraph => paragraph.text,
    buildFontDecodeMap: async () => decoderMap, qidianGlyphCache: new Map([['123:456', '正']]),
    FileSaver_min: { saveAs: (blob, name) => outputs.push({ blob, name }) }, setting: { Nw: { value: true } }
  });
  vm.runInContext(globals + ocrCode + txtCode + '\nthis.TXT=TXT;', ctx);
  const ownerDoc = { defaultView: { document: {}, getComputedStyle: () => ({ fontFamily: 'test-custom-font' }) } };
  const content = { ownerDocument: ownerDoc, querySelectorAll: () => paragraphs };
  const options = { expectedChars: 2000, ...(mode ? { qidianGlyphToleranceMode: mode } : {}) };
  const book = { bookUrl: 'https://www.qidian.com/book/123/', bookname: '测试书', author: '测试作者', chapters: [] };
  const chapter = result => ({
    chapterUrl: 'https://www.qidian.com/chapter/123/456/', chapterName: '第1章 测试', chapterNumber: 1,
    qidianCatalogTitle: '第1章 测试', isVIP: true, status: 5,
    contentText: result.contentText, contentHTML: result.contentHTML,
    options: { ...options, qidianBodyLength: result.contentText.length, qidianGlyphTolerance: result.qidianGlyphTolerance }
  });
  return { ctx, window, storage, outputs, content, options, decoderMap, unknown, book, chapter,
    ocr: () => ctx.ocrContent(content, options),
    async session() { return ctx.qidianCheckpointOpen(book, () => {}); },
    export(chapters) { book.chapters = chapters; book.downloadReport = { selectedCount: chapters.length, savedCount: chapters.length, missing: [] }; new ctx.TXT(book).saveTxt(); }
  };
}
const tests = [];
const test = (name, run) => tests.push({ name, run });

// Real typed DOM structure and production rendered-text walker: these fixtures
// vary the page scope, visibility and CSS ordering instead of replacing OCR's
// chapter extraction with a preselected text string.
function scopedFixture(tree) {
  const f = fixture({ missing: 0 });
  const ownerDoc = { styleSheets: [] };
  ownerDoc.defaultView = { document: ownerDoc, getComputedStyle(element, pseudo) {
    return { display: 'block', visibility: 'visible', opacity: '1', order: '0', fontFamily: 'test-custom-font', content: 'none',
      ...(pseudo ? element.pseudo?.[pseudo] : element.css) };
  } };
  function text(value) { return { nodeType: 3, textContent: value }; }
  function element(tag, attrs = {}, children = [], css = {}, pseudo = {}) {
    const result = { nodeType: 1, nodeName: tag.toUpperCase(), tagName: tag.toUpperCase(),
      childNodes: children, ownerDocument: ownerDoc, css, pseudo,
      getAttribute: key => attrs[key] ?? null, hasAttribute: key => Object.hasOwn(attrs, key),
      matches(selector) { return selector.startsWith('.') ? String(attrs.class ?? '').split(/\s+/).includes(selector.slice(1)) : selector.toUpperCase() === this.tagName; },
      querySelectorAll(selector) {
        const found = [];
        const visit = node => { for (const child of node.childNodes ?? []) { if (child.nodeType === 1 && child.matches(selector)) found.push(child); visit(child); } };
        visit(this); return found;
      } };
    for (const child of children) child.parentNode = child.parentElement = result;
    return result;
  }
  const main = tree({ element, text });
  f.ctx.Node = { TEXT_NODE: 3, ELEMENT_NODE: 1 };
  vm.runInContext(take('function extractRenderedText(', 'function canvasToUint8Array('), f.ctx);
  return { ...f, main, ocr: () => f.ctx.ocrContent(main, f.options) };
}

test('OCR scopes a single visible body and prevents outside, author, navigation and hidden prose from padding a short chapter', async () => {
  const f = scopedFixture(({ element: e, text: t }) => e('main', {}, [
    e('p', {}, [t('甲'.repeat(2000))]),
    e('div', { class: 'content-text' }, [
      e('p', {}, [t('甲'.repeat(30)), e('span', { class: 'review' }, [t('甲'.repeat(2000))])]),
      e('div', { id: 'r-authorSay' }, [e('p', {}, [t('甲'.repeat(2000))])]),
      e('nav', {}, [e('p', {}, [t('甲'.repeat(2000))])]),
      e('div', {}, [e('p', {}, [t('甲'.repeat(2000))])], { display: 'none' }),
      e('p', { 'aria-hidden': 'true' }, [t('甲'.repeat(2000))])
    ])
  ]));
  const result = await f.ocr();
  assert.equal(result.contentText, '正'.repeat(30));
  assert.equal(f.ctx.qidianContentIsComplete(result.contentText, 2000, true), false);
  assert.equal(f.ctx.qidianSelectOcrParagraphs(f.main, f.main.ownerDocument.defaultView).paragraphs.length, 1);
});

test('scoped OCR preserves paragraph sequence and the production pseudo/flex order while excluding nested controls', async () => {
  const f = scopedFixture(({ element: e, text: t }) => e('main', {}, [e('div', { class: 'content-text' }, [
    e('p', {}, [e('span', {}, [t('甲')], { order: '2' }), e('nav', {}, [t('甲'.repeat(100))]), e('span', {}, [t('乙')], { order: '1' })],
      { display: 'flex' }, { '::before': { content: '"丙"' }, '::after': { content: '"丁"' } }),
    e('p', {}, [t('甲')])
  ])]));
  f.decoderMap.set('乙', '中'); f.decoderMap.set('丙', '前'); f.decoderMap.set('丁', '后');
  assert.equal((await f.ocr()).contentText, '前中正后\n正');
});

test('scoped OCR rejects multiple visible body roots and a hidden body, and permits a clean main fallback', async () => {
  for (const kind of ['ambiguous', 'hidden']) {
    const f = scopedFixture(({ element: e, text: t }) => e('main', {}, kind === 'ambiguous'
      ? [e('div', { class: 'content-text' }, [e('p', {}, [t('甲')])]), e('div', { class: 'content-text' }, [e('p', {}, [t('甲')])])]
      : [e('div', { class: 'content-text', hidden: '' }, [e('p', {}, [t('甲')])])]));
    let mapCalls = 0; f.ctx.buildFontDecodeMap = async () => { mapCalls++; return f.decoderMap; };
    assert.equal(await f.ocr(), null); assert.equal(mapCalls, 0);
  }
  const fallback = scopedFixture(({ element: e, text: t }) => e('main', {}, [
    e('p', {}, [t('甲'.repeat(2000))]), e('aside', {}, [e('p', {}, [t('乙'.repeat(3000))])])
  ]));
  assert.equal((await fallback.ocr()).contentText, '正'.repeat(2000));
});

test('54 paragraph .content-text spans form one ordered OCR body including their rendered CSS text', async () => {
  const f = scopedFixture(({ element: e, text: t }) => e('main', {}, [
    ...Array.from({ length: 54 }, (_, index) => e('p', {}, [
      e('span', { class: 'content-text' }, [t('甲'.repeat(80))], { fontFamily: 'ABCDEFGH, serif' },
        { '::before': { content: '"乙"' }, '::after': { content: '"丁"' } }),
      e('span', { class: 'review' }, [t('丙'.repeat(200))])
    ])),
    e('p', { class: 'authorSay' }, [t('丙'.repeat(5000))]),
    e('nav', {}, [e('p', {}, [e('span', { class: 'content-text' }, [t('丙'.repeat(5000))])])])
  ], { fontFamily: 'serif' }));
  f.decoderMap.set('乙', '中'); f.decoderMap.set('丁', '后');
  let mapCalls = 0;
  f.ctx.buildFontDecodeMap = async (_doc, _win, fontFamily, chars, paragraphTexts) => {
    mapCalls++;
    assert.equal(fontFamily, 'ABCDEFGH, serif');
    assert.equal(paragraphTexts.length, 54);
    assert.deepEqual(Array.from(chars), ['乙', '甲', '丁']);
    assert(paragraphTexts.every(text => text === '乙' + '甲'.repeat(80) + '丁'));
    return f.decoderMap;
  };
  const result = await f.ocr();
  const expected = Array(54).fill('中' + '正'.repeat(80) + '后').join('\n');
  assert.equal(result.contentText, expected); assert.equal(mapCalls, 1);
  assert.equal(result.qidianGlyphTolerance, null);
  assert.equal(f.ctx.qidianContentIsComplete(result.contentText, 4000, true), true);
});

test('paragraph .content-text roots themselves preserve every paragraph and never join independent DIV containers', async () => {
  const f = scopedFixture(({ element: e, text: t }) => e('main', {}, [
    e('p', { class: 'content-text' }, [t('甲'.repeat(1000))]),
    e('p', { class: 'content-text' }, [t('𠀀'.repeat(1000))]),
    e('footer', {}, [e('p', {}, [t('丙'.repeat(5000))])])
  ]));
  assert.equal((await f.ocr()).contentText, '正'.repeat(1000) + '\n' + '文'.repeat(1000));
  const ambiguous = scopedFixture(({ element: e, text: t }) => e('main', {}, [
    e('div', { class: 'content-text' }, [e('p', {}, [t('甲'.repeat(2000))])]),
    e('div', { class: 'content-text' }, [e('p', {}, [t('𠀀'.repeat(2000))])])
  ]));
  assert.equal(await ambiguous.ocr(), null);
});

test('single inline and repeated inline roots capture their complete containing paragraph exactly once', async () => {
  for (const repeated of [false, true]) {
    const f = scopedFixture(({ element: e, text: t }) => e('main', {}, [
      e('p', {}, [t('甲'), e('span', { class: 'content-text' }, [t('乙')]), t(' '),
        e('span', repeated ? { class: 'content-text' } : {}, [t('𠀀')]), t('!')]),
      e('p', { class: 'authorSay' }, [t('丙'.repeat(5000))])
    ]));
    f.decoderMap.set('乙', '中');
    assert.equal((await f.ocr()).contentText, '正中 文!');
  }
});

for (const count of [1, 10]) test(`${count} distinct normally finished unknown glyphs become marked saved text with no encoded source leakage`, async () => {
  const f = fixture({ missing: count }), result = await f.ocr();
  assert.equal(result.qidianGlyphTolerance.distinctCount, count);
  assert.equal(result.qidianGlyphTolerance.occurrenceCount, count);
  assert.equal((result.contentText.match(/□/g) ?? []).length, count);
  assert(!/\p{Private_Use}/u.test(result.contentText));
  const quality = f.ctx.qidianContentCheck(result.contentText, 2000, true, result.qidianGlyphTolerance);
  assert.equal(quality.complete, true);
  assert.equal(quality.transcriptionComplete, false);
  assert.equal(quality.reason, 'tolerated_glyph_placeholders');
  assert.equal(f.ctx.qidianChapterQualityRank(f.chapter(result)), count * 1000000 + count);
  for (const unknown of f.unknown) assert.equal(f.decoderMap.has(unknown), false);
  assert.deepEqual(Array.from(f.ctx.qidianGlyphCache.values()), ['正']);
});

test('the default threshold counts distinct source glyphs and records every occurrence', async () => {
  const f = fixture({ missing: 1, repeats: 35 }), result = await f.ocr();
  assert.equal(result.qidianGlyphTolerance.distinctCount, 1);
  assert.equal(result.qidianGlyphTolerance.occurrenceCount, 35);
  assert.equal(f.ctx.qidianChapterContentCheck(f.chapter(result)).complete, true);
  const occurrenceMode = fixture({ missing: 1, repeats: 11, mode: 'occurrences' });
  await assert.rejects(occurrenceMode.ocr(), error => error.name === 'QidianGlyphError');
});

test('the production glyph-cache and reading validators never accept □ as a decoded reading', () => {
  const f = fixture();
  vm.runInContext(take('function qidianValidGlyphEntry(', 'function qidianRestoreGlyphCache(') +
    take('function qidianNormalizeGlyphReading(', 'async function ocrSingleChar(', source.indexOf('async function ocrContent(')), f.ctx);
  assert.equal(f.ctx.qidianValidGlyphEntry(['123:456', '□']), false);
  assert.equal(f.ctx.qidianNormalizeGlyphReading('□'), null);
  assert.equal(f.ctx.qidianValidGlyphEntry(['123:456', '正']), true);
});

test('unknown obfuscated Han is replaced with □, and positions survive paragraph trimming and supplementary source glyphs', async () => {
  const f = fixture({ missing: 0, texts: ['  𠀀甲甲乙  ', '\t甲乙甲\t'] }), result = await f.ocr();
  assert.equal(result.contentText, '文正正□\n正□正');
  assert.equal(result.qidianGlyphTolerance.glyphs[0].sourceCodepoint, 'U+4E59');
  assert.deepEqual(Array.from(result.qidianGlyphTolerance.glyphs[0].positions), [3, 6]);
  assert(!result.contentText.includes('乙'));
});

test('zero unknown glyphs keep strict quality, while >10, unfinished maps and build errors do not authorize tolerance', async () => {
  const strict = fixture({ missing: 0 }), result = await strict.ocr();
  assert.equal(result.qidianGlyphTolerance, null);
  assert.equal(strict.ctx.qidianChapterQualityRank(strict.chapter(result)), 0);
  await assert.rejects(fixture({ missing: 11 }).ocr(), error => error.name === 'QidianGlyphError');
  await assert.rejects(fixture({ missing: 1, buildError: true }).ocr(), error => error.name === 'QidianGlyphError');
  assert.equal(await fixture({ missing: 1, finished: false }).ocr(), null);
});

test('placeholders require valid position/count/body metadata; short text, PUA and replacement characters stay rejected', async () => {
  const f = fixture(), result = await f.ocr(), metadata = result.qidianGlyphTolerance;
  assert.equal(f.ctx.qidianContentIsComplete(result.contentText, 2000, true), false);
  for (const edit of [m => m.glyphs[0].positions[0]--, m => m.occurrenceCount++, m => m.distinctCount++, m => m.limit = 11, m => m.bodyDigest = 'bad', m => m.glyphs[0].sourceCodepoint = 'U+0041']) {
    const altered = structuredClone(metadata); edit(altered);
    assert.equal(f.ctx.qidianContentIsComplete(result.contentText, 2000, true, altered), false);
  }
  const short = result.contentText.slice(-2), shortMetadata = structuredClone(metadata);
  shortMetadata.glyphs[0].positions = [1]; shortMetadata.bodyDigest = f.ctx.qidianCheckpointDigest(short);
  assert.equal(f.ctx.qidianContentIsComplete(short, 2000, true, shortMetadata), false);
  for (const bad of ['\uE900', '\uFFFD']) assert.equal(f.ctx.qidianContentIsComplete('正文'.repeat(1200) + bad, 2000, true), false);
  assert.equal(f.ctx.qidianContentIsComplete(result.contentText, 2000, false, metadata), false);
});

test('checkpoint round-trip preserves tolerance/body boundaries and rejects corrupted tolerance without discarding valid saved content', async () => {
  const f = fixture(), result = await f.ocr(), chapter = f.chapter(result);
  chapter.contentText += '\n\n----------\n\n' + '作者留言'.repeat(400);
  const session = await f.session();
  assert.equal(await f.ctx.qidianCheckpointSave(session, chapter), true);
  const record = await f.ctx.qidianCheckpointRestore(session, chapter);
  assert(record);
  assert.equal(record.bodyLength, result.contentText.length);
  assert.equal(record.qidianGlyphTolerance.occurrenceCount, 1);
  assert.equal(record.text, chapter.contentText);
  const key = f.ctx.qidianCheckpointRecordKey(session, '456'), saved = structuredClone(f.storage.get(key));
  f.storage.get(key).qidianGlyphTolerance.glyphs[0].positions[0]--;
  assert.equal(await f.ctx.qidianCheckpointRestore(session, chapter), null);
  f.storage.set(key, saved);
  f.book.chapters = [chapter];
  f.window.qidianCheckpointSession = null;
  await f.ctx.qidianRestoreSelectedChapters(f.book, { saved: 5 });
  assert.equal(chapter.status, 5);
  assert.equal(f.ctx.qidianChapterContentCheck(chapter).complete, true);
  assert.equal(f.ctx.qidianChapterGlyphTolerance(chapter).distinctCount, 1);
});

test('TXT export marks uncertain chapters, sorts repaired chapters correctly, and imports only body-bound metadata', async () => {
  const f = fixture({ repeats: 3 }), result = await f.ocr(), first = f.chapter(result);
  const second = { ...first, chapterNumber: 2, chapterName: '第2章 测试', qidianCatalogTitle: '第2章 测试',
    chapterUrl: 'https://www.qidian.com/chapter/123/457/', contentText: '完整正文'.repeat(600),
    options: { expectedChars: 2000, qidianGlyphTolerance: null } };
  f.export([second, first]);
  const output = await f.outputs[0].blob.text();
  assert.match(f.outputs[0].name, /含OCR占位_1章/);
  assert.match(output, /1 个不同字形（共 3 处）/);
  assert.match(output, /===== OCR占位章节（正文已保留）=====/);
  const footerStart = output.indexOf('===== 起点下载器OCR占位续传记录 v2 =====');
  assert(footerStart > output.indexOf('===== OCR占位章节（正文已保留）====='));
  assert(!output.slice(0, footerStart).includes('"positions"'));
  assert(!output.slice(0, footerStart).includes('"bodyDigest"'));
  assert.equal(f.book.txtDownloadReport.toleratedCount, 1);
  assert(output.indexOf('第1章 测试') < output.indexOf('第2章 测试'));
  assert.equal((output.match(/^第1章 测试\r?$/gm) ?? []).length, 1);
  assert.equal(first.contentText, result.contentText);
  const importFixture = fixture({ missing: 0 });
  importFixture.book.chapters = [
    { ...first, contentText: null, options: { expectedChars: 2000 } },
    { ...second, contentText: null, options: { expectedChars: 2000 } }
  ];
  const session = await importFixture.session();
  const imported = await importFixture.ctx.qidianCheckpointImportTxt(session, importFixture.book, output);
  assert.equal(imported.imported, 2);
  const record = await importFixture.ctx.qidianCheckpointRestore(session, importFixture.book.chapters[0]);
  assert.equal(record.text, result.contentText);
  assert.equal(record.qidianGlyphTolerance.occurrenceCount, 3);
  assert(!record.text.includes('OCR识别提示'));
  const badImport = await importFixture.ctx.qidianCheckpointImportTxt(session, importFixture.book,
    output.replace('"occurrenceCount":3', '"occurrenceCount":4'));
  assert.equal(badImport.imported, 1);
  assert.equal(badImport.incomplete, 1);
});

test('TXT footer rejects duplicate or unknown bindings and still imports prior inline v1 records', async () => {
  const f = fixture(), result = await f.ocr(), chapter = f.chapter(result);
  f.export([chapter]);
  const output = (await f.outputs[0].blob.text()).replace(/\r\n/g, '\n');
  const marker = '\n===== 起点下载器OCR占位续传记录 v2 =====\n';
  const footerStart = output.indexOf(marker);
  const footerLine = output.slice(footerStart + marker.length).trim();
  for (const invalid of [
    output + '\n' + footerLine,
    output.replace('"chapterUrl":"https://www.qidian.com/chapter/123/456/"', '"chapterUrl":"https://www.qidian.com/chapter/123/999/"'),
    output.replace('"catalogTitle":"第1章 测试"', '"catalogTitle":"第9章 不匹配"'),
    output + marker + footerLine
  ]) {
    const fresh = fixture({ missing: 0 }); fresh.book.chapters = [{ ...chapter, options: { expectedChars: 2000 } }];
    const imported = await fresh.ctx.qidianCheckpointImportTxt(await fresh.session(), fresh.book, invalid);
    assert.equal(imported.imported, 0); assert.equal(imported.reason, 'txt_glyph_metadata_invalid');
    assert.equal(fresh.storage.size, 0);
  }
  const warning = f.ctx.qidianGlyphToleranceWarning(result.qidianGlyphTolerance);
  const legacy = output.slice(0, footerStart).replace(warning,
    `【起点下载器OCR占位记录 v1：${JSON.stringify(result.qidianGlyphTolerance)}】\n${warning}`);
  const fresh = fixture({ missing: 0 }); fresh.book.chapters = [{ ...chapter, options: { expectedChars: 2000 } }];
  const session = await fresh.session();
  assert.equal((await fresh.ctx.qidianCheckpointImportTxt(session, fresh.book, legacy)).imported, 1);
  const record = await fresh.ctx.qidianCheckpointRestore(session, fresh.book.chapters[0]);
  assert.equal(record.text, result.contentText);
  assert.equal(record.qidianGlyphTolerance.bodyDigest, result.qidianGlyphTolerance.bodyDigest);
});

test('the last tolerated chapter round-trips without importing warning footer or author-note prose into its checked body', async () => {
  const f = fixture(), result = await f.ocr(), chapter = f.chapter(result);
  chapter.contentText += '\n\n----------\n\n作者留言';
  f.export([chapter]);
  const text = await f.outputs[0].blob.text();
  const fresh = fixture({ missing: 0 });
  fresh.book.chapters = [{ ...chapter, contentText: null, options: { expectedChars: 2000 } }];
  const session = await fresh.session();
  assert.equal((await fresh.ctx.qidianCheckpointImportTxt(session, fresh.book, text)).imported, 1);
  const record = await fresh.ctx.qidianCheckpointRestore(session, fresh.book.chapters[0]);
  assert.equal(record.text, chapter.contentText);
  assert.equal(record.bodyLength, result.contentText.length);
});

test('the shipped VIP parser propagates validated tolerance before final body checks and never uses raw fallback', async () => {
  const f = fixture(), result = await f.ocr();
  const main = { querySelectorAll: () => Array(8), textContent: '正文'.repeat(1000) };
  const doc = { title: '测试章节', body: { textContent: main.textContent }, querySelector: selector =>
    selector === 'main' ? main : selector === '.content-text' || selector === '.content-text, .vip-limit-wrap' ? main : null };
  let rawCalls = 0;
  Object.assign(f.ctx, {
    _lib_http__WEBPACK_IMPORTED_MODULE_2__: { Q2: async (_url, predicate) => { const frame = { contentWindow: { document: doc }, remove() {} }; assert.equal(predicate(frame), true); return frame; } },
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__: { rm() {} },
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__: { an() { rawCalls++; throw new Error('raw VIP fallback'); } },
    qidianPersistGlyphCache: async () => {}
  });
  f.ctx.ocrContent = async () => result;
  vm.runInContext('class Parser {' + parserCode + '}\nthis.Parser=Parser;', f.ctx);
  const parsed = await new f.ctx.Parser().chapterParse('https://www.qidian.com/chapter/123/456/', '第1章 测试', true, true, 'UTF-8', f.options);
  assert.equal(parsed.contentText, result.contentText);
  assert.equal(f.options.qidianValidation.complete, true);
  assert.equal(f.options.qidianValidation.transcriptionComplete, false);
  assert.equal(f.options.qidianGlyphTolerance.distinctCount, 1);
  assert.equal(rawCalls, 0);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack ?? error); }
  }
  console.log(`${tests.length - failed}/${tests.length} glyph tolerance checks passed`);
  if (failed) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
