const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const start = source.indexOf('class TXT extends Options');
const end = source.indexOf(';// ./src/save/raw.ts', start);
assert(start > 0 && end > start);
class Options {
  genMetaDateTxt() { return '书籍元数据'; }
  getchapterName(c) { return c.chapterName; }
  genSectionText(s) { return `分卷：${s}`; }
  genChapterText(n, t) { return `${n}\n${t}`; }
  chapterSort(a, b) { return a.chapterNumber - b.chapterNumber; }
}
function chapter(n, extra = {}) {
  return { chapterNumber:n, chapterName:`第${n}章`, chapterUrl:`https://www.qidian.com/chapter/1/${n}`, contentText:`正文标记${n}正文正文`, status:5, ...extra };
}
function fixture(chapters, options = {}, extra = {}) {
  const outputs = [], alerts = [], warnings = [];
  const state = { throwSave:false };
  const book = { author:'作者', bookname:'测试书', chapters,
    downloadReport:{ selectedCount:chapters.length, savedCount:chapters.length, missing:[] }, ...extra };
  const ctx = vm.createContext({ Options, Blob,
    document:{location:{hostname:extra.hostname ?? 'www.qidian.com'}},
    setting:{Nw:{value:false}}, alert:m=>alerts.push(m),
    loglevel_default:()=>({debug(){},info(){},warn:m=>warnings.push(m)}),
    FileSaver_min:{saveAs:(blob,name)=>{if(state.throwSave) throw Error('浏览器下载失败'); outputs.push({blob,name});}}
  });
  vm.runInContext(source.slice(source.indexOf('function qidianContentIsComplete('), source.indexOf('/******/ \tvar __webpack_modules__')) + source.slice(start,end)+'\nthis.TXT=TXT;',ctx);
  return {book, outputs, alerts, warnings, state, txt:new ctx.TXT(book,options)};
}
const tests=[];const test=(name,run)=>tests.push({name,run});
test('middle formatter error preserves later chapters, correct counts, and EPUB metadata', async()=>{
  const f=fixture([chapter(1,{sectionName:'正常卷'}),chapter(2,{sectionName:'失败卷'}),chapter(3,{sectionName:'后续卷'})], {
    genChapterText(n,t){if(n==='第2章')throw Error('故障章节格式');return `${n}\n${t}`;}
  });
  const originalReport=f.book.downloadReport;
  f.txt.saveTxt();const text=await f.outputs[0].blob.text();
  assert.match(text,/正文标记1/);assert.match(text,/正文标记3/);assert.doesNotMatch(text,/正文标记2|分卷：失败卷/);
  assert.match(text,/已写入 2 \/ 已选 3 章/);assert.match(text,/第2章：TXT 格式化失败：故障章节格式/);
  assert.match(f.outputs[0].name,/部分下载_2章/);assert.equal(f.txt.downloadReport.savedCount,2);
  assert.equal(f.book.downloadReport,originalReport);assert.equal(originalReport.savedCount,3);
  assert(f.book.chapters.every(c=>c.status===5&&c.contentText));assert.equal(f.alerts.length,0);assert(f.warnings.some(text=>/已写入 2 \/ 3/.test(text)));
});
test('failed first chapter in a section does not hide the section of a later good chapter',async()=>{
  const f=fixture([chapter(1,{sectionName:'共同卷'}),chapter(2,{sectionName:'共同卷'})],{
    getchapterName(c){if(c.chapterNumber===1)throw Error('标题错误');return c.chapterName;}
  });f.txt.saveTxt();const text=await f.outputs[0].blob.text();
  assert.equal(text.split('分卷：共同卷').length-1,1);assert.match(text,/正文标记2/);assert.match(text,/第1章：TXT 格式化失败：标题错误/);
});
test('bad section formatter only skips affected chapters and keeps later sections',async()=>{
  const f=fixture([chapter(1,{sectionName:'坏卷'}),chapter(2,{sectionName:'好卷'})],{
    genSectionText(s){if(s==='坏卷')throw Error('分卷错误');return `分卷：${s}`;}
  });f.txt.saveTxt();const text=await f.outputs[0].blob.text();assert.match(text,/正文标记2|分卷：好卷/);assert.doesNotMatch(text,/正文标记1/);assert.equal(f.txt.downloadReport.savedCount,1);
});
test('all chapter formats failing produces an explicitly named zero-body missing report',async()=>{
  const f=fixture([chapter(1),chapter(2)],{genChapterText(){return null;}});f.txt.saveTxt();
  const text=await f.outputs[0].blob.text();assert.match(f.outputs[0].name,/TXT缺章报告/);assert.doesNotMatch(f.outputs[0].name,/部分下载/);
  assert.match(text,/已写入 0 \/ 已选 2 章/);assert.doesNotMatch(text,/正文标记/);assert.equal(f.txt.downloadReport.missing.length,2);assert.equal(f.alerts.length,0);assert(f.warnings.some(text=>/仅生成 TXT 缺章报告/.test(text)));
});
test('failed saveAs propagates and a second successful export keeps every body without duplicates',async()=>{
  const f=fixture([chapter(1),chapter(2)]);f.state.throwSave=true;
  assert.throws(()=>f.txt.saveTxt(),/浏览器下载失败/);assert.equal(f.outputs.length,0);assert.equal(f.book.txtDownloadReport,undefined);
  assert(f.book.chapters.every(c=>c.contentText));f.state.throwSave=false;f.txt.saveTxt();f.txt.saveTxt();
  assert.equal(f.outputs.length,2);const first=await f.outputs[0].blob.text(),second=await f.outputs[1].blob.text();assert.equal(first,second);
  assert.equal(second.split('书籍元数据').length-1,1);assert.equal(second.split('正文标记1').length-1,1);assert.equal(second.split('正文标记2').length-1,1);
});
test('repeat export after repairing a formatter recomputes report instead of keeping stale omissions',async()=>{
  const f=fixture([chapter(1),chapter(2)],{genChapterText(n,t){if(n==='第1章')throw Error('临时格式问题');return `${n}\n${t}`;}});
  f.txt.saveTxt();assert.equal(f.txt.downloadReport.savedCount,1);f.txt.genChapterText=Options.prototype.genChapterText;f.txt.saveTxt();
  const text=await f.outputs[1].blob.text();assert.equal(f.txt.downloadReport.savedCount,2);assert.equal(f.txt.downloadReport.missing.length,0);assert.doesNotMatch(f.outputs[1].name,/部分下载/);assert.match(text,/正文标记1/);assert.doesNotMatch(text,/临时格式问题/);
});
test('custom sort exception falls back to catalog order without mutating book order',async()=>{
  const f=fixture([chapter(3),chapter(1),chapter(2)],{chapterSort(){throw Error('排序错误');}});f.txt.saveTxt();
  const text=await f.outputs[0].blob.text();assert(text.indexOf('正文标记1')<text.indexOf('正文标记2'));assert(text.indexOf('正文标记2')<text.indexOf('正文标记3'));
  assert.deepEqual(f.book.chapters.map(c=>c.chapterNumber),[3,1,2]);assert.equal(f.txt.downloadReport.savedCount,3);assert(f.warnings.some(x=>/排序失败/.test(x)));
});
test('same title with distinct catalog identities keeps both missing chapters',async()=>{
  const title='第182章 同名章节';
  const f=fixture([chapter(183,{chapterName:title}),chapter(184)],{
    genChapterText(n,t){if(n===title)throw Error('TXT错误');return `${n}\n${t}`;}
  },{downloadReport:{selectedCount:3,savedCount:2,missing:[{title,chapterNumber:182,chapterUrl:'https://www.qidian.com/chapter/1/182',reason:'OCR失败'}]}});
  f.txt.saveTxt();const text=await f.outputs[0].blob.text();assert.equal(f.txt.downloadReport.missing.length,2);
  assert.match(text,/OCR失败（目录序号 182）/);assert.match(text,/TXT错误（目录序号 183）/);assert.match(text,/已写入 1 \/ 已选 3 章/);
});
test('empty chapter content is skipped without hiding a later valid body',async()=>{
  const f=fixture([chapter(1,{contentText:null}),chapter(2)]);f.txt.saveTxt();const text=await f.outputs[0].blob.text();
  assert.match(text,/正文标记2/);assert.match(text,/第1章：TXT 格式化失败：正文为空/);assert.equal(f.txt.downloadReport.savedCount,1);
});
test('other sites keep existing TXT behavior',async()=>{
  const f=fixture([chapter(1)],{}, {hostname:'example.com'});f.txt.saveTxt();assert.equal(f.book.chapters[0].contentText,null);assert.equal(f.book.txtDownloadReport,undefined);assert.match(await f.outputs[0].blob.text(),/正文标记1/);
});
(async()=>{for(const {name,run} of tests){await run();console.log(`PASS: ${name}`);}console.log(`PASS: ${tests.length} Qidian TXT resilience checks`);})().catch(error=>{console.error(error);process.exitCode=1;});
