// Deterministic regression: the optimized path must preserve every RGB byte
// and both legacy hash accumulators, including subarrays and realm fallback.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const helpers = source.slice(source.indexOf('function qidianGlyphFingerprint('), source.indexOf('async function ocrContent('));
function api(U32 = Uint32Array) {
  return new Function('Uint32Array', '_log__WEBPACK_IMPORTED_MODULE_6___default', helpers + '\nreturn {pack:qidianPackedGlyphPixels,hash:qidianHashGlyphPixels};')(U32, () => ({warn(){}}));
}
const {pack, hash} = api();
function legacy(pixels, width, x, y, cw, ch) {
  let a = 2166136261, b = 5381;
  for (let row = y; row < y + ch; row++) {
    for (let col = x; col < x + cw; col++) {
      const p = (row * width + col) * 4;
      const rgb = pixels[p] | (pixels[p+1] << 8) | (pixels[p+2] << 16);
      a = Math.imul(a ^ rgb, 16777619); b = Math.imul(b, 33) ^ rgb;
    }
  }
  return `${a >>> 0}:${b >>> 0}`;
}
let tests = 0;
function test(name, fn) { fn(); tests++; console.log('PASS', name); }
const width = 640, height = 768, data = new Uint8ClampedArray(width * height * 4);
let seed = 0x1425beef;
for (let i=0; i<data.length; i++) { seed ^= seed << 13; seed ^= seed >>> 17; seed ^= seed << 5; data[i] = seed & 255; }
test('all 64 cells preserve legacy full RGB hashes', () => {
  const packed = pack(data); assert(packed instanceof Uint32Array);
  for (let i=0; i<64; i++) { const x = i%8*80, y = Math.floor(i/8)*96; const want=legacy(data,width,x,y,80,96);
    assert.equal(hash(data,packed,width,x,y,80,96), want); assert.equal(hash(data,null,width,x,y,80,96), want);
  }
});
test('aligned nonzero byteOffset preserves view boundaries', () => {
  const backing=new Uint8Array(data.length+20); backing.set(data,12);
  const view=new Uint8ClampedArray(backing.buffer,12,data.length);
  assert.equal(hash(view,pack(view),width,160,384,80,96),legacy(data,width,160,384,80,96));
});
test('unaligned view uses exact byte fallback', () => {
  const backing=new Uint8Array(data.length+1); backing.set(data,1); const view=new Uint8ClampedArray(backing.buffer,1,data.length);
  assert.equal(pack(view),null); assert.equal(hash(view,pack(view),width,560,672,80,96),legacy(data,width,560,672,80,96));
});
test('unavailable cross-realm buffer uses byte fallback', () => {
  const wrapped=new Proxy(data,{get(target,key){if(key==='buffer') throw Error('not exposed'); return Reflect.get(target,key,target);}});
  assert.equal(pack(wrapped),null); assert.equal(hash(wrapped,null,width,0,0,80,96),legacy(data,width,0,0,80,96));
});
test('big-endian platform uses byte fallback', () => {
  function BigEndianU32(buffer, offset, length) { return arguments.length===1 ? [0x01000000] : new Uint32Array(buffer,offset,length); }
  const big=api(BigEndianU32); assert.equal(big.pack(data),null);
  assert.equal(big.hash(data,big.pack(data),width,80,192,80,96),legacy(data,width,80,192,80,96));
});
test('non-typed-array pixel source uses byte fallback', () => {
  const bytes=Array.from(data.subarray(0,320)); assert.equal(pack(bytes),null);
  assert.equal(hash(bytes,null,80,0,0,80,1),legacy(bytes,80,0,0,80,1));
});
test('alpha ignored exactly as legacy, every edge RGB pixel retained', () => {
  const bytes=new Uint8ClampedArray(80*96*4); const base=hash(bytes,pack(bytes),80,0,0,80,96);
  for(let i=3;i<bytes.length;i+=4) bytes[i]=i%255;
  assert.equal(hash(bytes,pack(bytes),80,0,0,80,96),base);
  for(const pixel of [0,79,80*95,80*96-1]) for(const channel of [0,1,2]) {
    bytes[pixel*4+channel]=127;
    assert.notEqual(hash(bytes,pack(bytes),80,0,0,80,96),base);
    assert.equal(hash(bytes,pack(bytes),80,0,0,80,96),legacy(bytes,80,0,0,80,96));
    bytes[pixel*4+channel]=0;
  }
});
test('packed view avoids repeated cross-realm indexed byte access', () => {
  let indexed=0; const wrapped=new Proxy(data,{get(target,key){if(typeof key==='string' && /^\d+$/.test(key)) indexed++; return Reflect.get(target,key,target);}});
  const want=legacy(wrapped,width,0,0,80,96); assert.equal(indexed,80*96*3); indexed=0;
  assert.equal(hash(wrapped,pack(wrapped),width,0,0,80,96),want); assert.equal(indexed,0);
});
console.log(`PASS ${tests} packed fingerprint regression checks.`);
