// Independent full-run QA of the shipped parser, queue, manual gate and export.
// Browser layout, network and OCR are deterministic; no website is contacted.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const dir = __dirname;
const source = fs.readFileSync(path.join(dir, 'novel-downloader-qidian-range.user.js'), 'utf8');
const fixtureSource = fs.readFileSync(path.join(dir, 'test-qidian-v19-resilience.cjs'), 'utf8');
const suite = vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('const tests=[];')) + '\n({fixture,status})',
  { require, __dirname: dir, AbortController, URL, console });
const runStart = source.indexOf('  async run() {', source.indexOf('class BaseRuleClass'));
const runEnd = source.indexOf('\n  async preHook()', runStart);
assert(runStart >= 0 && runEnd > runStart);
const runCode = source.slice(runStart, runEnd);
const deferred = () => { let resolve, reject; const promise = new Promise((a,b) => { resolve=a; reject=b; }); return { promise, resolve, reject }; };
async function drain() { for (let i=0; i<80; i++) await Promise.resolve(); }
async function until(predicate) { for(let i=0;i<1000;i++){ if(predicate())return; await Promise.resolve(); } assert.fail('expected asynchronous boundary was not reached'); }
function node(tag='div') {
  return { tagName: tag.toUpperCase(), style: {}, attributes: {}, children: [], handlers: new Map(), parentElement:null,
    get textContent() { return (this.ownText ?? '') + this.children.map(child => child.textContent).join(''); },
    set textContent(text) { this.ownText = text; },
    get innerText() { return this.textContent; },
    appendChild(child) { child.parentElement=this; this.children.push(child); return child; },
    setAttribute(key,value) { this.attributes[key]=value; },
    getAttribute(key) { return this.attributes[key] ?? null; },
    addEventListener(type,handler) { this.handlers.set(type,handler); },
    removeEventListener(type,handler) { if(this.handlers.get(type)===handler)this.handlers.delete(type); },
    getBoundingClientRect() { return { width:400,height:200 }; },
    closest(selector) { for(let current=this;current;current=current.parentElement) { if(selector.includes('#qidian-access-recovery-notice') && current.id==='qidian-access-recovery-notice')return current; } return null; },
    remove() { if(this.parentElement)this.parentElement.children=this.parentElement.children.filter(child=>child!==this); this.parentElement=null; }
  };
}
function fixture(configs) {
  const f=suite.fixture(configs), state=f.state;
  state.outputs=[];state.logExports=0;state.caught=[];state.intervals=new Map();state.postHooks=0;
  const document=f.ctx.document;
  Object.assign(document, {title:'章节目录',body:node('body'),documentElement:node('html'),createElement:node,
    defaultView:{getComputedStyle:()=>({display:'block',visibility:'visible',opacity:'1'})},
    querySelector:()=>null,
    querySelectorAll:selector=>selector.includes('[role="dialog"]') ? document.body.children.filter(item=>item.attributes.role==='dialog') : []});
  document.location.href='https://www.qidian.com/book/1/';
  f.window.workerId='manual-access-qa';
  f.window.localStorageExpired={get(){},set(){}};
  f.window.setInterval=fn=>{const id=++state.timer;state.intervals.set(id,fn);return id;};
  f.window.clearInterval=id=>state.intervals.delete(id);
  f.saver.save=async()=>state.outputs.push(f.book.chapters.map(chapter=>({id:Number(chapter.chapterUrl.split('/').at(-1)),body:chapter.contentText})));
  function SaveBook(){return f.saver;} SaveBook.saveLog=()=>state.logExports++;
  Object.assign(f.ctx, {unsafeWindow:f.window,GM_getValue:(_key,fallback)=>fallback,GM_info:{script:{version:'qa'}},SaveBook,
    saveOptionsValidate:()=>false,SessionMappingCache:{j:{getInstance:()=>({initializeSession(){},clearSession(){}})}}});
  Object.assign(f.ctx.setting, {Jv:{value:true},Zz:{value:false},Nw:{value:true},WZ:{value:false},BV:async()=>false});
  f.ctx.GM_getValue=(key,fallback)=>key==='qidianResumeEnabledV1'?false:fallback;
  vm.runInContext('\nclass FullRule extends Rule {'+runCode+'}\nthis.FullRule=FullRule;',f.ctx);
  const rule=new f.ctx.FullRule();
  Object.assign(rule,{needLogin:true,concurrencyLimit:1,sleepTime:8000,maxSleepTime:20000,
    async preHook(){},async bookParse(){return f.book;},async prepareChapters(){},selectChapters(){},
    postHook(){state.postHooks++;},catchError:error=>state.caught.push(error)});
  return {...f,rule,run:()=>rule.run(),tick(){for(const fn of [...state.intervals.values()])fn();}};
}
const ids=f=>Array.from(f.state.starts,row=>row.id);
const events=f=>Array.from(f.state.logs).filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14)));
const tests=[]; const test=(name,run)=>tests.push({name,run});

test('an access wait preserves the full queue and cannot detect its own Continue dialog as a site challenge',async()=>{
  const configs=[{id:1,vip:true},{id:2,vip:true,accessTitle:'安全验证'},{id:3,vip:true}];
  const f=fixture(configs), run=f.run();
  await until(()=>f.window.qidianAccessRecoveryGate);
  const gate=f.window.qidianAccessRecoveryGate;
  await drain();
  assert.deepEqual(ids(f),[1,2]);
  assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.window.qidianProgressState.state,'paused');
  assert.equal(f.state.outputs.length,0);
  assert.equal([...f.state.timers.values()].filter(timer=>timer.ms===600000).length,0,'manual verification wait has no chapter watchdog');
  f.state.now+=20*60*1000; f.tick(); await drain();
  assert.deepEqual(ids(f),[1,2],'time and disappearing verification never resume requests');
  f.ctx.qidianReportProgress('page_load','迟到章节');
  assert.equal(f.window.qidianProgressState.state,'paused','late stage cannot replace manual wait');
  configs[1].accessTitle=null;
  assert.equal(gate.continue(),true,'the downloader dialog must not veto its own button');
  await run;
  assert.deepEqual(ids(f),[1,2,2,3]);
  assert.equal(f.state.caught.length,0);
  assert.equal(f.state.outputs.length,1);
  assert.deepEqual(f.state.outputs[0].map(chapter=>chapter.id),[1,2,3]);
  assert.deepEqual(Array.from(f.state.saveCalls),['第1章','第2章','第3章']);
  assert.equal(f.state.logExports,1);
  assert.equal(f.state.intervals.size,0);
  assert.equal(f.window.qidianAccessRecoveryGate,null);
});

test('Stop during manual access wait wakes the same full run and exports retained bodies once',async()=>{
  const f=fixture([{id:1,vip:true},{id:2,vip:true,requestError:403},{id:3,vip:true}]);
  const run=f.run();await until(()=>f.window.qidianAccessRecoveryGate);await drain();
  const oldGate=f.window.qidianAccessRecoveryGate;
  oldGate.stop();await run;
  assert.equal(f.window.stopFlag.aborted,true);
  assert.deepEqual(ids(f),[1,2]);
  assert.equal(f.state.caught.length,0);
  assert.equal(f.state.outputs.length,1);
  assert.deepEqual(f.state.outputs[0].map(chapter=>chapter.id),[1]);
  assert.equal(f.book.downloadReport.savedCount,1);
  assert.equal(f.book.downloadReport.missing.length,2);
  assert.equal(f.state.logExports,1);
  assert.equal(oldGate.continue(),false,'old buttons cannot resume a stopped run');
  assert.equal(f.state.intervals.size,0);
  assert.equal(f.window.qidianAccessRecoveryEnabled,false);
});

test('a real top-page challenge vetoes Continue and requires a later explicit click after it clears',async()=>{
  const configs=[{id:1,vip:true,requestError:429},{id:2,vip:true}];
  const f=fixture(configs),run=f.run();await until(()=>f.window.qidianAccessRecoveryGate);await drain();
  const gate=f.window.qidianAccessRecoveryGate,challenge=node('div');
  challenge.setAttribute('role','dialog');challenge.textContent='请完成安全验证后继续';f.ctx.document.body.appendChild(challenge);
  assert.equal(gate.continue(),false);await drain();assert.deepEqual(ids(f),[1]);
  challenge.remove();delete configs[0].requestError;f.tick();await drain();assert.deepEqual(ids(f),[1]);
  assert.equal(gate.continue(),true);await run;
  assert.deepEqual(ids(f),[1,1,2]);assert.equal(f.book.downloadReport.savedCount,2);
});

test('one persistently denied chapter reaches its retry bound and preserves later readable chapters',async()=>{
  const f=fixture([{id:1,vip:true,requestError:403},{id:2,vip:true}]),run=f.run();
  let previous=null;
  for(let confirmation=0;confirmation<3;confirmation++){
    await until(()=>f.window.qidianAccessRecoveryGate && f.window.qidianAccessRecoveryGate!==previous);await drain();
    const gate=f.window.qidianAccessRecoveryGate;assert.equal(gate.continue(),true);previous=gate;
  }
  await run;
  assert.deepEqual(ids(f),[1,1,1,2]);
  assert.equal(f.chapters[0].status,suite.status.failed);
  assert.equal(f.chapters[0].qidianFailureKind,'access');
  assert.notEqual(f.chapters[0].qidianSkipReason,'unsubscribed');
  assert.equal(f.chapters[1].status,suite.status.saved);
  assert.equal(f.book.downloadReport.savedCount,1);assert.equal(f.book.downloadReport.missing.length,1);
  assert.deepEqual(f.state.outputs[0].map(chapter=>chapter.id),[2]);
  assert.equal(f.window.stopFlag.aborted,false);
});

test('a challenge during a pending page request retires that request and ignores its late verification body',async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:false}]),pending=deferred();
  const http=f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__,real=http.pG;let calls=0;
  http.pG=url=>url.endsWith('/1') && ++calls===1 ? pending.promise : real(url);
  const run=f.run();await until(()=>calls===1);
  const challenge=node('div');challenge.setAttribute('role','dialog');challenge.textContent='请完成安全验证';
  f.ctx.document.body.appendChild(challenge);f.tick();await until(()=>f.window.qidianAccessRecoveryGate);await drain();
  assert.equal([...f.state.timers.values()].filter(timer=>timer.ms===600000).length,0);
  const gate=f.window.qidianAccessRecoveryGate;challenge.remove();assert.equal(gate.continue(),true);await run;
  assert.equal(f.book.downloadReport.savedCount,2);
  const bodies=f.chapters.map(chapter=>chapter.contentText),logCount=f.state.logs.length;
  pending.resolve({title:'安全验证',body:{innerText:'请完成安全验证'},querySelector:()=>null});await drain();
  assert.equal(f.window.qidianAccessRecoveryGate,null);assert.equal(f.window.stopFlag.aborted,false);
  assert.deepEqual(f.chapters.map(chapter=>chapter.contentText),bodies);
  assert.equal(f.state.logs.length,logCount);
  assert.deepEqual(Array.from(f.state.saveCalls),['第1章','第2章']);
});

test('a retired page callback cannot create a gate in the next full run',async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:false}]),pending=deferred(),current=deferred();
  const http=f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__,real=http.pG;let started=false;
  http.pG=url=>url.endsWith('/1')?(started=true,pending.promise):real(url);
  const run=f.run();await until(()=>started);
  const timer=[...f.state.timers.values()].find(item=>item.ms===600000);assert(timer);timer.fn();await run;
  assert.equal(f.window.qidianAccessRecoveryGate,null);assert.equal(f.book.downloadReport.savedCount,1);
  f.book.chapters=f.chapters;
  f.chapters[0].status=suite.status.pending;f.chapters[0].retryTime=0;
  let newStarted=false;
  http.pG=url=>url.endsWith('/1')?(newStarted=true,current.promise):real(url);
  const restarted=f.run();await until(()=>newStarted);
  const logCount=f.state.logs.length;
  const progress=JSON.stringify(f.window.qidianProgressState);
  pending.reject(Object.assign(new Error('HTTP 403'),{status:403}));await drain();
  assert.equal(f.window.qidianAccessRecoveryGate,null);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.state.logs.length,logCount,'retired callback cannot add access diagnostics to the next run');
  assert.equal(JSON.stringify(f.window.qidianProgressState),progress);
  current.resolve(await real('https://www.qidian.com/chapter/1/1'));await restarted;
  assert.equal(f.book.downloadReport.savedCount,2);
  assert.deepEqual(f.state.outputs[1].map(chapter=>chapter.id),[1,2]);
});

(async()=>{let failed=0;for(const {name,run} of tests){try{await run();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,'\n',error.stack);}}console.log(`${tests.length-failed}/${tests.length} independent full-run access QA checks passed`);if(failed)process.exitCode=1;})().catch(error=>{console.error(error);process.exitCode=1;});
