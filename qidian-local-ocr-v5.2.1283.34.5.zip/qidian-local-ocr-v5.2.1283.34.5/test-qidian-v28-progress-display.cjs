// Evaluate the shipped template bindings and VM computed values together.
// This is an offline binding regression check, not a full Vue/browser render.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const moduleStart = src.indexOf(';// ./src/ui/progress.html');
const templateStart = src.indexOf('var code = `', moduleStart);
const templateEnd = src.indexOf('`;', templateStart);
assert(moduleStart >= 0 && templateStart > moduleStart && templateEnd > templateStart,
  'Missing shipped progress template');
const template = src.slice(templateStart + 'var code = `'.length, templateEnd);
const helperStart = src.indexOf('function formatETA(', templateEnd);
const appEnd = src.indexOf('app.config.compilerOptions', helperStart);
assert(helperStart > templateEnd && appEnd > helperStart, 'Missing shipped progress VM');
const options = vm.runInNewContext(src.slice(helperStart, appEnd) + '\napp', {
  external_Vue_: { createApp: value => value }, ui_progress: template
});
assert.equal(options.template, template, 'VM must use the template under test');

function elementById(id) {
  const match = template.match(new RegExp(`<([a-z]+)\\b([^>]*\\bid="${id}"[^>]*)>([\\s\\S]*?)</\\1>`));
  assert(match, `Missing actual UI element ${id}`);
  return { tag: match[1], attributes: match[2], text: match[3] };
}
const countElement = elementById('chapter-count');
const detailsElement = elementById('chapter-progress-details');
const percentElement = elementById('chapter-percent-text');
const barMatch = template.match(/<div\b[^>]*class="nd-progress-bar"[^>]*>/);
assert(barMatch, 'Missing actual progress bar');
function attribute(markup, name) {
  const match = markup.match(new RegExp(`\\b${name}="([^"]*)"`));
  assert(match, `Missing real template attribute ${name}`);
  return match[1];
}
const barStyle = attribute(barMatch[0], 'v-bind:style');
const barTitle = attribute(barMatch[0], 'v-bind:title');
const detailsCondition = attribute(detailsElement.attributes, 'v-if');
const tests = [];
function test(name, fn) { tests.push({ name, fn }); }
function state(values = {}) {
  const result = Object.assign(options.data(), options.methods, values);
  for (const [key, computed] of Object.entries(options.computed)) {
    Object.defineProperty(result, key, { get: () => computed.call(result) });
  }
  return result;
}
function displayed(values) {
  const scope = vm.createContext(values);
  const evaluate = expression => vm.runInContext(expression, scope);
  const interpolate = text => text.replace(/{{\s*([\s\S]*?)\s*}}/g, (_, expression) => String(evaluate(expression)));
  return {
    count: interpolate(countElement.text).trim(),
    details: evaluate(detailsCondition) ? interpolate(detailsElement.text).trim() : null,
    percentage: interpolate(percentElement.text).trim(),
    width: evaluate('(' + barStyle + ')')['--progress'],
    title: evaluate(barTitle),
    visible: evaluate('ntProgressSeen') && evaluate('chapterProgressSeen'),
    eta: values.etaText
  };
}
function assertQidianDisplay(values, completed, total, successful, skipped) {
  const result = displayed(values);
  assert.equal(result.count, `处理进度：${completed} / ${total}`);
  assert.equal(result.details, `成功 ${successful} · 跳过 ${skipped}（未订阅）`);
  const percent = total > 0 ? completed / total * 100 : 0;
  assert.equal(result.percentage, `${Math.floor(percent)}%`);
  assert.equal(result.width, percent + '%');
  assert.equal(result.title, skipped > 0 ? `章节：${completed}/${total}（成功${successful}，跳过${skipped}）` : `章节：${successful}/${total}`);
  assert.equal(values.completedChapterNumber, completed);
  return result;
}

test('the actual count, details, width, percentage and tooltip use live shipped bindings', () => {
  assert.equal(countElement.text.trim(), '{{ chapterProgressText }}');
  assert.match(detailsElement.text, /{{\s*finishedChapterNumber\s*}}/);
  assert.match(detailsElement.text, /{{\s*qidianSkippedChapterNumber\s*}}/);
  assert.equal(detailsCondition, 'isQidianRun');
  assert.equal(barTitle, 'chapterProgressTitle');
  assert.match(barStyle, /chapterPercent/);
  assert.match(percentElement.text, /Math\.floor\(chapterPercent\)/);
});

for (const skipped of [74, 75]) {
  test(`screenshot case: 1 successful + ${skipped} skipped / 174 agrees at visible 43 percent`, () => {
    const result = assertQidianDisplay(state({ isQidianRun: true, totalChapterNumber: 174,
      finishedChapterNumber: 1, qidianSkippedChapterNumber: skipped }), skipped + 1, 174, 1, skipped);
    assert.equal(result.percentage, '43%');
    assert.equal(result.visible, true);
  });
}

test('later reader skips update the displayed numerator and bar together without remounting', () => {
  const values = state({ isQidianRun: true, totalChapterNumber: 10, finishedChapterNumber: 1 });
  assertQidianDisplay(values, 1, 10, 1, 0);
  values.qidianSkippedChapterNumber = 3;
  assertQidianDisplay(values, 4, 10, 1, 3);
  values.finishedChapterNumber = 2;
  assertQidianDisplay(values, 5, 10, 2, 3);
});

test('all selected chapters skipped gives 100 percent, zero success and no ETA', () => {
  const result = assertQidianDisplay(state({ isQidianRun: true, totalChapterNumber: 174,
    finishedChapterNumber: 0, qidianSkippedChapterNumber: 174 }), 174, 174, 0, 174);
  assert.equal(result.percentage, '100%');
  assert.equal(result.visible, true);
  assert.equal(result.eta, '');
});

test('restored bodies already in the successful counter are displayed once, together with new saves and skips', () => {
  // The existing scheduler suites verify real restore. Here 8 restored + 2 new
  // saves comprise finishedChapterNumber=10; metadata must not add them again.
  const values = state({ isQidianRun: true, totalChapterNumber: 20,
    finishedChapterNumber: 10, qidianSkippedChapterNumber: 3, qidianResumedCount: 8 });
  assertQidianDisplay(values, 13, 20, 10, 3);
});

test('failed and attempted catalogue positions do not appear as success or force paused progress to 100 percent', () => {
  const values = state({ isQidianRun: true, totalChapterNumber: 174,
    finishedChapterNumber: 2, qidianSkippedChapterNumber: 3,
    processedChapterIndex: 174, failedChapterNumber: 169, qidianPaused: true });
  const result = assertQidianDisplay(values, 5, 174, 2, 3);
  assert.equal(result.percentage, '2%');
  assert.notEqual(values.chapterPercent, 100);
});

test('later recovery passes add saved chapters once without counting retries as completed chapters', () => {
  const values = state({ isQidianRun: true, totalChapterNumber: 5,
    finishedChapterNumber: 2, qidianSkippedChapterNumber: 1, processedChapterIndex: 5 });
  assertQidianDisplay(values, 3, 5, 2, 1);
  values.qidianRecoveryRound = 1;
  values.finishedChapterNumber = 3;
  assertQidianDisplay(values, 4, 5, 3, 1);
  values.qidianRecoveryRound = 2;
  assertQidianDisplay(values, 4, 5, 3, 1);
  values.finishedChapterNumber = 4;
  const result = assertQidianDisplay(values, 5, 5, 4, 1);
  assert.equal(result.eta, '');
});

test('ETA subtracts the same successful-plus-skipped count shown by the real UI bindings', () => {
  const values = state({ isQidianRun: true, totalChapterNumber: 174,
    finishedChapterNumber: 1, qidianSkippedChapterNumber: 75, totalRequestTime: 1000,
    qidianStartGaps: [10000, 10000, 10000, 10000], qidianChapterTimes: [1000, 1000, 1000, 1000, 1000] });
  const result = assertQidianDisplay(values, 76, 174, 1, 75);
  assert.equal(result.eta, '~16m11s');
});

test('reset hides an empty zero-total progress UI and clears its visible count, skips and ETA', () => {
  const values = state({ isQidianRun: true, totalChapterNumber: 174,
    finishedChapterNumber: 1, qidianSkippedChapterNumber: 75, totalRequestTime: 1000 });
  values.reset();
  const result = displayed(values);
  assert.equal(result.count, '下载进度：0 / 0');
  assert.equal(result.percentage, '0%');
  assert.equal(result.width, '0%');
  assert.equal(result.details, null);
  assert.equal(result.eta, '');
  assert.equal(Boolean(result.visible), false);
});

test('non-Qidian visible bindings retain downloaded-success progress and hide Qidian skip details', () => {
  const values = state({ isQidianRun: false, totalChapterNumber: 10,
    finishedChapterNumber: 5, qidianSkippedChapterNumber: 5, totalRequestTime: 5000,
    processedChapterIndex: 5, concurrencyLimit: 2 });
  const result = displayed(values);
  assert.equal(result.count, '下载进度：5 / 10');
  assert.equal(result.percentage, '50%');
  assert.equal(result.width, '50%');
  assert.equal(result.title, '章节：5/10');
  assert.equal(result.details, null);
  assert.equal(result.eta, '~3s');
});

let failed = 0;
for (const { name, fn } of tests) {
  try { fn(); console.log('PASS', name); }
  catch (error) { failed++; console.error('FAIL', name, error); }
}
console.log(`${tests.length - failed}/${tests.length} v28 offline template-binding checks passed (not a full Vue/browser render)`);
if (failed) process.exitCode = 1;
