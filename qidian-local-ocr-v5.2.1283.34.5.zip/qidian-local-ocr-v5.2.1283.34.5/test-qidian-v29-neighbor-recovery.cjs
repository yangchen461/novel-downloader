/* Real same-frame recovery functions; canvas and decoder are local test doubles. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const main = fs.readFileSync(process.env.QIDIAN_SCRIPT_PATH || path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const start = main.indexOf('function qidianGlyphNeighborContexts(');
const end = main.indexOf('function extractRenderedText(', start);
assert(start >= 0 && end > start, 'final source contains the neighbor and actual recovery functions');
const fragment = main.slice(start, end);
const unknown = '\uE0AA';
const known = new Map([['甲', '人'], ['乙', '中'], ['丙', '上'], ['丁', '下']]);
const anchors = [...known];
function plain(value) { return JSON.parse(JSON.stringify(value)); }
function harness(reply) {
  const calls = [], warnings = [], glyphs = [];
  const canvas = { height: 0 };
  Object.defineProperty(canvas, 'width', { get() { return this._width; }, set(value) { this._width = value; glyphs.length = 0; } });
  const ctx = { setTransform() {}, fillRect() {}, fillText(glyph) { glyphs.push(glyph); } };
  const context = vm.createContext({ Map, Set, Date, Math,
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => ({ warn: text => warnings.push(text) }),
    canvasToUint8Array: current => ({ glyphs: [...glyphs], width: current.width, height: current.height, font: ctx.font }) });
  vm.runInContext(fragment, context);
  const decoder = { async decodeFullText(data, phase) {
    const call = { phase, ...data }; calls.push(call);
    return reply ? reply(call, calls.length, calls) : '';
  } };
  return { context, canvas, ctx, decoder, calls, warnings,
    nearby: texts => context.qidianGlyphNeighborContexts(texts, unknown, known),
    recover: (nearby, evidence = {}, guard = () => true, customAnchors = anchors) =>
      context.qidianRecoverUnmappedGlyph(canvas, ctx, unknown, 'test-font', decoder, customAnchors, guard, nearby, evidence) };
}
function anchored(call, candidate) {
  return `${known.get(call.glyphs[0])}${candidate}${known.get(call.glyphs[2])}`;
}
function actualPairs(h) { return h.nearby([`甲${unknown}乙`, `丙${unknown}丁`]); }
function assertSafeEvidence(evidence) {
  assert.deepEqual(Object.keys(evidence).sort(), ['contextCount', 'nearbyContextCount', 'reasonCode']);
  const serialized = JSON.stringify(evidence);
  for (const forbidden of ['甲', '乙', '丙', '丁', '文', '武', '字', unknown, 'PRIVATE_BODY_SENTINEL']) {
    assert(!serialized.includes(forbidden), 'diagnostic records counters and fixed reason only');
  }
}
let passed = 0;
async function test(name, fn) { await fn(); passed++; }
(async () => {
  await test('neighbor extraction selects at most two distinct immediate source pairs', () => {
    const h = harness();
    assert.deepEqual(plain(h.nearby([`甲${unknown}乙甲${unknown}乙丙${unknown}丁乙${unknown}丙`])),
      [[['甲', '人'], ['乙', '中']], [['丙', '上'], ['丁', '下']]]);
  });
  await test('neighbor extraction never combines separate paragraphs or skips spaces', () => {
    const h = harness();
    for (const texts of [[`甲${unknown}`, '乙'], [`甲 ${unknown}乙`], [`甲${unknown} 乙`],
      [`甲\n${unknown}乙`], [`甲${unknown}\n乙`], [`甲\t${unknown}乙`]]) {
      assert.deepEqual(plain(h.nearby(texts)), []);
    }
    // Even a malformed map must not turn a paragraph boundary into an anchor.
    const unusualMap = new Map([...known, [' ', '人'], ['\n', '人'], ['\t', '人']]);
    for (const text of [` ${unknown}乙`, `甲${unknown}\n`, `\t${unknown}乙`]) {
      assert.deepEqual(plain(h.context.qidianGlyphNeighborContexts([text], unknown, unusualMap)), []);
    }
  });
  await test('missing, repeated, unresolved and non-Han anchors are rejected', () => {
    const h = harness();
    assert.deepEqual(plain(h.nearby([unknown, `甲${unknown}`, `${unknown}乙`, `甲${unknown}甲`, `${unknown}${unknown}乙`, `戊${unknown}乙`])), []);
    for (const bad of [null, '', 'abc', '人中', '\uE000', '\uFFFD', '😀', '。']) {
      const badMap = new Map([['甲', bad], ['乙', '中']]);
      assert.deepEqual(plain(h.context.qidianGlyphNeighborContexts([`甲${unknown}乙`], unknown, badMap)), []);
    }
  });
  await test('supplementary-plane source codepoints remain one glyph', () => {
    const h = harness(); const target = '\u{F0000}';
    assert.deepEqual(plain(h.context.qidianGlyphNeighborContexts([`甲${target}乙`], target, known)), [[['甲', '人'], ['乙', '中']]]);
  });
  await test('two actual neighbor contexts agree before accepting a formerly unreadable glyph', async () => {
    const h = harness(call => call.phase === 'single' ? '' : anchored(call, '文'));
    const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), '文');
    assert.deepEqual(h.calls.map(x => x.phase), ['single', 'single', 'anchored', 'anchored']);
    assert.deepEqual(h.calls.slice(2).map(x => x.glyphs), [['甲', unknown, '乙'], ['丙', unknown, '丁']]);
    assert.deepEqual(evidence, { reasonCode: 'anchored_agreement', contextCount: 2, nearbyContextCount: 2 });
    assertSafeEvidence(evidence);
  });
  await test('two isolated agreements keep the original fast path', async () => {
    const h = harness(() => '字'); const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), '字');
    assert.equal(h.calls.length, 2); assert.equal(evidence.reasonCode, 'isolated_agreement');
    assert.equal(evidence.contextCount, 0); assertSafeEvidence(evidence);
  });
  await test('conflicting isolated readings remain unresolved even when nearby contexts are available', async () => {
    const h = harness((_call, n) => n === 1 ? '字' : '文'); const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), null);
    assert.equal(h.calls.length, 2); assert.equal(evidence.reasonCode, 'isolated_conflict'); assertSafeEvidence(evidence);
  });
  await test('one valid isolated reading conflicts with a different anchored candidate', async () => {
    const h = harness((call, n) => call.phase === 'single' ? (n === 1 ? '字' : '') : anchored(call, '文'));
    const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), null);
    assert.equal(h.calls.length, 3); assert.equal(evidence.reasonCode, 'anchored_conflict'); assertSafeEvidence(evidence);
  });
  await test('different candidates from the two actual neighbor contexts are rejected', async () => {
    const h = harness((call, n) => call.phase === 'single' ? '' : anchored(call, n === 3 ? '文' : '武'));
    const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), null);
    assert.equal(h.calls.length, 4); assert.equal(evidence.reasonCode, 'anchored_conflict'); assertSafeEvidence(evidence);
  });
  await test('a single valid anchored rendering cannot certify a glyph', async () => {
    const h = harness((call, n) => n === 3 ? anchored(call, '文') : ''); const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), null);
    assert.equal(h.calls.length, 6); assert.equal(evidence.reasonCode, 'no_valid_reading');
    assert.equal(evidence.contextCount, 4); assert.equal(evidence.nearbyContextCount, 2); assertSafeEvidence(evidence);
  });
  await test('mismatched anchors and multicharacter or non-Han centers never produce a reading', async () => {
    const results = ['错文错', '人文中额外', '人😀中', '人\uE000中', '人\uFFFD中', '人。中'];
    for (const result of results) {
      const h = harness(call => call.phase === 'single' ? '' : result); const evidence = {};
      assert.equal(await h.recover(actualPairs(h), evidence), null);
      assert(h.calls.length <= 6); assert.equal(evidence.reasonCode, 'no_valid_reading'); assertSafeEvidence(evidence);
    }
  });
  await test('duplicate source pairs are not counted as independent context confirmations', async () => {
    const h = harness((call, n) => n === 3 ? anchored(call, '文') : ''); const evidence = {};
    const first = actualPairs(h)[0];
    assert.equal(await h.recover([first, first], evidence), null);
    assert.equal(evidence.nearbyContextCount, 1); assert(h.calls.length <= 6); assertSafeEvidence(evidence);
  });
  await test('insufficient confirmed anchors leave the glyph unresolved', async () => {
    const h = harness(); const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence, () => true, anchors.slice(0, 1)), null);
    assert.equal(h.calls.length, 2); assert.equal(evidence.reasonCode, 'insufficient_anchors'); assertSafeEvidence(evidence);
  });
  await test('stop and time budget guards take precedence without extra decode calls', async () => {
    for (const reason of ['call_budget', 'time_budget', 'stopped']) {
      const h = harness(call => call.phase === 'single' ? '' : anchored(call, '文')); const evidence = {};
      const guard = () => h.calls.length < 3;
      guard.reasonCode = () => reason;
      assert.equal(await h.recover(actualPairs(h), evidence, guard), null);
      assert.equal(h.calls.length, 3); assert.equal(evidence.reasonCode, reason); assertSafeEvidence(evidence);
    }
  });
  await test('decoder failures cannot escape and diagnostics contain neither candidate nor body', async () => {
    const h = harness(() => { throw new Error('PRIVATE_BODY_SENTINEL'); }); const evidence = {};
    assert.equal(await h.recover(actualPairs(h), evidence), null);
    assert.equal(h.calls.length, 6); assert.equal(evidence.reasonCode, 'no_valid_reading'); assertSafeEvidence(evidence);
    assert(!h.warnings.join('\n').includes('PRIVATE_BODY_SENTINEL'), 'recovery warnings omit raw decoder errors');
  });
  console.log(`Qidian v29 neighbor recovery: ${passed}/${passed} passed`);
})().catch(error => { console.error(error); process.exitCode = 1; });
