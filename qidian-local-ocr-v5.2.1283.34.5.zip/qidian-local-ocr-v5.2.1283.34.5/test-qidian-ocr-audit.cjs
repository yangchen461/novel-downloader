const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const script = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const globalHelpers = script.slice(script.indexOf('function qidianContentIsComplete('), script.indexOf('/******/ 	var __webpack_modules__'));
const attemptStart = script.indexOf('function qidianAttemptScope(');
const attemptEnd = script.indexOf('async function qidianStage(', attemptStart);
assert.ok(attemptStart >= 0 && attemptEnd > attemptStart);
const attemptHelpers = script.slice(attemptStart, attemptEnd);
const logger = () => ({error() {}, info() {}, warn() {}});
const element = () => ({appendChild() {}, textContent: ''});

async function testModelRecovery() {
  const start = script.indexOf('  async ensureModelLoaded() {');
  const end = script.indexOf('  /**', start);
  const Decoder = vm.runInNewContext(`(class {
    constructor() { this.modelLoaded = false; this.loadingPromise = null; this.attempts = 0; }
    async loadModel() {
      this.attempts++;
      await Promise.resolve();
      if (this.attempts === 1) throw new Error('transient failure');
      this.modelLoaded = true;
    }
    ${script.slice(start, end)}
  })`);
  const decoder = new Decoder();
  const first = await Promise.allSettled([decoder.ensureModelLoaded(), decoder.ensureModelLoaded()]);
  assert.ok(first.every(result => result.status === 'rejected'));
  assert.equal(decoder.attempts, 1, 'concurrent users must share the first attempt');
  assert.equal(decoder.loadingPromise, null, 'failed attempt must be released');
  await Promise.all([decoder.ensureModelLoaded(), decoder.ensureModelLoaded()]);
  assert.equal(decoder.attempts, 2, 'the next attempt should recover once');
  assert.equal(decoder.modelLoaded, true);
  await decoder.ensureModelLoaded();
  assert.equal(decoder.attempts, 2, 'loaded decoder should remain reused');
}

async function testModelPrewarm() {
  const start = script.indexOf('  prewarmVipOCR() {', script.indexOf('class Qidian extends'));
  const end = script.indexOf('  async bookParse()', start);
  assert.ok(start > 0 && end > start);
  let created = 0;
  let loads = 0;
  class Decoder {
    constructor() {created++;this.modelLoaded=false;this.loadingPromise=null;}
    ensureModelLoaded() {
      loads++;
      return this.loadingPromise = Promise.resolve().then(() => {this.modelLoaded=true;});
    }
  }
  const Qidian = vm.runInNewContext(`(function () {let qidianOcrDecoder;return class { ${script.slice(start, end)} };})()`, {
    _lib_decoders_OCRDecoder__WEBPACK_IMPORTED_MODULE_11__: {T:Decoder},
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
    qidianRestoreGlyphCache() {}
  });
  const downloader = new Qidian();
  downloader.prewarmVipOCR();
  downloader.prewarmVipOCR();
  await Promise.resolve();
  downloader.prewarmVipOCR();
  assert.equal(created,1,'all chapters should share one decoder');
  assert.equal(loads,1,'an already loading or ready model should not reload');
}

async function testStoredGlyphCache() {
  const start = script.indexOf('const QIDIAN_STORED_GLYPH_LIMIT =');
  const end = script.indexOf('window.addEventListener("pagehide"',start);
  assert.ok(start > 0 && end > start);
  let stored = [['123:456','你'],['invalid','乱码'],['78:90','两个字']];
  let reads = 0;
  let failWrites = false;
  const context = {
    setTimeout, clearTimeout, GM_getValue(key,fallback) {reads++;return stored??fallback;},
    GM_setValue(key,value) {if(failWrites)throw Error('storage unavailable');stored=value;},
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger
  };
  const createCache = () => vm.runInNewContext(
    script.slice(script.indexOf('function qidianContentIsComplete('), script.indexOf('/******/ \tvar __webpack_modules__')) + 'let qidianGlyphCache=new Map();' + script.slice(start,end) +
    '\n({restore:qidianRestoreGlyphCache, persist:qidianPersistGlyphCache, map:qidianGlyphCache, noteNew:(count)=>{qidianNewGlyphsSincePersist+=count;}, dirty:()=>qidianNewGlyphsSincePersist})',{...context}
  );
  const first = createCache();
  first.restore();first.restore();
  assert.equal(reads,1,'restore local mappings once per page');
  assert.equal(first.map.get('123:456'),'你');
  assert.equal(first.map.size,1,'reject malformed keys and multi-character OCR results');
  first.map.set('789:456','好');
  first.map.set('bad','坏');
  first.noteNew(1);
  await first.persist();
  assert.equal(stored.length,3,'small batches should wait until the end of the range');
  first.noteNew(99);
  await first.persist();
  assert.equal(stored.length,2,'persist only single-character mappings with rendered-glyph hashes');
  assert.equal(stored.some(([key])=>key==='bad'),false);
  assert.equal(first.dirty(),0);
  const second = createCache();
  second.restore();
  assert.equal(second.map.get('789:456'),'好','subsequent page can reuse verified local glyph mapping');
  const mapStart=script.indexOf('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars) {');
  const mapEnd=script.indexOf('async function ocrSingleChar(',mapStart);
  let recognitions=0;
  const buildMap=vm.runInNewContext(attemptHelpers+'let qidianOcrDecoder;'+script.slice(mapStart,mapEnd)+'\nbuildFontDecodeMap',{
    qidianNormalizeGlyphReading: vm.runInNewContext(
      script.slice(script.indexOf('function qidianNormalizeGlyphReading('), script.indexOf('async function ocrSingleChar(', mapStart)) + '\nqidianNormalizeGlyphReading'
    ),
    qidianRestoreGlyphCache:()=>second.restore(),
    qidianGlyphCache:second.map,
    qidianGlyphFingerprints:(ctx,chars)=>new Map(chars.map(ch=>[ch,ch==='甲'?'123:456':'789:456'])),
    window: {},
    _lib_decoders_OCRDecoder__WEBPACK_IMPORTED_MODULE_11__:{T:class {decodeFullText(){recognitions++;throw Error('OCR should not run for a cached glyph');}}},
    _log__WEBPACK_IMPORTED_MODULE_6___default:logger,
    QIDIAN_GLYPH_CACHE_LIMIT:30000
  });
  const canvas=()=>({width:80,height:96,getContext(){return {};}});
  const decoded=await buildMap({createElement:canvas},{},'sample',['甲','乙']);
  assert.equal(decoded.get('甲'),'你');
  assert.equal(decoded.get('乙'),'好');
  assert.equal(recognitions,0,'previously recognized glyphs must skip OCR on the next page');
  second.map.set('456:123','新');
  second.noteNew(1);
  await second.persist(true);
  assert.equal(stored.length,3,'a final flush must save the last partial batch');
  failWrites=true;
  second.noteNew(100);
  await second.persist();
  assert.equal(second.dirty(),100,'failed storage writes must be retried later');
}

async function testFinalCacheFlush() {
  const start=script.indexOf('  async initChapters(book, saveBookObj) {',script.indexOf('class Qidian extends'));
  const end=script.indexOf('  prewarmVipOCR() {',start);
  assert.ok(start>0 && end>start);
  let flushes=0;
  const Rule=vm.runInNewContext(`(class extends (class {async initChapters(book){if(book.fail)throw Error('stopped');return book;}}) {${script.slice(start,end)}})`,{
    qidianPersistGlyphCache:async force=>{assert.equal(force,true);flushes++;}
  });
  const rule=new Rule();
  assert.equal((await rule.initChapters({ok:true})).ok,true);
  await assert.rejects(rule.initChapters({fail:true}),/stopped/);
  assert.equal(flushes,2,'success and early stop both flush the remaining local cache');
}

async function testIncompleteMap() {
  const start = script.indexOf('async function ocrContent(');
  const end = script.indexOf('async function buildFontDecodeMap(ownerDoc, ownerWin', start);
  const context = {
    document: {createElement: element},
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
    collectPseudoContentRules: () => [],
    extractRenderedText: () => '甲乙',
    buildFontDecodeMap: async () => new Map([['甲', '你']])
  };
  const fn = vm.runInNewContext(globalHelpers + script.slice(start, end) + '\nocrContent', context);
  const content = {
    ownerDocument: {defaultView: {document: {}, getComputedStyle: () => ({fontFamily: 'Test'})}},
    querySelectorAll: () => [{}]
  };
  assert.equal(await fn(content), null, 'one unmapped CJK character must reject OCR');
  context.buildFontDecodeMap = async () => new Map([['甲', '你'], ['乙', '好']]);
  assert.equal((await fn(content)).contentText, '你好', 'complete map should preserve order');
}

async function testVipCannotFallBackToRawText() {
  const start = script.indexOf('  async chapterParse(', script.indexOf('class Qidian extends'));
  const end = script.indexOf('\n}\n\n\n/***/', start);
  assert.ok(start > 0 && end > start);
  let rawCalls = 0;
  let removed = 0;
  let persisted = 0;
  const doc = {querySelector: selector => selector === 'main' ? {} : null};
  const context = {
    document: {createElement: element},
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
    _lib_http__WEBPACK_IMPORTED_MODULE_2__: {Q2: async () => ({contentWindow: {document: doc}, remove() {removed++;}})},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__: {rm() {}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__: {an() {rawCalls++; throw Error('raw fallback called');}},
    qidianPageIsBlocked: () => false,
    qidianContentIsComplete: text => text === 'complete OCR',
    qidianContentFailure(message) { const error = Error(message); error.name = 'QidianContentError'; return error; },
    ocrContent: async () => null,
    qidianGlyphCache: new Map(),
    qidianPersistGlyphCache: async () => {persisted++;}
  };
  // Use the shipped diagnostics and stage helpers in the parser realm. The
  // preexisting fixture completeness predicate isolates the VIP fallback
  // branch; OCR character thresholds have separate body-validation coverage.
  context.window = {qidianTxtOnly: true};
  const Qidian = vm.runInNewContext(globalHelpers + `
(class { ${script.slice(start, end)} })`, context);
  const parser = new Qidian();
  await assert.rejects(parser.chapterParse('chapter', '第1章', true, true, '', {}), error => error.name === 'QidianContentError');
  context.ocrContent = async () => ({contentText: 'too short', contentHTML: {}});
  await assert.rejects(parser.chapterParse('chapter', '第1章', true, true, '', {}), error => error.name === 'QidianContentError');
  assert.equal(rawCalls, 0, 'failed VIP OCR must never call raw parser');
  assert.equal(removed, 2, 'failed attempts must remove their frames');
  assert.equal(persisted, 0, 'failed chapters must not persist OCR mappings');
  const completeText = '完整正文'.repeat(100);
  context.ocrContent = async () => ({contentText: completeText, contentHTML: {}});
  assert.equal((await parser.chapterParse('chapter', '第1章', true, true, '', {})).contentText, completeText);
  assert.equal(persisted, 1);
}

(async () => {
  await testModelRecovery();
  await testModelPrewarm();
  await testStoredGlyphCache();
  await testFinalCacheFlush();
  await testIncompleteMap();
  await testVipCannotFallBackToRawText();
  console.log('PASS: shared OCR recovery/prewarm, batched glyph cache and final flush, complete map, no VIP raw fallback');
})().catch(error => {console.error(error); process.exitCode = 1;});
