// Exercise production Rule.run, chapter parsing, scheduling and manual gates.
// Only browser layout, HTTP and OCR boundaries are replaced; no site is contacted.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const fixtureSource = fs.readFileSync(path.join(__dirname, 'test-qidian-v34-access-qa.cjs'), 'utf8');
const boundary = fixtureSource.indexOf('\nconst tests=[];');
assert(boundary > 0);
const { fixture, until, drain, events, suite, deferred } = vm.runInNewContext(
  fixtureSource.slice(0, boundary) + '\n({fixture,until,drain,ids,events,suite,deferred})',
  { require, __dirname, AbortController, URL, console });
const ids = f => Array.from(f.state.starts, row => row.id);
const tests = [];
const test = (name, run) => tests.push({ name, run });
function assertManualCooldown(f,confirmedAt,requestAt,initialRun=false) {
  const continued=events(f).findLast(row=>row.event==='access_manual_continue');
  assert(continued); assert.equal(continued.baseWaitMs,60000);
  assert(continued.waitMs>=55000 && continued.waitMs<=65000);
  const elapsed=requestAt-confirmedAt;
  if (initialRun) assert(elapsed>=continued.waitMs && elapsed<=continued.waitMs+10000,'initial VIP pacing may add its ordinary 10s interval');
  else assert.equal(elapsed,continued.waitMs,'the observed request uses the same cooldown sample logged at Continue');
}

test('a genuine short WAF page waits without requests, then manually retries the blocked chapter and saves every later chapter', async () => {
  const configs = [{ id: 1, vip: true }, { id: 2, vip: true, block: true, missingMain: true }, { id: 3, vip: true }];
  const f = fixture(configs), run = f.run();
  await until(() => f.window.qidianAccessRecoveryGate);
  await drain();
  assert.deepEqual(ids(f), [1, 2]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.chapters[1].qidianAccessEvidence, 'blocked_page');
  const error = events(f).find(row => row.event === 'attempt_error' && row.chapterId === '2');
  assert(error);
  assert.equal(error.accessEvidence, 'blocked_page');
  assert.equal(error.frameState.accessKind, 'verification_required');
  assert.equal([...f.state.timers.values()].filter(timer => timer.ms === 600000).length, 0);
  f.state.now += 30 * 60 * 1000;
  f.tick(); await drain();
  assert.deepEqual(ids(f), [1, 2]);
  const confirmedAt = f.state.now;
  configs[1].block = false; configs[1].missingMain = false;
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  await run;
  assert.deepEqual(ids(f), [1, 2, 2, 3]);
  assertManualCooldown(f,confirmedAt,f.state.starts[2].at);
  assert.equal(f.book.downloadReport.savedCount, 3);
  assert.equal(f.book.downloadReport.missing.length, 0);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第1章', '第2章', '第3章']);
});

for (const status of [401, 403, 429]) test(`HTTP ${status} never retries or reaches the next chapter before explicit Continue`, async () => {
  const configs = [{ id: 1, vip: true, requestError: status }, { id: 2, vip: true }];
  const f = fixture(configs), run = f.run();
  await until(() => f.window.qidianAccessRecoveryGate); await drain();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.chapters[0].options.qidianErrorInfo.httpStatus, status);
  assert.equal(f.chapters[0].qidianAccessEvidence, 'http_status');
  f.state.now += 10 * 60 * 1000; f.tick(); await drain();
  assert.deepEqual(ids(f), [1]);
  delete configs[0].requestError;
  const confirmedAt = f.state.now;
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  await run;
  assert.deepEqual(ids(f), [1, 1, 2]);
  assertManualCooldown(f,confirmedAt,f.state.starts[1].at);
  assert.equal(f.book.downloadReport.savedCount, 2);
});

test('repeated manually cleared gates have two retries per chapter and still allow a later valid chapter', async () => {
  const f = fixture([{ id: 1, vip: true, requestError: 403 }, { id: 2, vip: true }]);
  const run = f.run();
  let previousGate;
  for (let count = 0; count < 3; count++) {
    await until(() => f.window.qidianAccessRecoveryGate && f.window.qidianAccessRecoveryGate !== previousGate);
    await drain();
    assert.equal(ids(f).length, count + 1);
    previousGate = f.window.qidianAccessRecoveryGate;
    assert.equal(previousGate.continue(), true);
  }
  await run;
  assert.deepEqual(ids(f), [1, 1, 1, 2]);
  assert.equal(f.chapters[0].status, suite.status.failed);
  assert.equal(f.chapters[0].qidianFailureKind, 'access');
  assert.equal(f.chapters[0].qidianNoAutoRetry, true);
  assert.equal(f.chapters[1].status, suite.status.saved);
  assert.equal(f.book.downloadReport.missing.length, 1);
  assert.equal(events(f).filter(row => row.event === 'access_chapter_retry').length, 2);
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 0);
});

test('an initial login page waits before building or requesting the chapter queue', async () => {
  const f = fixture([{ id: 1, vip: true }, { id: 2, vip: true }]);
  f.ctx.document.title = '账号登录';
  const run = f.run();
  await until(() => f.window.qidianAccessRecoveryGate); await drain();
  assert.deepEqual(ids(f), []);
  assert.equal(f.state.timers.size, 0);
  const gate = f.window.qidianAccessRecoveryGate;
  assert.equal(gate.continue(), false);
  f.ctx.document.title = '章节目录';
  f.tick(); await drain(); assert.deepEqual(ids(f), []);
  assert.equal(gate.continue(), true);
  const confirmedAt = f.state.now;
  await run;
  assert.deepEqual(ids(f), [1, 2]);
  assertManualCooldown(f,confirmedAt,f.state.starts[0].at,true);
  assert.equal(f.book.downloadReport.savedCount, 2);
});

test('a verification gate interrupts an unresolved OCR attempt and removes its watchdog before waiting', async () => {
  const f = fixture([{ id: 1, vip: true }, { id: 2, vip: true }]), inference = deferred();
  let inferenceStarted = false;
  f.ctx.ocrContent = async () => { inferenceStarted = true; return inference.promise; };
  const run = f.run();
  await until(() => inferenceStarted);
  assert([...f.state.timers.values()].some(timer => timer.ms === 600000));
  f.ctx.qidianPauseDownload('检测到网站验证，等待手动处理', { accessKind: 'verification_required', accessEvidence: 'visible_verification_dialog' });
  await drain();
  assert.equal([...f.state.timers.values()].filter(timer => timer.ms === 600000).length, 0);
  assert.deepEqual(ids(f), [1]);
  f.window.qidianAccessRecoveryGate.stop();
  await run;
  assert.equal(f.window.qidianAccessRecoveryEnabled, false);
  assert.equal(f.window.qidianAccessRecoveryGate, null);
  const logCount = f.state.logs.length;
  inference.resolve({ contentText: '章节正文'.repeat(1000), contentHTML: {} });
  await drain();
  assert.equal(f.state.logs.length, logCount);
  assert.deepEqual(ids(f), [1]);
});

test('isolated legacy fixtures retain the established immediate-abort behavior', async () => {
  const f = suite.fixture([{ id: 1, vip: true, requestError: 403 }, { id: 2, vip: true }]);
  await f.run();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.equal(f.window.qidianAccessRecoveryGate, undefined);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack ?? error); }
  }
  console.log(`${tests.length - failed}/${tests.length} manual access recovery checks passed`);
  if (failed) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
