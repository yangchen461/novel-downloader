// Optional native-canvas regression and reproducible LOCAL benchmark.
// Requires @napi-rs/canvas. No browser, Qidian traffic, remote fonts or OCR.
// Timings from this local renderer are NOT browser/download speed claims.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const {performance} = require('node:perf_hooks');
const {createCanvas, GlobalFonts} = require('@napi-rs/canvas');
const makeLegacy = require('./fixtures/legacy-qidian-fingerprint-v17.cjs');
const source = fs.readFileSync(path.join(__dirname,'novel-downloader-qidian-range.user.js'),'utf8');
const helpers = source.slice(source.indexOf('function qidianGlyphFingerprint('),source.indexOf('async function ocrContent('));
const logs=[];
const log=()=>({warn:m=>logs.push(m)});
const makeNew=(math=Math)=>new Function('Math','_log__WEBPACK_IMPORTED_MODULE_6___default',helpers+'\nreturn {single:qidianGlyphFingerprint,tiled:qidianGlyphFingerprints};')(math,log);
const old=makeLegacy(Math,log), next=makeNew();
GlobalFonts.registerFromPath(path.join(__dirname,'fixtures/synthetic-glyphs.ttf'),'QidianLocalTest');
const ctx=()=>createCanvas(80,96).getContext('2d',{willReadFrequently:true});
const chars=Array.from({length:800},(_,i)=>String.fromCodePoint(0x4e00+i));
const latin=Array.from({length:400},(_,i)=>String.fromCodePoint(0x21+i));
const comparisons=[];
for(const family of ['QidianLocalTest','sans-serif','serif','monospace']) {
  const glyphs=family==='QidianLocalTest'?chars:latin, a=ctx(),b=ctx();
  const expected=old.tiled(a,glyphs,family); const actual=next.tiled(b,glyphs,family);
  assert.deepEqual(actual,expected);
  comparisons.push({family,glyphs:glyphs.length,equal:true,stats:actual.qidianFingerprintStats});
}
const boundaries=[];
for(const count of [0,1,7,8,63,64,65,129]) {
  const a=ctx(),b=ctx(),glyphs=chars.slice(0,count);
  assert.deepEqual(next.tiled(b,glyphs,'QidianLocalTest'),old.tiled(a,glyphs,'QidianLocalTest'));
  boundaries.push(count);
}
const fallback=ctx(), get=fallback.getImageData.bind(fallback);
fallback.getImageData=(...args)=> {if(args[2]>80) throw Error('simulated tile failure');return get(...args)};
const fallbackMap=next.tiled(fallback,chars.slice(0,65),'QidianLocalTest');
assert.deepEqual(fallbackMap,old.tiled(ctx(),chars.slice(0,65),'QidianLocalTest'));
assert.equal(fallbackMap.qidianFingerprintStats.fallback,true);
console.log('PASS native canvas: 2000 real glyph hashes match .17, 8 tile boundaries, legacy fallback and diagnostics.');
console.log(JSON.stringify({comparisons,boundaries,fallback:true},null,2));
if(process.argv.includes('--benchmark')) {
  const median=a=>[...a].sort((a,b)=>a-b)[Math.floor(a.length/2)];
  function bench(label,math) {
    const before=makeLegacy(math,log),after=makeNew(math),a=ctx(),b=ctx();
    const oldMs=[],newMs=[];
    for(let i=0;i<2;i++){before.tiled(a,chars,'QidianLocalTest');after.tiled(b,chars,'QidianLocalTest');}
    let diagnostic;
    for(let i=0;i<5;i++) {
      const runOld=()=>{const t=performance.now();before.tiled(a,chars,'QidianLocalTest');oldMs.push(performance.now()-t)};
      const runNew=()=>{const t=performance.now();diagnostic=after.tiled(b,chars,'QidianLocalTest').qidianFingerprintStats;newMs.push(performance.now()-t)};
      if(i%2){runNew();runOld()}else{runOld();runNew()}
    }
    return {label,glyphs:800,oldMs,newMs,oldMedian:median(oldMs),newMedian:median(newMs),diagnostic};
  }
  const native=bench('native Math; local NAPI canvas',Math);
  const proxyMath=new Proxy(Math,{get:(target,key)=>Reflect.get(target,key,target)});
  const proxy=bench('synthetic Math proxy; mechanism check ONLY, not a Tampermonkey measurement',proxyMath);
  console.log(JSON.stringify({benchmark:[native,proxy],note:'Offline local timings only; user browser must verify impact from QidianFingerprintStats logs.'},null,2));
}
