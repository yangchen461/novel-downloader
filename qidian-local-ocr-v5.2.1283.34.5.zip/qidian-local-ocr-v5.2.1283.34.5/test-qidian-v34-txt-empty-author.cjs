// Exercise shipped TXT export/import and checkpoint code. All GM writes stay in memory.
// Optional --actual-txt / --actual-log inputs are read-only and never printed.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const fixtureSource = fs.readFileSync(path.join(__dirname, 'test-qidian-v34-glyph-tolerance.cjs'), 'utf8');
const fixtureEnd = fixtureSource.search(/^const tests\s*=\s*\[\];/m);
assert(fixtureEnd > 0);
const { fixture } = vm.runInNewContext(fixtureSource.slice(0, fixtureEnd) + '\n({fixture});',
  { require, __dirname, AbortController, URL, console, structuredClone, Blob, setTimeout, clearTimeout });
const EMPTY_AUTHOR = '\n\n----------\n\n';
const TRIMMED_EMPTY_AUTHOR = '\n\n----------';
const FOOTER = '\n===== 起点下载器OCR占位续传记录 v2 =====\n';
const tests = [];
const test = (name, run) => tests.push({ name, run });

async function exported({ tail = EMPTY_AUTHOR, transform } = {}) {
  const f = fixture(), result = await f.ocr(), chapter = f.chapter(result);
  let body = result.contentText;
  if (transform) {
    body = transform(body);
    const metadata = structuredClone(result.qidianGlyphTolerance);
    metadata.glyphs[0].positions = Array.from(body.matchAll(/□/g), match => match.index);
    metadata.bodyDigest = f.ctx.qidianCheckpointDigest(body);
    chapter.options.qidianGlyphTolerance = metadata;
  }
  chapter.options.qidianBodyLength = body.length;
  chapter.contentText = body + tail;
  f.export([chapter]);
  return { f, body, chapter, output: (await f.outputs[0].blob.text()).replace(/\r\n?/g, '\n') };
}
async function imported(sample, input = sample.output) {
  const f = fixture({ missing: 0 });
  const chapter = { ...sample.chapter, contentText: null, options: { expectedChars: 2000 } };
  f.book.chapters = [chapter];
  const session = await f.session();
  const result = await f.ctx.qidianCheckpointImportTxt(session, f.book, input);
  const record = await f.ctx.qidianCheckpointRestore(session, chapter);
  return { f, chapter, session, result, record };
}
function changeFooter(input, mutate) {
  const index = input.lastIndexOf(FOOTER);
  assert(index >= 0);
  const records = input.slice(index + FOOTER.length).trim().split('\n').map(line => JSON.parse(line));
  records.forEach(mutate);
  return input.slice(0, index + FOOTER.length) + records.map(record => JSON.stringify(record)).join('\n') + '\n';
}
function assertRejected(value) {
  assert.equal(value.result.imported, 0);
  assert.equal(value.result.skipped, 1);
  assert.equal(value.result.incomplete, 1);
  assert.equal(value.record, null);
  assert.equal([...value.f.storage.keys()].filter(key => key.includes(':chapter:')).length, 0);
}

test('empty generated author suffix round-trips all text with an explicit digest-bound body', async () => {
  const sample = await exported(), value = await imported(sample);
  assert.equal(value.result.imported, 1);
  assert.equal(value.result.incomplete, 0);
  assert.equal(value.record.text, sample.chapter.contentText.trim());
  assert(value.record.text.endsWith(TRIMMED_EMPTY_AUTHOR));
  assert.equal(value.record.bodyLength, sample.body.length);
  assert.equal(value.record.bodyBoundarySource, 'explicit');
  assert.equal(value.record.bodyDigest, sample.chapter.options.qidianGlyphTolerance.bodyDigest);
  assert(value.f.ctx.qidianValidateGlyphTolerance(value.record.text.slice(0, value.record.bodyLength), value.record.qidianGlyphTolerance));
  value.f.export([{ ...value.chapter, contentText: value.record.text,
    options: { expectedChars: 2000, qidianBodyLength: value.record.bodyLength, qidianGlyphTolerance: value.record.qidianGlyphTolerance } }]);
  const second = await imported(sample, await value.f.outputs[0].blob.text());
  assert.equal(second.result.imported, 1);
  assert.equal(second.record.text, value.record.text);
  assert.equal(second.record.bodyLength, value.record.bodyLength);
});

test('a genuine story divider at the end remains part of the validated body', async () => {
  const sample = await exported({ tail: '', transform: body => body + TRIMMED_EMPTY_AUTHOR });
  const value = await imported(sample);
  assert.equal(value.result.imported, 1);
  assert.equal(value.record.text, sample.body);
  assert.equal(value.record.bodyLength, sample.body.length);
  assert.equal(value.record.bodyBoundarySource, 'full-text');
});

test('a genuine embedded divider remains in the body before an empty author suffix', async () => {
  const sample = await exported({ transform: body => body.slice(0, 1000) + EMPTY_AUTHOR + body.slice(1000) });
  const value = await imported(sample);
  assert.equal(value.result.imported, 1);
  assert.equal(value.record.text, sample.chapter.contentText.trim());
  assert.equal(value.record.bodyLength, sample.body.length);
  assert.equal(value.record.bodyDigest, sample.chapter.options.qidianGlyphTolerance.bodyDigest);
  assert(value.record.text.slice(0, value.record.bodyLength).includes(EMPTY_AUTHOR));
});

test('non-empty generated author notes keep the existing inferred boundary', async () => {
  const sample = await exported({ tail: EMPTY_AUTHOR + '测试作者留言' }), value = await imported(sample);
  assert.equal(value.result.imported, 1);
  assert.equal(value.record.text, sample.chapter.contentText);
  assert.equal(value.record.bodyLength, sample.body.length);
  assert.equal(value.record.bodyBoundarySource, 'inferred-author-separator');
});

test('digest, placeholder positions and counts must all validate before boundary recovery', async () => {
  const sample = await exported();
  for (const mutate of [
    record => { record.qidianGlyphTolerance.bodyDigest = record.qidianGlyphTolerance.bodyDigest.replace(/:[^:]+$/, ':00000000'); },
    record => { record.qidianGlyphTolerance.bodyDigest = '999999999999999999999:00000000:00000000'; },
    record => { record.qidianGlyphTolerance.glyphs[0].positions[0]--; },
    record => { record.qidianGlyphTolerance.occurrenceCount++; }
  ]) assertRejected(await imported(sample, changeFooter(sample.output, mutate)));
});

test('similar dividers or text after the empty divider cannot authorize boundary recovery', async () => {
  for (const tail of ['\n----------', '\n\n-----------', '\n\n----------X', TRIMMED_EMPTY_AUTHOR + '\n正文残留']) {
    assertRejected(await imported(await exported({ tail })));
  }
});

test('a matching footer does not bypass final body completeness checks', async () => {
  const sample = await exported(), short = '正'.repeat(100) + '□';
  const input = changeFooter(sample.output.replace(sample.body, short), record => {
    record.qidianGlyphTolerance.bodyDigest = sample.f.ctx.qidianCheckpointDigest(short);
    record.qidianGlyphTolerance.glyphs[0].positions = [100];
  });
  assertRejected(await imported(sample, input));
});

const txtFlag = process.argv.indexOf('--actual-txt'), logFlag = process.argv.indexOf('--actual-log');
if (txtFlag >= 0 || logFlag >= 0) {
  assert(txtFlag >= 0 && logFlag >= 0 && process.argv[txtFlag + 1] && process.argv[logFlag + 1], 'Both read-only actual input paths are required');
  test('actual user TXT imports and restores all 745 chapters including every original glyph record', async () => {
    const input = fs.readFileSync(process.argv[txtFlag + 1], 'utf8').replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
    const rows = [];
    for (const line of fs.readFileSync(process.argv[logFlag + 1], 'utf8').split(/\r?\n/)) {
      const index = line.indexOf('[QidianDebug] ');
      if (index < 0) continue;
      try { rows.push(JSON.parse(line.slice(index + 14))); } catch (_) {}
    }
    const selection = rows.findLast(row => row.event === 'selection_result');
    assert.equal(selection?.savedCount, 745); assert.equal(selection?.selectedCount, 754);
    const formatRows = rows.filter(row => row.event === 'chapter_stage_start' && row.stage === 'txt_format');
    assert.equal(formatRows.length, 745);
    const expectedById = new Map();
    for (const row of rows) if (row.chapterId && Number.isFinite(row.quality?.expectedChars) && row.quality.expectedChars > 0) {
      expectedById.set(row.chapterId, row.quality.expectedChars);
    }
    const f = fixture({ missing: 0 });
    Object.assign(f.book, {
      bookUrl: input.match(/^原始网址[：:]([^\n]*)$/m)[1],
      bookname: input.match(/^题名[：:]([^\n]*)$/m)[1],
      author: input.match(/^作者[：:]([^\n]*)$/m)[1]
    });
    const chapterFor = row => ({
      chapterUrl: `https://www.qidian.com/chapter/1044724292/${row.chapterId}/`,
      chapterName: row.title, qidianCatalogTitle: row.title, chapterNumber: row.catalogNumber,
      isVIP: row.mode === 'vip-ocr', status: 0, options: { expectedChars: expectedById.get(row.chapterId) ?? 0 }
    });
    f.book.chapters = [...formatRows.map(chapterFor), ...selection.missing.map(chapterFor)].sort((a, b) => a.chapterNumber - b.chapterNumber);
    assert.equal(new Set(f.book.chapters.map(chapter => chapter.chapterUrl)).size, 754);
    const session = await f.session();
    const result = await f.ctx.qidianCheckpointImportTxt(session, f.book, input);
    assert.equal(result.parsed, 745); assert.equal(result.imported, 745);
    for (const field of ['skipped', 'ambiguous', 'incomplete', 'storageFailed']) assert.equal(result[field], 0, field);
    let restored = 0, tolerated = 0;
    const originalGlyphs = new Map(input.slice(input.lastIndexOf(FOOTER) + FOOTER.length).trim()
      .split('\n').map(line => JSON.parse(line)).map(row => [row.chapterUrl, row.qidianGlyphTolerance]));
    assert(originalGlyphs.size > 0);
    for (const chapter of f.book.chapters) {
      const record = await f.ctx.qidianCheckpointRestore(session, chapter);
      if (!record) { assert(selection.missing.some(row => row.catalogNumber === chapter.chapterNumber)); continue; }
      restored++;
      assert.equal(record.bodyDigest, f.ctx.qidianCheckpointDigest(record.text.slice(0, record.bodyLength)));
      if (record.qidianGlyphTolerance) {
        tolerated++;
        const original = originalGlyphs.get(chapter.chapterUrl);
        assert(original);
        assert.equal(record.bodyLength, Number(original.bodyDigest.split(':')[0]));
        assert.equal(JSON.stringify(record.qidianGlyphTolerance), JSON.stringify(original));
        assert.equal(record.bodyBoundarySource, 'explicit');
        assert(record.text.endsWith(TRIMMED_EMPTY_AUTHOR));
        assert(f.ctx.qidianValidateGlyphTolerance(record.text.slice(0, record.bodyLength), record.qidianGlyphTolerance));
      }
    }
    assert.equal(restored, 745); assert.equal(tolerated, originalGlyphs.size);
  });
}

(async () => {
  let passed = 0;
  for (const entry of tests) {
    try { await entry.run(); passed++; console.log('PASS ' + entry.name); }
    catch (error) { console.error('FAIL ' + entry.name); console.error(error); process.exitCode = 1; }
  }
  console.log(`${passed}/${tests.length} TXT empty-author boundary checks passed`);
})();
