// Exercise shipped cancellation, parser, scheduler, and OCR-cache paths.
// Only clocks, DOM/network boundaries, and the physical OCR engine are fakes.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const dir = __dirname;
const source = fs.readFileSync(path.join(dir, 'novel-downloader-qidian-range.user.js'), 'utf8');
const fixtureSource = fs.readFileSync(path.join(dir, 'test-qidian-v19-resilience.cjs'), 'utf8');
const suite = vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('const tests=[];')) + '\n({fixture,status})',
  { require, __dirname: dir, AbortController, URL, console });
const take = (start, end) => {
  const a = source.indexOf(start), b = source.indexOf(end, a);
  assert(a >= 0 && b > a, start);
  return source.slice(a, b);
};
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const deferred = () => {
  let resolve, reject;
  const promise = new Promise((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
};
async function until(predicate) {
  for (let i = 0; i < 200; i++) { if (predicate()) return; await Promise.resolve(); }
  assert.fail('test boundary was not reached');
}
async function drain() { for (let i = 0; i < 80; i++) await Promise.resolve(); }
function watchdog(f) {
  const timer = [...f.state.timers.values()].find(item => item.ms === 600000);
  assert(timer, 'the real per-chapter watchdog must be installed');
  f.state.now += timer.ms; timer.fn();
}
const tests = [];
const test = (name, run) => tests.push({ name, run });

test('page watchdog retires only its chapter; a late access response cannot pause a later chapter', async () => {
  const f = suite.fixture([{ id: 1, vip: false }, { id: 2, vip: false }]);
  const pending = deferred();
  const http = f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__;
  const realHtml = http.pG;
  let started = false, oldOptions;
  const firstParser = f.chapters[0].chapterParse;
  f.chapters[0].chapterParse = (...args) => { oldOptions = args[5]; return firstParser(...args); };
  http.pG = url => {
    if (url.endsWith('/1')) { started = true; return pending.promise; }
    return realHtml(url);
  };
  const run = f.run(); await until(() => started); watchdog(f); await run;
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.chapters[0].status, suite.status.failed);
  assert.equal(f.chapters[0].qidianNoAutoRetry, true);
  assert.equal(f.chapters[0].options.qidianErrorInfo.errorName, 'QidianChapterTimeoutError');
  assert.equal(f.chapters[1].status, suite.status.saved);
  const beforeProgress = JSON.stringify(f.window.qidianProgressState);
  const beforeDiagnostics = JSON.stringify(f.chapters[0].options.qidianErrorInfo);
  const beforeLogs = f.state.logs.length;
  pending.reject(Object.assign(new Error('HTTP 403'), { status: 403 })); await drain();
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(JSON.stringify(f.window.qidianProgressState), beforeProgress);
  assert.equal(JSON.stringify(f.chapters[0].options.qidianErrorInfo), beforeDiagnostics);
  assert.equal(f.state.logs.length, beforeLogs, 'retired attempt cannot add diagnostics to the active run');
  assert.equal(oldOptions.qidianAttemptScope.cancelled, true);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第2章']);
});

test('manual restart replaces options while an old page result stays isolated', async () => {
  const f = suite.fixture([{ id: 1, vip: false }, { id: 2, vip: false }]);
  const pending = deferred(), http = f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__;
  const realHtml = http.pG;
  let started = false;
  http.pG = url => url.endsWith('/1') ? (started = true, pending.promise) : realHtml(url);
  const run = f.run(); await until(() => started);
  const oldOptions = f.chapters[0].options;
  watchdog(f); await run;
  http.pG = realHtml;
  f.chapters[0].status = suite.status.pending;
  f.chapters[0].retryTime = 0;
  await f.run();
  assert.equal(f.chapters[0].status, suite.status.saved);
  assert.notEqual(f.chapters[0].options, oldOptions);
  assert.equal(oldOptions.qidianAttemptScope.cancelled, true);
  const body = f.chapters[0].contentText, progress = JSON.stringify(f.window.qidianProgressState);
  const logs = f.state.logs.length;
  pending.resolve({ title: '安全验证', body: { innerText: '请完成安全验证' }, querySelector: () => null });
  await drain();
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.chapters[0].contentText, body);
  assert.equal(JSON.stringify(f.window.qidianProgressState), progress);
  assert.equal(f.state.logs.length, logs);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第2章', '第1章']);
});

test('OCR watchdog promptly detaches its loaded frame and ignores its late body', async () => {
  const f = suite.fixture([{ id: 1, vip: true }, { id: 2, vip: false }]);
  const pending = deferred(); let started = false;
  f.ctx.ocrContent = () => { started = true; return pending.promise; };
  const run = f.run(); await until(() => started); watchdog(f);
  assert.equal(f.state.removed, 1, 'watchdog cleanup removes the owned reader immediately');
  assert.equal(f.window.qidianActiveReaderDocument, null);
  await run;
  assert.equal(f.chapters[1].status, suite.status.saved);
  const logs = f.state.logs.length, progress = JSON.stringify(f.window.qidianProgressState);
  pending.resolve({ contentText: '迟到正文'.repeat(1000), contentHTML: {} }); await drain();
  assert.equal(f.chapters[0].contentText, null);
  assert.equal(f.chapters[0].status, suite.status.failed);
  assert.equal(f.state.logs.length, logs);
  assert.equal(JSON.stringify(f.window.qidianProgressState), progress);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第2章']);
});

function ocrFixture() {
  const cache = new Map([['fp:甲', '甲']]);
  const messages = [], pending = deferred();
  let calls = 0, active = 0, maxActive = 0;
  const window = { stopController: new AbortController() };
  window.stopFlag = window.stopController.signal;
  const document = { createElement() {
    const canvas = { width: 0, height: 0, drawn: [] };
    canvas.getContext = () => ({ canvas, setTransform() {}, fillRect() { canvas.drawn = []; }, fillText(ch) { canvas.drawn.push(ch); } });
    return canvas;
  } };
  const logger = { info: text => messages.push(text), warn: text => messages.push(text), error: text => messages.push(text) };
  const ctx = vm.createContext({ window, document, Date, URL, AbortController,
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => logger,
    qidianRestoreGlyphCache() {}, qidianGlyphCache: cache, qidianNewGlyphsSincePersist: 0,
    QIDIAN_GLYPH_CACHE_LIMIT: 30000,
    qidianGlyphFingerprints: (_, chars) => new Map(chars.map(ch => [ch, `fp:${ch}`])),
    canvasToUint8Array: canvas => canvas.drawn.join(''),
    qidianOcrDecoder: { async decodeFullText(data) {
      calls++; active++; maxActive = Math.max(maxActive, active);
      try { return calls === 1 ? await pending.promise : data; } finally { active--; }
    } }
  });
  vm.runInContext(globals + take('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars)', 'function extractRenderedText('), ctx);
  const options = title => { const value = { qidianDiagnostic: { title } }; ctx.qidianCreateAttempt(value); return value; };
  return { ctx, cache, messages, pending, options,
    build: (text, context) => ctx.buildFontDecodeMap(document, {}, 'fixture', [...text], [], context),
    calls: () => calls, maxActive: () => maxActive };
}

test('uncancellable inference blocks only new engine work, preserves cached chapters, and clears on settlement', async () => {
  const f = ocrFixture(), old = f.options('旧章');
  const oldBuild = f.build('乙', old);
  const oldRejected = assert.rejects(oldBuild, error => error.name === 'QidianChapterTimeoutError');
  await until(() => f.calls() === 1);
  const timeout = Object.assign(new Error('chapter timeout'), { name: 'QidianChapterTimeoutError' });
  old.qidianAttemptScope.cancel(timeout);
  const cached = await f.build('甲', f.options('缓存章'));
  assert.equal(cached.get('甲'), '甲'); assert.equal(f.calls(), 1);
  const busy = f.options('待补章');
  await assert.rejects(f.build('丙', busy), error => error.name === 'QidianOcrBusyError');
  assert.equal(f.calls(), 1); assert.equal(f.ctx.window.stopFlag.aborted, false);
  const entries = JSON.stringify([...f.cache]), progress = JSON.stringify(f.ctx.window.qidianProgressState);
  const logs = f.messages.length;
  f.pending.resolve('乙'); await oldRejected;
  assert.equal(JSON.stringify([...f.cache]), entries, 'late inference cannot add old glyphs to cache');
  assert.equal(JSON.stringify(f.ctx.window.qidianProgressState), progress);
  assert.equal(f.messages.length, logs, 'late inference cannot emit stale chapter metrics');
  const recovered = await f.build('丙', busy);
  assert.equal(recovered.get('丙'), '丙'); assert.equal(f.calls(), 2);
  assert.equal(f.maxActive(), 1, 'no concurrent inference or replacement engines');
  assert.equal(f.ctx.qidianRunOcrAttempt.pending, null);
});

test('busy chapter has one immediate attempt and can recover in the bounded deferred pass', async () => {
  const f = suite.fixture([{ id: 1, vip: true }, { id: 2, vip: false }]);
  const realOcr = f.ctx.ocrContent; let calls = 0;
  f.ctx.ocrContent = main => {
    if (++calls === 1) throw Object.assign(new Error('engine still running'), { name: 'QidianOcrBusyError' });
    return realOcr(main);
  };
  await f.run();
  assert.deepEqual(Array.from(f.state.starts, row => row.id), [1, 2, 1]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert(f.chapters.every(chapter => chapter.status === suite.status.saved));
});

test('current explicit access denial still cancels the task and preserves HTTP evidence', async () => {
  const f = suite.fixture([{ id: 1, vip: true, requestError: 403 }, { id: 2, vip: false }]);
  await f.run();
  assert.deepEqual(Array.from(f.state.starts, row => row.id), [1]);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.equal(f.chapters[0].options.qidianErrorInfo.httpStatus, 403);
  assert.equal(f.chapters[0].options.qidianErrorInfo.errorName, 'QidianAccessError');
  assert.equal(f.chapters[1].status, suite.status.pending);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack); }
  }
  console.log(`${tests.length - failed}/${tests.length} v34 watchdog isolation checks passed`);
  if (failed) process.exitCode = 1;
})();
