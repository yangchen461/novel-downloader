#!/usr/bin/env python3
"""v29 local OCR diagnostics: whitelist, privacy, and outcome isolation."""
import importlib.util
import json
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("analyzer", Path(__file__).with_name("analyze-qidian-debug.py"))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def event(name, **fields):
    return dict(schema=2, version="5.2.1283.29", runId="synthetic-v29", event=name, **fields)


def analyze(*rows):
    return A.analyze("\n".join("[QidianDebug] " + json.dumps(row) for row in rows))


def run(*rows):
    return analyze(*rows)["runs"][0]


class V29AnalyzerTests(unittest.TestCase):
    def test_partial_batch_retains_counts_and_does_not_fail_chapter(self):
        result = run(event("ocr_batch_metrics", chapterId="2", phase="batch", reasonCode="aligned_partial",
                           inputGlyphCount=30, outputRegionCount=29, acceptedGlyphCount=28,
                           unresolvedBatchGlyphs=2, splitDepth=0, durationMs=740),
                     event("chapter_result", chapterId="2", statusName="saved"))
        diagnostic = result["ocrBatchMetrics"][0]
        self.assertEqual(diagnostic["acceptedGlyphCount"], 28)
        self.assertEqual(diagnostic["unresolvedBatchGlyphs"], 2)
        self.assertEqual(diagnostic["reasonCode"], "aligned_partial")
        self.assertEqual(diagnostic["phase"], "batch")
        self.assertEqual(result["failures"], [])
        self.assertEqual(result["summary"]["success"], 1)
        self.assertFalse(result["chapters"][0]["recovered"])

    def test_all_batch_reasons_are_fixed_enums(self):
        reasons = ("aligned_partial", "aligned_complete", "missing_regions", "invalid_geometry", "duplicate_row",
                   "cross_row", "out_of_bounds", "missing_row", "invalid_output", "too_many_regions", "text_fallback", "text_mismatch")
        result = run(*(event("ocr_batch_metrics", reasonCode=value, phase="batch") for value in reasons))
        self.assertEqual([row["reasonCode"] for row in result["ocrBatchMetrics"]], list(reasons))
        self.assertEqual(result["failures"], [])
        self.assertEqual(result["summary"]["failed"], 0)

    def test_batch_invalid_categories_are_omitted(self):
        result = run(event("ocr_batch_metrics", reasonCode="CANDIDATE_SECRET", phase="BODY_SECRET"),
                     event("ocr_batch_metrics", reasonCode=[], phase={}))
        self.assertNotIn("SECRET", json.dumps(result))
        self.assertTrue(all("reasonCode" not in row and "phase" not in row for row in result["ocrBatchMetrics"]))

    def test_batch_privacy_drops_ocr_outputs_candidates_geometry_and_nested_errors(self):
        result = run(event("ocr_batch_metrics", reasonCode="text_mismatch", inputGlyphCount=30,
                           text="OCR_SECRET", ocrText="OCR_SECRET", candidates=["CANDIDATE_SECRET"],
                           boxes=[[1, 2]], image="IMAGE_SECRET", body="BODY_SECRET", fontFamily="FONT_SECRET",
                           message="ERROR_SECRET", reason="ERROR_SECRET", stack="STACK_SECRET",
                           error={"message": "ERROR_SECRET"}, quality={"reason": "BODY_SECRET"},
                           summary={"message": "SUMMARY_SECRET"}, frameState={"message": "NESTED_SECRET"},
                           readerDiagnostics={"controls": [{"labelKind": "chapter_purchase"}]}))
        self.assertNotIn("SECRET", json.dumps(result))
        row = result["ocrBatchMetrics"][0]
        for key in ("text", "ocrText", "candidates", "boxes", "image", "body", "fontFamily", "message", "reason", "stack",
                    "error", "quality", "summary", "frameState", "readerDiagnostics"):
            self.assertNotIn(key, row)

    def test_recovery_retains_only_source_codepoint_and_safe_context_counts(self):
        report = analyze(event("ocr_recovery_result", chapterId="2", sourceCodepoint="U+9602", reasonCode="isolated_agreement",
                               contextCount=2, nearbyContextCount=1, recoveryCalls=4, durationMs=200, success=True))
        result = report["runs"][0]["ocrRecoveryResults"][0]
        self.assertEqual(result["sourceCodepoint"], "U+9602")
        self.assertEqual(result["contextCount"], 2)
        self.assertEqual(result["nearbyContextCount"], 1)
        self.assertTrue(result["success"])
        self.assertEqual(report["malformedFields"], 0)

    def test_all_recovery_reasons_are_fixed_enums(self):
        reasons = ("isolated_agreement", "anchored_agreement", "isolated_conflict", "anchored_conflict", "no_valid_reading",
                   "insufficient_anchors", "call_budget", "time_budget", "stopped")
        result = run(*(event("ocr_recovery_result", reasonCode=value, success=False) for value in reasons))
        self.assertEqual([row["reasonCode"] for row in result["ocrRecoveryResults"]], list(reasons))
        self.assertEqual(result["failures"], [])
        self.assertEqual(result["retryStats"]["attemptErrors"], 0)

    def test_conflict_diagnostic_does_not_infer_unsubscribed_or_page_failure(self):
        result = run(event("ocr_recovery_result", chapterId="2", sourceCodepoint="U+3FF6", success=False,
                           reasonCode="anchored_conflict", accessKind="unsubscribed", skipReason="unsubscribed",
                           errorCode="chapter_unsubscribed", statusName="failed", outcome="failed"))
        self.assertEqual(result["chapters"][0]["finalOutcome"], "unknown")
        self.assertEqual(result["chapters"][0]["failures"], [])
        self.assertEqual(result["summary"]["failed"], 0)
        self.assertEqual(result["summary"]["skippedCount"], 0)

    def test_recovery_failure_and_real_attempt_error_remain_distinct(self):
        result = run(event("ocr_recovery_result", chapterId="2", sourceCodepoint="U+480D", success=False, reasonCode="isolated_conflict"),
                     event("attempt_error", chapterId="2", errorCode="glyph_unresolved", failureKind="local", stage="ocr"),
                     event("chapter_result", chapterId="2", statusName="failed", errorCode="glyph_unresolved"),
                     event("chapter_result", chapterId="3", statusName="saved"))
        self.assertEqual(len(result["ocrRecoveryResults"]), 1)
        self.assertEqual(len(result["failures"]), 2)
        self.assertEqual(result["retryStats"]["attemptErrors"], 1)
        self.assertEqual(result["summary"]["failed"], 1)
        self.assertEqual(result["summary"]["success"], 1)

    def test_recovery_privacy_drops_decoded_candidates_anchors_and_raw_payloads(self):
        result = run(event("ocr_recovery_result", sourceCodepoint="U+6CE1", success=False, reasonCode="no_valid_reading",
                           candidates=["CANDIDATE_SECRET"], isolatedReading="READING_SECRET", anchoredReading="READING_SECRET",
                           anchorText="BODY_SECRET", context="BODY_SECRET", codepoints=["U+4E00"],
                           message="MESSAGE_SECRET", stack="STACK_SECRET", error={"message": "ERROR_SECRET"},
                           boxes=[[1, 2]], frameState={"reason": "BODY_SECRET"}))
        self.assertNotIn("SECRET", json.dumps(result))
        self.assertNotIn("boxes", result["ocrRecoveryResults"][0])

    def test_cjk_and_private_use_source_codepoints_are_allowed(self):
        values = ("U+3400", "U+4E00", "U+F900", "U+20000", "U+2F800", "U+31350", "U+E000", "U+F8FF", "U+F0000", "U+10FFFD")
        result = run(*(event("ocr_recovery_result", sourceCodepoint=value) for value in values))
        self.assertEqual([row["sourceCodepoint"] for row in result["ocrRecoveryResults"]], list(values))

    def test_non_cjk_malformed_or_noncharacter_source_codepoints_are_dropped(self):
        values = ("U+0041", "U+0020", "U+D800", "U+FFFF", "U+FFFFE", "U+10FFFF", "U+110000", "U+3ff6",
                  "U+004E00 BODY_SECRET", "BODY_SECRET", "汉", 0x4E00, [], {})
        result = run(*(event("ocr_recovery_result", sourceCodepoint=value) for value in values))
        self.assertTrue(all("sourceCodepoint" not in row for row in result["ocrRecoveryResults"]))
        self.assertNotIn("SECRET", json.dumps(result))

    def test_success_is_strict_boolean_and_legacy_success_count_is_preserved(self):
        result = run(*(event("ocr_recovery_result", success=value) for value in (True, False, 1, 0, "false", None)),
                     event("run_summary", queued=2, success=1, failed=1, aborted=0, unprocessed=0, restored=0, skippedCount=0))
        rows = result["ocrRecoveryResults"]
        self.assertTrue(rows[0]["success"])
        self.assertFalse(rows[1]["success"])
        self.assertTrue(all("success" not in row for row in rows[2:]))
        self.assertEqual(result["summary"]["success"], 1)
        self.assertTrue(result["summary"]["countsComplete"])

    def test_new_ocr_measurement_counters_cache_sizes_profile_and_completion_are_retained(self):
        fields = dict(batchCalls=41, batchSplitCalls=2, singleCalls=3, alignedBatchCalls=40, partialBatchGlyphs=28, omittedBatchEvents=9,
                      glyphCacheSize=16245, glyphCacheLimit=30000, mappingCompleted=True,
                      renderProfile="custom_family", recoveryCalls=4, recoveryMs=400, totalMs=80000)
        result = run(event("ocr_metrics", chapterId="2", uniqueGlyphs=1227, cachedGlyphs=4, **fields))
        row = result["chapters"][0]["timeline"][0]
        for key, value in fields.items():
            self.assertEqual(row[key], value)
        self.assertEqual(result["ocrMetrics"]["weightedCacheHitRatio"], 4 / 1227)

    def test_profile_is_fixed_enum_and_optional_kind_object_drops_family_details(self):
        profiles = ("default_family", "custom_family", "unknown", {"kind": "custom_family", "fontFamily": "FONT_SECRET"},
                    "FONT_SECRET", {"kind": "FONT_SECRET"}, [], {"kind": []})
        result = run(*(event("ocr_metrics", chapterId=str(i), renderProfile=value) for i, value in enumerate(profiles)))
        rows = [chapter["timeline"][0] for chapter in result["chapters"]]
        self.assertEqual([row["renderProfile"] for row in rows[:4]], ["default_family", "custom_family", "unknown", "custom_family"])
        self.assertTrue(all("renderProfile" not in row for row in rows[4:]))
        self.assertNotIn("SECRET", json.dumps(result))

    def test_malformed_numeric_counts_and_mapping_boolean_are_ignored(self):
        row = A.sanitize(event("ocr_metrics", batchCalls=True, batchSplitCalls=-1, singleCalls="3", alignedBatchCalls=float("nan"),
                               partialBatchGlyphs=[], glyphCacheSize={}, glyphCacheLimit=float("inf"), mappingCompleted="true"))
        self.assertTrue(all(key not in row for key in ("batchCalls", "batchSplitCalls", "singleCalls", "alignedBatchCalls",
                                                      "partialBatchGlyphs", "glyphCacheSize", "glyphCacheLimit", "mappingCompleted")))
        json.dumps(row, allow_nan=False)

    def test_diagnostic_order_is_file_order_with_sequence_warnings(self):
        result = run(event("ocr_batch_metrics", chapterId="2", seq=5, acceptedGlyphCount=28),
                     event("ocr_recovery_result", chapterId="2", seq=3, sourceCodepoint="U+9602", success=True),
                     event("ocr_batch_metrics", chapterId="2", seq=5, acceptedGlyphCount=1))
        self.assertEqual([row["seq"] for row in result["chapters"][0]["timeline"]], [5, 3, 5])
        self.assertEqual([row["acceptedGlyphCount"] for row in result["ocrBatchMetrics"]], [28, 1])
        self.assertEqual(result["sequenceDiagnostics"]["duplicateSequences"], [5])
        self.assertEqual(result["sequenceDiagnostics"]["outOfOrderTransitions"], 1)

    def test_schema_one_and_absent_v29_diagnostics_remain_compatible(self):
        legacy = event("ocr_metrics", chapterId="2", uniqueGlyphs=10, cachedGlyphs=8, ocrCalls=1)
        legacy["schema"] = 1
        result = run(legacy, event("chapter_result", chapterId="2", statusName="saved"))
        self.assertEqual(result["ocrMetrics"]["weightedCacheHitRatio"], .8)
        self.assertEqual(result["ocrBatchMetrics"], [])
        self.assertEqual(result["ocrRecoveryResults"], [])
        self.assertEqual(result["summary"]["success"], 1)


if __name__ == "__main__":
    unittest.main()
