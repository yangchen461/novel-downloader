// Exercise shipped Rule.run, TXT export and notices. No network request or
// Qidian access is made; alert throws so modal regressions fail immediately.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a,b,from=0) {
  const start=src.indexOf(a,from),end=src.indexOf(b,start);
  assert(start>=0&&end>start,`Missing shipped boundary ${a}`);
  return src.slice(start,end);
}
const globals=take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode=take('class ChapterAbortError','\n\n/***/ },');
const runCode=take('  async run() {','\n  async preHook()',src.indexOf('class Rule'));
const txtCode=take('class TXT extends Options',';// ./src/save/raw.ts');
const logCode=take('if (_setting__WEBPACK_IMPORTED_MODULE_2__','\n\n\n/***/ },',src.indexOf('/***/ "./src/log.ts"'));
const staticSaveLogCode=take('  static saveLog() {','  async addChapter(',src.indexOf('class SaveBook'));
const statuses={pending:0,downloading:1,failed:2,finished:3,aborted:4,saved:5};
const body='PRIVATE_BODY_MUST_NOT_APPEAR_IN_DEBUG_'+'章节内容完整，中文校验正常。'.repeat(200);
class Options {
  genMetaDateTxt(){return '书籍元数据';}
  getchapterName(chapter){return chapter.chapterName;}
  genSectionText(section){return `分卷：${section}`;}
  genChapterText(name,text){return `${name}\n${text}`;}
  chapterSort(a,b){return a.chapterNumber-b.chapterNumber;}
}
function domNode(tag='div') {
  return {tagName:tag.toUpperCase(),style:{},children:[],attributes:{},
    appendChild(child){this.children.push(child);return child;},
    append(...children){this.children.push(...children);},
    setAttribute(key,value){this.attributes[key]=value;},addEventListener(){},remove(){},
    querySelector(){return null;}};
}
function fixture(config={}) {
  const state={now:1000,logs:[],outputs:[],logSaves:[],logFiles:[],caught:[],alerts:0,
    order:[],sessions:[],postHooks:0};
  const logger=Object.fromEntries(['info','warn','debug','error','trace'].map(level=>[level,
    (...values)=>state.logs.push({level,text:values.map(value=>String(value?.message??value)).join(' ')})]));
  const window={workerId:'export-fixture',localStorageExpired:{get(){},set(){}},
    qidianTxtOnly:true,stopController:new AbortController(),failedCount:0};
  window.stopFlag=window.stopController.signal;
  class ClockDate extends Date {static now(){return state.now;}}
  const document={location:{hostname:'www.qidian.com'},body:domNode('body'),
    documentElement:domNode('html'),createElement:domNode,getElementById(){return null;},querySelector(){return null;}};
  if(config.noticeDomFailure)document.createElement=()=>{throw Error('synthetic DOM unavailable');};
  const ctx=vm.createContext({window,unsafeWindow:window,document,Date:ClockDate,URL,Blob,
    Promise,Map,Set,AbortController,console:logger,Options,
    setTimeout(){return 1;},clearTimeout(){},
    alert(){state.alerts++;throw Error('Native alert must not block TXT or final debug delivery');},
    GM_getValue:(key,fallback)=>key==='qidianResumeEnabledV1'?false:fallback,
    GM_setValue(){},GM_info:{script:{version:'5.2.1283.26'}},
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:statuses},main:{nW:statuses,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>logger,loglevel_default:()=>logger,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:async ms=>{state.now+=ms;}},
    setting:{Jv:{value:true},Zz:{value:false},Nw:{value:true},WZ:{value:false},BV:async()=>false},
    misc:{yy:async ms=>{state.now+=ms;}},saveOptionsValidate:()=>false,
    Math:Object.assign(Object.create(Math),{random:()=>0.5}),
    FileSaver_min:{saveAs(blob,name){
      state.order.push('txt_save');state.now+=7;
      if(config.saveFailure)throw Error('Synthetic TXT output failure');
      state.outputs.push({blob,name});
    }}
  });
  vm.runInContext(globals+chapterCode+'\nthis.Chapter=Chapter;'+txtCode+'\nthis.TXT=TXT;',ctx);
  const events=()=>state.logs.filter(entry=>entry.text.startsWith('[QidianDebug] '))
    .map(entry=>JSON.parse(entry.text.slice('[QidianDebug] '.length)));
  if(config.realLog){
    logger.methodFactory=method=>(...values)=>state.logs.push({level:method,text:values.map(value=>String(value?.message??value)).join(' ')});
    logger.getLevel=()=>logger.level??'trace';
    logger.setLevel=level=>{logger.level=level;for(const method of ['info','warn','debug','error','trace'])logger[method]=logger.methodFactory(method,level,'export-fixture');};
    Object.assign(ctx,{_setting__WEBPACK_IMPORTED_MODULE_2__:{Nw:{value:true}},
      loglevel__WEBPACK_IMPORTED_MODULE_1___default:()=>logger,
      file_saver__WEBPACK_IMPORTED_MODULE_0__:{saveAs(blob,name){
        state.order.push('debug_save');state.logFiles.push({blob,name});state.logSaves.push(events());
      }}});
    vm.runInContext(logCode+'\nthis.exportShippedLog=saveLogTextToFile;this.getShippedLog=getLogText;',ctx);
    ctx.log={M6:ctx.exportShippedLog,get kc(){return ctx.getShippedLog();}};
    vm.runInContext('class ShippedLogSave {'+staticSaveLogCode+'}\nthis.ShippedLogSave=ShippedLogSave;',ctx);
  }
  const chapters=(config.modes??['saved']).map((mode,index)=>{
    const chapter=new ctx.Chapter({bookUrl:'https://www.qidian.com/book/1/',
      chapterUrl:`https://www.qidian.com/chapter/1/${index+1}/`,chapterNumber:index+1,
      chapterName:`第${index+1}章 测试章节`,isVIP:mode==='skip',isPaid:mode!=='skip',
      charset:'UTF-8',options:{expectedChars:2000}});
    chapter.fixtureMode=mode;return chapter;
  });
  const book={bookUrl:'https://www.qidian.com/book/1/',author:'fixture',bookname:'export flow',chapters};
  const session={initializeSession:id=>state.sessions.push(['start',id]),clearSession:id=>state.sessions.push(['clear',id])};
  class SaveBook {
    constructor(book){this.book=book;this.txt=new ctx.TXT(book,config.txtOptions);}
    async save(){state.order.push('export_start');this.txt.saveTxt();state.order.push('export_finish');}
    static saveLog(){state.order.push('debug_save');state.logSaves.push(events());}
  }
  if(config.realLog)SaveBook.saveLog=()=>ctx.ShippedLogSave.saveLog();
  Object.assign(ctx,{SaveBook,SessionMappingCache:{j:{getInstance:()=>session}}});
  vm.runInContext('\nclass RunRule {'+runCode+'}\nthis.RunRule=RunRule;',ctx);
  const rule=new ctx.RunRule();
  Object.assign(rule,{needLogin:true,concurrencyLimit:1,sleepTime:8000,maxSleepTime:20000,
    async preHook(){},async bookParse(){return book;},async prepareChapters(){},selectChapters(){},
    async initChapters(){
      for(const chapter of chapters){
        if(chapter.fixtureMode==='saved'){
          chapter.status=statuses.saved;chapter.contentText=body;
          chapter.options.qidianValidation=ctx.qidianContentCheck(body,2000,chapter.isVIP);
        }else if(chapter.fixtureMode==='skip'){
          // Run the shipped skip classifier, including its diagnostic error
          // code and status fields, rather than fabricating only its status.
          chapter.chapterParse=()=>{throw ctx.qidianUnsubscribedFailure(chapter.chapterName,'reader_subscription_gate');};
          await chapter.init();
        }else if(chapter.fixtureMode==='failed'){
          chapter.status=statuses.failed;chapter.qidianFailureKind='local';
          chapter.errorMessage='章节正文未通过基础检查';
        }
      }
      if(config.pause){window.qidianPauseReason='网站返回访问限制，已暂停';window.stopController.abort();}
    },postHook(){state.postHooks++;},catchError:error=>state.caught.push(error)});
  return {ctx,window,state,book,chapters,rule,events,run:()=>rule.run()};
}
const tests=[];const test=(name,fn)=>tests.push({name,fn});
function finalSummary(f){const summaries=f.events().filter(event=>event.event==='run_summary');assert.equal(summaries.length,1);return summaries[0];}
function assertFinalDebug(f){
  assert.equal(f.state.logSaves.length,1);
  assert.equal(f.state.logSaves[0].filter(event=>event.event==='run_summary').length,1);
  assert.deepEqual(f.state.sessions.map(call=>call[0]),['start','clear']);
  assert.equal(f.state.alerts,0);
  assert(!JSON.stringify(f.events()).includes('PRIVATE_BODY_MUST_NOT_APPEAR_IN_DEBUG'));
}
test('ordinary failed chapter exports later bodies and final debug with native alerts forbidden',async()=>{
  const f=fixture({modes:['saved','failed','saved']});await f.run();
  assert.equal(f.state.caught.length,0);assert.equal(f.state.outputs.length,1);
  const text=await f.state.outputs[0].blob.text();assert.match(text,/第1章/);assert.match(text,/第3章/);
  const summary=finalSummary(f);assert.equal(summary.outcome,'partial');
  assert.equal(summary.selectedCount,3);assert.equal(summary.savedCount,2);assert.equal(summary.exportedCount,2);
  assert.equal(summary.failedCount,1);assert.equal(summary.missingCount,1);assert.equal(summary.skippedCount,0);
  assert(f.events().some(event=>event.event==='completion_notice'));
  assert(f.state.order.indexOf('txt_save')<f.state.order.indexOf('debug_save'));
  assertFinalDebug(f);
});
test('paused partial task delivers success bodies and final log before any dismissible notice',async()=>{
  const f=fixture({modes:['saved','pending'],pause:true});await f.run();
  assert.equal(f.state.caught.length,0);assert.equal(f.state.outputs.length,1);
  const summary=finalSummary(f);assert.equal(summary.outcome,'paused');assert.equal(summary.exportedCount,1);
  assert.equal(summary.unprocessedCount,1);assert.equal(summary.missingCount,1);
  assertFinalDebug(f);
});
test('unsubscribed chapters produce a completed-with-skips result without failure or missing inflation',async()=>{
  const f=fixture({modes:['saved','skip','saved']});await f.run();
  assert.equal(f.state.caught.length,0);assert.equal(f.state.outputs.length,1);
  const summary=finalSummary(f);assert.equal(summary.outcome,'completed_with_skips');
  assert.equal(summary.selectedCount,3);assert.equal(summary.exportedCount,2);
  assert.equal(summary.skippedCount,1);assert.equal(summary.missingCount,0);assert.equal(summary.failedCount,0);assert.equal(summary.abortedCount,0);
  assert.equal(summary.skipped.length,1);assert.equal(summary.skipped[0].skipReason,'unsubscribed');
  assert.equal(f.book.downloadReport.skippedCount,1);assert.equal(f.book.downloadReport.missing.length,0);
  const diagnostic=f.ctx.qidianChapterDiagnostic(f.chapters[1]);
  assert.equal(diagnostic.statusName,'skipped');assert.equal(diagnostic.errorCode,'chapter_unsubscribed');
  const text=await f.state.outputs[0].blob.text();assert.match(text,/未订阅/);
  assert.doesNotMatch(f.state.outputs[0].name,/部分下载/,'expected subscription skips are not failed partial downloads');
  assert.doesNotMatch(text,/===== 未写入章节/,'skipped chapters belong in their own report section');
  assertFinalDebug(f);
});
test('all unsubscribed selection returns normally and creates no empty TXT',async()=>{
  const f=fixture({modes:['skip','skip']});const result=await f.run();
  assert.equal(result,f.book);assert.equal(f.state.outputs.length,0);assert.equal(f.state.caught.length,0);
  assert.equal(f.state.postHooks,1,'controlled no-body return must release the run UI and worker state');
  assert.equal(f.events().filter(event=>event.event==='run_error').length,0);
  const summary=finalSummary(f);assert.equal(summary.outcome,'completed_with_skips');
  assert.equal(summary.skippedCount,2);assert.equal(summary.failedCount,0);assert.equal(summary.missingCount,0);
  assert.equal(summary.unprocessedCount,0);assert.equal(summary.abortedCount,0);assert.equal(summary.exportedCount,0);
  assert(f.events().some(event=>event.event==='completion_notice'));assertFinalDebug(f);
});
test('no successful body finishes its diagnostics without inventing a whole-run exception or empty TXT',async()=>{
  const f=fixture({modes:['failed','failed']});await f.run();
  assert.equal(f.state.outputs.length,0);assert.equal(f.state.caught.length,0);
  assert.equal(f.events().filter(event=>event.event==='run_error').length,0);
  const summary=finalSummary(f);assert.equal(summary.failedCount,2);assert.equal(summary.missingCount,2);
  assert.equal(summary.exportedCount,0);assert.notEqual(summary.outcome,'completed');assertFinalDebug(f);
});
test('a mixed skipped-and-failed no-body selection keeps the two reasons separate',async()=>{
  const f=fixture({modes:['skip','failed']});await f.run();
  assert.equal(f.state.outputs.length,0);assert.equal(f.state.caught.length,0);
  const summary=finalSummary(f);assert.equal(summary.outcome,'partial');
  assert.equal(summary.selectedCount,2);assert.equal(summary.skippedCount,1);
  assert.equal(summary.failedCount,1);assert.equal(summary.missingCount,1);
  assert.equal(summary.abortedCount,0);assert.equal(summary.exportedCount,0);assertFinalDebug(f);
});
test('actual TXT middle formatter failure preserves later chapter and cannot block automatic debug',async()=>{
  const f=fixture({modes:['saved','saved','saved'],txtOptions:{genChapterText(name,text){if(name.startsWith('第2章'))throw Error('Synthetic chapter format error');return `${name}\n${text}`;}}});
  await f.run();assert.equal(f.state.caught.length,0);assert.equal(f.state.outputs.length,1);
  const text=await f.state.outputs[0].blob.text();assert.match(text,/第1章/);assert.match(text,/第3章/);assert.match(text,/TXT 格式化失败/);
  const summary=finalSummary(f);assert.equal(summary.formatFailureCount,1);assert.equal(summary.exportedCount,2);
  assert.equal(summary.missingCount,1);assert.equal(summary.outcome,'partial');
  assert(f.events().some(event=>event.event==='completion_notice'));assertFinalDebug(f);
});
test('export phase surrounds actual delivery and reports local duration before final summary',async()=>{
  const f=fixture();await f.run();const events=f.events();
  const begin=events.find(event=>event.event==='export_begin');const end=events.find(event=>event.event==='export_end');
  assert(begin);assert(end);assert.equal(end.outcome,'success');assert.equal(end.durationMs,7);
  assert(begin.seq<events.find(event=>event.event==='txt_export').seq);
  assert(end.seq>events.find(event=>event.event==='txt_export').seq);assert(end.seq<finalSummary(f).seq);
  assertFinalDebug(f);
});
test('output delivery failure retains export error and still exports one final debug snapshot',async()=>{
  const f=fixture({saveFailure:true});await f.run();
  assert.equal(f.state.outputs.length,0);assert.equal(f.state.caught.length,1);
  const end=f.events().find(event=>event.event==='export_end');assert(end);assert.equal(end.outcome,'error');assert.equal(end.durationMs,7);
  assert.equal(finalSummary(f).outcome,'failed');assertFinalDebug(f);
});
test('unavailable notification DOM cannot prevent partial TXT or debug delivery',async()=>{
  const f=fixture({modes:['saved','failed'],noticeDomFailure:true});await f.run();
  assert.equal(f.state.caught.length,0);assert.equal(f.state.outputs.length,1);
  assert.equal(finalSummary(f).exportedCount,1);
  assert(f.events().some(event=>event.event==='completion_notice'&&event.noticeShown===false));
  assertFinalDebug(f);
});
test('nonmodal completion notice renders plain text and emits its delivery state',()=>{
  const f=fixture();
  f.ctx.qidianNotifyResult(f.ctx.loglevel_default(),'本次已保存 2 章；未订阅 1 章已跳过。');
  assert.equal(f.state.alerts,0);
  const notice=f.ctx.document.body.children.find(item=>item.id==='qidian-download-result-notice');
  assert(notice,'the actual shipped helper must render a page notice when the DOM works');
  assert.equal(notice.attributes.role,'status');
  assert.match(notice.children[0].textContent,/未订阅 1 章/);
  assert(f.events().some(event=>event.event==='completion_notice'&&event.noticeShown===true));
});
test('notification logger failures remain nonfatal and never invoke native alert',()=>{
  const f=fixture({noticeDomFailure:true});
  assert.doesNotThrow(()=>f.ctx.qidianNotifyResult({warn(){throw Error('broken notice logger');},info(){throw Error('broken event logger');}},'诊断提示'));
  assert.equal(f.state.alerts,0);
});
test('complete task preserves ordinary export and all-formats-failed report remains nonmodal',async()=>{
  const normal=fixture({modes:['saved','saved']});await normal.run();
  assert.equal(finalSummary(normal).outcome,'completed');assert.equal(finalSummary(normal).exportedCount,2);assertFinalDebug(normal);
  const f=fixture({modes:['saved','saved'],txtOptions:{genChapterText(){throw Error('All chapter formats failed');}}});
  await f.run();assert.equal(f.state.caught.length,0);assert.equal(f.state.outputs.length,1);
  assert.match(f.state.outputs[0].name,/TXT缺章报告/);assert.equal(finalSummary(f).exportedCount,0);
  assert.equal(finalSummary(f).formatFailureCount,2);assertFinalDebug(f);
});
test('actual automatic SaveBook.saveLog delegates to the bounded exporter and embeds final result metadata',async()=>{
  const f=fixture({modes:['saved','skip','failed'],realLog:true});await f.run();
  assert.equal(f.state.outputs.length,1);assert.equal(f.state.logFiles.length,1);
  const debug=await f.state.logFiles[0].blob.text();
  assert(debug.startsWith('[QidianLogBuffer] '),'automatic debug files must include the same buffer metadata as manual exports');
  const buffer=JSON.parse(debug.split('\n')[0].slice('[QidianLogBuffer] '.length));
  assert.equal(buffer.maxRetainedChars,4*1024*1024);assert.equal(buffer.droppedChars,0);assert(buffer.retainedChars>0);
  const savedEvents=debug.split('\n').filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice('[QidianDebug] '.length)));
  const requested=savedEvents.filter(event=>event.event==='log_export'&&event.outcome==='download_requested');
  assert.equal(requested.length,1);assert.equal(requested[0].summary.exportedCount,1);
  assert.equal(requested[0].summary.skippedCount,1);assert.equal(requested[0].summary.missingCount,1);
  assert.equal(requested[0].summary.outcome,'partial');
  const summary=savedEvents.find(event=>event.event==='run_summary');assert(summary);assert(summary.seq<requested[0].seq);
  assert(!debug.includes('PRIVATE_BODY_MUST_NOT_APPEAR_IN_DEBUG'));
  assertFinalDebug(f);
});
(async()=>{
  let failed=0;
  for(const {name,fn} of tests){try{await fn();console.log(`PASS ${name}`);}catch(error){failed++;console.error(`FAIL ${name}\n${error.stack}`);}}
  console.log(`${tests.length-failed}/${tests.length} v26 export and nonblocking notice checks passed`);
  if(failed)process.exitCode=1;
})();
