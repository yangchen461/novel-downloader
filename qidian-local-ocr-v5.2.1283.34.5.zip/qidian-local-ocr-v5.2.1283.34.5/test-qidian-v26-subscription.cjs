// Run the shipped access helpers, parser, Chapter.parse and serial scheduler.
// Only browser/network/OCR/storage delivery are fixtures; no site is contacted.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a,b,from=0) {
  const start=src.indexOf(a,from),end=src.indexOf(b,start);
  assert(start>=0&&end>start,`Missing shipped source boundary: ${a}`);
  return src.slice(start,end);
}
const globals=take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode=take('class ChapterAbortError','\n\n/***/ },');
const parser=take('  async chapterParse(', '\n}\n\n\n/***/',src.indexOf('class Qidian extends'));
const scheduler=take('  async initChapters(book,','\n  postHook()');
const saveCode=take('  async addChapter(chapter) {','\n  async save()',src.indexOf('class SaveBook'));
const validation=take('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {',
  '      if (/^(?:www|book)\\.qidian\\.com$/.test(document.location.hostname)) {\n        const exportStart',src.indexOf('await self.initChapters(self.book'));
const txtCode=take('class TXT extends Options',';// ./src/save/raw.ts');
const progressCode=take('function formatETA(','app.config.compilerOptions');
const progressOptions=vm.runInNewContext(progressCode+'\napp',{external_Vue_:{createApp:o=>o},ui_progress:''});
const statuses={pending:0,downloading:1,failed:2,finished:3,aborted:4,saved:5};
const body='真实正文内容完整，页面正常显示。'.repeat(200);
const normalize=value=>JSON.parse(JSON.stringify(value));
function node(tag='div') {
  return {tagName:tag.toUpperCase(),children:[],appendChild(child){this.children.push(child);return child;}};
}
function makeDoc(cfg) {
  const text=cfg.rawText??(cfg.short?'短正文':body);
  const visibleText=cfg.gate&&!cfg.fullWithGate?cfg.prompt??'本章为VIP章节，请订阅后阅读':text;
  const limit=cfg.gate?{textContent:cfg.prompt??'本章为VIP章节，请订阅后阅读',innerText:cfg.prompt??'本章为VIP章节，请订阅后阅读',
    hidden:cfg.hiddenGate??false,style:cfg.hiddenGateStyle?{display:'none'}:{},
    getAttribute(name){return name==='aria-hidden'&&cfg.ariaHiddenGate?'true':null;},querySelector(){return null;},querySelectorAll(){return [];}}:null;
  const control=cfg.control?{innerText:cfg.control,textContent:cfg.control,getAttribute(){return null;},
    closest(selector){
      if(cfg.navControl&&/nav|header|footer|aside/.test(selector))return {};
      if(cfg.bodyControl&&selector==='.content-text')return main;
      return null;
    }}:null;
  const main=cfg.noMain?null:{cfg,textContent:visibleText,innerText:visibleText,
    querySelectorAll:selector=>selector==='p'?Array(5).fill({}):[],
    querySelector(selector){
      if(selector==='.content-text')return cfg.gate&&!cfg.fullWithGate?null:main;
      if(selector.split(',').some(s=>s.trim()==='.vip-limit-wrap'))return limit;
      return null;
    }};
  const doc={title:cfg.block?'WAF拦截页面':cfg.login?'用户登录':cfg.verify?'安全验证':`第${cfg.id}章`,
    body:{textContent:cfg.block?'403 您的请求已中断':cfg.login?'请先登录，订阅后阅读':cfg.verify?'请完成安全验证':visibleText,
      innerText:cfg.block?'403 您的请求已中断':cfg.login?'请先登录，订阅后阅读':cfg.verify?'请完成安全验证':visibleText},
    querySelector(selector){
      for(const s of selector.split(',').map(v=>v.trim())) {
        if(s==='main'&&main)return main;
        if(s==='h1.title')return {innerText:`第${cfg.id}章`};
        if(s==='.vip-limit-wrap'&&limit)return limit;
        if(s==='.content-text'&&main&&(!cfg.gate||cfg.fullWithGate))return main;
      }
      return null;
    },querySelectorAll(selector){return control&&selector.startsWith('main button')?[control]:[];}};
  main&&(main.ownerDocument=doc);
  return doc;
}
function fixture(configs) {
  const state={now:1000,requests:[],waits:[],ocr:[],clean:[],persist:0,saved:[],logs:[],timers:new Map(),timer:0,removed:[],postHooks:0};
  const log=Object.fromEntries(['info','warn','error','trace','debug'].map(level=>[level,(...args)=>state.logs.push({level,text:args.map(value=>String(value?.message??value)).join(' ')})]));
  const window={stopController:new AbortController(),qidianTxtOnly:true,failedCount:0,qidianDebugLogger:log};
  window.stopFlag=window.stopController.signal;
  const progress=progressOptions.data();Object.assign(progress,progressOptions.methods);
  const configsById=new Map(configs.map(cfg=>[cfg.id,cfg]));
  async function request(route,url,predicate) {
    const id=Number(String(url).split('/').filter(Boolean).at(-1));
    const cfg=configsById.get(id);assert(cfg,`Unexpected chapter ${id}`);
    state.requests.push({id,route,at:state.now});state.now+=cfg.pageMs??700;
    if(cfg.httpStatus){const e=new Error(`HTTP ${cfg.httpStatus}`);e.status=cfg.httpStatus;throw e;}
    if(cfg.blank){const e=new Error('Frame Timeout!');e.frameState={addressKind:'requested',readyState:'complete',bodyPresent:true,
      bodyTextLength:0,contentPresent:false,mainParagraphs:0};throw e;}
    if(cfg.network){throw Error('ordinary network failure');}
    const doc=makeDoc(cfg);
    if(route==='html')return doc;
    let removed=false;
    const frame={contentWindow:{document:doc},remove(){if(!removed){removed=true;state.removed.push(id);}}};
    try{assert.equal(predicate(frame),true);}catch(e){frame.remove();throw e;}
    return frame;
  }
  class ClockDate extends Date {static now(){return state.now;}}
  const sleep=async ms=>{state.waits.push(ms);state.now+=ms;};
  const ctx=vm.createContext({window,unsafeWindow:window,Date:ClockDate,URL,Map,Set,Promise,AbortController,console:log,
    Math:Object.assign(Object.create(Math),{random:()=>0}),alert(){},
    document:{location:{hostname:'www.qidian.com'},createElement:node},
    setTimeout:(fn,ms)=>{const id=++state.timer;state.timers.set(id,{fn,ms});return id;},clearTimeout:id=>state.timers.delete(id),
    GM_getValue:(_key,fallback)=>fallback,GM_setValue(){},
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:statuses},main:{nW:statuses,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log,_log__WEBPACK_IMPORTED_MODULE_6___default:()=>log,loglevel_default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:sleep},misc:{yy:sleep},setting:{Zz:{value:false},Nw:{value:false}},progress:{vm:progress},log:{M6(){}},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async url=>request('html',url),Q2:async(url,predicate)=>request('frame',url,predicate)},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(){},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{async an(main){state.clean.push(main.cfg.id);return {dom:node(),text:main.textContent,images:[]};},is(){}},
    async ocrContent(main){state.ocr.push(main.cfg.id);state.now+=400;return {contentText:main.cfg.ocrText??main.textContent,contentHTML:node()};},
    qidianGlyphCache:new Map(),async qidianPersistGlyphCache(){state.persist++;}
  });
  vm.runInContext(globals+chapterCode+'\nclass Qidian {'+parser+'}\nclass Rule {'+scheduler+'}\nclass Save {'+saveCode+'}\nthis.Chapter=Chapter;this.Qidian=Qidian;this.Rule=Rule;this.Save=Save;'+
    '\nthis.validate=self=>{let qidianCompletionMessage;'+validation+'return self.book;};',ctx);
  const qidian=new ctx.Qidian();
  const chapters=configs.map(cfg=>new ctx.Chapter({bookUrl:'https://www.qidian.com/book/1/',chapterUrl:`https://www.qidian.com/chapter/1/${cfg.id}/`,
    chapterNumber:cfg.id,chapterName:`第${cfg.id}章`,isVIP:cfg.vip??true,isPaid:cfg.paid??true,charset:'UTF-8',options:{expectedChars:cfg.expectedChars??2000},chapterParse:qidian.chapterParse.bind(qidian)}));
  const book={chapters};
  window.qidianDebugRun={id:'subscription-fixture',startedAt:state.now,book,selectedChapters:chapters,selectedCount:chapters.length};
  const rule=new ctx.Rule();Object.assign(rule,{concurrencyLimit:1,sleepTime:8000,maxSleepTime:20000});
  const saver=new ctx.Save();saver.saveType={txt:true,epub:false};
  const originalAdd=saver.addChapter.bind(saver);
  saver.addChapter=async chapter=>{state.saved.push(chapter.chapterNumber);return originalAdd(chapter);};
  const events=()=>state.logs.filter(entry=>entry.text.startsWith('[QidianDebug] ')).map(entry=>JSON.parse(entry.text.slice('[QidianDebug] '.length)));
  return {ctx,state,window,progress,chapters,book,events,
    async run(){try{await rule.initChapters(book,saver);}catch(e){if(!window.stopFlag.aborted)throw e;}window.qidianDebugRun.finished=true;window.qidianDebugRun.endedAt=state.now;return book;},
    validate:()=>ctx.validate({book,postHook(){state.postHooks++;}}),summary:()=>normalize(ctx.qidianRunSummary(book))};
}
const tests=[];const test=(name,fn)=>tests.push({name,fn});
const ids=f=>f.state.requests.map(r=>r.id);
function assertSkipped(f,index) {
  const chapter=f.chapters[index],row=normalize(f.ctx.qidianChapterDiagnostic(chapter));
  assert.equal(chapter.status,statuses.aborted);
  assert.equal(chapter.qidianSkipReason,'unsubscribed');
  assert.equal(chapter.qidianFailureKind,null);
  assert.equal(chapter.retryTime,0,'a confirmed subscription gate must not start a retry');
  assert.equal(chapter.qidianAttemptCount,1);
  assert.equal(chapter.contentText,null);
  assert.equal(chapter.contentHTML,null);
  assert.equal(row.statusName,'skipped');
  assert.equal(row.skipReason,'unsubscribed');
  assert.equal(row.errorCode,'chapter_unsubscribed');
  assert.equal(row.stage,'access_check');
  assert.equal(row.quality,null,'a skipped chapter has no body-integrity measurement');
}

test('confirmed unpaid VIP is skipped once, and the next subscribed VIP is saved',async()=>{
  const f=fixture([{id:1,paid:false,gate:true},{id:2,paid:true}]);await f.run();
  assertSkipped(f,0);assert.equal(f.chapters[1].status,statuses.saved);
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.ocr,[2]);assert.deepEqual(f.state.clean,[]);
  assert.deepEqual(f.state.saved,[2]);assert.equal(f.state.persist,1);
  assert.equal(f.window.failedCount,0);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.progress.processedChapterIndex,2);assert.equal(f.progress.finishedChapterNumber,1);
  assert.deepEqual(f.state.removed,[1,2]);assert.equal(f.state.timers.size,0);
  assert(f.state.requests[1].at-f.state.requests[0].at>=10000,'skip must keep the protected request gap');
});
test('stale paid:true catalog flag cannot override an explicit reader subscription gate',async()=>{
  const f=fixture([{id:1,paid:true,gate:true},{id:2}]);await f.run();
  assertSkipped(f,0);assert.equal(f.chapters[1].status,statuses.saved);assert.deepEqual(f.state.ocr,[2]);
});
test('a readable body takes priority over an inactive retained subscription widget',async()=>{
  const f=fixture([{id:1,gate:true,fullWithGate:true},{id:2}]);await f.run();
  assert(f.chapters.every(chapter=>chapter.status===statuses.saved));
  assert.deepEqual(f.state.ocr,[1,2]);assert.equal(f.summary().skippedCount,0);
});
test('a full PUA-encoded body with a retained gate reaches OCR and requires decoded quality to pass',async()=>{
  const rawText='\ue000'.repeat(3000);
  const f=fixture([{id:1,gate:true,fullWithGate:true,rawText,ocrText:body},{id:2}]);
  const doc=makeDoc({id:1,gate:true,fullWithGate:true,rawText});
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true,2000)).kind,'unknown',
    'raw encoded glyphs must not make an otherwise full reader body look unsubscribed');
  await f.run();assert.deepEqual(f.state.ocr,[1,2]);assert.deepEqual(f.state.saved,[1,2]);
  assert.equal(f.chapters[0].status,statuses.saved);assert.equal(f.chapters[0].options.qidianValidation.complete,true);
  assert.equal(f.summary().skippedCount,0);
});
test('a full encoded reader body still fails integrity checks if OCR leaves PUA characters unresolved',async()=>{
  const rawText='\ue000'.repeat(3000);
  const f=fixture([{id:1,gate:true,fullWithGate:true,rawText,ocrText:rawText},{id:2}]);await f.run();
  assert.deepEqual(ids(f),[1,1,2,1,1,1,1]);assert.deepEqual(f.state.ocr,[1,1,2,1,1,1,1]);
  assert.equal(f.chapters[0].status,statuses.failed);assert.equal(f.chapters[0].qidianFailureKind,'local');
  assert.notEqual(f.chapters[0].qidianSkipReason,'unsubscribed');
  assert.equal(f.chapters[0].options.qidianValidation.complete,false);
  assert.equal(f.chapters[0].options.qidianValidation.reason,'unresolved_private_use');
  assert.equal(f.chapters[1].status,statuses.saved);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.summary().failedCount,1);assert.equal(f.summary().skippedCount,0);
});
test('a 300-character preview below the 5000-character catalog expectation remains an unpaid gate',async()=>{
  const rawText='正文'.repeat(150);
  const f=fixture([{id:1,gate:true,fullWithGate:true,rawText,expectedChars:5000},{id:2}]);
  assert.equal(normalize(f.ctx.qidianChapterAccessState(makeDoc({id:1,gate:true,fullWithGate:true,rawText}),true,5000)).kind,'unsubscribed');
  await f.run();assertSkipped(f,0);assert.deepEqual(f.state.ocr,[2]);assert.equal(f.chapters[1].status,statuses.saved);
});
for(const hidden of ['hiddenGate','hiddenGateStyle','ariaHiddenGate'])test(`${hidden}: a hidden subscription widget cannot create a skip`,async()=>{
  const f=fixture([{id:1}]);const doc=makeDoc({id:1,gate:true,[hidden]:true});
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true,2000)).kind,'unknown');
});
test('an explicit reader subscription button without a legacy gate skips once and continues',async()=>{
  const f=fixture([{id:1,short:true,control:'订阅本章'},{id:2}]);await f.run();
  assertSkipped(f,0);assert.equal(f.chapters[1].status,statuses.saved);
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.ocr,[2]);assert.equal(f.window.stopFlag.aborted,false);
});
for(const control of ['自动订阅','取消订阅','已订阅本章'])test(`control '${control}' is not an unpaid purchase gate`,async()=>{
  const f=fixture([{id:1}]);const doc=makeDoc({id:1,short:true,control});
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true,2000)).kind,'unknown');
});
test('a subscription button in navigation is excluded from reader gate detection',async()=>{
  const f=fixture([{id:1}]);const doc=makeDoc({id:1,short:true,control:'订阅本章',navControl:true});
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true,2000)).kind,'unknown');
});
test('a generic subscription widget in navigation cannot classify the reader chapter as unpaid',async()=>{
  const f=fixture([{id:1}]);const doc=makeDoc({id:1,short:true});
  const original=doc.querySelector.bind(doc);
  const navWidget={textContent:'订阅本章',innerText:'订阅本章',closest(){return {};},getAttribute(){return null;}};
  doc.querySelector=selector=>selector==='.subscribe-wrap'?navWidget:original(selector);
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true,2000)).kind,'unknown');
});
test('paid:false catalog flag with a readable VIP chapter remains downloadable',async()=>{
  const f=fixture([{id:1,paid:false},{id:2}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.ocr,[1,2]);
  assert(f.chapters.every(chapter=>chapter.status===statuses.saved));
  assert.equal(f.summary().skippedCount,0);
});
test('four unsubscribed VIPs do not increment failure count or trigger the page-error pause',async()=>{
  const f=fixture([1,2,3,4].map(id=>({id,gate:true,paid:false})));await f.run();
  f.chapters.forEach((_chapter,index)=>assertSkipped(f,index));
  assert.deepEqual(ids(f),[1,2,3,4]);assert.deepEqual(f.state.ocr,[]);
  assert.equal(f.window.failedCount,0);assert.equal(f.window.stopFlag.aborted,false);
  const summary=f.summary();assert.equal(summary.skippedCount,4);assert.equal(summary.failedCount,0);
  assert.equal(summary.abortedCount,0);assert.equal(summary.missingCount,0);assert.equal(summary.unprocessedCount,0);
  assert.equal(summary.outcome,'completed_with_skips');
});
test('logs and final summary separate unsubscribed skips from failures and retries',async()=>{
  const f=fixture([{id:1,gate:true},{id:2}]);await f.run();
  const events=f.events(),results=events.filter(e=>e.event==='chapter_result');
  assert.equal(results.length,2);assert.equal(results[0].statusName,'skipped');
  assert.equal(results[0].skipReason,'unsubscribed');assert.equal(results[0].errorCode,'chapter_unsubscribed');
  assert.equal(results[0].accessEvidence,'vip_limit_wrap');
  assert.equal(results[1].statusName,'saved');
  assert(!events.some(e=>e.chapterId==='1'&&['attempt_error','retry_scheduled'].includes(e.event)));
  assert(!events.some(e=>e.chapterId==='1'&&e.event==='chapter_stage_end'&&e.outcome==='error'),
    'a subscription skip must not be recorded as a processing failure');
  assert(events.some(e=>e.event==='chapter_skipped'&&e.chapterId==='1'));
  const summary=f.summary();assert.equal(summary.skippedCount,1);assert.equal(summary.skipped.length,1);
  assert.equal(summary.skipped[0].chapterId,'1');assert.equal(summary.savedCount,1);
  assert.equal(summary.failedCount,0);assert.equal(summary.abortedCount,0);assert.equal(summary.missingCount,0);
});
test('actual export report removes unpaid skips from retryable missing chapters and preserves successful TXT',async()=>{
  const f=fixture([{id:1,gate:true},{id:2},{id:3,blank:true},{id:4}]);await f.run();f.validate();
  const report=normalize(f.book.downloadReport);
  assert.equal(report.selectedCount,4);assert.equal(report.savedCount,2);assert.equal(report.skippedCount,1);
  assert.equal(report.skipped.length,1);assert.equal(report.skipped[0].chapterUrl,f.chapters[0].chapterUrl);
  assert.equal(report.missing.length,1);assert.equal(report.missing[0].chapterUrl,f.chapters[2].chapterUrl);
  assert.deepEqual(f.book.chapters.map(chapter=>chapter.chapterNumber),[2,4]);
  Object.assign(f.book,{author:'fixture',bookname:'subscription test'});
  let output;
  class Options {
    genMetaDateTxt(){return 'fixture';}getchapterName(chapter){return chapter.chapterName;}
    genSectionText(section){return section;}genChapterText(title,text){return title+'\n'+text;}
    chapterSort(a,b){return a.chapterNumber-b.chapterNumber;}
  }
  Object.assign(f.ctx,{Options,Blob,FileSaver_min:{saveAs(blob,name){output={blob,name};}}});
  vm.runInContext(txtCode+'\nthis.TXT=TXT;',f.ctx);
  new f.ctx.TXT(f.book).saveTxt();
  const txt=await output.blob.text();
  assert.match(txt,/第2章/);assert.match(txt,/第4章/);
  assert(!txt.includes('本章为VIP章节，请订阅后阅读'),'never export a subscription gate as chapter text');
  const final=f.summary();assert.equal(final.exportedCount,2);assert.equal(final.skippedCount,1);
  assert.equal(final.failedCount,1);assert.equal(final.missingCount,1);
  const txtReport=normalize(f.book.txtDownloadReport);assert.equal(txtReport.skippedCount,1);assert.equal(txtReport.skipped.length,1);
});
test('all-unsubscribed export validation records skips without creating an empty-file error',async()=>{
  const f=fixture([{id:1,gate:true},{id:2,gate:true}]);await f.run();
  assert.doesNotThrow(()=>f.validate());
  const report=normalize(f.book.downloadReport);
  assert.equal(report.selectedCount,2);assert.equal(report.savedCount,0);assert.equal(report.skippedCount,2);
  assert.equal(report.missing.length,0);assert.equal(f.book.chapters.length,0);
  assert.equal(f.state.postHooks,1,'all skips still close the task through the normal post hook');
  assert.equal(f.summary().outcome,'completed_with_skips');
});
for(const wall of ['block','login','verify'])test(`${wall} takes priority over a coexisting subscription gate and pauses following requests`,async()=>{
  const f=fixture([{id:1},{id:2,gate:true,[wall]:true,noMain:true},{id:3}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.window.stopFlag.aborted,true);
  assert.notEqual(f.chapters[1].qidianSkipReason,'unsubscribed');
  assert.equal(f.chapters[2].status,statuses.pending);assert.deepEqual(f.state.ocr,[1]);
  assert.equal(f.summary().skippedCount,0);assert.equal(f.summary().outcome,'paused');
});
for(const prompt of ['请先登录，订阅后阅读','请完成安全验证，订阅后阅读'])test(`reader prompt '${prompt}' pauses rather than claiming unpaid subscription`,async()=>{
  const f=fixture([{id:1,gate:true,prompt},{id:2}]);await f.run();
  assert.deepEqual(ids(f),[1]);assert.equal(f.window.stopFlag.aborted,true);
  assert.notEqual(f.chapters[0].qidianSkipReason,'unsubscribed');assert.equal(f.chapters[1].status,statuses.pending);
  assert.equal(f.summary().skippedCount,0);
});
for(const httpStatus of [401,403,429])test(`HTTP ${httpStatus} remains a global pause, not a subscription skip`,async()=>{
  const f=fixture([{id:1,httpStatus},{id:2}]);await f.run();
  assert.deepEqual(ids(f),[1]);assert.equal(f.window.stopFlag.aborted,true);
  assert.notEqual(f.chapters[0].qidianSkipReason,'unsubscribed');
  assert.equal(f.chapters[1].status,statuses.pending);assert.equal(f.summary().skippedCount,0);
});
test('three consecutive blank pages retain errors, save later chapters and retry only misses twice',async()=>{
  const f=fixture([{id:1,blank:true},{id:2,blank:true},{id:3,blank:true},{id:4}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,4,1,2,3,1,2,3]);assert.equal(f.window.stopFlag.aborted,false);
  assert(f.chapters.slice(0,3).every(chapter=>chapter.status===statuses.failed&&chapter.qidianFailureKind==='page'&&chapter.qidianSkipReason!=='unsubscribed'&&chapter.contentText===null));
  assert(f.chapters.slice(0,3).every(chapter=>chapter.qidianAttemptCount===3));
  assert.equal(f.chapters[3].status,statuses.saved);assert.equal(f.window.failedCount,9);
  for(let i=1;i<4;i++)assert.equal(f.state.requests[i].at-f.state.requests[i-1].at,10000,'a 5s sampled cooldown still preserves the ordinary 10s protected request interval');
  const summary=f.summary();assert.equal(summary.failedCount,3);assert.equal(summary.skippedCount,0);assert.equal(summary.unprocessedCount,0);assert.equal(summary.savedCount,1);assert.equal(summary.outcome,'partial');
});
test('one blank page is retained as an error while a skip and the next subscribed chapter continue',async()=>{
  const f=fixture([{id:1,blank:true},{id:2,gate:true},{id:3}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,1,1]);assert.equal(f.chapters[0].qidianFailureKind,'page');
  assertSkipped(f,1);assert.equal(f.chapters[2].status,statuses.saved);
  assert.equal(f.window.stopFlag.aborted,false);assert.equal(f.window.failedCount,3);
  const summary=f.summary();assert.equal(summary.failedCount,1);assert.equal(summary.skippedCount,1);
  assert.equal(summary.missingCount,1);assert.equal(summary.missing[0].chapterId,'1');assert.equal(summary.outcome,'partial');
});
test('subscription words within a novel body cannot create an unpaid skip',async()=>{
  const f=fixture([{id:1}]);
  const doc=makeDoc({id:1});doc.querySelector('main').textContent='他大喊：请订阅后阅读！本章为VIP章节。'+body;
  doc.body.textContent=doc.querySelector('main').textContent;
  const state=normalize(f.ctx.qidianChapterAccessState(doc,true));
  assert.equal(state.kind,'unknown');
});
for(const control of ['登录','安全验证','订阅本章'])test(`a '${control}' anchor inside the full content root cannot become an access control`,async()=>{
  const f=fixture([{id:1,control,bodyControl:true},{id:2}]);
  const doc=makeDoc({id:1,control,bodyControl:true});
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true,2000)).kind,'unknown');
  await f.run();assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.ocr,[1,2]);
  assert(f.chapters.every(chapter=>chapter.status===statuses.saved));
  assert.equal(f.window.stopFlag.aborted,false);assert.equal(f.summary().skippedCount,0);
});
test('a generic subscription mention in site navigation cannot classify the chapter as unsubscribed',async()=>{
  const f=fixture([{id:1}]);const doc=makeDoc({id:1,noMain:true});
  doc.body.textContent='起点中文网导航 登录 充值 订阅 管理书架 请订阅后阅读';
  assert.equal(normalize(f.ctx.qidianChapterAccessState(doc,true)).kind,'unknown');
});

(async()=>{let failed=0;for(const{name,fn}of tests){try{await fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error);}}
console.log(`${tests.length-failed}/${tests.length} v26 subscription checks passed`);if(failed)process.exitCode=1;})();
