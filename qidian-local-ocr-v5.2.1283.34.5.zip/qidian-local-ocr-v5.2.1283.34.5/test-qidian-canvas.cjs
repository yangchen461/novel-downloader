// Optional real-canvas test: Node.js + playwright + its Chromium executable.
// Run: node test-qidian-canvas.cjs
// No Qidian pages, remote fonts, cookies, credentials, or network requests.
const fs = require('node:fs');
const path = require('node:path');
const assert = require('node:assert/strict');
const { chromium } = require('playwright');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const helpers = source.slice(source.indexOf('function qidianGlyphFingerprint('), source.indexOf('async function ocrContent('));
const font = fs.readFileSync(path.join(__dirname, 'fixtures/synthetic-glyphs.ttf')).toString('base64');

(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.route('**/*', route => route.abort());
    const result = await page.evaluate(async ({ helpers, font }) => {
      const logs = [];
      const _log__WEBPACK_IMPORTED_MODULE_6___default = () => ({ warn: m => logs.push(m) });
      const api = eval(helpers + '\n({single:qidianGlyphFingerprint,tiled:qidianGlyphFingerprints})');
      const face = await new FontFace('QidianLocalTest', `url(data:font/ttf;base64,${font})`).load();
      document.fonts.add(face);
      const glyphs = Array.from({ length: 800 }, (_, i) => String.fromCodePoint(0x4e00 + i));
      const latin = Array.from({ length: 400 }, (_, i) => String.fromCodePoint(0x21 + i));
      const make = () => {
        const canvas = document.createElement('canvas');
        return canvas.getContext('2d', { willReadFrequently: true });
      };
      const a = make(), b = make();
      const comparisons = [];
      for (const family of ['QidianLocalTest', 'sans-serif', 'serif', 'monospace']) {
        const chars = family === 'QidianLocalTest' ? glyphs : latin;
        const old = new Map(chars.map(c => [c, api.single(a, c, family)]));
        const next = api.tiled(b, chars, family);
        const mismatches = chars.filter(c => next.get(c) !== old.get(c));
        comparisons.push({ family, glyphs: chars.length, mismatches: mismatches.length });
      }
      let reads = 0;
      const get = b.getImageData.bind(b);
      b.getImageData = (...args) => { reads++; return get(...args); };
      api.tiled(b, glyphs, 'QidianLocalTest');
      const tileReads = reads;
      const boundaries = [];
      for (const count of [0, 1, 7, 8, 63, 64, 65, 129]) {
        const chars = glyphs.slice(0, count);
        const old = new Map(chars.map(c => [c, api.single(a, c, 'QidianLocalTest')]));
        const next = api.tiled(b, chars, 'QidianLocalTest');
        boundaries.push({ count, equal: next.size === count && chars.every(c => old.get(c) === next.get(c)) });
      }
      b.getImageData = (...args) => {
        if (args[2] > 80) throw Error('simulated tile allocation/readback failure');
        return get(...args);
      };
      const recovered = api.tiled(b, glyphs.slice(0, 65), 'QidianLocalTest');
      const fallbackEqual = glyphs.slice(0, 65).every(c => recovered.get(c) === api.single(a, c, 'QidianLocalTest'));
      b.getImageData = get;
      // Interleaved warm timings avoid counting font load and first-run JIT.
      for (let i = 0; i < 2; i++) {
        glyphs.forEach(c => api.single(a, c, 'QidianLocalTest'));
        api.tiled(b, glyphs, 'QidianLocalTest');
      }
      const singleMs = [], tiledMs = [];
      for (let i = 0; i < 5; i++) {
        const single = () => { const t = performance.now(); glyphs.forEach(c => api.single(a, c, 'QidianLocalTest')); singleMs.push(performance.now() - t); };
        const tiled = () => { const t = performance.now(); api.tiled(b, glyphs, 'QidianLocalTest'); tiledMs.push(performance.now() - t); };
        if (i % 2) { tiled(); single(); } else { single(); tiled(); }
      }
      return { comparisons, tileReads, boundaries, fallbackEqual, fallbackLogged: logs.length > 0, singleMs, tiledMs };
    }, { helpers, font });
    assert(result.comparisons.every(r => r.mismatches === 0), JSON.stringify(result.comparisons));
    assert(result.boundaries.every(r => r.equal), JSON.stringify(result.boundaries));
    assert.equal(result.tileReads, 16);
    assert(result.fallbackEqual && result.fallbackLogged);
    console.log('PASS real Chromium canvas: 2000 glyph comparisons, tile boundaries, legacy hashes, fallback; 800 readbacks -> 13 + 3 spot checks.');
    console.log(JSON.stringify(result, null, 2));
  } finally {
    await browser.close();
  }
})().catch(error => { console.error(error); process.exitCode = 1; });
