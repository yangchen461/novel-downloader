// Whole-run numeric diagnostics use the shipped helpers and full Rule.run.
// Only the clock, logger and browser/network boundary are deterministic.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const begin = source.indexOf('function qidianContentIsComplete(');
const end = source.indexOf('/******/ \tvar __webpack_modules__', begin);
assert(begin >= 0 && end > begin);
const globals = source.slice(begin, end);
const plain = value => JSON.parse(JSON.stringify(value));
const deferred = () => { let resolve; const promise = new Promise(r => { resolve = r; }); return {promise, resolve}; };
function fixture() {
  const state = { now:1000, logs:[] };
  class Clock extends Date { static now() { return state.now; } }
  const logger = {info:line => {state.logs.push(line); if (state.logs.length > 8) state.logs.shift();}};
  const window = {qidianDebugRun:{id:'performance-fixture',startedAt:1000},qidianDebugLogger:logger};
  const ctx = vm.createContext({window, Date:Clock, console, URL, AbortController});
  vm.runInContext(globals, ctx);
  const summary = () => plain(ctx.qidianRunSummary());
  const snapshot = () => plain(ctx.qidianPerformanceSnapshot(window.qidianDebugRun));
  return {state,window,ctx,summary,snapshot,phase:name => snapshot().stages.find(x=>x.stage===name)};
}
const tests=[];
const test=(name,fn)=>tests.push({name,fn});

test('inclusive nested stages are counted once with explicit overlap labels', async()=>{
  const f=fixture();
  await f.ctx.qidianStage(null,'chapter_parse',async()=>{
    f.state.now+=5;
    await f.ctx.qidianStage(null,'page_load',async()=>{f.state.now+=20;});
    await f.ctx.qidianStage(null,'ocr',async()=>{
      await f.ctx.qidianStage(null,'font_ready',async()=>{f.state.now+=3;});
      await f.ctx.qidianStage(null,'glyph_decode',async()=>{f.state.now+=7;});
    });
    f.state.now+=5;
  });
  assert.equal(f.phase('chapter_parse').totalMs,40);
  assert.equal(f.phase('page_load').totalMs,20);
  assert.equal(f.phase('ocr').totalMs,10);
  assert.equal(f.phase('font_ready').totalMs,3);
  assert.equal(f.phase('glyph_decode').totalMs,7);
  assert(f.snapshot().stages.every(x=>x.count===1 && x.successCount===1));
  assert.equal(f.snapshot().stagesAreInclusive,true);
  assert.equal(f.snapshot().nestedStagesOverlap,true);
  assert.equal(f.snapshot().sumIsWallTime,false);
  assert.equal(f.snapshot().activeStageCount,0);
});

test('ring-log eviction cannot remove accumulated stages from run_summary',async()=>{
  const f=fixture();
  for(let i=1;i<=40;i++) await f.ctx.qidianStage(null,'page_load',async()=>{f.state.now+=i;});
  assert.equal(f.state.logs.length,8);
  const row=f.summary().performanceSummary.stages[0];
  assert.equal(row.count,40);assert.equal(row.totalMs,820);assert.equal(row.maxMs,40);
  f.ctx.qidianDebugEvent(null,'run_summary',f.ctx.qidianRunSummary());
  const logged=JSON.parse(f.state.logs.at(-1).slice(14));
  assert.equal(logged.performanceSummary.stages[0].totalMs,820);
});

test('asynchronous errors, unsubscribe and explicit abort retain their outcomes',async()=>{
  const f=fixture();
  for(const [name,ms] of [['Error',11],['QidianUnsubscribedError',12],['AbortError',13],['ChapterAbortError',14]]) {
    const error=Object.assign(new Error('fixture failure'),{name});
    await assert.rejects(f.ctx.qidianStage(null,'chapter_parse',async()=>{f.state.now+=ms;throw error;}),e=>e===error);
  }
  const row=f.phase('chapter_parse');
  assert.equal(row.count,4);assert.equal(row.totalMs,50);assert.equal(row.maxMs,14);
  assert.equal(row.errorCount,1);assert.equal(row.skippedCount,1);assert.equal(row.cancelledCount,2);
});

test('sync formatting and save failures share the same bounded counters',()=>{
  const f=fixture();
  f.ctx.qidianStageSync(null,'txt_format',()=>{f.state.now+=4;});
  assert.throws(()=>f.ctx.qidianStageSync(null,'txt_format',()=>{f.state.now+=7;throw new Error('format');}));
  const row=f.phase('txt_format');
  assert.equal(row.count,2);assert.equal(row.totalMs,11);assert.equal(row.maxMs,7);
  assert.equal(row.successCount,1);assert.equal(row.errorCount,1);
});

test('attempt cancellation closes waiting stages immediately and late settlement cannot count twice',async()=>{
  const f=fixture(),pending=deferred(),context={};
  const scope=f.ctx.qidianCreateAttempt(context);
  const error=Object.assign(new Error('cancel'),{name:'AbortError'});
  const operation=f.ctx.qidianStage(context,'page_load',()=>pending.promise);
  const rejected=assert.rejects(operation,e=>e===error);
  f.state.now+=17;scope.cancel(error);
  assert.equal(f.phase('page_load').totalMs,17);assert.equal(f.phase('page_load').cancelledCount,1);
  assert.equal(f.snapshot().activeStageCount,0);
  const before=f.snapshot();f.state.now+=900;pending.resolve();await rejected;
  assert.deepEqual(f.snapshot(),before);
});

test('run close seals unfinished work at endedAt and ignores a later successful callback',async()=>{
  const f=fixture(),pending=deferred();
  const operation=f.ctx.qidianStage(null,'glyph_decode',()=>pending.promise);
  f.state.now+=31;f.window.qidianDebugRun.endedAt=f.state.now;
  f.window.qidianDebugRun.finished=true;f.ctx.qidianPerformanceCloseRun(f.window.qidianDebugRun);
  assert.equal(f.phase('glyph_decode').incompleteCount,1);assert.equal(f.phase('glyph_decode').totalMs,31);
  const before=f.snapshot();f.state.now+=1000;pending.resolve();await operation;
  assert.deepEqual(f.snapshot(),before);assert.equal(f.snapshot().closed,true);
});

test('old-stage tokens retain their run ownership after a new run starts',async()=>{
  const f=fixture(),pending=deferred(),old=f.window.qidianDebugRun;
  const operation=f.ctx.qidianStage(null,'ocr',()=>pending.promise);
  f.state.now+=15;f.ctx.qidianPerformanceCloseRun(old);
  f.window.qidianDebugRun={id:'next-run',startedAt:f.state.now,phasePerformance:f.ctx.qidianPerformanceCreateState()};
  await f.ctx.qidianStage(null,'ocr',async()=>{f.state.now+=4;});
  pending.resolve();await operation;
  assert.equal(f.phase('ocr').count,1);assert.equal(f.phase('ocr').totalMs,4);
  assert.equal(f.ctx.qidianPerformanceSnapshot(old).stages[0].totalMs,15);
});

test('scheduled waits are grouped by fixed pacing modes and do not masquerade as measured elapsed waits',()=>{
  const f=fixture();
  for(const [pacingMode,waitMs] of [['stable-fast',5000],['stable-fast',7000],['conservative',18000],['free',250],['unknown-secret-value',100]]) {
    f.ctx.qidianDebugEvent(null,'request_pacing',{pacingMode,waitMs,requestGapMs:600000,contentText:'do not retain'});
  }
  const view=f.snapshot();
  assert.equal(view.pacingWaitsAreScheduled,true);
  const rows=Object.fromEntries(view.requestPacing.map(x=>[x.pacingMode,x]));
  assert.deepEqual(rows['stable-fast'],{pacingMode:'stable-fast',count:2,scheduledWaitMs:12000,maxScheduledWaitMs:7000});
  assert.equal(rows.conservative.scheduledWaitMs,18000);assert.equal(rows.free.scheduledWaitMs,250);
  assert.equal(rows.unknown.scheduledWaitMs,100);assert(!JSON.stringify(view).includes('unknown-secret-value'));
  assert(!JSON.stringify(view).includes('600000'));assert(!JSON.stringify(view).includes('do not retain'));
});

test('export lifecycle is recorded as an inclusive parent with success and error counts',()=>{
  const f=fixture();
  f.ctx.qidianDebugEvent(null,'export_end',{durationMs:12,outcome:'success'});
  f.ctx.qidianDebugEvent(null,'export_end',{durationMs:3,outcome:'error'});
  const row=f.phase('export');
  assert.equal(row.count,2);assert.equal(row.totalMs,15);assert.equal(row.maxMs,12);
  assert.equal(row.successCount,1);assert.equal(row.errorCount,1);
});

test('only fixed numeric metadata survives in direct and nested sanitized summaries',async()=>{
  const f=fixture(),context={qidianDiagnostic:{title:'secret title',chapterId:'secret-id'},contentText:'chapter body',token:'credential'};
  await f.ctx.qidianStage(context,'page_load',async()=>{f.state.now+=5;},{contentText:'another body',token:'another credential'});
  const view=f.snapshot();
  assert(!/secret|credential|body/.test(JSON.stringify(view)));
  const wrapped=f.ctx.qidianDebugSanitize({summary:f.ctx.qidianRunSummary()});
  assert.equal(wrapped.summary.performanceSummary.stages[0].totalMs,5);
  f.ctx.qidianDebugEvent(null,'log_export',{summary:f.ctx.qidianRunSummary()});
  const row=JSON.parse(f.state.logs.at(-1).slice(14));
  assert.equal(row.summary.performanceSummary.stages[0].stage,'page_load');
  assert.equal(row.summary.performanceSummary.stages[0].totalMs,5);
  view.stages[0].count=999;assert.equal(f.phase('page_load').count,1,'snapshots do not expose mutable counter objects');
});

test('unknown names, active-stage count and overflowing durations are bounded',async()=>{
  const f=fixture();
  await f.ctx.qidianStage(null,'secret-or-unbounded-stage',async()=>{});
  assert.equal(f.snapshot().stages.length,0);
  const tokens=Array.from({length:100},()=>f.ctx.qidianPerformanceBegin('page_load',f.state.now));
  assert.equal(tokens.filter(Boolean).length,64);assert.equal(f.snapshot().activeStageCount,64);
  assert.equal(f.snapshot().omittedStages,36);
  f.ctx.qidianPerformanceCloseRun(f.window.qidianDebugRun);
  assert.equal(f.phase('page_load').count,64);assert.equal(f.snapshot().activeStageCount,0);
  f.window.qidianDebugRun={id:'bounds',startedAt:f.state.now};
  f.ctx.qidianDebugEvent(null,'request_pacing',{pacingMode:'free',waitMs:Number.MAX_VALUE});
  f.ctx.qidianDebugEvent(null,'request_pacing',{pacingMode:'free',waitMs:Number.MAX_VALUE});
  f.ctx.qidianDebugEvent(null,'request_pacing',{pacingMode:'free',waitMs:NaN});
  assert.equal(f.snapshot().requestPacing[0].scheduledWaitMs,Number.MAX_SAFE_INTEGER);
});

test('a missing or throwing logger cannot disable accumulated diagnostics',async()=>{
  const f=fixture();f.window.qidianDebugLogger=null;
  await f.ctx.qidianStage(null,'page_load',async()=>{f.state.now+=4;});
  f.window.qidianDebugLogger={info(){throw new Error('logger');}};
  await f.ctx.qidianStage(null,'page_load',async()=>{f.state.now+=7;});
  f.ctx.qidianDebugEvent(null,'request_pacing',{pacingMode:'free',waitMs:80});
  assert.equal(f.phase('page_load').totalMs,11);assert.equal(f.snapshot().requestPacing[0].scheduledWaitMs,80);
});

test('the actual Rule.run closes its final summary and resets all counters for a reused rule',async()=>{
  const code=fs.readFileSync(path.join(__dirname,'test-qidian-v34-access-qa.cjs'),'utf8');
  const stop=code.search(/^const tests\s*=\s*\[\];/m);assert(stop>0);
  const suite=vm.runInNewContext(code.slice(0,stop)+'\n({fixture})',{require,__dirname,AbortController,URL,console});
  const f=suite.fixture([{id:1,vip:true,pageMs:10,ocrMs:20},{id:2,vip:true,pageMs:12,ocrMs:22}]);
  await f.run();
  const first=f.window.qidianDebugRun;
  const view=plain(f.ctx.qidianRunSummary().performanceSummary);
  assert.equal(view.closed,true);assert.equal(view.activeStageCount,0);
  assert.equal(view.stages.find(x=>x.stage==='page_load').count,2);
  assert.equal(view.stages.find(x=>x.stage==='export').count,1);
  const summaries=f.state.logs.filter(x=>x.startsWith('[QidianDebug] ')).map(x=>JSON.parse(x.slice(14))).filter(x=>x.event==='run_summary');
  assert.deepEqual(summaries.at(-1).performanceSummary,view);
  f.rule.preHook=async()=>{throw new Error('new run stops before chapter selection');};
  await f.run();
  assert.notEqual(f.window.qidianDebugRun,first);
  const next=plain(f.ctx.qidianRunSummary().performanceSummary);
  assert.equal(next.closed,true);assert.equal(next.stages.length,0);assert.equal(next.requestPacing.length,0);
  assert.deepEqual(plain(f.ctx.qidianPerformanceSnapshot(first)),view);
});

(async()=>{
  let passed=0;
  for(const {name,fn} of tests){try{await fn();passed++;console.log(`ok ${passed} - ${name}`);}catch(error){console.error(`FAIL - ${name}`);throw error;}}
  console.log(`Passed ${passed}/${tests.length} performance summary checks.`);
})().catch(error=>{console.error(error);process.exitCode=1;});
