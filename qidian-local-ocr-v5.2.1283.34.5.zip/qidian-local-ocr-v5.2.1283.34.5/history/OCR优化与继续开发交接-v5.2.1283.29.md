# 继续开发交接 — 5.2.1283.29

## 当前交付

主脚本 `novel-downloader-qidian-range.user.js`，版本5.2.1283.29，SHA256 `70ecf84ee0d69702058602e1086b21f970187510ec0652a89edb055d17211da6`。基于.28继续，不要从GitHub原版重写而丢掉续传和准确率改动。ZIP内使用说明、最新98章分析、验证原始输出及测试为当前依据；history中的旧报告是历史。

用户要求ZIP交付、TXT默认开/EPUB默认关、按原标题号范围、免费用原HTML路线/VIP用本地OCR、未订阅连续任意章跳过、单章失败不阻断、可续传/旧TXT导入、debug可继续排查。用户在自己的浏览器登录；无需账户密码、Cookie，不使用云浏览器代登。

## 最新证据

实际新日志仍是.27，不是.28；runId muotuldl-zc2dsh。166～340共174所选，98保存/导出/断点、74目录锁跳过、2本地glyph_unresolved（256和338）、无未处理或暂停。TXT逐章核对相符，导出没有丢成功章。最长连续跳过238～251共14章，252继续；256后257～260继续，338后339/340继续。

后16次实际访问（标题323～340）占OCR时间96.9%，缓存约41.72%而此前99.87%。前后fontFamily类别有变化，但无像素不能断言具体字形变化原因；缓存未到30000上限，不支持淘汰原因。页面约1秒，冷缓存及拆分/逐字是主要瓶颈。256缺1源字U+9602且有冲突；338缺U+3FF6/U+6CE1/U+480D，2项有冲突、1项旧日志未细分；均未耗尽恢复额度。没有字形像素，不能宣称现版已修复这两章。

## .29修改

独立OCRDecoder.decodeTextRegions使用一次同样模型推理，返回完整文字和src原图检测框（src缺失才fallbackparragraphs，旋转坐标无效）。共享decodeFullText保持字节不变。buildFontDecodeMap旧完整成功路径保留，失败批组才用qidianAlignedBatchReadings全部框逐行严格对应；合法单Han入map/精确缓存，其余行递归或逐字。无完整几何证据不复用，最多32异常批组事件/章，省略数有计数。

qidianGlyphNeighborContexts只从同段立即前后已确认Han/PUA源字取最多2组，拒绝跨空白/段、不跳标点、不猜词；qidianRecoverUnmappedGlyph把两组纳入原4上下文额度，校验锚点在已确认map中。两种孤立读数一致或两组distinct有效锚点上下文一致才返回；任一有效冲突立即拒绝。原全局32次/45秒额度检查保留，在途推理不竞速、不复制。成功新锚点可供剩余缺字使用。

ocr_batch_metrics: phase=batch,inputGlyphCount,outputRegionCount,acceptedGlyphCount,unresolvedBatchGlyphs,splitDepth,durationMs,固定reasonCode。
ocr_recovery_result: sourceCodepoint,reasonCode,contextCount,nearbyContextCount,recoveryCalls,durationMs,success。
ocr_metrics: batchCalls,batchSplitCalls,singleCalls,alignedBatchCalls,partialBatchGlyphs,omittedBatchEvents,glyphCacheSize/Limit,mappingCompleted,renderProfile固定default_family/custom_family/unknown；原计时保留。分析器按事件白名单整理，不把这些诊断当章节失败或恢复。新事件不记候选/正文/图片/坐标/完整字体名。

qidianFormatChapterName绑定实际默认章名预设：起点已有第N章保留原标题，否则旧补目录号。范围及断点键不变，旧双章号TXT导入继续兼容。.28进度修复随本版包含。

## 不得弱化

所有unique字形必须映射齐全，85%正文长度+CJK+无PUA/U+FFFD及正文断点边界验收；不能猜替源字、用最新票压过冲突、截去未识别字或导出预览。现有精确像素缓存键不改模糊匹配。页面串行，VIP/切换至少10秒开始间隔，未增加并发/提频。真实401/403/429、登录/验证/WAF和连续3未知页面失败仍保护暂停；确认未订阅单独跳过不影响后续。不能保证永不检查。

## 验证及下一步

node run-tests.cjs：33/33（2syntax+31回归文件），含新增batch13、title9、neighbor15项。4套Python合77/77。原始输出与验证记录在包内，不应把此离线测试称为真实用户浏览器实测。

用户更新现有脚本后保留启用续传，重选166～340应复用有效98章，重新核验跳过目录并重试256/338；本地断点丢失可先导入98章TXT。收集下一次.29日志及TXT，按runId核对终态，分析新批组accepted/未解决数与recovery.reasonCode。只有有真实新结果才宣称具体缺字已恢复或提速；阶段相互嵌套不简单相加。标题234未进选中项尚待目录完整证据，不能宣称已处理。更早免费94/100中6章与无源码.22改动，也不能凭本次VIP日志确认已解决。
