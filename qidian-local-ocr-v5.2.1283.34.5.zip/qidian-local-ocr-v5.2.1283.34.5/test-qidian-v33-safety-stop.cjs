// Exercise the shipped scheduler with deterministic page/OCR boundaries.
// These tests neither contact the site nor solve or interact with verification.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const directory = path.resolve(process.argv[2] || __dirname);
const fixtureSource = fs.readFileSync(path.join(directory, 'test-qidian-v19-resilience.cjs'), 'utf8');
const suite = vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('const tests=[];')) + '\n({fixture,status})',
  { require, __dirname: directory, AbortController, URL, console });
const tests = [];
const test = (name, run) => tests.push({ name, run });
const ids = f => Array.from(f.state.starts, row => row.id);
const events = f => Array.from(f.state.logs).filter(line => line.startsWith('[QidianDebug] '))
  .map(line => JSON.parse(line.slice(14)));

for (const httpStatus of [401,403,429]) test(`HTTP ${httpStatus} pauses immediately before the next chapter, with no deferred rounds`, async () => {
  const f = suite.fixture([
    { id: 1, vip: true, requestError: httpStatus },
    { id: 2, vip: true },
    { id: 3, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.match(f.window.qidianPauseReason, new RegExp(String(httpStatus)));
  assert.deepEqual(Array.from(f.chapters, c => c.status), [suite.status.failed, suite.status.pending, suite.status.pending]);
  assert.equal(f.chapters[0].qidianFailureKind, 'access');
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 0);
});

test('a successful chapter resets the page-failure streak and isolated misses can recover', async () => {
  const f = suite.fixture([
    { id: 1, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 2, vip: true },
    { id: 3, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 4, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 1, 3]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert(f.chapters.every(chapter => chapter.status === suite.status.saved));
  assert.equal(events(f).filter(row => row.event === 'page_failure_pause').length, 0);
});

test('verification-paused work never automatically restarts; an explicit new run reuses successful bodies once', async () => {
  const configs = [
    { id: 1, vip: true },
    { id: 2, vip: true, accessTitle: '安全验证' },
    { id: 3, vip: true },
    { id: 4, vip: true },
  ];
  const f = suite.fixture(configs);
  await f.run();
  assert.deepEqual(ids(f), [1, 2]);
  assert.equal(f.chapters[0].status, suite.status.saved);
  const retainedBody = f.chapters[0].contentText;
  const retainedSaveCalls = Array.from(f.state.saveCalls);
  await f.run();
  assert.deepEqual(ids(f), [1, 2], 'the existing aborted signal cannot resume requests');
  assert.deepEqual(Array.from(f.state.saveCalls), retainedSaveCalls);

  // Model the user starting a fresh task after normal reading works again.
  // Persistent checkpoint loading itself is exercised by the v24 checkpoint suite.
  configs[1].accessTitle = null;
  f.window.stopController = new AbortController();
  f.window.stopFlag = f.window.stopController.signal;
  f.window.qidianPauseReason = '';
  f.window.failedCount = 0;
  f.book.qidianResumedCount = 1;
  f.chapters[0].qidianSource = 'checkpoint';
  for (const chapter of f.chapters.slice(1)) {
    chapter.status = suite.status.pending;
    chapter.retryTime = 0;
  }
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 2, 3, 4]);
  assert.equal(f.chapters[0].contentText, retainedBody);
  assert.equal(f.progress.finishedChapterNumber, 4);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第1章', '第2章', '第3章', '第4章']);
  assert(f.chapters.every(chapter => chapter.status === suite.status.saved));
});

test('consecutive local OCR errors remain bounded recoverable failures, not access pauses', async () => {
  const f = suite.fixture([{ id: 1, vip: true, glyphFail: true }, { id: 2, vip: true, glyphFail: true }, { id: 3, vip: true }]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 1, 2, 1, 2]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.chapters[2].status, suite.status.saved);
  assert.equal(events(f).filter(row => row.event === 'page_failure_pause').length, 0);
});

test('a new browser task restores the actual persisted checkpoint after an explicit access pause', async () => {
  const checkpointFixture = fs.readFileSync(path.join(directory, 'test-qidian-v27-catalog-skip.cjs'), 'utf8');
  const checkpointSuite = vm.runInNewContext(checkpointFixture.slice(0, checkpointFixture.indexOf('const tests=[];')) + '\n({fixture,statuses})',
    { require, __dirname: directory, AbortController, URL, console, TextEncoder, TextDecoder, structuredClone, Blob });
  const storage = new Map();
  const first = checkpointSuite.fixture([{ id: 1 }, { id: 2, httpStatus: 403 }, { id: 3 }, { id: 4 }], { storage });
  await first.run();
  assert.deepEqual(Array.from(first.state.requests, row => row.id), [1, 2]);
  assert.equal(first.window.stopFlag.aborted, true);
  assert(Array.from(storage.values()).some(value => value?.chapterId === '1'), 'success was persisted through the real checkpoint writer');

  const resumed = checkpointSuite.fixture([{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }], { storage });
  await resumed.run();
  assert.deepEqual(Array.from(resumed.state.requests, row => row.id), [2, 3, 4]);
  assert.equal(resumed.book.qidianResumedCount, 1);
  assert.equal(resumed.chapters[0].qidianSource, 'checkpoint');
  assert.equal(resumed.chapters[0].contentText, first.chapters[0].contentText);
  assert.equal(resumed.progress.finishedChapterNumber, 4);
  assert(resumed.chapters.every(chapter => chapter.status === checkpointSuite.statuses.saved));
  assert.deepEqual(Array.from(resumed.state.saved), [2, 3, 4]);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack ?? error); }
  }
  console.log(`${tests.length - failed}/${tests.length} explicit-access safety checks passed`);
  if (failed) process.exitCode = 1;
})();
