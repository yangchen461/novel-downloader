// Extract the shipped implementation; replace only browser/network/OCR boundaries.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const take = (a, b, from = 0) => {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing source boundary: ${a}`);
  return src.slice(start, end);
};
const status = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode = take('class ChapterAbortError', '\n\n/***/ },');
const scheduler = take('  async initChapters(book,', '\n  postHook()');
const parse = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const saveCode = take('  async addChapter(chapter) {', '\n  async save()', src.indexOf('class SaveBook'));
// Extract filtering only; v26 full-run tests cover the instrumented export.
const validation = take('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {', '      // Export lifecycle begins after per-chapter filtering.', src.indexOf('await self.initChapters(self.book'));
const progressCode = take('function formatETA(', 'app.config.compilerOptions');
const progressOptions = vm.runInNewContext(progressCode + '\napp', { external_Vue_: { createApp:o=>o }, ui_progress:'' });
function node(tag='div') { return { tag, children:[], appendChild(child) { this.children.push(child); return child; } }; }
function fixture(configs) {
  const state = { now:1000, starts:[], waits:[], clean:[], ocr:[], persist:0, removed:0, active:0, maxActive:0, onSleep:null, onClean:null, onSave:null, saveCalls:[], notices:[], logs:[], timer:0, timers:new Map(), attempts:new Map() };
  const window = { stopController:new AbortController(), failedCount:0 };
  window.stopFlag = window.stopController.signal;
  const configsById = new Map(configs.map(c=>[c.id,c]));
  const progress = progressOptions.data(); Object.assign(progress, progressOptions.methods);
  const log = { info:x=>state.logs.push(String(x)), warn:x=>state.logs.push(String(x)), error(){}, trace(){}, debug(){} };
  const sleep = async ms => { state.waits.push(ms); state.now += ms; if (state.onSleep) state.onSleep(ms); };
  const docFor = (cfg, attempt) => {
    const text = (cfg.short || cfg.shortFirst && attempt === 1) ? '短文' : `第${cfg.id}章正文` + '正文'.repeat(1000);
    // VIP short/shortFirst models truncated OCR, not an unready reader. Keep
    // its rendered source complete so readiness and OCR validation are distinct.
    const main = { id:cfg.id, cfg, textContent:cfg.vip ? `第${cfg.id}章正文` + '正文'.repeat(1000) : text, ocrText:text, querySelectorAll:()=>Array(5) };
    const doc = { title:cfg.accessTitle || (cfg.block ? 'WAF拦截页面' : `第${cfg.id}章`), body:{textContent:cfg.accessTitle || cfg.password ? '' : cfg.block ? '403 您的请求已中断' : text}, querySelector(s) {
      if (s === 'main') return cfg.missingMain || ((cfg.accessTitle || cfg.password) && !cfg.normalAccessTitle) ? null : main;
      if (s === 'form input[type=\"password\"]') return cfg.password ? {} : null;
      if (s === 'h1.title') return {innerText:`第${cfg.id}章`};
      if (s === '.vip-limit-wrap') return cfg.locked ? {} : null;
      if (s === '.content-text, .vip-limit-wrap') return main;
      return null;
    }};
    return doc;
  };
  const request = async (route, url, predicate, timeout) => {
    const id = Number(url.split('/').at(-1)), cfg = configsById.get(id);
    assert(cfg, `unexpected chapter request ${id}`);
    const attempt = (state.attempts.get(id) || 0) + 1; state.attempts.set(id,attempt);
    state.starts.push({id,route,at:state.now,attempt});
    const frameTimedOut=cfg.frameTimeout && (!cfg.frameTimeoutFirst || attempt===1);
    state.now += frameTimedOut ? timeout : cfg.pageMs ?? 1000;
    if (frameTimedOut) {
      const error = new Error('Frame Timeout!');
      error.frameState = cfg.frameTimeout === 'blank'
        ? {addressKind:'requested',readyState:'complete',bodyPresent:true,bodyTextLength:0,contentPresent:false,mainParagraphs:0}
        : {addressKind:'about:blank',readyState:'loading',bodyPresent:true,bodyTextLength:0,contentPresent:false,mainParagraphs:0};
      state.removed++;
      throw error;
    }
    if (cfg.requestError) {
      const error = new Error(typeof cfg.requestError === 'number' ? `HTTP ${cfg.requestError}` : cfg.requestError);
      if (cfg.requestErrorName) error.name = cfg.requestErrorName;
      if(typeof cfg.requestError === 'number') error.status = cfg.requestError;
      throw error;
    }
    const doc = docFor(cfg,attempt);
    if (route === 'html') return doc;
    let removed = false;
    const frame = { contentWindow:{document:doc}, remove() { if(!removed){removed=true;state.removed++;} } };
    try { assert.equal(predicate(frame),true); } catch(e) { frame.remove(); throw e; }
    return frame;
  };
  const ctx = vm.createContext({
    window, document:{location:{hostname:'www.qidian.com'}, createElement:node}, Date:{now:()=>state.now}, Math:Object.assign(Object.create(Math),{random:()=>0}),
    setTimeout:(fn,ms)=>{const id=++state.timer;state.timers.set(id,{fn,ms});return id;}, clearTimeout:id=>state.timers.delete(id), AbortController, console:log, alert:x=>state.notices.push(x),
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:status}, main:{nW:status,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log, _log__WEBPACK_IMPORTED_MODULE_6___default:()=>log, loglevel_default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:sleep}, misc:{yy:sleep}, setting:{Zz:{value:false},Nw:{value:false}}, progress:{vm:progress}, log:{M6(){}},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async url=>request('html',url),Q2:async(url,predicate,_unused,timeout)=>request('frame',url,predicate,timeout)},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(){},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{async an(main) { assert.equal(main.cfg.vip,false,'VIP body must not use cleanDOM fallback'); state.clean.push(main.id); if(state.onClean)state.onClean(main.id); if(main.cfg.cleanThrows)throw Error('synthetic cleanup failure'); return {dom:node(),text:main.textContent,images:main.cfg.hangingImage ? [{status:status.downloading}] : []}; },is(){}},
    async ocrContent(main) { assert.equal(main.cfg.vip,true,'free HTML must not use OCR'); state.ocr.push(main.id); if(main.cfg.ocrHang){const timer=[...state.timers.values()].find(t=>t.ms===600000);assert(timer);state.now+=timer.ms;timer.fn();return new Promise(()=>{});} state.now += main.cfg.ocrMs ?? 6000; if(main.cfg.glyphFail){const e=new Error('local glyph recovery exhausted');e.name='QidianGlyphError';throw e;} return {contentText:main.ocrText,contentHTML:node()}; },
    qidianGlyphCache:new Map([['fixture','字']]), async qidianPersistGlyphCache(){state.persist++;}
  });
  vm.runInContext(globals + chapterCode + '\nclass Rule {'+scheduler+'}\nclass Qidian {'+parse+'}\nclass Save {'+saveCode+'}\nthis.Chapter=Chapter;this.Rule=Rule;this.Qidian=Qidian;this.Save=Save;this.validate=self=>{let qidianCompletionMessage;'+validation+'return self.book;};',ctx);
  const parser = new ctx.Qidian(), chapters = configs.map(cfg=>new ctx.Chapter({
    bookUrl:'https://www.qidian.com/book/1/', chapterUrl:`https://www.qidian.com/chapter/1/${cfg.id}`, chapterNumber:cfg.id+1, chapterName:`第${cfg.id}章`,
    isVIP:cfg.vip, isPaid:cfg.paid, charset:'UTF-8', options:{expectedChars:2000},
    chapterParse:async(...args)=>{state.active++;state.maxActive=Math.max(state.maxActive,state.active);try{return await parser.chapterParse(...args);}finally{state.active--;}}
  }));
  for(let i=0;i<chapters.length;i++) {
    if(configs[i].initThrows) chapters[i].init=async()=>{throw Error('synthetic init failure');};
    if(configs[i].invalidSuccess) chapters[i].chapterParse=async()=>({chapterName:chapters[i].chapterName,contentText:'短',contentHTML:node(),contentImages:[]});
  }
  const rule=new ctx.Rule();rule.concurrencyLimit=1;rule.sleepTime=8000;rule.maxSleepTime=20000;
  const saver=new ctx.Save();saver.saveType={txt:true,epub:true};saver.epub={addChapter(){throw Error('EPUB must remain disabled');}};
  const realAdd=saver.addChapter.bind(saver);
  saver.addChapter=async chapter=>{
    state.saveCalls.push(chapter.chapterName);
    const cfg=configsById.get(Number(chapter.chapterUrl.split('/').at(-1)));
    if(cfg.saveThrows)throw Error('synthetic export failure');
    if(state.onSave)state.onSave(chapter);
    return realAdd(chapter);
  };
  const book={chapters};
  return {state,window,progress,ctx,chapters,book,saver,async run(){try{await rule.initChapters(book,saver);}catch(e){if(!window.stopFlag.aborted)throw e;}return book;},validate:()=>ctx.validate({book,postHook(){}})};
}
const tests=[];const test=(name,fn)=>tests.push({name,fn});
const ids=f=>f.state.starts.map(x=>x.id);
const saved=f=>f.chapters.filter(c=>c.status===status.saved).map(c=>c.chapterName);
const debugEvents=f=>f.state.logs.filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14)));
function sampledWait(f,eventName,baseMs,chapterId) {
  const event=debugEvents(f).find(row=>row.event===eventName && row.baseWaitMs===baseMs &&
    (chapterId===undefined || row.chapterId===String(chapterId)));
  assert(event,`missing sampled cooldown ${eventName}/${baseMs}`);
  assert(event.waitMs>=baseMs-5000 && event.waitMs<=baseMs+5000);
  assert.equal(event.waitMs,baseMs-5000,'the fixture uses RNG=0; the real helper samples its lower bound');
  return event.waitMs;
}
function assertContinuation(f, goodIds, missingId) {
  assert.equal(f.window.stopFlag.aborted,false);
  assert.deepEqual(saved(f),goodIds.map(id=>`第${id}章`));
  const bad=f.chapters.find(c=>c.chapterName===`第${missingId}章`);
  assert.equal(bad.status,status.failed);assert(bad.errorMessage,'failure must have a reportable reason');
  assert.equal(f.progress.processedChapterIndex,f.chapters.length);
  const book=f.validate();assert.equal(book.downloadReport.savedCount,goodIds.length);
  assert.deepEqual(book.downloadReport.missing.map(x=>x.title),[`第${missingId}章`]);
  assert(book.downloadReport.missing[0].reason);
}
async function exportTxt(book) {
  let output;
  class Options {
    genMetaDateTxt(){return 'fixture';} getchapterName(c){return c.chapterName;}
    genSectionText(s){return s;} genChapterText(n,t){return n+'\n'+t;}
    chapterSort(a,b){return a.chapterNumber-b.chapterNumber;}
  }
  const context=vm.createContext({Options,Blob,setting:{Nw:{value:false}},loglevel_default:()=>({debug(){},info(){}}),FileSaver_min:{saveAs:(blob,name)=>{output={blob,name};}}});
  vm.runInContext(globals + take('class TXT extends Options',';// ./src/save/raw.ts')+'\nthis.TXT=TXT;',context);
  Object.assign(book,{author:'fixture',bookname:'chapter-resilience',downloadSuffix:' [119-121]'});
  new context.TXT(book).saveTxt();
  return {name:output.name,text:await output.blob.text()};
}

test('isolated confirmed blank VIP page is skipped; later chapter and partial TXT survive',async()=>{
  const f=fixture([{id:119,vip:true},{id:120,vip:true,frameTimeout:'blank'},{id:121,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[119,120,121,120,120]);assert.equal(f.chapters[1].retryTime,1);
  assert.equal(f.chapters[1].qidianFailureKind,'page');assert.equal(f.state.maxActive,1);
  assert.equal(f.state.starts[2].at-f.state.starts[1].at,20000+sampledWait(f,'page_failure_cooldown',10000,120),'20s blank timeout plus the sampled cooldown');
  assertContinuation(f,[119,121],120);
  const txt=await exportTxt(f.book);
  assert.match(txt.name,/部分下载_2章/);assert.match(txt.text,/已写入 2 \/ 已选 3 章/);
  assert.match(txt.text,/第120章：/);assert.match(txt.text,/第119章正文/);assert.match(txt.text,/第121章正文/);
  assert(!txt.text.includes('第120章正文'));assert(txt.text.indexOf('第119章正文')<txt.text.indexOf('第121章正文'));
});

for(const failure of [{missingMain:true},{requestError:500},{requestError:'Network Error'}])test(`one free page anomaly preserves randomized cooldown and later free cadence: ${JSON.stringify(failure)}`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:false,...failure},{id:3,vip:false},{id:4,vip:false}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,4,2,2]);assert.equal(f.chapters[1].retryTime,1);assert.equal(f.chapters[1].qidianFailureKind,'page');
  assert.equal(f.state.starts[2].at-f.state.starts[1].at,1000+sampledWait(f,'page_failure_cooldown',10000,2),'the failed free request plus its sampled page cooldown accounts for elapsed time');
  assert.equal(f.state.starts[3].at-f.state.starts[2].at,1150,'success must restore upstream free cadence');
  assertContinuation(f,[1,3,4],2);
});

test('ordinary VIP network failure is isolated and never uses HTML fallback',async()=>{
  const f=fixture([{id:1,vip:true},{id:2,vip:true,requestError:'Failed to fetch'},{id:3,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,2,2]);assert.deepEqual(f.state.clean,[]);assert.equal(f.chapters[1].retryTime,1);
  assert.equal(f.chapters[1].qidianFailureKind,'page');assertContinuation(f,[1,3],2);
});

test('unknown frame timeout keeps one cooled retry then continues after exhausted chapter',async()=>{
  const f=fixture([{id:1,vip:true},{id:2,vip:true,frameTimeout:'unknown'},{id:3,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2,2,3,2,2,2,2]);assert.equal(f.chapters[1].retryTime,2);assert.equal(f.chapters[1].qidianFailureKind,'page');
  assert.equal(f.state.starts[2].at-f.state.starts[1].at,20000+sampledWait(f,'retry_scheduled',90000,2),'20s initial timeout plus sampled 85-95s cooldown');
  assert.equal(f.chapters[1].qidianRequestStartedAt,f.state.starts.at(-1).at);
  assert.equal(f.state.starts[3].at-f.state.starts[2].at,45000+sampledWait(f,'page_failure_cooldown',10000,2),'45s retry timeout plus sampled page cooldown');assertContinuation(f,[1,3],2);
});

test('successful content retry updates timestamp used by next VIP',async()=>{
  const f=fixture([{id:1,vip:true,shortFirst:true,ocrMs:0},{id:2,vip:true,ocrMs:0}]);await f.run();
  assert.deepEqual(ids(f),[1,1,2]);assert.equal(f.state.starts[2].at-f.state.starts[1].at,10000);
  assert.equal(f.chapters[0].qidianRequestStartedAt,f.state.starts[1].at);
  assert.equal(f.window.stopFlag.aborted,false);assert.equal(saved(f).length,2);
});

test('successful unknown-frame retry is followed by ordinary VIP timing without stale failure cooldown',async()=>{
  const f=fixture([{id:1,vip:true,frameTimeout:'unknown',frameTimeoutFirst:true,ocrMs:0},{id:2,vip:true,ocrMs:0}]);await f.run();
  assert.deepEqual(ids(f),[1,1,2]);assert.equal(f.state.starts[1].at-f.state.starts[0].at,20000+sampledWait(f,'retry_scheduled',90000,1));
  assert.equal(f.state.starts[2].at-f.state.starts[1].at,10000);
  assert.equal(f.window.stopFlag.aborted,false);assert.equal(saved(f).length,2);assert.equal(f.chapters[0].qidianFailureKind,null);
});

test('more than ten isolated temporary page failures recover without cumulative-failure stop',async()=>{
  const configs=Array.from({length:25},(_,i)=>({id:i+1,vip:true,...(i%2===0?{frameTimeout:'blank',frameTimeoutFirst:true}:{})}));
  configs.push({id:26,vip:true});const f=fixture(configs);await f.run();
  assert.equal(f.window.failedCount,13);assert.equal(f.window.stopFlag.aborted,false);assert.deepEqual(ids(f),[...configs.map(c=>c.id),...configs.filter(c=>c.frameTimeout).map(c=>c.id)]);
  assert.equal(f.progress.processedChapterIndex,26);assert.equal(saved(f).length,26);assert.equal(f.chapters[25].status,status.saved);
  const book=f.validate();assert.equal(book.downloadReport.savedCount,26);assert.equal(book.downloadReport.missing.length,0);
});

test('three consecutive unknown page failures preserve later chapters and retry only misses twice',async()=>{
  const f=fixture([{id:1,vip:true},{id:2,vip:true,frameTimeout:'blank'},{id:3,vip:true,missingMain:true},{id:4,vip:true,requestError:500},{id:5,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,4,5,2,3,4,2,3,4]);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.progress.processedChapterIndex,5);assert.equal(f.chapters[4].status,status.saved);
  for(const chapter of f.chapters.slice(1,4)) {
    assert.equal(chapter.status,status.failed);assert.equal(chapter.qidianFailureKind,'page');
    assert.notEqual(chapter.qidianSkipReason,'unsubscribed');assert.equal(chapter.contentText,null);
  }
  assert.equal(f.state.starts[2].at-f.state.starts[1].at,20000+sampledWait(f,'page_failure_cooldown',10000,2),'20s blank timeout plus sampled cooldown');
  for(const requestIndex of [3,4,7,10])assert.equal(f.state.starts[requestIndex].at-f.state.starts[requestIndex-1].at,10000,'1s failed request and sampled 5s cooldown cannot shorten the ordinary protected interval');
  assert(f.state.waits.every(ms=>ms<=1000),'failure countdowns remain promptly cancellable');
  const book=f.validate();assert.equal(book.downloadReport.savedCount,2);assert.equal(book.downloadReport.missing.length,3);
  assert(book.downloadReport.missing.every(chapter=>!/尚未处理/.test(chapter.reason)));
});

test('success resets consecutive-page counter',async()=>{
  const f=fixture([{id:1,vip:true,frameTimeout:'blank',frameTimeoutFirst:true},{id:2,vip:true},{id:3,vip:true,frameTimeout:'blank',frameTimeoutFirst:true},{id:4,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,4,1,3]);assert.equal(f.window.stopFlag.aborted,false);assert.deepEqual(saved(f),['第1章','第2章','第3章','第4章']);
});

test('twelve consecutive local glyph errors are isolated without page-error escalation',async()=>{
  const configs=Array.from({length:12},(_,i)=>({id:i+1,vip:true,glyphFail:true}));configs.push({id:13,vip:true});
  const f=fixture(configs);await f.run();assert.deepEqual(ids(f),[...configs.map(c=>c.id),...configs.slice(0,12).map(c=>c.id),...configs.slice(0,12).map(c=>c.id)]);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.window.failedCount,36);assert.equal(f.progress.processedChapterIndex,13);
  for(const chapter of f.chapters.slice(0,12)){assert.equal(chapter.status,status.failed);assert.equal(chapter.qidianFailureKind,'local');assert.equal(chapter.retryTime,1);assert.equal(chapter.contentText,null);}
  assert.deepEqual(f.state.clean,[]);assert.equal(f.state.removed,37);assert.deepEqual(saved(f),['第13章']);
});

test('content integrity rejection keeps body out of TXT and later chapter proceeds',async()=>{
  const f=fixture([{id:1,vip:true},{id:2,vip:true,short:true},{id:3,vip:true}]);await f.run();
  assert.equal(f.chapters[1].qidianFailureKind,'local');assert.equal(f.chapters[1].contentText,null);assertContinuation(f,[1,3],2);
});

for(const failure of ['initThrows','saveThrows','invalidSuccess'])test(`${failure} marks chapter failed with a reason, advances progress and preserves following chapter`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:false,[failure]:true},{id:3,vip:false}]);await f.run();
  assertContinuation(f,[1,3],2);
  assert.equal(f.progress.finishedChapterNumber,2);assert(f.chapters[1].qidianFailureKind);
  if(failure==='saveThrows')assert.match(f.chapters[1].errorMessage,/export|导出|保存/);
  if(failure==='initThrows')assert.match(f.chapters[1].errorMessage,/init/);
  if(failure==='invalidSuccess')assert(!f.state.saveCalls.includes('第2章'),'invalid body must be rejected before saver');
});

for(const vip of [false,true])for(const code of [401,403,429])test(`HTTP ${code} on ${vip?'VIP':'free'} stops and never requests following chapter`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip,requestError:code},{id:3,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[1].retryTime,1);
  assert(f.window.qidianPauseReason);const book=f.validate();assert.equal(book.downloadReport.savedCount,1);assert.match(book.downloadReport.missing[1].reason,/尚未处理/);
});

for(const vip of [false,true])test(`${vip?'VIP':'free'} WAF still stops with no retry or following request`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip,block:true},{id:3,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[1].retryTime,1);assert.match(f.window.qidianPauseReason,/拦截/);
});

test('user stop during anomaly cooldown sends no later request',async()=>{
  const f=fixture([{id:1,vip:false,missingMain:true},{id:2,vip:false}]);
  f.state.onSleep=()=>f.window.stopController.abort();await f.run();assert.deepEqual(ids(f),[1]);assert.equal(f.window.stopFlag.aborted,true);
});

test('user stop during 90s timeout retry cooldown prevents both retry and next chapter',async()=>{
  const f=fixture([{id:1,vip:true,frameTimeout:'unknown'},{id:2,vip:true}]);
  f.state.onSleep=()=>{if(f.state.starts.length)f.window.stopController.abort();};await f.run();
  assert.deepEqual(ids(f),[1]);assert.equal(f.window.stopFlag.aborted,true);
});

for(const vip of [false,true])for(const access of [{accessTitle:'用户登录'},{accessTitle:'安全验证'}])test(`explicit access wall stops ${vip?'VIP':'free'}: ${JSON.stringify(access)}`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip,...access},{id:3,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[1].retryTime,1);
});

for(const vip of [false,true])test(`generic password modal alone does not pause ${vip?'VIP':'free'} processing`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip,password:true},{id:3,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,2,2]);assert.equal(f.chapters[1].qidianFailureKind,'page');
  assertContinuation(f,[1,3],2);
});

for(const main of [null,{textContent:'',querySelectorAll:()=>[]}])test(`loading chapter with password modal is not an access wall (${main ? 'empty main' : 'missing main'})`,async()=>{
  const f=fixture([]);
  const doc={title:'第120章',body:{textContent:'加载中'},querySelector:selector=>selector==='main'?main:selector==='form input[type=\"password\"]'?{}:null};
  assert.equal(f.ctx.qidianPageIsBlocked(doc),false,'generic login form must not turn page loading into a task-wide stop');
  doc.title='用户登录';assert.equal(f.ctx.qidianPageIsBlocked(doc),true,'explicit standalone login title remains blocking');
  doc.title='安全验证';assert.equal(f.ctx.qidianPageIsBlocked(doc),true,'explicit standalone verification title remains blocking');
});

test('normal chapter main containing access words is not treated as an access wall',async()=>{
  const f=fixture([{id:1,vip:true,accessTitle:'安全验证',normalAccessTitle:true},{id:2,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.window.stopFlag.aborted,false);assert.equal(saved(f).length,2);
});

test('600s unresolved OCR watchdog fails only its chapter and continues without retrying the hung work',async()=>{
  const f=fixture([{id:1,vip:true,ocrHang:true},{id:2,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.window.stopFlag.aborted,false);assert.equal(f.window.qidianPauseReason,undefined);
  assert.equal(f.chapters[0].status,status.failed);assert.equal(f.chapters[0].qidianFailureKind,'local');
  assert.equal(f.chapters[0].qidianNoAutoRetry,true);assert.equal(f.chapters[0].contentText,null);
  assert.equal(f.chapters[1].status,status.saved);
  const book=f.validate();assert.equal(book.downloadReport.savedCount,1);assert.equal(book.downloadReport.missing.length,1);
  assert.match(book.downloadReport.missing[0].reason,/600|超时/);
});

// Read the shipped HTTP functions too: parser-only mocks would miss a swallowed
// 403/429 in ggetText before Qidian's error classifier could see it.
const httpCode=take('function gfetch(', '\nasync function getText(')+
  take('async function ggetText(', '\nasync function ggetHtmlDomWithRetry(');
function attachHttp(context, response) {
  const requests=[], errors=[];
  context.TextDecoder=TextDecoder;
  context._log__WEBPACK_IMPORTED_MODULE_0___default=()=>({debug(){},error:error=>{errors.push(error);}});
  context._misc__WEBPACK_IMPORTED_MODULE_3__={OJ:value=>structuredClone(value)};
  context._GM__WEBPACK_IMPORTED_MODULE_2__={nV:request=>{
    requests.push(request);
    if(response.event)request[response.event](response.error || new Error('synthetic GM network error'));
    else request.onload({status:response.status,responseText:'正常正文',response:new TextEncoder().encode('正常正文').buffer});
  }};
  vm.runInContext(httpCode,context);
  return {requests,errors};
}
for(const charset of [undefined,'UTF-8'])for(const code of [401,403,429])test(`real ggetText preserves ${code}, parser pauses, timeout=20s (${charset ?? 'unspecified charset'})`,async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:false}]);
  const http=attachHttp(f.ctx,{status:code});
  f.chapters[0].charset=charset;
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.pG=f.ctx.ggetHtmlDOM;
  await f.run();
  assert.equal(http.requests.length,1,'no retry and no next chapter');
  assert.equal(http.requests[0].timeout,20000,'free parser must pass a bounded request timeout through ggetText');
  assert.equal(http.requests[0].responseType,charset === undefined ? undefined : 'arraybuffer');
  assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[0].retryTime,1);
  assert.equal(f.chapters[0].qidianFailureKind,'access');assert.equal(f.chapters[1].status,status.pending);
  assert.match(f.window.qidianPauseReason,new RegExp(String(code)));
  // Also inspect the real propagated status, separate from classifier outcome.
  await assert.rejects(f.ctx.ggetText('https://www.qidian.com/chapter/1/9',charset,{timeout:20000}),error=>error.status===code);
  assert.equal(http.errors.length,0,'Qidian transport errors must reach the parser instead of being swallowed');
});
for(const event of ['ontimeout','onabort'])for(const charset of [undefined,'UTF-8'])test(`gfetch ${event} rejects and Qidian ggetText propagates (${charset ?? 'unspecified charset'})`,async()=>{
  const ctx=vm.createContext({});const http=attachHttp(ctx,{event});
  const options={timeout:20000};
  await assert.rejects(ctx.ggetText('https://book.qidian.com/chapter/1/9',charset,options),new RegExp(event==='ontimeout'?'timed out':'aborted'));
  assert.equal(http.requests.length,1);assert.equal(http.requests[0].timeout,20000);assert.equal(http.errors.length,0);
  assert.deepEqual(options,{timeout:20000},'charset handling must not mutate caller options');
});
for(const charset of [undefined,'UTF-8'])test(`ordinary-site ggetText still logs and swallows transport/status errors (${charset ?? 'unspecified charset'})`,async()=>{
  for(const response of [{status:403},{event:'ontimeout'},{event:'onabort'},{event:'onerror'}]) {
    const ctx=vm.createContext({});const http=attachHttp(ctx,response);
    const value=await ctx.ggetText('https://example.com/chapter/1/9',charset,{timeout:20000});
    assert.equal(value,undefined);assert.equal(http.errors.length,1);assert.equal(http.requests.length,1);
  }
});

test('TXT-only hanging chapter image does not delay body export or following chapter',async()=>{
  const f=fixture([{id:1,vip:false,hangingImage:true},{id:2,vip:false}]);f.window.qidianTxtOnly=true;await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.waits,[50]);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.chapters[0].retryTime,0);assert.equal(saved(f).length,2);assert.equal(f.progress.finishedChapterNumber,2);
  assert.equal(f.validate().downloadReport.savedCount,2);
});

test('non-TXT hanging image is bounded to 30s per attempt; failure does not block next chapter',async()=>{
  const f=fixture([{id:1,vip:false,hangingImage:true},{id:2,vip:false}]);f.window.qidianTxtOnly=false;await f.run();
  assert.deepEqual(ids(f),[1,1,2,1,1,1,1]);assert.equal(f.state.waits.filter(ms=>ms===500).length,360,'six bounded 30s image waits across three passes');
  const retries=f.state.logs.filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14))).filter(event=>event.event==='retry_scheduled');
  assert.equal(retries.length,3,'one normal bounded content retry per pass');
  assert(retries.every(event=>event.baseWaitMs===10000 && event.waitMs===5000),'RNG=0 uses the 5s lower bound of each sampled content retry');
  assert(f.state.waits.every(ms=>ms<=1000),'retry countdowns remain promptly cancellable');
  assert.equal(f.chapters[0].retryTime,2);assert.equal(f.chapters[0].qidianFailureKind,'local');assert.match(f.chapters[0].errorMessage,/附图等待超时/);
  assertContinuation(f,[2],1);
});

test('user stop during image wait returns promptly and prevents retry or subsequent chapter',async()=>{
  const f=fixture([{id:1,vip:false,hangingImage:true},{id:2,vip:false}]);f.window.qidianTxtOnly=false;
  f.state.onSleep=ms=>{if(ms===500)f.window.stopController.abort();};await f.run();
  assert.deepEqual(ids(f),[1]);assert.deepEqual(f.state.waits,[500]);assert.equal(f.window.stopFlag.aborted,true);
  assert.equal(f.chapters[0].status,status.aborted);assert.equal(f.chapters[0].retryTime,0);assert.equal(f.chapters[1].status,status.pending);
});

(async()=>{let failed=0;for(const {name,fn} of tests){try{await fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error);}}
console.log(`${tests.length-failed}/${tests.length} v19 resilience checks passed`);if(failed)process.exitCode=1;})();
