#!/usr/bin/env python3
"""Summarize schema 1/2 QidianDebug JSON lines using whitelisted diagnostics.

Events retain file order. Missing/duplicate sequence numbers must not invent an
execution order. Reports omit novel bodies, options, URL and credential fields.
"""
import argparse
import collections
import json
import math
import re
import statistics
from pathlib import Path


IDENTIFIER = re.compile(r"^[A-Za-z0-9_.:-]{1,160}$")
EVENT_NAME = re.compile(r"^[a-z][a-z0-9_]{0,79}$")
STATUS = {0: "pending", 1: "downloading", 2: "failed", 3: "finished", 4: "aborted", 5: "saved"}
NUMBERS = set("seq elapsedMs timestampMs attempt attempts validationAttempt durationMs catalogNumber chapterNumber status httpStatus selectedCount savedCount exportedCount resumedCount restoredCount pendingCount liveSuccessCount attemptCount retryLimit waitMs plannedDelayMs requestGapMs minimumGapMs formatFailures formatFailureCount failedCount abortedCount skippedCount unprocessedCount inProgressCount missingCount queued success failed aborted unprocessed restored chars bodyLength fullTextChars expectedChars actualChars cjkChars minimumChars minimumCjk unresolvedPrivateUseChars replacementChars cachedGlyphs uniqueGlyphs unresolvedGlyphs ocrCalls fingerprintMs ocrMs cacheHitRatio bytes eventCount eventRows logBytes droppedEvents sourceChars cleanedChars paragraphCount knownRecordsDeleted processedCount remainingCount percent progressPercent etaMs timeoutMs contentNodeCount frameCount elapsedWaitMs bodyTextLength mainParagraphs loadEvents errorEvents bodyElements scriptCount".split())
NUMBERS.update("capturedPageErrors droppedPageErrors observationMs".split())
NUMBERS.update("documentGeneration rawMainChars rawMainCjk removedDuringCleanup pageMs cleanMs".split())
NUMBERS.update("summarySeq offset total chunkIndex chunkCount detailChunkCount missingTotal missingOmitted skippedTotal skippedOmitted failuresTotal failuresOmitted".split())
NUMBERS.update("inputGlyphCount outputRegionCount acceptedGlyphCount unresolvedBatchGlyphs splitDepth contextCount nearbyContextCount recoveryCalls totalMs recoveryMs batchCalls batchSplitCalls singleCalls alignedBatchCalls partialBatchGlyphs omittedBatchEvents glyphCacheSize glyphCacheLimit".split())
STRINGS = set("version chapterId title mode source statusName failureKind reason errorName errorCode stage outcome operation pauseReason fileName bodyBoundarySource timestampISO stack message lastFailureStage lastErrorName lastErrorCode lastFailureReason skipReason accessKind accessEvidence kind evidence readyState frameState addressKind".split())
BOOLS = set("complete enabled replaced legacyBodyRevalidated expectedCharsChanged persistenceDisabled hasBody hasContent hasPurchasePrompt hasLoginPrompt hasAccessWall frameLoaded frameAccessible bodyPresent mainPresent contentPresent noticeShown".split())
BOOLS.update("pageErrorProbeAvailable trustedMixedCatalog catalogLocked catalogMarkedPaid catalogSkipEnabled".split())
BOOLS.add("mappingCompleted")
BOOLS.update("sourceSnapshot rawMainComplete".split())
BOOLS.add("detailsFollow")
QUALITY = set("expectedChars actualChars cjkChars minimumChars minimumCjk unresolvedPrivateUseChars replacementChars complete reason".split())
STATS = set("restored missed rejected written writeFailed readFailed imported matched skipped failed bytes records".split())
READER_NUMBERS = set("mainTextLength contentTextLength purchaseControlCount genericSubscribeControlCount loginControlCount verificationControlCount loadingControlCount controlCount omittedControls".split())
READER_NUMBERS.update("mainNonWhitespaceChars contentRootCount visibleContentRootCount".split())
READER_BOOLS = set("contentRootPresent contentRootVisible vipLimitPresent vipLimitVisible".split())
CONTROL_BOOLS = {"visible", "inContent", "inNavigation"}
CONTROL_LABELS = set("unclassified subscription_setting login verification chapter_purchase generic_purchase loading".split())
PAGE_REASON_CODES = {"unhandled_rejection", "resource_error", "runtime_error"}
PAGE_RESOURCE_KINDS = set("none script style image source video audio".split())
PAGE_MESSAGE_KINDS = set("blocked_by_client module_load_failed cross_origin_failed network_failed unclassified".split())
PAGE_ERROR_NAMES = set("Error TypeError ReferenceError SyntaxError RangeError URIError EvalError SecurityError ChunkLoadError AbortError NetworkError NotAllowedError QuotaExceededError".split())
CATALOG_REASON_CODES = {"user_disabled", "no_paid_catalog_reference", "visible_catalog_locks"}
OCR_BATCH_REASON_CODES = set("aligned_partial aligned_complete missing_regions invalid_geometry duplicate_row cross_row out_of_bounds missing_row invalid_output too_many_regions text_fallback text_mismatch".split())
OCR_RECOVERY_REASON_CODES = set("isolated_agreement anchored_agreement isolated_conflict anchored_conflict no_valid_reading insufficient_anchors call_budget time_budget stopped".split())
OCR_RENDER_PROFILES = {"default_family", "custom_family", "unknown"}
OCR_DIAGNOSTIC_COMMON_FIELDS = set("version chapterId catalogNumber title mode source attempt attempts stage seq elapsedMs timestampMs timestampISO durationMs".split())
OCR_BATCH_FIELDS = set("inputGlyphCount outputRegionCount acceptedGlyphCount unresolvedBatchGlyphs splitDepth".split())
OCR_RECOVERY_FIELDS = set("contextCount nearbyContextCount recoveryCalls".split())
CONTROL_CLASS = re.compile(r"^[a-z][a-z0-9_-]{0,59}$", re.I)
CONTROL_CLASS_RELEVANT = re.compile(r"subscribe|purchase|vip|limit|read|content|login|verif|loading|btn|button|pay|chapter|unlock", re.I)
CONTROL_CLASS_SECRET = re.compile(r"cookie|credential|token|secret|password|passwd|csrf|session", re.I)


def number(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        try:
            return value if 0 <= value <= 9007199254740991 and math.isfinite(value) else None
        except (OverflowError, TypeError):
            pass
    return None


def safe_text(value, limit=240):
    if not isinstance(value, str):
        return None
    value = re.sub(r"(?:https?|chrome-extension|moz-extension|file)://[^\s<>\"']+", "[URL]", value, flags=re.I)
    value = re.sub(r"\b(?:cookie|set-cookie|authorization)\s*[:=][^\r\n]*", "[REDACTED]", value, flags=re.I)
    value = re.sub(r"\b(?:password|passwd|token|access_token|refresh_token|sessionid|csrf|api[_-]?key)\s*[:=]\s*[^\s,;]+", "[REDACTED]", value, flags=re.I)
    value = re.sub(r"\bBearer\s+\S+", "Bearer [REDACTED]", value, flags=re.I)
    value = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]", "", value)
    return value[:limit]


def identifier(value):
    return value if isinstance(value, str) and IDENTIFIER.fullmatch(value) else None


def source_codepoint(value):
    """Allow only a source Han/PUA code point, never a decoded candidate."""
    if not isinstance(value, str) or not re.fullmatch(r"U\+[0-9A-F]{4,6}", value):
        return None
    code = int(value[2:], 16)
    ranges = ((0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF),
              (0x20000, 0x2A6DF), (0x2A700, 0x2B73F), (0x2B740, 0x2B81F),
              (0x2B820, 0x2CEAF), (0x2CEB0, 0x2EBEF), (0x2EBF0, 0x2EE5F),
              (0x30000, 0x3134F), (0x31350, 0x323AF), (0x2F800, 0x2FA1F),
              (0xE000, 0xF8FF), (0xF0000, 0xFFFFD), (0x100000, 0x10FFFD))
    return value if any(left <= code <= right for left, right in ranges) else None


def reader_diagnostics(raw):
    """Retain typed structure and fixed labels, never reader/control text."""
    result = {key: number(raw[key]) for key in sorted(READER_NUMBERS) if key in raw and number(raw[key]) is not None}
    result.update({key: raw[key] for key in sorted(READER_BOOLS) if isinstance(raw.get(key), bool)})
    if isinstance(raw.get("controls"), list):
        controls = []
        for item in raw["controls"][:40]:
            if not isinstance(item, dict):
                continue
            control = {key: item[key] for key in sorted(CONTROL_BOOLS) if isinstance(item.get(key), bool)}
            tag = item.get("tagName")
            if isinstance(tag, str) and re.fullmatch(r"[a-z]{1,12}", tag, re.I):
                control["tagName"] = tag.lower()
            if isinstance(item.get("labelKind"), str) and item["labelKind"] in CONTROL_LABELS:
                control["labelKind"] = item["labelKind"]
            if isinstance(item.get("classes"), list):
                control["classes"] = [name for name in item["classes"][:40] if isinstance(name, str) and CONTROL_CLASS.fullmatch(name)
                                      and not re.search(r"\d{6,}", name) and CONTROL_CLASS_RELEVANT.search(name)
                                      and not CONTROL_CLASS_SECRET.search(name)][:6]
            controls.append(control)
        result["controls"] = controls
        if len(raw["controls"]) > 40:
            result["analyzerOmittedControls"] = len(raw["controls"]) - 40
    return result


def sanitize(raw, nested=False, depth=0):
    """Do not copy arbitrary nested metadata or raw exception objects."""
    if depth > 2:
        return {}
    row = {}
    for key in sorted(NUMBERS):
        value = number(raw.get(key))
        if value is not None:
            row[key] = value
    for key in sorted(STRINGS):
        value = safe_text(raw.get(key), 1200 if key == "stack" else 120 if key in {"title", "stage", "errorCode", "errorName"} else 240)
        if value is not None:
            row[key] = value
    for key in sorted(BOOLS):
        if isinstance(raw.get(key), bool):
            row[key] = raw[key]
    if isinstance(raw.get("readerDiagnostics"), dict):
        row["readerDiagnostics"] = reader_diagnostics(raw["readerDiagnostics"])
    # Page probes emit categories only. Raw message/stack/error objects must not
    # leak through the generic legacy error whitelist, even in malformed logs.
    diagnostic_event = raw.get("event")
    if diagnostic_event in {"ocr_batch_metrics", "ocr_recovery_result"}:
        # Local OCR diagnostics retain fixed categories and counts only. Do not
        # copy legacy error fields, OCR text/candidates, geometry, or nested data.
        fields = OCR_BATCH_FIELDS if diagnostic_event == "ocr_batch_metrics" else OCR_RECOVERY_FIELDS
        row = {key: value for key, value in row.items() if key in OCR_DIAGNOSTIC_COMMON_FIELDS | fields}
        allowed = OCR_BATCH_REASON_CODES if diagnostic_event == "ocr_batch_metrics" else OCR_RECOVERY_REASON_CODES
        if isinstance(raw.get("reasonCode"), str) and raw["reasonCode"] in allowed:
            row["reasonCode"] = raw["reasonCode"]
        if diagnostic_event == "ocr_batch_metrics" and raw.get("phase") == "batch":
            row["phase"] = "batch"
        if diagnostic_event == "ocr_recovery_result":
            if isinstance(raw.get("success"), bool):
                row["success"] = raw["success"]
            codepoint = source_codepoint(raw.get("sourceCodepoint"))
            if codepoint is not None:
                row["sourceCodepoint"] = codepoint
    elif diagnostic_event == "frame_page_error":
        row = {key: value for key, value in row.items() if key in {
            "version", "chapterId", "catalogNumber", "title", "mode", "attempt", "attempts",
            "stage", "seq", "elapsedMs", "timestampMs", "timestampISO", "durationMs"}}
        for key, allowed in (("reasonCode", PAGE_REASON_CODES), ("resourceKind", PAGE_RESOURCE_KINDS),
                             ("messageKind", PAGE_MESSAGE_KINDS), ("errorName", PAGE_ERROR_NAMES)):
            if isinstance(raw.get(key), str) and raw[key] in allowed:
                row[key] = raw[key]
    elif raw.get("event") == "catalog_skip_summary" and isinstance(raw.get("reasonCode"), str) and raw["reasonCode"] in CATALOG_REASON_CODES:
        row["reasonCode"] = raw["reasonCode"]
    if diagnostic_event == "ocr_metrics":
        profile = raw.get("renderProfile")
        if isinstance(profile, dict):
            profile = profile.get("kind")
        if isinstance(profile, str) and profile in OCR_RENDER_PROFILES:
            row["renderProfile"] = profile
    if not nested:
        row.update(schema=raw["schema"], event=raw["event"], runId=identifier(raw.get("runId")))
    if diagnostic_event in {"frame_page_error", "ocr_batch_metrics", "ocr_recovery_result"}:
        return row
    if "sourceMatched" in raw and (raw["sourceMatched"] is None or isinstance(raw["sourceMatched"], bool)):
        row["sourceMatched"] = raw["sourceMatched"]
    roots = raw.get("rootSelection")
    if isinstance(roots, dict):
        row["rootSelection"] = {key: number(roots[key]) for key in ("contentRootCount", "eligibleRootCount")
                                if key in roots and number(roots[key]) is not None}
        reason = roots.get("reason")
        if isinstance(reason, str) and reason in {"ambiguous_content_roots", "single_content_root", "excluded_content_roots", "main_fallback"}:
            row["rootSelection"]["reason"] = reason
    fingerprint = raw.get("sourceFingerprint")
    if isinstance(fingerprint, dict) and fingerprint.get("kind") == "dual32_utf16_nonspace":
        digest = fingerprint.get("digest")
        if isinstance(digest, str) and re.fullmatch(r"\d{1,12}:[0-9a-f]{1,8}:[0-9a-f]{1,8}", digest):
            row["sourceFingerprint"] = {"kind": "dual32_utf16_nonspace", "digest": digest}
    installation = raw.get("probeInstallState")
    if isinstance(installation, dict) and isinstance(installation.get("readyState"), str) and installation["readyState"] in {"loading", "interactive", "complete", "unknown"}:
        row["probeInstallState"] = {"readyState": installation["readyState"]}
    if isinstance(raw.get("quality"), dict):
        row["quality"] = {key: value for key, value in sanitize(raw["quality"], True, depth + 1).items() if key in QUALITY}
    if isinstance(raw.get("checkpointStats"), dict):
        row["checkpointStats"] = {key: number(value) for key, value in raw["checkpointStats"].items() if key in STATS and number(value) is not None}
    for key in ("missing", "failures", "skipped"):
        if isinstance(raw.get(key), list):
            row[key] = [sanitize(item, True, depth + 1) for item in raw[key] if isinstance(item, dict)]
    for key in ("error", "buildError"):
        if isinstance(raw.get(key), dict):
            safe_error = {}
            for field in ("errorName", "errorCode", "httpStatus", "reason", "stack", "stage"):
                value = raw[key].get(field)
                if value is None and field in {"errorName", "reason"}:
                    value = raw[key].get("name" if field == "errorName" else "message")
                value = number(value) if field == "httpStatus" else safe_text(value, 1200 if field == "stack" else 240)
                if value is not None:
                    safe_error[field] = value
            row[key] = safe_error
    for key in ("snapshot", "progress", "summary", "frameState"):
        if isinstance(raw.get(key), dict):
            row[key] = sanitize(raw[key], True, depth + 1)
    if "catalogNumber" not in row and "chapterNumber" in row:
        row["catalogNumber"] = row["chapterNumber"]
    return row


def timings(values):
    values = sorted(value for value in values if number(value) is not None)
    if not values:
        return dict(count=0, medianMs=None, p95Ms=None, minMs=None, maxMs=None)
    return dict(count=len(values), medianMs=statistics.median(values),
                p95Ms=values[math.ceil(len(values) * .95) - 1], minMs=values[0], maxMs=values[-1])


def chapter_key(row):
    chapter_id = identifier(row.get("chapterId"))
    if chapter_id:
        return "id:" + chapter_id
    catalog = number(row.get("catalogNumber"))
    return "catalog:" + str(catalog) if catalog is not None else None


def status_name(row):
    if row.get("statusName") == "skipped":
        return "skipped"
    if row.get("statusName") in STATUS.values():
        return row["statusName"]
    status = row.get("status")
    return STATUS.get(status) if isinstance(status, int) and not isinstance(status, bool) else None


def is_skip(row):
    """Use explicit local diagnostics, never infer access from HTTP or text."""
    return row.get("event") == "chapter_skipped" or status_name(row) == "skipped" or row.get("skipReason") == "unsubscribed" or row.get("errorCode") == "chapter_unsubscribed"


def failure(row):
    keys = set("event seq elapsedMs chapterId catalogNumber title mode attempt attempts stage durationMs outcome errorName errorCode httpStatus reason message failureKind quality operation lastFailureStage lastErrorName lastErrorCode lastFailureReason error buildError frameState accessKind accessEvidence readerDiagnostics pageErrorProbeAvailable capturedPageErrors droppedPageErrors observationMs catalogLocked catalogMarkedPaid".split())
    result = {key: row[key] for key in sorted(keys) if key in row}
    result.setdefault("stage", row.get("lastFailureStage") or "unknown")
    return result


def sequences(rows):
    valid = [row["seq"] for row in rows if isinstance(row.get("seq"), int) and row["seq"] >= 0]
    counts = collections.Counter(valid)
    unique = sorted(counts)
    return {"ordering": "file_order", "observedCount": len(valid), "missingSequenceFields": len(rows) - len(valid),
            "duplicateSequences": [seq for seq, count in sorted(counts.items()) if count > 1],
            "outOfOrderTransitions": sum(right < left for left, right in zip(valid, valid[1:])),
            "gaps": [{"after": left, "before": right, "missingCount": right - left - 1} for left, right in zip(unique, unique[1:]) if right - left > 1],
            "note": "Sequence gaps can indicate omitted or truncated events; they do not establish their cause."}


def expand_summary_details(row, rows):
    """Join only final-detail chunks linked to this exact summary sequence.

    Keep partial evidence explicit when the bounded log has lost a chunk; never
    infer rows from counts or blend a different summary's chapter outcomes.
    """
    result = dict(row)
    diagnostics = {}
    summary_seq = row.get("seq")
    for key in ("missing", "skipped", "failures"):
        total = row.get(key + "Total")
        if not isinstance(total, int) or total <= len(row.get(key, [])):
            continue
        slots = dict(enumerate(row.get(key, [])))
        observed_chunks = duplicates = 0
        if isinstance(summary_seq, int):
            for chunk in rows:
                if (chunk.get("event") != "run_details" or chunk.get("summarySeq") != summary_seq
                        or chunk.get("kind") != key or chunk.get("total") != total):
                    continue
                offset, items = chunk.get("offset"), chunk.get(key)
                if (not isinstance(offset, int) or offset < len(row.get(key, []))
                        or not isinstance(items, list) or len(items) > 40 or offset + len(items) > total):
                    continue
                observed_chunks += 1
                for index, item in enumerate(items, offset):
                    if index in slots:
                        duplicates += 1
                    else:
                        slots[index] = item
        result[key] = [slots[index] for index in sorted(slots)]
        diagnostics[key] = dict(expectedCount=total, observedCount=len(slots),
                                unavailableCount=total - len(slots), observedChunks=observed_chunks,
                                duplicateItems=duplicates, complete=len(slots) == total)
    if diagnostics:
        result["detailDiagnostics"] = diagnostics
    return result


def summary(rows, chapters):
    summaries = [row for row in rows if row["event"] == "run_summary"]
    if summaries:
        row = expand_summary_details(summaries[-1], rows)
        aliases = {"queued": "selectedCount", "success": "savedCount", "failed": "failedCount", "aborted": "abortedCount", "unprocessed": "unprocessedCount", "restored": "resumedCount"}
        result = {key: row.get(key, row.get(alias)) for key, alias in aliases.items()}
        result.update(durationMs=row.get("durationMs"), inProgress=row.get("inProgressCount", 0), exportedCount=row.get("exportedCount"), formatFailureCount=row.get("formatFailureCount", row.get("formatFailures")), missingCount=row.get("missingCount"), skippedCount=row.get("skippedCount", 0 if not row.get("skipped") else None), skipped=row.get("skipped", []))
        result.update(source="run_summary", outcome=row.get("outcome") if row.get("outcome") in {"completed", "completed_with_skips", "partial", "paused", "stopped", "failed"} else "unknown", failures=[item for item in row.get("failures", [item for item in row.get("missing", []) if status_name(item) == "failed"]) if not is_skip(item)], missing=row.get("missing", []))
        for key in ("pauseReason", "error", "detailDiagnostics"):
            if key in row:
                result[key] = row[key]
        count_keys = ("queued", "success", "failed", "aborted", "unprocessed", "restored", "skippedCount")
        complete = all(isinstance(result[key], int) for key in count_keys) and isinstance(result["inProgress"], int)
        mismatch = complete and (result["queued"] != sum(result[key] for key in ("success", "failed", "aborted", "unprocessed", "inProgress", "skippedCount")) or result["restored"] > result["success"])
        result["countsComplete"] = complete and not mismatch
        result["countMismatch"] = bool(mismatch)
        return result
    selections = [row for row in rows if row["event"] == "selection_result"]
    if selections:
        row = selections[-1]
        counts = collections.Counter(status_name(item) for item in row.get("missing", []))
        return dict(source="legacy_selection", outcome="unknown", queued=row.get("selectedCount"), success=row.get("savedCount"),
                    failed=counts["failed"], aborted=counts["aborted"], unprocessed=counts["pending"] + counts["downloading"],
                    restored=row.get("resumedCount"), skippedCount=row.get("skippedCount", counts["skipped"]), skipped=row.get("skipped", [item for item in row.get("missing", []) if status_name(item) == "skipped"]), unclassifiedMissing=sum(count for name, count in counts.items() if name not in {"failed", "aborted", "pending", "downloading", "skipped"}),
                    durationMs=row.get("elapsedMs"), countsComplete=False, note="Legacy selection describes extraction, not a confirmed final export or disk write.")
    counts = collections.Counter(chapter["finalOutcome"] for chapter in chapters)
    return dict(source="observed_results", outcome="unknown", queued=None, success=counts["success"], failed=counts["failed"], aborted=counts["aborted"],
                unprocessed=None, restored=sum(chapter["restored"] for chapter in chapters), skippedCount=counts["skipped"], skipped=[{key: chapter[key] for key in ("chapterId", "catalogNumber", "title", "mode", "source", "skipReason", "accessEvidence", "latestStatus") if key in chapter} for chapter in chapters if chapter["finalOutcome"] == "skipped"], durationMs=None, countsComplete=False,
                note="Only observed selected chapters are counted; missing or unrequested catalog chapters are not inferred.")


def analyze_run(run_id, rows):
    chapters = collections.OrderedDict()
    durations, starts = collections.defaultdict(list), collections.defaultdict(list)
    duration_sources, stage_issues = collections.Counter(), collections.Counter()
    failures = []
    for row in rows:
        event, key = row["event"], chapter_key(row)
        if key and event not in {"run_summary", "selection_result", "txt_export", "log_export", "export_begin", "export_end", "completion_notice", "catalog_skip_summary"}:
            chapter = chapters.setdefault(key, dict(timeline=[], failures=[], finalOutcome="unknown", restored=False))
            for field in ("chapterId", "catalogNumber", "title", "mode", "source", "skipReason", "accessEvidence", "catalogLocked", "catalogMarkedPaid"):
                if field in row:
                    chapter[field] = row[field]
            chapter["timeline"].append(row)
            if "quality" in row:
                chapter["latestQuality"] = row["quality"]
            attempt = row.get("attempt", row.get("attempts"))
            if attempt is not None:
                chapter["attempts"] = max(chapter.get("attempts", 0), attempt)
            if event in {"checkpoint_restored", "chapter_restored"}:
                chapter["restored"] = True
            if event in {"chapter_result", "chapter_restored", "chapter_skipped"}:
                status = "skipped" if is_skip(row) else status_name(row)
                chapter["latestStatus"] = status or "unknown"
                chapter["finalOutcome"] = "success" if status in {"finished", "saved"} else "failed" if status == "failed" else "aborted" if status == "aborted" else "skipped" if status == "skipped" else "unknown"
        failed = event in {"attempt_error", "checkpoint_storage_error", "glyph_cache_storage_error", "run_error", "txt_import_error", "log_export_error"} or (event == "content_check" and row.get("quality", {}).get("complete") is False) or (event == "chapter_result" and status_name(row) == "failed") or (event == "chapter_stage_end" and row.get("outcome") in {"failed", "error"}) or (event in {"txt_export", "log_export", "run_summary"} and row.get("outcome") == "failed") or (event == "export_end" and row.get("outcome") in {"failed", "error"})
        if failed and not is_skip(row):
            entry = failure(row)
            failures.append(entry)
            if key in chapters:
                chapters[key]["failures"].append(entry)
        if event in {"chapter_stage_start", "chapter_stage_end"}:
            stage = row.get("stage")
            if not stage or not EVENT_NAME.fullmatch(stage):
                stage_issues["invalidStageName"] += 1
                continue
            stage_key = (key, row.get("attempt", row.get("attempts")), stage)
            if event == "chapter_stage_start":
                starts[stage_key].append(row)
            else:
                pending = starts.pop(stage_key, [])
                start = pending[0].get("elapsedMs") if len(pending) == 1 else None
                duration = row.get("durationMs")
                if duration is not None:
                    duration_sources["reported"] += 1
                elif start is not None and row.get("elapsedMs") is not None and row["elapsedMs"] >= start:
                    duration = row["elapsedMs"] - start
                    duration_sources["paired_elapsed"] += 1
                else:
                    stage_issues["missingDuration"] += 1
                if len(pending) != 1:
                    stage_issues["unmatchedEnds" if not pending else "ambiguousStarts"] += 1
                if duration is not None:
                    durations[stage].append(duration)
    stage_issues["unmatchedStarts"] = sum(len(values) for values in starts.values())
    chapter_list = list(chapters.values())
    for chapter in chapter_list:
        extraction_failures = [row for row in chapter["failures"] if row.get("event") in {"attempt_error", "content_check"} or (row.get("event") == "chapter_stage_end" and row.get("stage") not in {"checkpoint_commit", "checkpoint_restore"})]
        chapter["recovered"] = bool(extraction_failures and chapter["finalOutcome"] == "success")
        chapter["lastFailure"] = chapter["failures"][-1] if chapter["failures"] else None
    counter = collections.Counter(row["event"] for row in rows)
    retries = [row for row in rows if row["event"] == "retry_scheduled"]
    pacing = [row for row in rows if row["event"] in {"request_pacing", "request_wait", "pacing_wait"}]
    ocr = [row for row in rows if row["event"] == "ocr_metrics"]
    ocr_batches = [row for row in rows if row["event"] == "ocr_batch_metrics"]
    ocr_recoveries = [row for row in rows if row["event"] == "ocr_recovery_result"]
    ratios = [row["cacheHitRatio"] for row in ocr if 0 <= row.get("cacheHitRatio", -1) <= 1]
    pairs = [row for row in ocr if "cachedGlyphs" in row and "uniqueGlyphs" in row and row["cachedGlyphs"] <= row["uniqueGlyphs"]]
    cached, unique = sum(row["cachedGlyphs"] for row in pairs), sum(row["uniqueGlyphs"] for row in pairs)
    selections = [row for row in rows if row["event"] == "selection_result"]
    exports = [row for row in rows if row["event"] == "txt_export"]
    export_lifecycle = [row for row in rows if row["event"] in {"export_begin", "export_end", "completion_notice"}]
    export_durations, export_starts = [], []
    export_pairing = collections.Counter()
    for row in export_lifecycle:
        if row["event"] == "export_begin":
            export_starts.append(row)
        elif row["event"] == "export_end":
            duration = row.get("durationMs")
            start = export_starts[0].get("elapsedMs") if len(export_starts) == 1 else None
            if duration is None and start is not None and row.get("elapsedMs") is not None and row["elapsedMs"] >= start:
                duration = row["elapsedMs"] - start
            if duration is not None:
                export_durations.append(duration)
            else:
                export_pairing["missingDuration"] += 1
            if len(export_starts) != 1:
                export_pairing["unmatchedEnds" if not export_starts else "ambiguousStarts"] += 1
            export_starts = []
    export_pairing["unmatchedStarts"] = len(export_starts)
    versions = list(dict.fromkeys(row["version"] for row in rows if row.get("version")))
    commits = [row["durationMs"] for row in rows if row["event"] == "checkpoint_commit" and "durationMs" in row]
    page_errors = [row for row in rows if row["event"] == "frame_page_error"]
    reader_states = [row for row in rows if row["event"] == "frame_reader_diagnostics"]
    return {"runId": run_id, "version": versions[-1] if versions else None, "versions": versions, "schemas": sorted(set(row["schema"] for row in rows)),
            "eventCounts": dict(counter), "lastElapsedMs": max((row.get("elapsedMs", 0) for row in rows), default=0),
            "sequenceDiagnostics": sequences(rows), "chapters": chapter_list, "summary": summary(rows, chapter_list), "failures": failures,
            "stageDurations": {stage: timings(values) for stage, values in durations.items()},
            "stageDiagnostics": dict(durationSources=dict(duration_sources), pairingIssues=dict(stage_issues), note="Nested stage durations overlap; never sum them into total runtime or a critical path."),
            "retryStats": dict(scheduledRetries=len(retries), attemptErrors=sum(row["event"] == "attempt_error" and not is_skip(row) for row in rows), chaptersRetried=len({chapter_key(row) for row in retries if chapter_key(row)}), totalScheduledWaitMs=sum(row.get("waitMs", 0) for row in retries)),
            "pacing": dict(events=len(pacing), waitMs=timings([row["waitMs"] for row in pacing if "waitMs" in row]), requestGapMs=timings([row["requestGapMs"] for row in pacing if "requestGapMs" in row]), minimumGapMs=timings([row["minimumGapMs"] for row in pacing if "minimumGapMs" in row]), note="A wait value records planned waiting; it is not proof of actual server request timing."),
            "ocrMetrics": dict(events=len(ocr), cachedGlyphs=cached, uniqueGlyphs=unique, weightedCacheHitRatio=cached / unique if unique else None,
                               medianReportedCacheHitRatio=statistics.median(ratios) if ratios else None, unresolvedGlyphs=sum(row.get("unresolvedGlyphs", 0) for row in ocr),
                               ocrCalls=sum(row.get("ocrCalls", 0) for row in ocr), fingerprintMs=timings([row["fingerprintMs"] for row in ocr if "fingerprintMs" in row]), ocrMs=timings([row["ocrMs"] for row in ocr if "ocrMs" in row]), note="Counts are per reported chapter measurement; repeated glyphs across chapters are counted repeatedly."),
            "ocrBatchMetrics": ocr_batches, "ocrRecoveryResults": ocr_recoveries,
            "selection": selections[-1] if selections else None, "export": exports[-1] if exports else None, "logExports": [row for row in rows if row["event"] == "log_export"],
            "accessChecks": [row for row in rows if row["event"] == "access_check"], "frameWaitStates": [row for row in rows if row["event"] == "frame_wait_state"],
            "frameReaderDiagnostics": reader_states, "framePageErrors": page_errors,
            "pageErrorDiagnostics": dict(observedEvents=len(page_errors),
                                         reasonCodes=dict(collections.Counter(row.get("reasonCode", "unknown") for row in page_errors)),
                                         resourceKinds=dict(collections.Counter(row.get("resourceKind", "unknown") for row in page_errors)),
                                         messageKinds=dict(collections.Counter(row.get("messageKind", "unknown") for row in page_errors)),
                                         note="Observed page/resource error categories are diagnostic evidence, not chapter failures or proof of a subscription/access cause. Probes attach when readiness is first checked (on load or polling) and may miss earlier errors; zero captured errors does not prove successful page initialization."),
            "catalogSkipSummaries": [row for row in rows if row["event"] == "catalog_skip_summary"],
            "exportLifecycle": export_lifecycle, "exportDurations": timings(export_durations), "exportDiagnostics": dict(pairingIssues=dict(export_pairing)),
            "progress": [row for row in rows if row["event"] in {"progress_snapshot", "export_begin", "export_end", "completion_notice"}],
            "failedChecks": [row for row in rows if row["event"] == "content_check" and row.get("quality", {}).get("complete") is False and not is_skip(row)],
            "storageErrors": [row for row in rows if row["event"] in {"checkpoint_storage_error", "glyph_cache_storage_error"}], "medianCheckpointMs": statistics.median(commits) if commits else None,
            "exportNote": "download_requested/save_requested means a browser save request; it does not prove that the file reached disk."}


def analyze(text):
    events = []
    invalid = unsupported = malformed = 0
    decoder = json.JSONDecoder()
    for match in re.finditer(r"\[QidianDebug\]\s*", text):
        try:
            raw, _ = decoder.raw_decode(text, match.end())
        except (ValueError, TypeError, RecursionError):
            invalid += 1
            continue
        if not isinstance(raw, dict):
            malformed += 1
            continue
        if type(raw.get("schema")) is not int or raw["schema"] not in (1, 2):
            unsupported += 1
            continue
        if not isinstance(raw.get("event"), str) or not EVENT_NAME.fullmatch(raw["event"]):
            malformed += 1
            continue
        malformed += sum(value is not None and number(value) is None for key, value in raw.items() if key in NUMBERS
                         and not (raw["event"] == "ocr_recovery_result" and key == "success" and isinstance(value, bool)))
        if raw.get("runId") is not None and identifier(raw["runId"]) is None:
            malformed += 1
        events.append(sanitize(raw))
    grouped, unassigned = collections.OrderedDict(), []
    for event in events:
        if event["runId"] is None:
            unassigned.append(event)
        else:
            grouped.setdefault(event["runId"], []).append(event)
    return dict(structuredEvents=len(events), invalidJsonEvents=invalid, unsupportedSchemaEvents=unsupported, malformedFields=malformed,
                runs=[analyze_run(run_id, rows) for run_id, rows in grouped.items()], unassignedEvents=unassigned, preRun=analyze_run(None, unassigned) if unassigned else None,
                note="No structured events found; older logs require manual review." if not events else None,
                privacy="Whitelisted diagnostics only; bodies/options/URL/credential fields are omitted and free-text URL or credential syntax is redacted.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("log", type=Path)
    parser.add_argument("--output", type=Path, help="Optional JSON summary path")
    args = parser.parse_args()
    result = analyze(args.log.read_text(encoding="utf-8-sig", errors="replace"))
    output = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)
    if args.output:
        args.output.write_text(output + "\n", encoding="utf-8")
    else:
        print(output)
