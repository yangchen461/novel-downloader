const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const take = (start, end) => {
  const a = source.indexOf(start), b = source.indexOf(end, a);
  assert(a >= 0 && b > a, `Missing shipped source boundary: ${start}`);
  return source.slice(a, b);
};
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const mapCode = take('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars)', 'async function qidianRecoverUnmappedGlyph(');
const helpers = take('async function qidianRecoverUnmappedGlyph(', 'function extractRenderedText(');
const ocrCode = take('async function ocrContent(', 'async function buildFontDecodeMap(ownerDoc, ownerWin');
const tests = [];
const test = (name, run) => tests.push({name, run});

function fixture({text = '甲乙', cached = [], fail = false} = {}) {
  let now = 1000, engineCalls = 0;
  class Clock extends Date { static now() {return now;} }
  const messages = [], canvases = [];
  const logger = () => ({info: value => messages.push(value), warn: value => messages.push(value), error: value => messages.push(value)});
  const cache = new Map(cached.map(ch => [`fp:${ch}`, ch]));
  const document = {
    createElement(kind) {
      if (kind !== 'canvas') return {appendChild() {}, textContent: ''};
      const canvas = {width: 0, height: 0, drawn: []};
      const ctx = {canvas, setTransform() {}, fillRect() {canvas.drawn = [];}, fillText(ch) {canvas.drawn.push(ch);}};
      canvas.getContext = () => ctx;
      canvases.push(canvas);
      return canvas;
    }
  };
  const window = {stopFlag: {aborted: false}, qidianDebugRun: {id: 'metrics-fixture', startedAt: now}};
  const context = vm.createContext({
    window, document, Date: Clock, URL,
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
    qidianRestoreGlyphCache() {}, qidianGlyphCache: cache, qidianNewGlyphsSincePersist: 0,
    QIDIAN_GLYPH_CACHE_LIMIT: 30000,
    qidianGlyphFingerprints(_, chars) {
      now += 9;
      const result = new Map(chars.map(ch => [ch, `fp:${ch}`]));
      Object.defineProperty(result, 'qidianFingerprintStats', {value: {drawMs:1, readbackMs:2, hashMs:3, verifyMs:3, packedTiles:1, byteTiles:0, fallback:false, fallbackMs:0}});
      return result;
    },
    qidianOcrDecoder: {async decodeFullText(data) {
      engineCalls++; now += 7;
      if (fail) throw new Error('inference failure');
      return data;
    }},
    canvasToUint8Array: canvas => canvas.drawn.join(''),
    collectPseudoContentRules: () => [], extractRenderedText: () => text,
  });
  vm.runInContext(globals + mapCode + helpers + ocrCode + '\nthis.build = buildFontDecodeMap; this.ocr = ocrContent;', context);
  const ownerWin = {document: {}, getComputedStyle: () => ({fontFamily:'fixture'})};
  document.defaultView = ownerWin;
  const content = {ownerDocument: document, querySelectorAll: () => [{}]};
  const diagnostic = {qidianDiagnostic: {chapterId:'120', catalogNumber:120, title:'第120章', mode:'vip-ocr', attempt:2}};
  return {
    build: () => context.build(document, ownerWin, 'fixture', [...new Set(text)]),
    ocr: () => context.ocr(content, diagnostic),
    events: () => messages.filter(value => typeof value === 'string' && value.startsWith('[QidianDebug] ')).map(value => JSON.parse(value.slice('[QidianDebug] '.length))),
    engineCalls: () => engineCalls, canvases,
  };
}
function assertMetrics(map, expected) {
  const metrics = map.qidianMetrics;
  assert(metrics && typeof metrics === 'object', 'the actual Qidian function must attach its metrics');
  for (const key of ['uniqueGlyphs','cachedGlyphs','unresolvedGlyphs','ocrCalls','ocrMs','fingerprintMs','totalMs','recoveryCalls','recoveryMs','fingerprintDrawMs','fingerprintReadbackMs','fingerprintHashMs','fingerprintVerifyMs']) {
    assert.equal(typeof metrics[key], 'number', `${key} must be numeric`);
    assert(Number.isFinite(metrics[key]) && metrics[key] >= 0, `${key} must be a finite duration/count`);
  }
  for (const [key, value] of Object.entries(expected)) assert.equal(metrics[key], value, key);
  assert(metrics.totalMs >= metrics.ocrMs, 'total duration covers OCR inference');
}

test('unrelated JJWXC OCR function remains byte-for-byte unchanged', () => {
  const before = fs.readFileSync(path.join(__dirname, 'fixtures/jjwxc-ocr-before-v25.cjs'), 'utf8');
  assert.equal(take('async function buildFontDecodeMap(fontFamily, uniqueChars) {', 'async function ocrSingleChar('), before);
});
test('hot cache records a complete hit ratio without OCR', async () => {
  const f = fixture({cached:['甲','乙']}), map = await f.build();
  assert.equal(map.get('甲'), '甲'); assert.equal(map.get('乙'), '乙');
  assertMetrics(map, {uniqueGlyphs:2, cachedGlyphs:2, cacheHitRatio:1, unresolvedGlyphs:0, ocrCalls:0, ocrMs:0, fingerprintMs:9, totalMs:9});
  assert.equal(f.engineCalls(), 0);
  assert(f.canvases.every(canvas => canvas.width === 0 && canvas.height === 0));
});
test('cold and mixed caches record actual inference time and prior hits', async () => {
  for (const cached of [[], ['甲']]) {
    const f = fixture({cached}), map = await f.build();
    assertMetrics(map, {uniqueGlyphs:2, cachedGlyphs:cached.length, cacheHitRatio:cached.length/2, unresolvedGlyphs:0, ocrCalls:1, ocrMs:7, fingerprintMs:9, totalMs:16});
    assert.equal(map.size, 2); assert.equal(f.engineCalls(), 1);
  }
});
test('persistent engine failure retains a classified build error and numeric metrics', async () => {
  const text = Array.from({length:30}, (_, index) => String.fromCodePoint(0x4e00 + index)).join('');
  const f = fixture({text, fail:true}), map = await f.build();
  assert.equal(map.qidianBuildError?.name, 'Error');
  assert.equal(map.qidianBuildError?.message, 'inference failure');
  assert.equal(map.qidianLocalRecoveryFinished, undefined, 'engine exceptions keep the existing retry path');
  assertMetrics(map, {uniqueGlyphs:30, cachedGlyphs:0, cacheHitRatio:0, unresolvedGlyphs:30, ocrCalls:2, ocrMs:14});
  assert(f.canvases.every(canvas => canvas.width === 0 && canvas.height === 0));
});
test('actual OCR caller attributes hot-cache metrics to chapter and attempt', async () => {
  const f = fixture({cached:['甲','乙']});
  assert.equal((await f.ocr()).contentText, '甲乙');
  const event = f.events().find(event => event.event === 'ocr_metrics');
  assert(event, 'OCR caller must emit its measured counters');
  assert.equal(event.chapterId, '120'); assert.equal(event.catalogNumber, 120);
  assert.equal(event.mode, 'vip-ocr'); assert.equal(event.attempt, 2);
  assert.equal(event.cachedGlyphs, 2); assert.equal(event.cacheHitRatio, 1);
  assert.equal(event.ocrCalls, 0); assert.equal(event.buildError, null);
});
test('actual OCR caller preserves engine error attribution while rejecting incomplete text', async () => {
  const text = Array.from({length:30}, (_, index) => String.fromCodePoint(0x4e00 + index)).join('');
  const f = fixture({text, fail:true});
  assert.equal(await f.ocr(), null);
  const event = f.events().find(event => event.event === 'ocr_metrics');
  assert(event); assert.equal(event.chapterId, '120'); assert.equal(event.attempt, 2);
  assert.equal(event.buildError.errorName, 'Error');
  assert.equal(event.buildError.reason, 'inference failure');
  assert.equal(event.buildError.errorCode, 'operation_failed');
  assert.equal(event.unresolvedGlyphs, 30); assert.equal(event.ocrCalls, 2);
});

(async () => {
  let failed = 0;
  for (const {name, run} of tests) {
    try {await run(); console.log('PASS', name);}
    catch (error) {failed++; console.error('FAIL', name, '\n', error.stack ?? error);}
  }
  console.log(`${tests.length - failed}/${tests.length} v25 OCR metrics checks passed`);
  if (failed) process.exitCode = 1;
})();
