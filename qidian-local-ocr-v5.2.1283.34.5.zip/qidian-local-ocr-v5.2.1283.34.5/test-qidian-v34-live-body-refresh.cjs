// Real OCR/map/cache/renderer with deterministic physical raster and inference.
// Reader mutations happen while an actual shipped glyph-map build is awaiting
// the engine, rather than replacing extraction with a preselected text string.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const prior = fs.readFileSync(path.join(__dirname, 'test-qidian-v34-glyph-tolerance.cjs'), 'utf8');
const fixtureCode = prior.slice(0, prior.indexOf('const tests = [];')) +
  prior.slice(prior.indexOf('function scopedFixture('), prior.indexOf("test('OCR scopes")) + '\nscopedFixture';
const scopedFixture = vm.runInNewContext(fixtureCode, { require, __dirname, AbortController, URL, Blob,
  structuredClone, setTimeout, clearTimeout, console });
const take = (start, end) => {
  const a = source.indexOf(start), b = source.indexOf(end, a);
  assert(a >= 0 && b > a, start); return source.slice(a, b);
};
const mapCode = take('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars)', 'async function qidianRecoverUnmappedGlyph(');
const mapHelpers = take('async function qidianRecoverUnmappedGlyph(', 'function extractRenderedText(');
const tests = [], test = (name, run) => tests.push({ name, run });

function fixture({ paragraphs = ['甲'.repeat(1000)], mutation, font = 'ReaderFont' } = {}) {
  let nodes, main;
  const f = scopedFixture(({ element, text }) => {
    nodes = { element, text };
    main = element('main', {}, [element('div', { class: 'content-text' },
      paragraphs.map(value => element('p', {}, [text(value)])), { fontFamily: font })]);
    return main;
  });
  const doc = main.ownerDocument, messages = [], engineInputs = [], canvases = [];
  const log = { info: text => messages.push(text), warn: text => messages.push(text),
    error: text => messages.push(text), trace() {}, debug() {} };
  let liveMain = main;
  doc.querySelectorAll = selector => selector.split(',').flatMap(raw => raw.trim() === 'main'
    ? liveMain ? [liveMain] : [] : liveMain?.querySelectorAll(raw.trim()) ?? []);
  doc.querySelector = selector => doc.querySelectorAll(selector)[0] ?? null;
  doc.createElement = tag => {
    assert.equal(tag, 'canvas');
    const canvas = { width: 0, height: 0, drawn: [] };
    const ctx = { canvas, setTransform() {}, fillRect() { canvas.drawn = []; }, fillText(ch) { canvas.drawn.push(ch); } };
    canvas.ctx = ctx; canvas.getContext = () => ctx; canvases.push(canvas); return canvas;
  };
  const state = { mapBuilds: 0, fontsAwaited: 0 };
  Object.assign(f.ctx, {
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => log,
    qidianRestoreGlyphCache() {}, qidianGlyphCache: new Map(),
    qidianNewGlyphsSincePersist: 0, QIDIAN_GLYPH_CACHE_LIMIT: 30000,
    // Pixel-hash boundary: different physical font families produce different
    // keys. The production map controls cache lookup, insertion and reuse.
    qidianGlyphFingerprints(_ctx, chars, family) {
      state.mapBuilds++;
      return new Map(Array.from(chars, ch => [ch, family + ':' + ch.codePointAt(0)]));
    },
    canvasToUint8Array: canvas => ({ text: canvas.drawn.join(''), font: canvas.ctx.font }),
    qidianOcrDecoder: { async decodeFullText(data) {
      engineInputs.push({ ...data });
      if (mutation) await mutation({ ...api, call: engineInputs.length, data });
      return data.text;
    } }
  });
  vm.runInContext(mapCode + mapHelpers, f.ctx);
  const append = (parent, child) => { parent.childNodes.push(child); child.parentNode = child.parentElement = parent; return child; };
  const api = { ...f, doc, main, nodes, state, messages, engineInputs, canvases, append,
    get body() { return liveMain.childNodes[0]; },
    replaceMain(next) { liveMain.isConnected = false; liveMain = next; },
    events() { return messages.filter(line => line.startsWith('[QidianDebug] ')).map(line => JSON.parse(line.slice(14))); },
    ocr: () => f.ctx.ocrContent(main, f.options)
  };
  f.options.qidianDiagnostic = { chapterId: '846050140', title: '第74章 测试', mode: 'vip', attempt: 1 };
  f.ctx.qidianCreateAttempt(f.options);
  return api;
}

function snapshots(f) { return f.events().filter(row => row.event === 'ocr_body_snapshot'); }
function metrics(f) { return f.events().filter(row => row.event === 'ocr_metrics'); }
function assertReleased(f) { assert(f.canvases.every(canvas => canvas.width === 0 && canvas.height === 0)); }

test('an unchanged scoped body performs one map build and one inference, with a stable private diagnostic', async () => {
  const f = fixture(), result = await f.ocr();
  assert.equal(result.contentText, '甲'.repeat(1000));
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  assert.deepEqual(snapshots(f).map(row => row.outcome), ['stable']);
  assert.equal(snapshots(f)[0].changed, false);
  assert.equal(snapshots(f)[0].before.digest, snapshots(f)[0].after.digest);
  assert(!JSON.stringify(f.events()).includes('甲甲甲'));
  assertReleased(f);
});

test('a paragraph added during OCR is recaptured once; known glyphs reuse the production cache', async () => {
  const f = fixture({ mutation({ call, body, append, nodes }) {
    if (call === 1) append(body, nodes.element('p', {}, [nodes.text('乙'.repeat(1000))]));
  } });
  const result = await f.ocr();
  assert.equal(result.contentText, '甲'.repeat(1000) + '\n' + '乙'.repeat(1000));
  assert.deepEqual(f.engineInputs.map(input => input.text), ['甲', '乙']);
  assert.equal(f.state.mapBuilds, 2);
  assert.equal(metrics(f)[1].cachedGlyphs, 1);
  assert.deepEqual(snapshots(f).map(row => row.outcome), ['refresh', 'stable']);
  assert.equal(snapshots(f)[1].before.paragraphCount, 2);
  assert.equal(f.ctx.qidianGlyphCache.size, 2); assertReleased(f);
});

test('CSS pseudo-content arriving during OCR is included by the actual rendered-text walker', async () => {
  const f = fixture({ mutation({ call, body }) {
    if (call === 1) body.childNodes[0].pseudo['::after'] = { content: JSON.stringify('乙'.repeat(1000)) };
  } });
  assert.equal((await f.ocr()).contentText, '甲'.repeat(1000) + '乙'.repeat(1000));
  assert.deepEqual(f.engineInputs.map(input => input.text), ['甲', '乙']);
  assert.equal(snapshots(f)[0].after.renderedChars, 2000);
  assert.equal(f.state.mapBuilds, 2);
});

test('same-length paragraph reordering changes the fingerprint and does not repeat cached inference', async () => {
  const f = fixture({ paragraphs: ['甲'.repeat(1000), '乙'.repeat(1000)], mutation({ call, body }) {
    if (call === 1) body.childNodes.reverse();
  } });
  assert.equal((await f.ocr()).contentText, '乙'.repeat(1000) + '\n' + '甲'.repeat(1000));
  assert.equal(f.state.mapBuilds, 2); assert.equal(f.engineInputs.length, 1);
  assert.notEqual(snapshots(f)[0].before.digest, snapshots(f)[0].after.digest);
  assert.equal(metrics(f)[1].cachedGlyphs, 2);
});

test('live main replacement in the same reader document never exports the detached old body', async () => {
  const f = fixture({ mutation({ call, nodes, replaceMain }) {
    if (call === 1) replaceMain(nodes.element('main', {}, [nodes.element('div', { class: 'content-text' },
      [nodes.element('p', {}, [nodes.text('乙'.repeat(2000))])], { fontFamily: 'ReaderFont' })]));
  } });
  assert.equal((await f.ocr()).contentText, '乙'.repeat(2000));
  assert.equal(f.main.isConnected, false); assert.equal(f.state.mapBuilds, 2);
  assert.deepEqual(f.engineInputs.map(input => input.text), ['甲', '乙']);
});

test('a navigated real reader Document rejects the old main even when it remains connected to its retired Document', async () => {
  const f = fixture({ mutation({ doc }) { doc.defaultView.document = { nodeType: 9 }; } });
  f.doc.nodeType = 9;
  await assert.rejects(f.ocr(), error => error.name === 'QidianContentError');
  assert.notEqual(f.doc.defaultView.document, f.doc);
  assert.notEqual(f.main.isConnected, false);
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  assert.equal(snapshots(f)[0].after, null); assert.equal(snapshots(f)[0].outcome, 'unstable');
});

test('a font-family change causes a fresh physical fingerprint instead of using mappings from the old font', async () => {
  const f = fixture({ mutation({ call, body }) { if (call === 1) body.css.fontFamily = 'NewReaderFont'; } });
  assert.equal((await f.ocr()).contentText, '甲'.repeat(1000));
  assert.deepEqual(f.engineInputs.map(input => input.font), ['48px ReaderFont', '48px NewReaderFont']);
  assert.equal(f.state.mapBuilds, 2); assert.equal(metrics(f)[1].cachedGlyphs, 0);
});

test('late fonts loading waits for the real font-ready promise before the single refreshed build', async () => {
  let finishFonts;
  const f = fixture({ mutation({ call, doc }) {
    if (call === 1) {
      doc.fonts.status = 'loading'; doc.fonts.size = 2;
      doc.fonts.ready = new Promise(resolve => { finishFonts = () => { doc.fonts.status = 'loaded'; resolve(); }; });
    }
  } });
  f.doc.fonts = { status: 'loaded', size: 1, ready: Promise.resolve() };
  const pending = f.ocr();
  for (let i = 0; i < 30 && !finishFonts; i++) await Promise.resolve();
  assert.equal(typeof finishFonts, 'function');
  for (let i = 0; i < 20; i++) await Promise.resolve();
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  finishFonts();
  assert.equal((await pending).contentText, '甲'.repeat(1000));
  assert.equal(f.state.mapBuilds, 2); assert.equal(f.engineInputs.length, 1);
  assert.equal(metrics(f)[1].cachedGlyphs, 1);
});

test('a second live body change fails as ContentError after two maps and produces no unstable result', async () => {
  const f = fixture({ mutation({ call, body, append, nodes }) {
    append(body, nodes.element('p', {}, [nodes.text((call === 1 ? '乙' : '丙').repeat(1000))]));
  } });
  await assert.rejects(f.ocr(), error => error.name === 'QidianContentError' && /不稳定快照/.test(error.message));
  assert.equal(f.state.mapBuilds, 2); assert.equal(f.engineInputs.length, 2);
  assert.deepEqual(snapshots(f).map(row => row.outcome), ['refresh', 'unstable']);
  assert.equal(f.events().filter(row => row.event === 'ocr_body_refresh').length, 1);
  assertReleased(f);
});

test('a lost or newly ambiguous body fails rather than saving the earlier complete snapshot', async () => {
  for (const mode of ['lost', 'ambiguous']) {
    const f = fixture({ mutation({ main, append, nodes }) {
      if (mode === 'lost') main.isConnected = false;
      else append(main, nodes.element('div', { class: 'content-text' }, [nodes.element('p', {}, [nodes.text('乙'.repeat(1000))])]));
    } });
    if (mode === 'lost') f.doc.querySelector = () => null;
    await assert.rejects(f.ocr(), error => error.name === 'QidianContentError');
    assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
    assert.equal(snapshots(f)[0].outcome, 'unstable');
  }
});

test('author, navigation and hidden mutations cannot cause a refresh or pad the accepted body', async () => {
  const f = fixture({ mutation({ main, body, append, nodes }) {
    append(main, nodes.element('nav', {}, [nodes.element('p', {}, [nodes.text('乙'.repeat(5000))])]));
    append(body, nodes.element('div', { id: 'r-authorSay' }, [nodes.element('p', {}, [nodes.text('乙'.repeat(5000))])]));
    append(body, nodes.element('p', {}, [nodes.text('乙'.repeat(5000))], { display: 'none' }));
  } });
  assert.equal((await f.ocr()).contentText, '甲'.repeat(1000));
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  assert.equal(snapshots(f)[0].changed, false);
});

test('Stop during inference forbids post-OCR capture, cache writes and a refreshed request', async () => {
  let finish;
  const f = fixture({ mutation() { return new Promise(resolve => { finish = resolve; }); } });
  const pending = f.ocr();
  for (let i = 0; i < 30 && !finish; i++) await Promise.resolve();
  assert.equal(typeof finish, 'function');
  f.window.stopController.abort(); finish();
  await assert.rejects(pending, error => error.name === 'AbortError');
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  assert.equal(f.ctx.qidianGlyphCache.size, 0); assert.equal(snapshots(f).length, 0);
  assertReleased(f);
});

test('the shipped VIP parser propagates unstable-body ContentError without checkpointing or raw fallback', async () => {
  const f = fixture({ mutation({ call, body, append, nodes }) {
    append(body, nodes.element('p', {}, [nodes.text((call === 1 ? '乙' : '丙').repeat(1000))]));
  } });
  const parserStart = source.indexOf('  async chapterParse(', source.indexOf('class Qidian extends'));
  const parserEnd = source.indexOf('\n}\n\n\n/***/', parserStart);
  assert(parserStart > 0 && parserEnd > parserStart);
  f.doc.URL = 'https://www.qidian.com/chapter/1044724292/846050140/';
  f.doc.title = '第74章 测试'; f.doc.body = { textContent: '甲'.repeat(1000) };
  f.doc.querySelectorAll = selector => selector.split(',').flatMap(raw => raw.trim() === 'main'
    ? [f.main] : f.main.querySelectorAll(raw.trim()));
  f.doc.querySelector = selector => f.doc.querySelectorAll(selector)[0] ?? null;
  let persisted = 0, rawCalls = 0, removed = 0;
  Object.assign(f.ctx, {
    _lib_http__WEBPACK_IMPORTED_MODULE_2__: { Q2: async () => ({ contentWindow: { document: f.doc }, remove() { removed++; } }) },
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__: { rm() {} },
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__: { an() { rawCalls++; throw Error('raw VIP fallback'); } },
    qidianPersistGlyphCache: async () => { persisted++; }
  });
  vm.runInContext('class Parser {' + source.slice(parserStart, parserEnd) + '}\nthis.Parser=Parser;', f.ctx);
  await assert.rejects(new f.ctx.Parser().chapterParse(f.doc.URL, '第74章 测试', true, true, 'UTF-8', f.options),
    error => error.name === 'QidianContentError' && /不稳定快照/.test(error.message));
  assert.equal(f.state.mapBuilds, 2); assert.equal(removed, 1);
  assert.equal(rawCalls, 0); assert.equal(persisted, 0);
  assert.equal(f.options.qidianValidation, undefined);
  assert.equal(f.options.qidianBodyLength, undefined);
  assert.equal(f.options.qidianLengthWarning, undefined);
});

test('50–84% preview text with a visible subscription gate remains unsubscribed while a full reader may ignore its inactive widget', () => {
  for (const count of [2000, 3360, 4000]) {
    const f = fixture({ paragraphs: ['甲'.repeat(count)] });
    const body = f.body; body.innerText = '甲'.repeat(count);
    const gate = f.nodes.element('div', { class: 'vip-limit-wrap' });
    gate.innerText = count === 4000 ? '自动订阅 已订阅' : '订阅本章后阅读';
    f.append(f.main, gate);
    f.doc.querySelectorAll = selector => selector.split(',').flatMap(raw => raw.trim() === 'main'
      ? [f.main] : f.main.querySelectorAll(raw.trim()));
    f.doc.querySelector = selector => f.doc.querySelectorAll(selector)[0] ?? null;
    const access = f.ctx.qidianChapterAccessState(f.doc, true, 4000);
    assert.equal(access.kind, count === 4000 ? 'unknown' : 'unsubscribed');
    // The requested50% body threshold remains separate from access evidence.
    assert.equal(f.ctx.qidianContentCheck('甲'.repeat(count), 4000, true).complete, true);
  }
});

test('a subscription gate arriving during inference skips the chapter even when its rendered body and font never change', async () => {
  const f = fixture({ mutation({ main, append, nodes }) {
    const gate = nodes.element('div', { class: 'vip-limit-wrap' }); gate.innerText = '订阅本章后阅读'; append(main, gate);
  } });
  f.body.innerText = '甲'.repeat(1000);
  await assert.rejects(f.ocr(), error => error.name === 'QidianUnsubscribedError' && error.qidianAccessEvidence === 'vip_limit_wrap');
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  assert.equal(f.window.stopFlag.aborted, false); assert.equal(f.window.qidianAccessRecoveryGate, undefined);
  assert.equal(f.events().filter(row => row.event === 'ocr_body_refresh').length, 0);
  assert(f.events().some(row => row.event === 'access_check' && row.stage === 'ocr_body_recapture' && row.accessKind === 'unsubscribed'));
});

for (const label of ['请先登录', '安全验证']) test(`late ${label} uses the existing manual access gate, preserving the run Stop signal`, async () => {
  const f = fixture({ mutation({ main, append, nodes }) {
    const gate = nodes.element('div', { class: 'vip-limit-wrap' }); gate.innerText = label; append(main, gate);
  } });
  f.body.innerText = '甲'.repeat(1000);
  f.options.qidianAttemptScope.dispose();
  f.window.qidianAccessRecoveryEnabled = true;
  const run = f.window.qidianAccessRecoveryRun = { id: 'live-ocr-access' };
  const attempt = f.ctx.qidianCreateAttempt(f.options);
  await assert.rejects(f.ocr(), error => error.name === 'QidianAccessError' && error.qidianStage === 'access_check');
  const gate = f.window.qidianAccessRecoveryGate;
  assert(gate); assert.equal(gate.settled, false); assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(attempt.cancelled, true); assert.equal(f.options.qidianAccessEvidence, label === '请先登录' ? 'reader_login_control' : 'reader_verification_control');
  for (let i = 0; i < 20; i++) await Promise.resolve();
  assert.equal(f.state.mapBuilds, 1); assert.equal(f.engineInputs.length, 1);
  f.ctx.qidianDisposeAccessRecovery(run);
  assert.equal(await gate.promise, false); assert.equal(gate.settled, true);
  attempt.dispose();
});

(async () => {
  let passed = 0;
  for (const { name, run } of tests) {
    try { await run(); passed++; console.log('PASS ' + name); }
    catch (error) { console.error('FAIL ' + name); console.error(error); process.exitCode = 1; }
  }
  console.log(`${passed}/${tests.length} live body refresh checks passed`);
})();
