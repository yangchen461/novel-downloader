// Exercise the shipped diagnostic helpers, Chapter.parse, Qidian parser and
// Rule.run. Only browser, network, OCR, storage and file delivery are fixtures.
// No Qidian request is made by this suite.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b, from = 0) {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing shipped boundary: ${a}`);
  return src.slice(start, end);
}
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode = take('class ChapterAbortError', '\n\n/***/ },');
const parserCode = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const runCode = take('  async run() {', '\n  async preHook()', src.indexOf('class Rule'));
const saveCode = take('  async save() {', '\n  saveTxt()', src.indexOf('class SaveBook'));
const statuses = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
const body = 'BODY_CONTENT_MUST_NOT_BE_LOGGED_' + '章节正文完整，中文校验正常。'.repeat(200);
const tests = [];
const test = (name, fn) => tests.push({ name, fn });
const normalize = value => JSON.parse(JSON.stringify(value));
function node(tag = 'div') {
  return { tagName:tag.toUpperCase(), children:[], appendChild(child) { this.children.push(child); return child; } };
}
function diagnosticFixture() {
  const state = { now:1000, logs:[], timers:new Map(), timer:0 };
  const log = Object.fromEntries(['info','warn','error','trace','debug'].map(level => [level,
    (...values) => state.logs.push({ level, text:values.map(value => String(value?.message ?? value)).join(' ') })]));
  const window = { qidianDebugRun:{ id:'flow-fixture', startedAt:900 }, qidianDebugLogger:log,
    qidianTxtOnly:true, stopController:new AbortController(), failedCount:0 };
  window.stopFlag = window.stopController.signal;
  class ClockDate extends Date { static now() { return state.now; } }
  const ctx = vm.createContext({ window, unsafeWindow:window, URL, Date:ClockDate, Promise, Map, Set,
    AbortController, console:log, document:{ location:{ hostname:'www.qidian.com' }, createElement:node },
    setTimeout:(fn, ms) => { const id = ++state.timer; state.timers.set(id, { fn, ms }); return id; },
    clearTimeout:id => state.timers.delete(id), alert(){},
    GM_getValue:(_key, fallback) => fallback, GM_setValue(){}, GM_info:{script:{version:'5.2.1283.34.5'}},
    _main__WEBPACK_IMPORTED_MODULE_3__:{ nW:statuses }, main:{ nW:statuses, K5:class ExpectError extends Error{} },
    _log__WEBPACK_IMPORTED_MODULE_1___default:() => log,
    _log__WEBPACK_IMPORTED_MODULE_6___default:() => log, loglevel_default:() => log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{ yy:async ms => { state.now += ms; } }
  });
  vm.runInContext(globals + chapterCode + '\nthis.Chapter=Chapter;', ctx);
  const events = () => state.logs.filter(entry => entry.text.startsWith('[QidianDebug] '))
    .map(entry => JSON.parse(entry.text.slice('[QidianDebug] '.length)));
  return { ctx, window, state, log, events };
}
function chapter(ctx, fields = {}) {
  return new ctx.Chapter({ bookUrl:'https://www.qidian.com/book/1/',
    chapterUrl:'https://www.qidian.com/chapter/1/39/?token=URL_SECRET_NEVER_LOG', chapterNumber:40,
    chapterName:'第39章 测试章节', isVIP:false, isPaid:true, charset:'UTF-8',
    options:{ expectedChars:2000 }, ...fields });
}
function parserFixture(config = {}) {
  const f = diagnosticFixture();
  Object.assign(f.state, { requests:[], cleanCalls:0, ocrCalls:0, removed:0 });
  const cfgForAttempt = attempt => Array.isArray(config.attempts) ? config.attempts[Math.min(attempt - 1, config.attempts.length - 1)] : config;
  const log = f.log;
  let attempt = 0;
  function makeDoc(cfg) {
    const text = cfg.short ? '短正文' : body;
    const main = { cfg, textContent:text, querySelectorAll:selector => selector === 'p' ? Array(5).fill({}) : [],
      querySelector:selector => selector === '.content-text' ? main : null };
    return { title:cfg.block ? '安全验证' : '第39章 测试章节', body:{ textContent:cfg.block ? '访问验证' : text },
      querySelector(selector) {
        if (selector === 'main' || selector === '.content-text, .vip-limit-wrap') return cfg.noMain ? null : main;
        if (selector === 'h1.title') return { innerText:'第39章 测试章节' };
        if (selector === '.vip-limit-wrap') return cfg.locked ? {} : null;
        return null;
      } };
  }
  async function request(route, _url, predicate) {
    const cfg = cfgForAttempt(++attempt) || {};
    f.state.requests.push({ route, attempt }); f.state.now += 700;
    if (cfg.httpStatus) { const error = new Error(`HTTP ${cfg.httpStatus}`); error.status = cfg.httpStatus; throw error; }
    if (cfg.networkFailure) throw Error('network failure; token=ERR_SECRET_NEVER_LOG');
    if (cfg.frameTimeout) {
      assert.equal(route,'frame');
      const error = new Error('Frame Timeout!');
      error.frameState = { addressKind:'about:blank', readyState:'loading', bodyPresent:false,
        bodyTextLength:0, contentPresent:false, mainParagraphs:0 };
      throw error;
    }
    const doc = makeDoc(cfg);
    if (route === 'html') return doc;
    let removed = false;
    const frame = { contentWindow:{ document:doc }, remove() { if (!removed) { removed = true; f.state.removed++; } } };
    try { assert.equal(predicate(frame), true); } catch(error) { frame.remove(); throw error; }
    return frame;
  }
  Object.assign(f.ctx, {
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{ pG:async url => request('html', url), Q2:async (url, predicate) => request('frame', url, predicate) },
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{ rm(){}, Sf(){} },
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{ async an(main) {
      f.state.cleanCalls++; f.state.now += 200;
      if (main.cfg.cleanFailure) { const error = new Error('cleanup failure; token=ERR_SECRET_NEVER_LOG'); error.name = 'QidianGlyphError'; throw error; }
      return { dom:node(), text:main.textContent, images:[] };
    }, is(){} },
    async ocrContent(main) {
      f.state.ocrCalls++; f.state.now += 400;
      if (main.cfg.ocrFailure) { const error = new Error('glyph inference failed; token=ERR_SECRET_NEVER_LOG'); error.name = 'QidianGlyphError'; throw error; }
      return { contentText:main.cfg.ocrShort ? '短正文' : main.textContent, contentHTML:node() };
    }, qidianGlyphCache:new Map(), async qidianPersistGlyphCache(){}
  });
  vm.runInContext('\nclass Qidian {' + parserCode + '}\nthis.Qidian=Qidian;', f.ctx);
  const qidian = new f.ctx.Qidian();
  f.chapter = chapter(f.ctx, { isVIP:config.vip ?? false, chapterParse:qidian.chapterParse.bind(qidian) });
  f.run = async () => { await f.chapter.init(); return f.chapter; };
  return f;
}
function summaryChapters(ctx) {
  return [
    chapter(ctx, { chapterUrl:'https://www.qidian.com/chapter/1/1/', chapterName:'第1章 断点恢复', chapterNumber:1 }),
    chapter(ctx, { chapterUrl:'https://www.qidian.com/chapter/1/2/', chapterName:'第2章 格式化失败', chapterNumber:2 }),
    chapter(ctx, { chapterUrl:'https://www.qidian.com/chapter/1/3/', chapterName:'第3章 正文失败', chapterNumber:3 }),
    chapter(ctx, { chapterUrl:'https://www.qidian.com/chapter/1/4/', chapterName:'第4章 尚未处理', chapterNumber:4 }),
    chapter(ctx, { chapterUrl:'https://www.qidian.com/chapter/1/5/', chapterName:'第5章 已停止', chapterNumber:5 })
  ].map((item, index) => {
    item.status = [statuses.saved, statuses.saved, statuses.failed, statuses.pending, statuses.aborted][index];
    item.contentText = index < 2 ? body : null;
    item.options.qidianValidation = ctx.qidianContentCheck(item.contentText, item.options.expectedChars, item.isVIP);
    if (index === 0) item.qidianSource = 'checkpoint';
    if (index === 2) { item.qidianFailureKind = 'local'; item.errorMessage = '章节正文未通过校验'; }
    if (index === 4) item.errorMessage = '已停止下载';
    return item;
  });
}
function runFixture(config = {}) {
  const f = diagnosticFixture();
  f.state.logSaves = [];
  f.state.caught = [];
  f.state.outputSaves = 0;
  f.state.sessionCalls = [];
  f.window.workerId = 'test-worker';
  f.window.localStorageExpired = { get(){}, set(){} };
  const chapters = config.chapters?.(f.ctx) ?? [chapter(f.ctx, { chapterNumber:1, chapterName:'第1章 正常章节' })];
  const book = { bookUrl:'https://www.qidian.com/book/1/', author:'fixture', bookname:'debug flow', chapters };
  const session = { initializeSession:id => f.state.sessionCalls.push(['start',id]), clearSession:id => {
    f.state.sessionCalls.push(['clear',id]);
    if(config.cleanupError) throw config.cleanupError;
  } };
  class SaveBook {
    constructor(book) { this.book = book; }
    async save() {
      f.state.outputSaves++;
      if (config.exportError) throw Error('TXT export failed; token=EXPORT_SECRET_NEVER_LOG');
      const missing = config.formatFailure ? [{ title:'第2章 格式化失败', chapterNumber:2, reason:'TXT格式化错误' }] : [];
      this.book.txtDownloadReport = { selectedCount:chapters.length,
        savedCount:this.book.chapters.length - missing.length, missing };
    }
    static saveLog() {
      f.state.logSaves.push(f.events());
      if (config.logSaveError) throw Error('synthetic log save failure');
    }
  }
  Object.assign(f.ctx, {
    SessionMappingCache:{ j:{ getInstance:() => session } }, SaveBook,
    setting:{ Jv:{value:true}, Zz:{value:false}, Nw:{value:true}, WZ:{value:false}, BV:async () => false },
    misc:{ yy:async ms => { f.state.now += ms; } },
    saveOptionsValidate:() => false,
    GM_getValue:(key, fallback) => key === 'qidianResumeEnabledV1' ? false : fallback,
    Math:Object.assign(Object.create(Math), { random:() => 0.5 })
  });
  vm.runInContext('\nclass RunRule {' + runCode + '}\nthis.RunRule=RunRule;', f.ctx);
  const rule = new f.ctx.RunRule();
  Object.assign(rule, {
    needLogin:true, concurrencyLimit:1, sleepTime:8000, maxSleepTime:20000,
    async preHook() { if (config.preHookError) throw Error('preHook failed'); },
    async bookParse() { return book; }, async prepareChapters(){}, selectChapters(){},
    async initChapters() {
      if (config.initError) throw Error('scheduler failure');
      if (config.applyStatuses) await config.applyStatuses(f, chapters);
      else for (const item of chapters) { item.status = statuses.saved; item.contentText = body; item.options.qidianValidation = f.ctx.qidianContentCheck(body,2000,false); }
    },
    postHook(){}, catchError:error => f.state.caught.push(error)
  });
  return Object.assign(f, { rule, book, chapters, run:() => rule.run() });
}

test('debug envelope protects event identity, uses monotonic sequence and contains timestamps', () => {
  const f = diagnosticFixture();
  f.ctx.qidianDebugEvent(null, 'genuine_event', { schema:99, version:'forged', event:'forged', runId:'forged', seq:-10, timestampMs:-10, elapsedMs:-10, safeNumber:4 });
  f.state.now = 1234;
  f.ctx.qidianDebugEvent(null, 'next_event', {});
  const [first, second] = f.events();
  assert.equal(first.schema,2); assert.equal(first.version,'5.2.1283.34.5'); assert.equal(first.event,'genuine_event');
  assert.equal(first.runId,'flow-fixture'); assert.equal(first.timestampMs,1000); assert.equal(first.elapsedMs,100); assert.equal(first.safeNumber,4);
  assert(Number.isInteger(first.seq) && first.seq > 0); assert.equal(second.seq,first.seq+1); assert.equal(second.timestampMs,1234);
});
test('diagnostic logging failures and circular data remain harmless', () => {
  const f = diagnosticFixture();
  const circular = {}; circular.self = circular;
  assert.doesNotThrow(() => f.ctx.qidianDebugEvent({ info(){throw Error('logger failed');} }, 'broken_logger', {}));
  assert.doesNotThrow(() => f.ctx.qidianDebugEvent(null, 'circular', circular));
});
test('stage wrapper supports synchronous and asynchronous results and accurate local timing', async () => {
  const f = diagnosticFixture(); const c = chapter(f.ctx);
  const sync = await f.ctx.qidianStage(c, 'synthetic_sync', () => { f.state.now += 7; return 42; });
  const asyncResult = await f.ctx.qidianStage(c, 'synthetic_async', async () => { await Promise.resolve(); f.state.now += 11; return 'ok'; });
  assert.equal(sync,42); assert.equal(asyncResult,'ok');
  const starts = f.events().filter(event => event.event === 'chapter_stage_start');
  const ends = f.events().filter(event => event.event === 'chapter_stage_end');
  assert.deepEqual(starts.map(event => event.stage),['synthetic_sync','synthetic_async']);
  assert.deepEqual(ends.map(event => event.durationMs),[7,11]);
  assert(ends.every(event => event.outcome === 'success'));
});
for (const asynchronous of [false,true]) test(`${asynchronous?'asynchronous':'synchronous'} stage failure annotates the original error without swallowing it`, async () => {
  const f = diagnosticFixture(); const c = chapter(f.ctx); const error = new Error('local failure; token=ERR_SECRET_NEVER_LOG'); error.code = 'TEST_LOCAL_FAILURE';
  const operation = asynchronous ? async () => { await Promise.resolve(); f.state.now += 3; throw error; } : () => { f.state.now += 3; throw error; };
  await assert.rejects(() => f.ctx.qidianStage(c,'synthetic_failure',operation), value => value === error);
  assert.equal(error.qidianStage,'synthetic_failure');
  const event = f.events().find(event => event.event === 'chapter_stage_end');
  assert.equal(event.stage,'synthetic_failure'); assert.equal(event.durationMs,3); assert.equal(event.outcome,'error');
  assert(!JSON.stringify(f.events()).includes('ERR_SECRET_NEVER_LOG'));
});
test('a faulty logger never changes stage success or failure', async () => {
  const f = diagnosticFixture(); const badLogger = { info(){ throw Error('broken logging'); } };
  assert.equal(await f.ctx.qidianStage(chapter(f.ctx),'safe_log',() => 5,{},badLogger),5);
  const error = new Error('actual operation failure');
  await assert.rejects(() => f.ctx.qidianStage(chapter(f.ctx),'safe_log',() => {throw error;},{},badLogger), value => value === error);
});
test('nested stages retain the innermost failure and remain locally timed', async () => {
  const f = diagnosticFixture(); const c = chapter(f.ctx); const error = new Error('nested inference failure');
  await assert.rejects(() => f.ctx.qidianStage(c,'ocr',() => f.ctx.qidianStage(c,'glyph_decode',() => { f.state.now += 9; throw error; })), value => value === error);
  assert.equal(error.qidianStage,'glyph_decode'); assert.equal(c.options.qidianFailureStage,'glyph_decode');
  const failures = f.events().filter(event => event.event === 'chapter_stage_end' && event.outcome === 'error');
  assert.deepEqual(failures.map(event => event.stage),['glyph_decode','ocr']);
  assert(failures.every(event => event.failureStage === 'glyph_decode' && event.durationMs === 9));
  assert.equal(c.options.qidianStage,undefined,'nested stage cleanup must restore the outer context');
});
test('a frozen error still propagates unchanged and preserves failure attribution on the chapter', async () => {
  const f = diagnosticFixture(); const c = chapter(f.ctx); const error = Object.freeze(new Error('immutable operation error'));
  await assert.rejects(() => f.ctx.qidianStage(c,'free_cleanup',() => {throw error;}), value => value === error);
  assert.equal(c.options.qidianFailureStage,'free_cleanup');
  const event = f.events().find(event => event.event === 'chapter_stage_end');
  assert.equal(event.failureStage,'free_cleanup'); assert.equal(event.outcome,'error');
});
test('shipped synchronous Chapter.parse failure records local kind, stage and code without orphan watchdogs', async () => {
  const f = diagnosticFixture();
  const c = chapter(f.ctx, { chapterParse() { const error = new Error('parser failed; token=ERR_SECRET_NEVER_LOG'); error.name = 'QidianGlyphError'; error.code = 'FIXTURE_GLYPH_ERROR'; error.qidianStage = 'glyph_decode'; throw error; } });
  await c.init();
  assert.equal(c.status,statuses.failed); assert.equal(c.qidianFailureKind,'local'); assert.equal(c.retryTime,1); assert.equal(f.state.timers.size,0);
  const event = f.events().find(event => event.event === 'attempt_error');
  assert(event); assert.equal(event.failureKind,'local'); assert.equal(event.stage,'glyph_decode'); assert.equal(event.errorCode,'glyph_unresolved');
  assert(!JSON.stringify(f.events()).includes('ERR_SECRET_NEVER_LOG')); assert(!JSON.stringify(f.events()).includes('URL_SECRET_NEVER_LOG'));
});
test('actual free parser produces attributed load/cleanup/validation stages and no body text', async () => {
  const f = parserFixture(); await f.run();
  assert.equal(f.chapter.status,statuses.finished); assert.equal(f.state.requests.length,1);
  const ends = f.events().filter(event => event.event === 'chapter_stage_end');
  assert(ends.length >= 3, 'load, cleanup and validation must be distinguishable');
  assert(ends.every(event => event.chapterId === '39'));
  assert(ends.every(event => typeof event.stage === 'string' && event.stage && Number.isFinite(event.durationMs)));
  assert(!JSON.stringify(f.events()).includes('BODY_CONTENT_MUST_NOT_BE_LOGGED'));
  assert(!JSON.stringify(f.events()).includes('URL_SECRET_NEVER_LOG'));
});
test('actual VIP OCR error records the failed stage then isolated chapter error, and releases the frame', async () => {
  const f = parserFixture({ vip:true, ocrFailure:true }); await f.run();
  assert.equal(f.chapter.status,statuses.failed); assert.equal(f.chapter.qidianFailureKind,'local');
  assert.equal(f.state.requests.length,1); assert.equal(f.state.removed,1); assert.equal(f.state.timers.size,0); assert.equal(f.window.stopFlag.aborted,false);
  const stage = f.events().find(event => event.event === 'chapter_stage_end' && event.outcome === 'error');
  const attempt = f.events().find(event => event.event === 'attempt_error');
  assert(stage); assert(attempt); assert.equal(attempt.stage,stage.stage); assert.equal(attempt.failureKind,'local');
  assert(!JSON.stringify(f.events()).includes('ERR_SECRET_NEVER_LOG'));
});
test('HTTP access failure preserves status and stage in attempt_error after failure classification', async () => {
  const f = parserFixture({ httpStatus:403 }); await f.run();
  assert.equal(f.window.stopFlag.aborted,true); assert.equal(f.state.requests.length,1); assert.equal(f.state.timers.size,0);
  const event = f.events().find(event => event.event === 'attempt_error');
  assert(event); assert.equal(event.failureKind,'access'); assert.equal(event.httpStatus,403); assert(event.stage); assert(event.errorCode);
});
test('successful retry replaces stale validation and failure data with the current result', async () => {
  const f = parserFixture({ attempts:[{short:true},{}] }); await f.run();
  assert.equal(f.state.requests.length,2); assert.equal(f.chapter.status,statuses.finished); assert.equal(f.chapter.qidianFailureKind,null); assert.equal(f.chapter.errorMessage,null);
  const attempts = f.events().filter(event => event.event === 'attempt_start');
  assert.equal(attempts.length,2); assert.equal(attempts[1].attempts,2); assert.equal(attempts[1].reason,null); assert.equal(attempts[1].failureKind,null);
  assert.equal(attempts[1].quality,null,'a new attempt must not claim the previous attempt\'s body quality');
  const result = f.ctx.qidianChapterDiagnostic(f.chapter);
  assert.equal(result.quality.complete,true); assert.equal(result.quality.actualChars,body.replace(/\s/g,'').length); assert.equal(result.errorCode,null);
  assert.equal(f.state.timers.size,0);
});
test('failed retry before body extraction does not reuse the previous short body validation', async () => {
  const f = parserFixture({ attempts:[{short:true},{networkFailure:true}] }); await f.run();
  assert.equal(f.state.requests.length,2); assert.equal(f.chapter.status,statuses.failed);
  const errors = f.events().filter(event => event.event === 'attempt_error');
  assert.equal(errors.length,2); assert.equal(errors[0].quality.complete,false); assert.equal(errors[1].quality,null);
  assert.equal(errors[1].failureKind,'page'); assert(errors[1].stage);
});
test('short OCR body failures retain body_check through the outer actual Chapter.parse wrapper', async () => {
  const f = parserFixture({vip:true,ocrShort:true}); await f.run();
  assert.equal(f.chapter.status,statuses.failed); assert.equal(f.state.requests.length,2); assert.equal(f.state.timers.size,0);
  const failures=f.events().filter(event=>event.event==='attempt_error');
  assert.equal(failures.length,2);
  for(const failure of failures) {
    assert.equal(failure.stage,'body_check'); assert.equal(failure.failureKind,'local');
    assert.equal(failure.errorCode,'body_integrity_failed'); assert.equal(failure.quality.complete,false);
    assert.equal(failure.quality.reason,'below_expected_length');
  }
  assert.equal(f.ctx.qidianChapterDiagnostic(f.chapter).stage,'body_check');
});
test('converted frame timeouts retain page_load through retry without stale body validation', async () => {
  const f = parserFixture({vip:true,frameTimeout:true}); await f.run();
  assert.equal(f.chapter.status,statuses.failed); assert.equal(f.state.requests.length,2); assert.equal(f.state.timers.size,0);
  assert.equal(f.window.stopFlag.aborted,false);
  const failures=f.events().filter(event=>event.event==='attempt_error');
  assert.equal(failures.length,2);
  for(const failure of failures) {
    assert.equal(failure.stage,'page_load'); assert.equal(failure.failureKind,'page');
    assert.equal(failure.errorName,'QidianPageTimeoutError'); assert.equal(failure.errorCode,'page_timeout');
    assert.equal(failure.quality,null); assert.equal(failure.frameState.addressKind,'about:blank');
  }
  assert.equal(f.state.ocrCalls,0); assert.equal(f.state.cleanCalls,0);
});
test('summary includes selected snapshot, formatter omissions, restored chapters and untouched statuses', () => {
  const f = diagnosticFixture(); const selected = summaryChapters(f.ctx);
  f.window.qidianDebugRun.selectedChapters = selected;
  f.window.qidianDebugRun.finished = true;
  const book = { chapters:selected.slice(0,2), qidianResumedCount:1,
    downloadReport:{ selectedCount:5, savedCount:2, missing:[{title:selected[2].chapterName,chapterNumber:3,reason:selected[2].errorMessage},{title:selected[3].chapterName,chapterNumber:4,reason:'尚未处理'},{title:selected[4].chapterName,chapterNumber:5,reason:'已停止'}] },
    txtDownloadReport:{ selectedCount:5, savedCount:1, missing:[{title:selected[1].chapterName,chapterNumber:2,reason:'TXT格式化错误'}] } };
  f.state.now = 1900;
  const summary = f.ctx.qidianRunSummary(book);
  assert.equal(summary.selectedCount,5); assert.equal(summary.savedCount,2); assert.equal(summary.exportedCount,1);
  assert.equal(summary.failedCount,1); assert.equal(summary.unprocessedCount,1); assert.equal(summary.abortedCount,1); assert.equal(summary.resumedCount,1);
  assert.equal(summary.formatFailureCount,1); assert.equal(summary.missingCount,4);
  assert.equal(summary.durationMs,1000); assert.equal(summary.outcome,'partial');
  assert.deepEqual(normalize(summary.missing.map(item => item.title)).sort(),selected.slice(1).map(item => item.chapterName).sort());
  assert(!JSON.stringify(summary).includes('BODY_CONTENT_MUST_NOT_BE_LOGGED'));
});
for (const expected of ['completed','partial','failed','paused','stopped']) test(`summary distinguishes ${expected}`, () => {
  const f = diagnosticFixture(); const c = chapter(f.ctx); let exported = 1;
  c.status = statuses.saved; c.contentText = body; c.options.qidianValidation = f.ctx.qidianContentCheck(body,2000,false);
  const selected = [c];
  if (expected === 'partial') { const failed = chapter(f.ctx,{chapterNumber:2,chapterName:'第2章 失败'}); failed.status = statuses.failed; selected.push(failed); }
  if (expected === 'failed') { c.status = statuses.failed; c.contentText = null; exported = 0; f.window.qidianDebugRun.error = { errorCode:'operation_failed', reason:'任务失败' }; }
  if (expected === 'paused') { f.window.qidianPauseReason = '网站返回访问限制，已暂停'; f.window.stopController.abort(); }
  if (expected === 'stopped') f.window.stopController.abort();
  f.window.qidianDebugRun.selectedChapters = selected;
  f.window.qidianDebugRun.finished = true;
  const summary = f.ctx.qidianRunSummary({ chapters:selected, txtDownloadReport:{selectedCount:selected.length,savedCount:exported,missing:[]} });
  assert.equal(summary.outcome,expected);
  assert.equal(summary.pauseReason,expected === 'paused' ? f.window.qidianPauseReason : null);
});
test('summary handles a run failing before selection without inventing chapter successes', () => {
  const f = diagnosticFixture();
  const summary = f.ctx.qidianRunSummary(undefined,'failed');
  assert.equal(summary.outcome,'failed'); assert.equal(summary.selectedCount,0); assert.equal(summary.savedCount,0); assert.equal(summary.exportedCount,null);
  assert.deepEqual(normalize(summary.missing),[]);
});
test('before selection a new run ignores all stale counts and missing entries from the previous book', () => {
  const f=diagnosticFixture(); const stale=summaryChapters(f.ctx);
  const oldBook={chapters:stale,qidianResumedCount:8,
    downloadReport:{selectedCount:100,savedCount:94,missing:[{title:'OLD_BOOK_FAILURE_NEVER_REUSE',chapterNumber:3,reason:'前次失败'}]},
    txtDownloadReport:{selectedCount:100,savedCount:94,missing:[{title:'OLD_BOOK_FAILURE_NEVER_REUSE',chapterNumber:3,reason:'前次失败'}]}};
  const summary=f.ctx.qidianRunSummary(oldBook,'failed');
  assert.equal(summary.selectedCount,0); assert.equal(summary.savedCount,0); assert.equal(summary.exportedCount,null);
  assert.equal(summary.resumedCount,0); assert.equal(summary.attemptCount,0); assert.equal(summary.formatFailureCount,0); assert.equal(summary.missingCount,0);
  assert.deepEqual(normalize(summary.missing),[]); assert(!JSON.stringify(summary).includes('OLD_BOOK_FAILURE_NEVER_REUSE'));
});
test('running summary remains running and preserves two same-title formatter failures with distinct URLs', () => {
  const f = diagnosticFixture(); const selected = [101,102].map(id => chapter(f.ctx,{chapterUrl:`https://www.qidian.com/chapter/1/${id}/`,chapterNumber:9,chapterName:'第9章 同名正文'}));
  for(const item of selected) { item.status=statuses.saved; item.contentText=body; }
  f.window.qidianDebugRun.selectedChapters=selected;
  const summary=f.ctx.qidianRunSummary({chapters:selected,txtDownloadReport:{selectedCount:2,savedCount:0,missing:selected.map(item=>({title:item.chapterName,chapterNumber:9,chapterUrl:item.chapterUrl,reason:'TXT格式化错误'}))}});
  assert.equal(summary.outcome,'running'); assert.equal(summary.formatFailureCount,2);
  assert.deepEqual(normalize(summary.missing.map(item=>item.chapterId)),['101','102']);
});
test('formatter failure summary retains original VIP mode, attempts and checkpoint source', () => {
  const f=diagnosticFixture(); const paid=chapter(f.ctx,{chapterUrl:'https://www.qidian.com/chapter/1/101/',chapterNumber:101,chapterName:'第101章 VIP正文',isVIP:true});
  paid.status=statuses.saved; paid.contentText=body; paid.qidianAttemptCount=3; paid.qidianSource='checkpoint';
  paid.options.qidianValidation=f.ctx.qidianContentCheck(body,2000,true);
  f.window.qidianDebugRun.selectedChapters=[paid]; f.window.qidianDebugRun.finished=true;
  const summary=f.ctx.qidianRunSummary({chapters:[paid],txtDownloadReport:{selectedCount:1,savedCount:0,missing:[{title:paid.chapterName,chapterNumber:101,chapterUrl:paid.chapterUrl,reason:'TXT格式化错误'}]}});
  assert.equal(summary.formatFailureCount,1); assert.equal(summary.missingCount,1);
  const [missing]=summary.missing;
  assert.equal(missing.mode,'vip-ocr'); assert.equal(missing.attempts,3); assert.equal(missing.source,'checkpoint');
  assert.equal(missing.stage,'txt_format'); assert.equal(missing.errorCode,'txt_format_failed');
  assert.equal(missing.quality.complete,true,'a formatting failure must not falsely erase a previously valid paid body');
});
test('actual Rule.run saves one complete summary before the automatic debug log on success', async () => {
  const f = runFixture(); await f.run();
  const summaries = f.events().filter(event => event.event === 'run_summary');
  assert.equal(summaries.length,1); assert.equal(summaries[0].outcome,'completed'); assert.equal(summaries[0].selectedCount,1); assert.equal(summaries[0].exportedCount,1);
  assert.equal(f.state.logSaves.length,1); assert.equal(f.state.logSaves[0].filter(event => event.event === 'run_summary').length,1);
  assert.deepEqual(f.state.sessionCalls.map(call => call[0]),['start','clear']);
  assert(!JSON.stringify(f.events()).includes('BODY_CONTENT_MUST_NOT_BE_LOGGED'));
});
test('actual Rule.run summary retains a failed filtered chapter and formatter failure', async () => {
  const f = runFixture({
    chapters:ctx => [1,2,3].map(id => chapter(ctx,{chapterUrl:`https://www.qidian.com/chapter/1/${id}/`,chapterNumber:id,chapterName:`第${id}章 ${id === 2 ? '格式化失败' : id === 3 ? '正文失败' : '正常'}`})),
    formatFailure:true,
    applyStatuses(_f, chapters) { for (const item of chapters) { item.status = item.chapterNumber === 3 ? statuses.failed : statuses.saved; item.contentText = item.chapterNumber === 3 ? null : body; if(item.chapterNumber === 3)item.errorMessage = '章节正文未通过校验'; } }
  });
  await f.run(); assert.equal(f.book.chapters.length,2,'actual run validation must exercise filtering');
  const summary = f.events().find(event => event.event === 'run_summary');
  assert.equal(summary.selectedCount,3); assert.equal(summary.savedCount,2); assert.equal(summary.exportedCount,1); assert.equal(summary.outcome,'partial');
  assert.equal(summary.formatFailureCount,1); assert.equal(summary.missingCount,2);
  assert.deepEqual(summary.missing.map(item => item.title).sort(),['第2章 格式化失败','第3章 正文失败']);
  assert(f.state.logSaves[0].some(event => event.event === 'run_summary' && event.selectedCount === 3));
});
for (const failure of ['preHookError','initError','exportError']) test(`actual Rule.run ${failure} produces one failed summary before debug save`, async () => {
  const f = runFixture({ [failure]:true }); await f.run();
  const summaries = f.events().filter(event => event.event === 'run_summary');
  assert.equal(summaries.length,1); assert.equal(summaries[0].outcome,'failed');
  assert.equal(f.state.logSaves.length,1); assert(f.state.logSaves[0].some(event => event.event === 'run_summary'));
  assert.equal(f.state.caught.length,1); assert.deepEqual(f.state.sessionCalls.map(call => call[0]),['start','clear']);
  assert(!JSON.stringify(f.events()).includes('EXPORT_SECRET_NEVER_LOG'));
});
test('actual Rule.run with a paused partial task includes untouched chapters in saved debug summary', async () => {
  const f = runFixture({ chapters:ctx => [1,2].map(id => chapter(ctx,{chapterNumber:id,chapterName:`第${id}章`})),
    applyStatuses(f, selected) { selected[0].status = statuses.saved; selected[0].contentText = body; f.window.qidianPauseReason = '网站返回访问限制，已暂停'; f.window.stopController.abort(); } });
  await f.run();
  const summary = f.events().find(event => event.event === 'run_summary');
  assert.equal(summary.outcome,'paused'); assert.equal(summary.selectedCount,2); assert.equal(summary.exportedCount,1); assert.equal(summary.unprocessedCount,1);
  assert.equal(summary.pauseReason,'网站返回访问限制，已暂停'); assert(summary.missing.some(item => item.title === '第2章'));
  assert(f.state.logSaves[0].some(event => event.event === 'run_summary' && event.unprocessedCount === 1));
});
test('automatic debug-file save failure does not erase a completed download or bypass session cleanup', async () => {
  const f = runFixture({ logSaveError:true }); await f.run();
  assert.equal(f.state.outputSaves,1); assert.equal(f.state.caught.length,0);
  assert.deepEqual(f.state.sessionCalls.map(call => call[0]),['start','clear']);
  assert.equal(f.events().find(event => event.event === 'run_summary').outcome,'completed');
});
test('actual session cleanup rejection survives after one final summary and one automatic debug export', async () => {
  const error=new Error('original session cleanup failure; token=CLEANUP_SECRET_NEVER_LOG');
  const f=runFixture({cleanupError:error});
  await assert.rejects(()=>f.run(),value=>value===error);
  const events=f.events(); const cleanup=events.find(event=>event.event==='run_cleanup_error');
  const summaries=events.filter(event=>event.event==='run_summary');
  assert(cleanup); assert.equal(summaries.length,1); assert.equal(summaries[0].outcome,'failed');
  assert.equal(summaries[0].exportedCount,1,'a cleanup failure must retain the already exported body count');
  assert.equal(f.state.outputSaves,1); assert.equal(f.state.logSaves.length,1);
  const saved=f.state.logSaves[0]; assert.equal(saved.filter(event=>event.event==='run_summary').length,1);
  assert(saved.indexOf(saved.find(event=>event.event==='run_cleanup_error'))<saved.indexOf(saved.find(event=>event.event==='run_summary')));
  assert.deepEqual(f.state.sessionCalls.map(call=>call[0]),['start','clear']);
  assert(!JSON.stringify(events).includes('CLEANUP_SECRET_NEVER_LOG'));
});
test('actual watchdog logs the observed stage with its distinct code and fails only the current chapter', async () => {
  const f=diagnosticFixture();
  const c=chapter(f.ctx,{isVIP:true,chapterParse(_url,_name,_vip,_paid,_charset,options){options.qidianStage='ocr';return new Promise(()=>{});}});
  const task=c.init();
  for(let turn=0;turn<20;turn++) await Promise.resolve();
  const [timerId,timer]=[...f.state.timers.entries()].find(([,value])=>value.ms===600000)??[];
  assert(timer,'actual Chapter.parse watchdog must be registered');
  f.state.now+=timer.ms; f.state.timers.delete(timerId); timer.fn();
  await task;
  const watchdog=f.events().find(event=>event.event==='watchdog_timeout');
  assert(watchdog); assert.equal(watchdog.stage,'ocr'); assert.equal(watchdog.errorCode,'chapter_watchdog_timeout');
  assert.equal(watchdog.timeoutMs,600000); assert.equal(watchdog.taskPaused,false); assert.equal(watchdog.quality,null);
  const failure=f.events().find(event=>event.event==='attempt_error');
  assert.equal(failure.stage,'ocr'); assert.equal(failure.errorCode,'chapter_watchdog_timeout'); assert.equal(failure.failureKind,'local');
  assert.equal(f.window.stopFlag.aborted,false); assert.equal(c.retryTime,1); assert.equal(f.state.timers.size,0); assert.equal(c.qidianNoAutoRetry,true);
  assert.equal(f.events().filter(event=>event.event==='retry_scheduled').length,0);
});
for(const qidian of [true,false]) test(`shipped SaveBook.save ${qidian?'defers Qidian debug save until run finally':'preserves ordinary-site automatic debug saving'}`, async () => {
  const f=diagnosticFixture(); let textSaves=0, logSaves=0;
  f.ctx.setting={Jv:{value:true},Zz:{value:false},Nw:{value:true}};
  f.ctx.document.location.hostname=qidian?'www.qidian.com':'example.invalid';
  f.ctx.onLogSave=()=>{logSaves++;};
  vm.runInContext('class SaveBook {'+saveCode+' static saveLog(){onLogSave();}}\nthis.ShippedSaveBook=SaveBook;',f.ctx);
  const save=new f.ctx.ShippedSaveBook(); save.saveType={txt:true,epub:false}; save.saveTxt=()=>{textSaves++;};
  await save.save();
  assert.equal(textSaves,1); assert.equal(logSaves,qidian?0:1);
});

(async () => {
  let failed = 0;
  for (const {name,fn} of tests) {
    try { await fn(); console.log(`PASS ${name}`); }
    catch(error) { failed++; console.error(`FAIL ${name}\n${error.stack}`); }
  }
  console.log(`${tests.length-failed}/${tests.length} v25 shipped debug flow checks passed`);
  if (failed) process.exitCode = 1;
})();
