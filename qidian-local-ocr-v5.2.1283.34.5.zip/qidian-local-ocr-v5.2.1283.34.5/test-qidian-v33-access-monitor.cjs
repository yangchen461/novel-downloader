const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const globals = source.slice(source.indexOf('function qidianContentIsComplete('), source.indexOf('/******/ \tvar __webpack_modules__'));
function fixture() {
  const state = { nodes: [], timers: new Map(), next: 0, logs: [], reports: [] };
  const doc = { title: '章节目录', body: { innerText: '' },
    defaultView: { getComputedStyle: node => node.computed || {display:'block',visibility:'visible',opacity:'1'} },
    querySelector: () => null,
    querySelectorAll: selector => selector.includes('[aria-modal="true"]') ? state.nodes : [] };
  const window = {stopController:new AbortController(),
    setInterval(fn) { const id=++state.next; state.timers.set(id,fn); return id; },
    clearInterval(id) { state.timers.delete(id); },
    qidianDebugLogger:{info:line=>state.logs.push(line)},
    qidianProgressSink:value=>state.reports.push(value)};
  window.stopFlag=window.stopController.signal;
  const ctx=vm.createContext({window,document:doc,URL,Date,AbortController});
  vm.runInContext(globals,ctx);
  const node=(text,extra={})=>({tagName:'DIV',innerText:text,style:{},
    getAttribute:()=>null,closest:()=>null,getBoundingClientRect:()=>({width:320,height:180}),...extra});
  return {ctx,window,doc,state,node,tick(){for(const fn of [...state.timers.values()])fn();}};
}
const tests=[];
const test=(name,fn)=>tests.push({name,fn});
test('visible verification dialog outside main is an access gate even on a normal titled page',()=>{
  const f=fixture();f.state.nodes=[f.node('请完成安全验证后继续')];
  assert.equal(f.ctx.qidianChapterAccessState(f.doc,false).kind,'verification_required');
  assert.equal(f.ctx.qidianChapterAccessState(f.doc,false).evidence,'visible_verification_dialog');
});
test('visible slider instructions and explicit iframe titles require manual verification',()=>{
  for(const node of [f=>f.node('请拖动滑块完成拼图'),f=>f.node('',{tagName:'IFRAME',getAttribute:k=>k==='title'?'安全验证':null})]){
    const f=fixture();f.state.nodes=[node(f)];assert.equal(f.ctx.qidianCheckActiveAccess(),false);
    assert.equal(f.window.stopFlag.aborted,true);assert.match(f.window.qidianPauseReason,/手动完成验证/);
  }
});
test('hidden, transparent, tiny and aria-hidden SDK widgets do not pause normal reading',()=>{
  for(const extra of [{hidden:true},{computed:{display:'none'}},{computed:{visibility:'hidden'}},{computed:{opacity:'0'}},
    {getBoundingClientRect:()=>({width:1,height:1})},{getAttribute:k=>k==='aria-hidden'?'true':null}]){
    const f=fixture();f.state.nodes=[f.node('请完成安全验证',extra)];
    assert.equal(f.ctx.qidianCheckActiveAccess(),true);assert.equal(f.window.stopFlag.aborted,false);
  }
});
test('novel prose, author notes and navigation do not count as verification dialogs',()=>{
  const f=fixture();f.state.nodes=[f.node('安全验证',{closest:()=>({})})];
  assert.equal(f.ctx.qidianCheckActiveAccess(),true);
  f.state.nodes=[];f.doc.body.innerText='书中说请完成安全验证';
  assert.equal(f.ctx.qidianCheckActiveAccess(),true);
});
test('generic password dialogs and captcha script availability do not prove an access gate',()=>{
  const f=fixture();f.state.nodes=[f.node('请输入密码')];
  assert.equal(f.ctx.qidianCheckActiveAccess(),true);
});
test('detached static HTML does not prove that a captcha template is visible',()=>{
  const f=fixture();f.doc.defaultView=null;f.state.nodes=[f.node('安全验证')];
  assert.equal(f.ctx.qidianVisibleChallenge(f.doc),null);
  assert.equal(f.ctx.qidianCheckActiveAccess(),true);
  f.doc.title='WAF拦截页面';
  assert.equal(f.ctx.qidianCheckActiveAccess(),false,'explicit static WAF page still pauses');
});
test('visible login requirement receives a login reason without requesting or purchasing',()=>{
  const f=fixture();f.state.nodes=[f.node('请先登录后继续阅读')];
  assert.equal(f.ctx.qidianCheckActiveAccess(),false);assert.match(f.window.qidianPauseReason,/手动登录/);
});
test('monitor detects a new top-page challenge during a wait and stops its own interval',()=>{
  const f=fixture();const dispose=f.ctx.qidianStartAccessMonitor();
  assert.equal(f.state.timers.size,1);assert.equal(f.window.stopFlag.aborted,false);
  f.state.nodes=[f.node('安全验证')];f.tick();
  assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.state.timers.size,0);
  assert.equal(f.window.qidianProgressState.state,'paused');
  f.state.nodes=[];f.tick();assert.equal(f.window.stopFlag.aborted,true,'disappearing dialog never auto resumes');
  dispose();assert.equal(f.state.timers.size,0);
});
test('monitor observes only the active owned reader document as well as the parent',()=>{
  const f=fixture();const child=fixture();child.state.nodes=[child.node('人机验证')];
  f.window.qidianActiveReaderDocument=child.doc;
  const dispose=f.ctx.qidianStartAccessMonitor();assert.equal(f.window.stopFlag.aborted,true);
  dispose();assert.equal(f.window.qidianActiveReaderDocument,null);assert.equal(f.state.timers.size,0);
});
test('disposing monitor and user cancellation both remove interval without pausing a later run',()=>{
  const f=fixture();const dispose=f.ctx.qidianStartAccessMonitor();dispose();
  f.state.nodes=[f.node('安全验证')];f.tick();assert.equal(f.window.stopFlag.aborted,false);
  const g=fixture();const cleanup=g.ctx.qidianStartAccessMonitor();g.window.stopController.abort();
  assert.equal(g.state.timers.size,0);assert.equal(g.window.qidianProgressState.state,'stopped');cleanup();
});
let failed=0;
for(const {name,fn} of tests)try{fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error.stack);}
console.log(`${tests.length-failed}/${tests.length} v33 access monitor checks passed`);
if(failed)process.exitCode=1;
