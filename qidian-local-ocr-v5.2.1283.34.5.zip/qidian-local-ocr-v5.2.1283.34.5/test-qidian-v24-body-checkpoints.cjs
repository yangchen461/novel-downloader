/* Actual helper body-only checkpoint regression suite. No remote requests. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const mainPath = process.env.QIDIAN_SCRIPT_PATH || path.join(__dirname, 'novel-downloader-qidian-range.user.js');
const main = fs.readFileSync(mainPath, 'utf8');
assert(main.includes('function qidianContentBodyText(') && main.includes('inferred-image-links'), 'final main contains v24 body checkpoint helpers');
const source = main;
const fragment = source.slice(source.indexOf('// Local TXT checkpoints.'), source.indexOf('// End local TXT checkpoint helpers.'));
const validation = main.slice(main.indexOf('function qidianContentIsComplete('), main.indexOf('function qidianContentFailure('));
assert(fragment.includes('bodyValidationVersion: 2'), 'real v24 helper fragment');
const fullBody = '这是完整章节正文。包含足够汉字并保留全部段落。\n'.repeat(100);
const shortBody = '这是残缺正文。';
const notes = '作者的话。很长的作者留言不应填补正文。\n'.repeat(200);
const separator = '\n\n----------\n\n';
const bookId = '1048193111';
function chapter(extra = {}) { return { chapterName: '第1章 正文', qidianCatalogTitle: '第1章 正文',
  chapterUrl: `https://www.qidian.com/chapter/${bookId}/101/`, chapterNumber: 1,
  isVIP: false, contentText: fullBody, options: { expectedChars: 2000 }, ...extra }; }
function book() { return { bookUrl: `https://www.qidian.com/book/${bookId}/`, bookname: '测试书', author: '测试作者', chapters: [chapter()] }; }
function harness() {
  const storage = new Map(), events = [];
  const context = vm.createContext({ URL, Map, Math, Date, Promise, setTimeout, clearTimeout,
    GM_getValue: (k, d) => structuredClone(storage.get(k) ?? d),
    GM_setValue: (k, v) => storage.set(k, structuredClone(v)), GM_deleteValue: k => storage.delete(k) });
  vm.runInContext(validation + fragment, context);
  return { context, storage, events, logger: (event, data) => events.push({ event, ...data }) };
}
async function initial(h, c = chapter()) { const s = await h.context.qidianCheckpointOpen(book(), h.logger); assert(await h.context.qidianCheckpointSave(s, c)); return s; }
function legacy(h, session, text) {
  const key = h.context.qidianCheckpointRecordKey(session, '101');
  const record = h.storage.get(key);
  record.text = text; record.digest = h.context.qidianCheckpointDigest(text);
  delete record.bodyLength; delete record.bodyDigest; delete record.bodyValidationVersion; delete record.bodyBoundarySource;
  return record;
}
function importTxt(b, text) { return `题名：${b.bookname}\n作者：${b.author}\n原始网址：${b.bookUrl}\n本文件由小说下载器生成，软件地址：https://github.com/404-novel-project/novel-downloader\n\n${'…'.repeat(30)}\n第1章 正文\n\n${text}\n`; }
let passed = 0;
async function test(name, fn) { await fn(); passed++; }
(async () => {
  await test('body helper explicit boundary ignores author notes', async () => {
    const h = harness(); const full = fullBody + separator + notes;
    assert.equal(h.context.qidianContentBodyText(full, fullBody.length), fullBody);
    assert.equal(h.context.qidianContentBodyText(full), fullBody);
    assert.equal(h.context.qidianContentBodyText(full, 0), '');
    assert.equal(h.context.qidianContentBodyText(full, undefined), fullBody);
  });
  await test('malformed explicit boundary fails closed', async () => {
    const h = harness(); const full = fullBody + separator + notes;
    for (const boundary of [-1, 1.5, full.length + 1, null, '2000', Infinity, NaN]) {
      assert.equal(h.context.qidianContentBodyText(full, boundary), '');
    }
  });
  await test('options boundary takes precedence over chapter fallback', async () => {
    const h = harness(); const full = fullBody + separator + notes;
    assert.equal(h.context.qidianChapterBodyText(chapter({ contentText: full, options: { qidianBodyLength: fullBody.length }, qidianBodyLength: 2 })), fullBody);
    assert.equal(h.context.qidianChapterBodyText(chapter({ contentText: full, options: {}, qidianBodyLength: fullBody.length })), fullBody);
    assert.equal(h.context.qidianChapterBodyText(chapter({ contentText: full, options: { qidianBodyLength: 0 }, qidianBodyLength: fullBody.length })), '');
  });
  await test('short body plus long notes rejected by inferred checkpoint save', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter({ contentText: shortBody + separator + notes })), false);
    assert.equal(h.storage.size, 0);
  });
  await test('short body plus long notes rejected with explicit body length', async () => {
    const h = harness(); const s = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter({ contentText: shortBody + separator + notes, options: { expectedChars: 2000, qidianBodyLength: shortBody.length } })), false);
    assert.equal(h.storage.size, 0);
  });
  await test('complete body with long notes keeps full export and body digest', async () => {
    const h = harness(); const full = fullBody + separator + notes; const s = await initial(h, chapter({ contentText: full, options: { expectedChars: 2000, qidianBodyLength: fullBody.length } }));
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.text, full);
    assert.equal(record.bodyLength, fullBody.length);
    assert.equal(record.bodyDigest, h.context.qidianCheckpointDigest(fullBody));
    assert.equal(record.bodyValidationVersion, 2);
    assert(!Object.hasOwn(record, 'bodyText'));
    const written = h.events.find(e => e.event === 'checkpoint_written');
    assert.equal(written.chars, fullBody.replace(/\s/g, '').length);
    assert(written.fullTextChars > written.chars);
  });
  await test('legitimate in-story separator kept when DOM body length is explicit', async () => {
    const h = harness(); const story = shortBody + separator + fullBody; const full = story + separator + notes;
    const s = await initial(h, chapter({ contentText: full, options: { expectedChars: 2000, qidianBodyLength: story.length } }));
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.bodyLength, story.length);
    assert.equal(h.context.qidianContentBodyText(record.text, record.bodyLength), story);
    assert.equal(record.text, full);
  });
  await test('legacy good record revalidated and returned with version2 boundary', async () => {
    const h = harness(); const s = await initial(h); const full = fullBody + separator + notes;
    legacy(h, s, full);
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.bodyLength, fullBody.length);
    assert.equal(record.bodyValidationVersion, 2);
    assert.equal(record.bodyBoundarySource, 'inferred-author-separator');
    assert.equal(record.text, full);
    assert(h.events.some(e => e.legacyBodyRevalidated === true));
  });
  await test('legacy short-body long-notes record cannot masquerade as complete', async () => {
    const h = harness(); const s = await initial(h);
    legacy(h, s, shortBody + separator + notes);
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    assert(h.events.some(e => e.reason === 'body_check_failed'));
  });
  await test('old good record without separator kept with full body length', async () => {
    const h = harness(); const s = await initial(h); legacy(h, s, fullBody);
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.bodyLength, fullBody.length);
    assert.equal(record.bodyBoundarySource, 'full-text');
  });
  await test('damaged body length or body digest rejected independently', async () => {
    const h = harness(); const s = await initial(h);
    const key = h.context.qidianCheckpointRecordKey(s, '101'); const original = structuredClone(h.storage.get(key));
    for (const length of [-1, '2000', 1.5, fullBody.length + 1]) {
      h.storage.set(key, { ...original, bodyLength: length });
      assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    }
    h.storage.set(key, { ...original, bodyLength: original.bodyLength - 1 });
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    h.storage.set(key, { ...original, bodyDigest: 'wrong' });
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    assert(h.events.some(e => e.reason === 'body_boundary_metadata'));
    assert(h.events.some(e => e.reason === 'body_prefix_digest_mismatch'));
  });
  await test('partially missing v2 metadata cannot downgrade to legacy inference', async () => {
    const h = harness(); const s = await initial(h);
    const record = h.storage.get(h.context.qidianCheckpointRecordKey(s, '101'));
    delete record.bodyDigest;
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
  });
  await test('TXT import validates body prefix and cannot count long notes', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const result = await h.context.qidianCheckpointImportTxt(s, b, importTxt(b, shortBody + separator + notes));
    assert.equal(result.imported, 0); assert.equal(result.incomplete, 1); assert.equal(h.storage.size, 0);
  });
  await test('TXT import preserves notes but emits inferred boundary metadata', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const result = await h.context.qidianCheckpointImportTxt(s, b, importTxt(b, fullBody + separator + notes));
    assert.equal(result.imported, 1); assert.equal(result.inferredBodyBoundary, 1);
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.text, (fullBody + separator + notes).trim());
    assert.equal(record.bodyLength, fullBody.length);
    assert.equal(record.bodyBoundarySource, 'inferred-author-separator');
  });
  await test('legacy ambiguous true story separator is rejected conservatively', async () => {
    const h = harness(); const s = await initial(h);
    legacy(h, s, shortBody + separator + fullBody);
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
  });
  await test('non-exact separators stay part of the inferred full body', async () => {
    const h = harness(); const full = shortBody + '\n----------\n' + fullBody;
    assert.equal(h.context.qidianContentBodyText(full), full);
  });
  await test('old book info route and canonical route share checkpoint', async () => {
    const h = harness(); const oldBook = { ...book(), bookUrl: `https://book.qidian.com/info/${bookId}/` };
    const s = await h.context.qidianCheckpointOpen(oldBook, h.logger);
    assert.equal(s.disabled, false);
    await h.context.qidianCheckpointSave(s, chapter());
    const fresh = await h.context.qidianCheckpointOpen(book(), h.logger);
    assert(await h.context.qidianCheckpointRestore(fresh, chapter()));
  });
  await test('generated image link appendix cannot fill a short body', async () => {
    const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
    const imageAppendix = '\n\n[正文图片链接]\n' + ('正文图片说明：https://example.test/image.png\n'.repeat(200));
    const full = shortBody + imageAppendix + separator + notes;
    assert.equal(h.context.qidianContentBodyText(full), shortBody);
    assert.equal(await h.context.qidianCheckpointSave(s, chapter({ contentText: full })), false);
    const result = await h.context.qidianCheckpointImportTxt(s, b, importTxt(b, full));
    assert.equal(result.imported, 0); assert.equal(result.incomplete, 1);
  });
  await test('image links remain in full cached export but outside body checks', async () => {
    const h = harness(); const b = book(); const imageAppendix = '\n\n[正文图片链接]\nhttps://example.test/image.png';
    const full = fullBody + imageAppendix + separator + notes;
    const s = await initial(h, chapter({ contentText: full }));
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.text, full); assert.equal(record.bodyLength, fullBody.length);
    assert.equal(record.bodyBoundarySource, 'inferred-image-links');
    const importSession = await h.context.qidianCheckpointOpen(b, h.logger);
    const result = await h.context.qidianCheckpointImportTxt(importSession, b, importTxt(b, full));
    assert.equal(result.imported, 1);
    assert.equal(result.inferredBodyBoundary, 1);
    const imported = await h.context.qidianCheckpointRestore(importSession, chapter());
    assert.equal(imported.text, full.trim());
    assert.equal(imported.bodyBoundarySource, 'inferred-image-links');
  });
  await test('earliest author or image appendix marker wins only for inferred metadata', async () => {
    const h = harness(); const imageMarker = '\n\n[正文图片链接]\n';
    const imageFirst = fullBody + imageMarker + '图片地址' + separator + notes;
    const authorFirst = fullBody + separator + notes + imageMarker + '图片地址';
    assert.equal(h.context.qidianContentBodyText(imageFirst), fullBody);
    assert.equal(h.context.qidianContentBodyText(authorFirst), fullBody);
    assert.equal(h.context.qidianCheckpointBodyBoundarySource(imageFirst), 'inferred-image-links');
    assert.equal(h.context.qidianCheckpointBodyBoundarySource(authorFirst), 'inferred-author-separator');
    const story = shortBody + imageMarker + fullBody;
    assert.equal(h.context.qidianContentBodyText(story, story.length), story);
  });
  await test('legacy image appendix record revalidates real body only', async () => {
    const h = harness(); const s = await initial(h);
    const imageAppendix = '\n\n[正文图片链接]\n' + ('正文图片说明：https://example.test/image.png\n'.repeat(200));
    legacy(h, s, shortBody + imageAppendix);
    assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    legacy(h, s, fullBody + imageAppendix);
    const record = await h.context.qidianCheckpointRestore(s, chapter());
    assert.equal(record.bodyLength, fullBody.length);
    assert.equal(record.bodyBoundarySource, 'inferred-image-links');
    assert.equal(record.text, fullBody + imageAppendix);
  });
  await test('residual BMP/supplementary PUA and replacement glyphs reject save, v2/legacy restore, and import', async () => {
    const cases = [
      { label: 'BMP-PUA-first', value: '\uE000', reason: 'unresolved_private_use' },
      { label: 'BMP-PUA-last', value: '\uF8FF', reason: 'unresolved_private_use' },
      { label: 'plane15-PUA-first', value: '\u{F0000}', reason: 'unresolved_private_use' },
      { label: 'plane15-PUA-last', value: '\u{FFFFD}', reason: 'unresolved_private_use' },
      { label: 'plane16-PUA-first', value: '\u{100000}', reason: 'unresolved_private_use' },
      { label: 'plane16-PUA-last', value: '\u{10FFFD}', reason: 'unresolved_private_use' },
      { label: 'replacement-character', value: '\uFFFD', reason: 'replacement_characters' }
    ];
    for (const entry of cases) {
      const h = harness(); const b = book(); const s = await h.context.qidianCheckpointOpen(b, h.logger);
      const body = fullBody + entry.value;
      const full = body + separator + notes;
      const quality = h.context.qidianContentCheck(body, 2000, false);
      assert.equal(quality.complete, false, entry.label);
      assert.equal(quality.reason, entry.reason, entry.label);
      assert.equal(quality.unresolvedPrivateUseChars, entry.reason === 'unresolved_private_use' ? 1 : 0, entry.label);
      assert.equal(quality.replacementChars, entry.reason === 'replacement_characters' ? 1 : 0, entry.label);
      assert.equal(await h.context.qidianCheckpointSave(s, chapter({ contentText: full, options: { expectedChars: 2000, qidianBodyLength: body.length } })), false, entry.label);
      assert.equal(h.storage.size, 0, entry.label);
      // Seed through the real save API, then keep both digests consistent with
      // the contaminated body so this tests quality rather than corruption.
      assert(await h.context.qidianCheckpointSave(s, chapter()));
      const key = h.context.qidianCheckpointRecordKey(s, '101');
      const record = h.storage.get(key);
      record.text = full; record.digest = h.context.qidianCheckpointDigest(full);
      record.bodyLength = body.length; record.bodyDigest = h.context.qidianCheckpointDigest(body);
      assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null, entry.label);
      legacy(h, s, full);
      assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null, entry.label);
      const result = await h.context.qidianCheckpointImportTxt(s, b, importTxt(b, full));
      assert.equal(result.imported, 0, entry.label);
      assert.equal(result.incomplete, 1, entry.label);
    }
  });
  await test('normal emoji, punctuation, and extension Han are accepted through save, restore, and import', async () => {
    const cases = [
      { label: 'emoji', value: '😀👩‍💻🌙' },
      { label: 'punctuation', value: '“对白……”——【正文】！？，；：' },
      { label: 'extension-Han', value: '\u{20000}\u{2A6D6}\u{30000}' }
    ];
    for (const entry of cases) {
      const h = harness(); const b = book(); const body = fullBody + entry.value;
      const full = body + separator + notes;
      const quality = h.context.qidianContentCheck(body, 2000, false);
      assert.equal(quality.complete, true, entry.label);
      assert.equal(quality.reason, 'passed', entry.label);
      assert.equal(quality.unresolvedPrivateUseChars, 0, entry.label);
      assert.equal(quality.replacementChars, 0, entry.label);
      const s = await initial(h, chapter({ contentText: full, options: { expectedChars: 2000, qidianBodyLength: body.length } }));
      const restored = await h.context.qidianCheckpointRestore(s, chapter());
      assert.equal(restored.text, full, entry.label);
      assert.equal(restored.bodyLength, body.length, entry.label);
      const result = await h.context.qidianCheckpointImportTxt(s, b, importTxt(b, full));
      assert.equal(result.imported, 1, entry.label);
      const imported = await h.context.qidianCheckpointRestore(s, chapter());
      assert.equal(imported.text, full.trim(), entry.label);
      assert.equal(imported.bodyLength, body.length, entry.label);
    }
  });
  await test('v2 record requires a recognized body boundary source even when digests are valid', async () => {
    const h = harness(); const s = await initial(h);
    const key = h.context.qidianCheckpointRecordKey(s, '101');
    const original = structuredClone(h.storage.get(key));
    for (const source of [undefined, null, '', 'unrecognized']) {
      const record = { ...original, bodyBoundarySource: source };
      if (source === undefined) delete record.bodyBoundarySource;
      h.storage.set(key, record);
      assert.equal(await h.context.qidianCheckpointRestore(s, chapter()), null);
    }
    assert(h.events.some(e => e.reason === 'body_boundary_metadata'));
    h.storage.set(key, original);
    assert(await h.context.qidianCheckpointRestore(s, chapter()));
  });
  console.log(`Qidian body-only checkpoint helpers: ${passed}/${passed} passed`);
})().catch(error => { console.error(error); process.exitCode = 1; });
