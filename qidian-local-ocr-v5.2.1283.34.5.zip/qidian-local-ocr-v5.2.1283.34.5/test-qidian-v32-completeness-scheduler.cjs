// Execute the shipped scheduler with the existing deterministic browser boundary.
// No network, credentials, source novel text, or real waiting is used.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const directory = path.resolve(process.argv[2] || __dirname);
const source = fs.readFileSync(path.join(directory, 'novel-downloader-qidian-range.user.js'), 'utf8');
const fixtureSource = fs.readFileSync(path.join(directory, 'test-qidian-v19-resilience.cjs'), 'utf8');
const suite = vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('const tests=[];')) + '\n({fixture,status})',
  { require, __dirname: directory, AbortController, URL, console });
const tests = [];
const test = (name, run) => tests.push({ name, run });
const ids = f => Array.from(f.state.starts, row => row.id);
const saved = f => Array.from(f.chapters).filter(chapter => chapter.status === suite.status.saved);
const events = f => Array.from(f.state.logs).filter(line => line.startsWith('[QidianDebug] ')).map(line => JSON.parse(line.slice(14)));

test('isolated temporary blank pages recover after successful pages between failures', async () => {
  const f = suite.fixture([
    { id: 1, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 2, vip: true },
    { id: 3, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 4, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 1, 3]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(saved(f).length, 4);
  assert.equal(f.progress.finishedChapterNumber, 4);
  assert.deepEqual(Array.from(f.chapters, c => c.chapterNumber), [2, 3, 4, 5]);
  assert.deepEqual(Array.from(f.chapters, c => c.qidianAttemptCount), [2, 1, 2, 1]);
  assert.equal(f.chapters[3].options.qidianRecoveryRound, undefined);
  assert(f.state.waits.every(ms => ms <= 1000));
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 1);
});

test('permanently blank chapter gets exactly two deferred retries and remains explicitly missing', async () => {
  const f = suite.fixture([{ id: 1, vip: true, frameTimeout: 'blank' }, { id: 2, vip: true }]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 1, 1]);
  assert.equal(f.chapters[0].qidianAttemptCount, 3);
  assert.equal(f.chapters[0].status, suite.status.failed);
  assert.equal(f.chapters[1].status, suite.status.saved);
  assert.equal(f.progress.finishedChapterNumber, 1);
  const book = f.validate();
  assert.equal(book.downloadReport.missing.length, 1);
  assert.equal(book.downloadReport.missing[0].title, '第1章');
});

test('valid saved checkpoints are never requested again or duplicated in recovery', async () => {
  const f = suite.fixture([{ id: 1, vip: true }, { id: 2, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true }]);
  f.chapters[0].status = suite.status.saved;
  f.book.qidianResumedCount = 1;
  await f.run();
  assert.deepEqual(ids(f), [2, 2]);
  assert.equal(f.progress.finishedChapterNumber, 2);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第2章']);
});

test('local OCR failure is deferred but cannot trigger unbounded request loops', async () => {
  const f = suite.fixture([{ id: 1, vip: true, glyphFail: true }, { id: 2, vip: true }]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 1, 1]);
  assert.equal(f.chapters[0].qidianAttemptCount, 3);
  assert.equal(f.chapters[0].retryTime, 1);
  assert.equal(saved(f).length, 1);
});

test('export errors do not re-request a body or risk duplicate writes in recovery', async () => {
  const f = suite.fixture([{ id: 1, vip: true, saveThrows: true }, { id: 2, vip: true }]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2]);
  assert.equal(f.chapters[0].qidianFailureKind, 'export');
});

test('a saver that writes successfully then throws is not repeated by a repair pass', async () => {
  const f = suite.fixture([{ id: 1, vip: true }, { id: 2, vip: true }]);
  const addChapter = f.saver.addChapter.bind(f.saver);
  f.saver.addChapter = async chapter => {
    await addChapter(chapter);
    if (chapter.chapterName === '第1章') throw Error('synthetic post-write failure');
  };
  await f.run();
  assert.deepEqual(ids(f), [1, 2]);
  assert.equal(f.chapters[0].qidianFailureKind, 'export');
  assert.deepEqual(Array.from(f.state.saveCalls), ['第1章', '第2章']);
});

test('stop during a page cooldown prevents the next request and all repair rounds', async () => {
  const f = suite.fixture([{ id: 1, vip: true, frameTimeout: 'blank' }, { id: 2, vip: true }]);
  f.state.onSleep = () => {
    if (f.state.starts.length === 1 && f.chapters[0].status === suite.status.failed) f.window.stopController.abort();
  };
  await f.run();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.chapters[1].status, suite.status.pending);
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 0);
});

test('stop during a deferred-round cooldown preserves failure state without another request', async () => {
  const f = suite.fixture([{ id: 1, vip: true, frameTimeout: 'blank' }]);
  f.state.onSleep = () => { if (f.state.starts.length) f.window.stopController.abort(); };
  await f.run();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.chapters[0].status, suite.status.failed);
});

for (const status of [401, 403, 429]) test(`HTTP ${status} stops immediately with no deferred recovery`, async () => {
  const f = suite.fixture([{ id: 1, vip: false, requestError: status }, { id: 2, vip: true }]);
  await f.run();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 0);
});

test('all-selection revives stale catalogue locks before the selection filter', async () => {
  const start = source.indexOf('  async prepareChapters(book) {');
  const end = source.indexOf('  async initChapters(book,', start);
  const ctx = vm.createContext({
    document: { location: { hostname: 'www.qidian.com' } },
    main: { nW: suite.status }, unsafeWindow: {},
    GM_getValue: () => ({ filterType: 'all' }),
    loglevel_default: () => ({ debug() {}, info() {} }),
  });
  vm.runInContext('this.Rule = class {' + source.slice(start, end) + '}', ctx);
  const chapter = { isVIP: true, status: suite.status.aborted, chapterUrl: 'https://www.qidian.com/chapter/1/2', options: { qidianCatalogLocked: true } };
  const explicitSkip = { ...chapter, qidianSkipReason: 'unsubscribed' };
  const book = { chapters: [chapter, explicitSkip] };
  const rule = new ctx.Rule();
  await rule.prepareChapters(book);
  assert.equal(chapter.status, suite.status.pending);
  assert.equal(explicitSkip.status, suite.status.aborted);
  rule.selectChapters(book);
  assert.equal(book.chapters.length, 1);
  assert.equal(book.chapters[0], chapter);
});

test('range selection still excludes out-of-range chapters after catalogue candidates revive', async () => {
  const start = source.indexOf('  async prepareChapters(book) {');
  const end = source.indexOf('  async initChapters(book,', start);
  const ctx = vm.createContext({
    document: { location: { hostname: 'www.qidian.com' } }, main: { nW: suite.status },
    unsafeWindow: { chapterFilter: c => c.chapterNumber <= 2 },
    loglevel_default: () => ({ debug() {}, info() {} }),
  });
  vm.runInContext('this.Rule = class {' + source.slice(start, end) + '}', ctx);
  const book = { chapters: [1, 2, 3].map(chapterNumber => ({ chapterNumber, isVIP: true, status: 4, chapterUrl: `https://www.qidian.com/chapter/1/${chapterNumber}` })) };
  const rule = new ctx.Rule();
  await rule.prepareChapters(book); rule.selectChapters(book);
  assert.deepEqual(Array.from(book.chapters, c => c.chapterNumber), [1, 2]);
});

test('all-chapter preview includes catalogue-locked candidates and still honors actual filters', () => {
  const start = source.indexOf('    const filter = (chapter) => {', source.indexOf('const src_ui_ChapterList'));
  const end = source.indexOf('    const totalCount', start);
  assert(start > 0 && end > start);
  const ctx = vm.createContext({main:{nW:suite.status},activeFilter:{value:()=>true},filterSetting:{value:{filterType:'null'}}});
  vm.runInContext(source.slice(start,end)+'\nthis.filterChapter=filter;',ctx);
  const chapter={status:suite.status.aborted,isVIP:true,bookUrl:'https://www.qidian.com/book/1/',chapterNumber:20};
  assert.equal(ctx.filterChapter(chapter),true);
  assert.equal(ctx.filterChapter({...chapter,qidianSkipReason:'unsubscribed'}),false);
  assert.equal(ctx.filterChapter({...chapter,bookUrl:'https://example.test/book/1/'}),false);
  ctx.activeFilter.value=c=>c.chapterNumber<10;
  assert.equal(ctx.filterChapter(chapter),false);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack ?? error); }
  }
  console.log(`${tests.length - failed}/${tests.length} v32 completeness scheduler checks passed`);
  if (failed) process.exitCode = 1;
})();
