// Exercise the shipped scheduler, Chapter retry path, parser and saver.
// Only browser, OCR, storage, time and random-number boundaries are simulated.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
function suite(file, expression, exposeRule = false) {
  let code = fs.readFileSync(path.join(__dirname, file), 'utf8');
  const end = code.search(/^const tests\s*=\s*\[\];/m);
  assert(end > 0, file);
  code = code.slice(0, end);
  if (exposeRule) {
    const boundary = 'return {state,window,progress,ctx,chapters,book,saver,async run()';
    assert(code.includes(boundary), 'fixture return boundary');
    code = code.replace(boundary, 'return {rule,state,window,progress,ctx,chapters,book,saver,async run()');
  }
  return vm.runInNewContext(code + '\n(' + expression + ')',
    { require, __dirname, AbortController, URL, console });
}
const queue = suite('test-qidian-v19-resilience.cjs', '{fixture,status}', true);
const full = suite('test-qidian-v34-access-qa.cjs', '{fixture,drain,until}');
const tests = [];
const test = (name, run) => tests.push({ name, run });
const configs = count => Array.from({ length: count }, (_, index) =>
  ({ id: index + 1, vip: true, pageMs: 0, ocrMs: 0 }));
const events = f => Array.from(f.state.logs).filter(line => line.startsWith('[QidianDebug] '))
  .map(line => JSON.parse(line.slice(14)));
const pacing = f => events(f).filter(row => row.event === 'request_pacing');
const ids = f => Array.from(f.state.starts, row => row.id);
const modes = rows => rows.map(row => row.pacingMode);
function setup(input, draw = 0) {
  const f = queue.fixture(input);
  f.ctx.Math.random = () => draw;
  return f;
}
function rowFor(rows, id) {
  const row = rows.find(item => item.chapterId === String(id));
  assert(row, `missing pacing event for chapter ${id}`);
  return row;
}
function allSaved(f) {
  assert(f.chapters.every(chapter => chapter.status === queue.status.saved));
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.state.maxActive, 1, 'browser/OCR parsing stays serial');
  assert.equal(f.state.timers.size, 0, 'all chapter watchdogs are cleared');
}

test('the request-gap helper keeps its old default and accepts a separate fast minimum', () => {
  const f = setup([]), wait = f.ctx.qidianRemainingRequestWait;
  assert.equal(wait(5000, 1000, 2000), 9000);
  assert.equal(wait(5000, 1000, 2000, 5000), 4000);
  assert.equal(wait(15000, 1000, 2000, 5000), 14000);
  assert.equal(wait(5000, 1000, 31000, 5000), 0);
  assert.equal(wait(5000, null, 2000, 5000), 5000);
});

for (const [draw, expected] of [[0, 5000], [1, 15000], [0.6234, 11234]]) {
  test(`five clean VIP saves enable the sixth request at ${expected} ms with one RNG draw`, async () => {
    const f = setup(configs(8), draw);
    let draws = 0;
    f.ctx.Math.random = () => { draws++; return draw; };
    await f.run();
    const rows = pacing(f);
    assert.equal(rows.length, 8);
    assert.deepEqual(modes(rows), [...Array(5).fill('conservative'), ...Array(3).fill('stable-fast')]);
    assert.deepEqual(rows.slice(0, 5).map(row => row.stableSuccessCount), [0, 1, 2, 3, 4]);
    for (let index = 5; index < 8; index++) {
      assert.equal(rows[index].minimumGapMs, expected);
      assert.equal(rows[index].plannedDelayMs, expected);
      assert.equal(rows[index].waitMs, expected);
      assert.equal(f.state.starts[index].at - f.state.starts[index - 1].at, expected);
      assert.equal(rows[index].fastPacingSuspended, false);
    }
    assert.equal(draws, 8, 'one pacing sample per actual queue dispatch');
    allSaved(f);
  });
}

test('slow OCR consumes the entire fast gap without an extra idle wait', async () => {
  const f = setup(configs(7).map(cfg => ({ ...cfg, pageMs: 2500, ocrMs: 22000 })));
  await f.run();
  const row = rowFor(pacing(f), 6);
  assert.equal(row.pacingMode, 'stable-fast');
  assert.equal(row.waitMs, 0);
  assert.equal(row.minimumGapMs, 5000);
  assert.equal(f.state.starts[5].at - f.state.starts[4].at, 24500);
  allSaved(f);
});

test('short OCR time is subtracted from the fast request-start interval', async () => {
  const f = setup(configs(7).map(cfg => ({ ...cfg, pageMs: 1000, ocrMs: 1500 })));
  await f.run();
  assert.equal(rowFor(pacing(f), 6).waitMs, 2500);
  assert.equal(f.state.starts[5].at - f.state.starts[4].at, 5000);
  assert(f.state.waits.every(ms => ms > 0 && ms <= 1000));
  allSaved(f);
});

test('an internal retry during warm-up resets the clean count before fast mode can start', async () => {
  const input = configs(10); input[2].shortFirst = true;
  const f = setup(input); await f.run();
  const rows = pacing(f);
  assert.deepEqual(ids(f), [1, 2, 3, 3, 4, 5, 6, 7, 8, 9, 10]);
  assert.equal(rowFor(rows, 4).stableSuccessCount, 0);
  assert(rows.filter(row => Number(row.chapterId) <= 8).every(row => row.pacingMode === 'conservative'));
  assert.equal(rowFor(rows, 9).pacingMode, 'stable-fast');
  assert(rows.every(row => row.fastPacingSuspended === false));
  allSaved(f);
});

test('an internal retry during a fast request permanently returns this run to conservative pacing', async () => {
  const input = configs(14); input[5].shortFirst = true;
  const f = setup(input); await f.run();
  const rows = pacing(f);
  assert.equal(rowFor(rows, 6).pacingMode, 'stable-fast');
  assert.deepEqual(ids(f).slice(0, 8), [1, 2, 3, 4, 5, 6, 6, 7]);
  assert(rows.filter(row => Number(row.chapterId) >= 7).every(row =>
    row.pacingMode === 'conservative' && row.fastPacingSuspended));
  assert.equal(rowFor(rows, 7).stableSuccessCount, 0);
  assert.equal(f.state.starts[7].at - f.state.starts[6].at, 10000, 'gap follows the final internal retry start');
  assert(events(f).some(row => row.event === 'pacing_fallback'));
  allSaved(f);
});

test('a fast failed chapter cannot prevent later saves and both deferred passes remain conservative', async () => {
  const input = configs(13); input[5].glyphFail = true;
  const f = setup(input); await f.run();
  const rows = pacing(f), fastIndex = rows.findIndex(row => row.pacingMode === 'stable-fast');
  assert.equal(rows[fastIndex].chapterId, '6');
  assert(rows.slice(fastIndex + 1).every(row => row.pacingMode === 'conservative' && row.fastPacingSuspended));
  assert.deepEqual(ids(f), [...Array.from({ length: 13 }, (_, i) => i + 1), 6, 6]);
  assert.equal(f.chapters[5].status, queue.status.failed);
  assert(f.chapters.filter((_, index) => index !== 5).every(chapter => chapter.status === queue.status.saved));
  assert.equal(f.window.stopFlag.aborted, false);
  const report = f.validate().downloadReport;
  assert.equal(report.savedCount, 12); assert.equal(report.missing.length, 1);
  assert.equal(report.missing[0].title, '第6章');
});

for (const kind of ['placeholder', 'length-warning']) {
  test(`saved ${kind} content during fast mode suspends fast pacing while retaining and later repairing the body`, async () => {
    const f = setup(configs(13)), original = f.ctx.ocrContent;
    f.window.qidianTxtOnly = true;
    let changed = false, retained = null;
    f.ctx.ocrContent = async main => {
      const result = await original(main);
      if (main.id !== 6 || changed) return result;
      changed = true;
      if (kind === 'length-warning') result.contentText = '文'.repeat(800);
      else {
        const position = result.contentText.length - 1;
        result.contentText = result.contentText.slice(0, position) + '□';
        result.qidianGlyphTolerance = { schema: 1, placeholder: '□', mode: 'distinct', limit: 10,
          distinctCount: 1, occurrenceCount: 1, bodyDigest: f.ctx.qidianCheckpointDigest(result.contentText),
          glyphs: [{ sourceCodepoint: 'U+4E00', positions: [position], occurrences: 1 }] };
      }
      return result;
    };
    f.state.onSave = chapter => { if (chapter.chapterUrl.endsWith('/6') && !retained)
      retained = { body: chapter.contentText, rank: f.ctx.qidianChapterQualityRank(chapter) }; };
    await f.run();
    const rows = pacing(f), firstSix = rows.findIndex(row => row.chapterId === '6');
    assert.equal(rows[firstSix].pacingMode, 'stable-fast');
    assert(retained && retained.rank > 0, 'the original uncertain body was preserved before repair');
    assert(rows.slice(firstSix + 1).every(row => row.pacingMode === 'conservative' && row.fastPacingSuspended));
    assert.equal(f.ctx.qidianChapterQualityRank(f.chapters[5]), 0, 'deferred repair still improves the body');
    assert.equal(f.book.chapters.length, 13); assert.equal(f.progress.finishedChapterNumber, 13);
    allSaved(f);
  });
}

test('free/VIP transitions reset warm-up while preserving free chapter cadence', async () => {
  const input = configs(14); input[6].vip = false; input[7].vip = false;
  const f = setup(input); await f.run();
  const rows = pacing(f);
  assert.equal(rowFor(rows, 6).pacingMode, 'stable-fast');
  assert.equal(rowFor(rows, 7).pacingMode, 'conservative');
  assert.equal(rowFor(rows, 7).requestGapMs, 10000);
  assert.equal(rowFor(rows, 8).pacingMode, 'free');
  assert.equal(rowFor(rows, 8).requestGapMs, 250);
  assert.equal(rowFor(rows, 9).stableSuccessCount, 0);
  assert.equal(rowFor(rows, 9).requestGapMs, 10000);
  assert(rows.filter(row => Number(row.chapterId) >= 9 && Number(row.chapterId) <= 13)
    .every(row => row.pacingMode === 'conservative' && !row.fastPacingSuspended));
  assert.equal(rowFor(rows, 14).pacingMode, 'stable-fast');
  allSaved(f);
});

test('restored chapters do not count as live warm-up successes or issue requests', async () => {
  const f = setup(configs(11));
  f.book.qidianResumedCount = 5;
  for (const chapter of f.chapters.slice(0, 5)) {
    chapter.status = queue.status.saved; chapter.contentText = '正文'.repeat(1000);
    chapter.qidianSource = 'checkpoint'; chapter.qidianAttemptCount = 0;
  }
  await f.run();
  assert.deepEqual(ids(f), [6, 7, 8, 9, 10, 11]);
  assert.deepEqual(modes(pacing(f)), [...Array(5).fill('conservative'), 'stable-fast']);
  assert.equal(pacing(f)[0].stableSuccessCount, 0);
  allSaved(f);
});

for (const settings of [{ sleepTime: 9000 }, { maxSleepTime: 30000 }]) {
  test(`slower user settings disable fast mode: ${JSON.stringify(settings)}`, async () => {
    const f = setup(configs(10), 1); Object.assign(f.rule, settings);
    await f.run();
    assert(pacing(f).every(row => row.pacingMode === 'conservative'));
    assert(pacing(f).slice(2).every(row => row.minimumGapMs >= 20000));
    allSaved(f);
  });
}

test('the start of a deferred pass is conservative even when the preceding live chapter was fast', async () => {
  const input = configs(10); input[0].glyphFail = true;
  const f = setup(input); let released = false;
  f.state.onSave = chapter => { if (chapter.chapterUrl.endsWith('/10')) { input[0].glyphFail = false; released = true; } };
  await f.run();
  assert(released); assert.equal(pacing(f).at(-2).pacingMode, 'stable-fast');
  const last = pacing(f).at(-1);
  assert.equal(f.state.starts.at(-1).id, 1); assert.equal(last.pacingMode, 'conservative');
  assert.equal(last.stableSuccessCount, 0); assert.equal(last.fastPacingSuspended, false);
  assert.deepEqual(ids(f), [...Array.from({ length: 10 }, (_, index) => index + 1), 1]);
  allSaved(f);
});

test('Stop interrupts a fast countdown before starting the next chapter', async () => {
  const f = setup(configs(8), 1);
  f.state.onSleep = () => {
    if (f.state.starts.length === 5) f.window.stopController.abort();
  };
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 5]);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.equal(f.state.waits.at(-1), 1000);
  assert(f.chapters.slice(0, 5).every(chapter => chapter.status === queue.status.saved));
  assert.equal(f.chapters[5].status, queue.status.pending);
  assert.equal(f.state.timers.size, 0);
});

test('manual access recovery during a fast request suspends fast mode and preserves ordered full export', async () => {
  const input = configs(13); input[5].accessTitle = '安全验证';
  const f = full.fixture(input); f.ctx.Math.random = () => 0;
  const task = f.run();
  await full.until(() => f.window.qidianAccessRecoveryGate); await full.drain();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 5, 6]);
  assert.equal(pacing(f).at(-1).pacingMode, 'stable-fast');
  input[5].accessTitle = null;
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  await task;
  const rows = pacing(f);
  assert(rows.slice(6).every(row => row.pacingMode === 'conservative' && row.fastPacingSuspended));
  assert.deepEqual(ids(f), [1, 2, 3, 4, 5, 6, 6, 7, 8, 9, 10, 11, 12, 13]);
  assert.equal(f.state.outputs.length, 1);
  assert.deepEqual(f.state.outputs[0].map(chapter => chapter.id), Array.from({ length: 13 }, (_, index) => index + 1));
  allSaved(f);
});

test('an access gate during a fast countdown discards the fast plan before the next request', async () => {
  const f = full.fixture(configs(13)); f.ctx.Math.random = () => 0;
  let challenged = false;
  f.state.onSleep = () => {
    if (f.state.starts.length !== 5 || challenged) return;
    challenged = true;
    f.ctx.document.title = '安全验证';
    f.tick();
  };
  const task = f.run();
  await full.until(() => f.window.qidianAccessRecoveryGate); await full.drain();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 5]);
  const confirmedAt = f.state.now;
  f.ctx.document.title = '章节目录';
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  await task;
  const rows = pacing(f);
  assert(rows.slice(5).every(row => row.pacingMode === 'conservative' && row.fastPacingSuspended));
  assert.equal(rows[5].stableSuccessCount, 0);
  assert.equal(rows[5].minimumGapMs, 10000);
  assert(f.state.starts[5].at >= confirmedAt + 55000, 'manual Continue cooling is honored before dispatch');
  assert.deepEqual(ids(f), Array.from({ length: 13 }, (_, index) => index + 1));
  assert.equal(f.state.outputs.length, 1);
  assert.deepEqual(f.state.outputs[0].map(chapter => chapter.id), Array.from({ length: 13 }, (_, index) => index + 1));
  allSaved(f);
});

test('a fresh invocation starts a new conservative warm-up and can accelerate after an earlier run fell back', async () => {
  const input = configs(12); input[5].shortFirst = true;
  const f = setup(input); await f.run();
  assert.equal(pacing(f).at(-1).fastPacingSuspended, true);
  delete input[5].shortFirst;
  const priorEvents = pacing(f).length;
  for (const chapter of f.chapters) { chapter.status = queue.status.pending; chapter.retryTime = 0; }
  await f.run();
  const rows = pacing(f).slice(priorEvents);
  assert.deepEqual(modes(rows.slice(0, 6)), [...Array(5).fill('conservative'), 'stable-fast']);
  assert(rows.every(row => row.fastPacingSuspended === false));
  allSaved(f);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack); }
  }
  console.log(`${tests.length - failed}/${tests.length} adaptive pacing checks passed`);
  if (failed) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
