const { spawnSync } = require('node:child_process');
const { readFileSync } = require('node:fs');
const { createHash } = require('node:crypto');
process.chdir(__dirname);
const script = 'novel-downloader-qidian-range.user.js';
const commands = [
  ['--check', script],
  ['--check', 'qidian-reader-diagnostics.user.js'],
  ['test-qidian-rare-glyph-recovery.cjs'],
  ['audit-scheduler-tests.cjs'],
  ['test-qidian-regression.cjs'],
  ['test-qidian-ocr-audit.cjs'],
  ['test-qidian-export-audit.cjs'],
  ['test-qidian-progress-eta.cjs'],
  ['test-qidian-v15-regression.cjs'],
  ['test-qidian-v16-regression.cjs'],
  ['test-qidian-v17-routing.cjs'],
  ['test-qidian-v18-hash.cjs'],
  ['test-qidian-v18-frame.cjs'],
  ['test-qidian-v19-export.cjs'],
  ['test-qidian-v19-resilience.cjs'],
  ['test-qidian-v23-checkpoint.cjs'],
  ['test-qidian-v23-resume-integration.cjs'],
  ['test-qidian-v23-diagnostics.cjs'],
  ['test-qidian-v24-free-accuracy.cjs'],
  ['test-qidian-v24-body-checkpoints.cjs'],
  ['test-qidian-v24-failure-isolation.cjs'],
  ['test-qidian-v24-parser-accuracy.cjs'],
  ['test-qidian-v25-debug-flow.cjs'],
  ['test-qidian-v25-log-export.cjs'],
  ['test-qidian-v25-ocr-metrics.cjs'],
  ['test-qidian-v26-subscription.cjs'],
  ['test-qidian-v26-export-flow.cjs'],
  ['test-qidian-v27-reader-diagnostics.cjs'],
  ['test-qidian-v27-catalog-skip.cjs'],
  ['test-qidian-v28-progress-display.cjs'],
  ['test-qidian-v29-batch-regions.cjs'],
  ['test-qidian-v29-title-format.cjs'],
  ['test-qidian-v29-neighbor-recovery.cjs'],
  ['test-qidian-v30-frame-metadata.cjs'],
  ['test-qidian-v31-readiness-scope.cjs'],
  ['test-qidian-v32-completeness-scheduler.cjs'],
  ['test-qidian-v32-reader-recovery.cjs'],
  ['test-qidian-v32-large-diagnostics.cjs'],
  ['test-qidian-v33-access-monitor.cjs'],
  ['test-qidian-v33-safety-stop.cjs'],
  ['test-qidian-v33-progress.cjs'],
  ['test-qidian-v34-continuation.cjs'],
  ['test-qidian-v34-watchdog.cjs'],
  ['test-qidian-v34-access-recovery.cjs'],
  ['test-qidian-v34-access-qa.cjs'],
  ['test-qidian-v34-page-recovery.cjs'],
  ['test-qidian-v34-deferred-repair.cjs'],
  ['test-qidian-v34-glyph-tolerance.cjs'],
  ['test-qidian-v34-readiness.cjs'],
  ['test-qidian-v34-random-waits.cjs'],
  ['test-qidian-v34-length-retention.cjs'],
  ['test-qidian-v34-length-import.cjs'],
  ['test-qidian-v34-txt-empty-author.cjs'],
  ['test-qidian-v34-live-body-refresh.cjs'],
  ['test-qidian-v35-adaptive-pacing.cjs'],
  ['test-qidian-v35-glyph-cache.cjs'],
  ['test-qidian-v35-performance-summary.cjs'],
  ['test-qidian-v35-wait-deadlines.cjs'],
];
let failed = 0;
console.log(`Node ${process.version}`);
console.log(`Script SHA256 ${createHash('sha256').update(readFileSync(script)).digest('hex')}`);
for (const args of commands) {
  console.log(`\n$ node ${args.join(' ')}`);
  const result = spawnSync(process.execPath, args, { stdio: 'inherit', timeout: 60000 });
  if (result.error) console.error(result.error.message);
  if (result.status !== 0 || result.error) failed++;
  console.log(`exit ${result.status}`);
}
const syntaxCount = commands.filter(args => args[0] === '--check').length;
console.log(`\n${commands.length-failed}/${commands.length} gates passed (${syntaxCount} syntax checks + ${commands.length-syntaxCount} regression files).`);
console.log('Real browser font rasterization and live Qidian downloads are not part of these gates.');
if (failed) process.exitCode = 1;
