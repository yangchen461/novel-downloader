// Run the shipped random helper, Chapter retries, queue and manual Continue.
// Only the clock, browser/network/OCR boundary and prescribed RNG are fixtures.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
function suite(file, expression) {
  const code = fs.readFileSync(path.join(__dirname,file),'utf8');
  const end = code.search(/^const tests\s*=\s*\[\];/m);
  assert(end>0,file);
  return vm.runInNewContext(code.slice(0,end)+'\n('+expression+')',
    {require,__dirname,AbortController,URL,console});
}
const queue = suite('test-qidian-v19-resilience.cjs','{fixture,status}');
const full = suite('test-qidian-v34-access-qa.cjs','{fixture,drain,until}');
const tests=[];
const test=(name,run)=>tests.push({name,run});
const ids=f=>Array.from(f.state.starts,row=>row.id);
const events=f=>Array.from(f.state.logs).filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14)));
const sum=values=>values.reduce((total,value)=>total+value,0);
const reasons={retry:'当前章读取失败，等待后重试',page:'当前章页面超时，等待后重试',
  failure:'上一章页面异常，等待后检查下一章',deferred:'准备补试缺章、缺字及字数待核验章节',
  manual:'已确认验证完成，冷却后继续剩余章节'};
function observe(f,draws=[],normalDraw=0.5) {
  const original=f.ctx.qidianRandomizedWaitMs;
  assert.equal(typeof original,'function','the production helper must exist');
  const state={plans:[],sleeps:[],progress:[],randomCalls:0,inside:false};
  f.ctx.Math.random=()=>{state.randomCalls++;return state.inside ? draws[state.plans.length]??0.5 : normalDraw;};
  f.ctx.qidianRandomizedWaitMs=baseMs=>{
    const before=state.randomCalls;state.inside=true;
    let waitMs;
    try{waitMs=original(baseMs);}finally{state.inside=false;}
    assert.equal(state.randomCalls-before,1,'each wait draws exactly once');
    state.plans.push({baseMs,waitMs,at:f.state.now});return waitMs;
  };
  f.window.qidianProgressSink=next=>state.progress.push({...next});
  const sleep=f.ctx.misc.yy;
  const recorded=async ms=>{
    const row={ms,at:f.state.now,reason:f.window.qidianProgressState?.reason};
    state.sleeps.push(row);await sleep(ms);row.end=f.state.now;
  };
  f.ctx.misc.yy=recorded;f.ctx._lib_misc__WEBPACK_IMPORTED_MODULE_0__.yy=recorded;
  return Object.assign(f,{observed:state});
}
function exactWait(f,plan,reason) {
  const rows=f.observed.sleeps.filter(row=>row.reason===reason && row.at>=plan.at && row.at<plan.at+plan.waitMs);
  assert.equal(sum(rows.map(row=>row.ms)),plan.waitMs,'actual countdown equals the sampled diagnostic wait');
  assert(rows.every(row=>row.ms>0 && row.ms<=1000),'countdown sleeps stay promptly stoppable');
  assert.equal(rows.at(-1)?.end,plan.at+plan.waitMs,'the final fractional slice never oversleeps');
  assert(f.observed.progress.some(row=>row.reason===reason && row.updatedAt===plan.at && row.waitUntil===plan.at+plan.waitMs),
    'UI countdown uses the same sampled deadline');
}

test('every requested baseline spans minus/plus5seconds, rounds milliseconds and clips negative waits with one draw',()=>{
  const f=queue.fixture([]);let calls=0,draw=0;
  f.ctx.Math.random=()=>{calls++;return draw;};
  for(const base of [10000,20000,40000,60000,90000,120000]){
    for(const [random,expected] of [[0,base-5000],[0.5,base],[1,base+5000],[0.51234,base+123]]){
      draw=random;const before=calls;assert.equal(f.ctx.qidianRandomizedWaitMs(base),expected);assert.equal(calls-before,1);
    }
  }
  draw=0;assert.equal(f.ctx.qidianRandomizedWaitMs(3000),0);
  draw=0.6234;assert.equal(f.ctx.qidianRandomizedWaitMs(10000),11234);
});

for(const [draw,expected] of [[0,5000],[1,15000],[0.6234,11234]])
test(`a real ordinary Chapter retry waits exactly${expected}ms and logs the same value`,async()=>{
  const f=observe(queue.fixture([{id:1,vip:true,shortFirst:true,pageMs:0,ocrMs:0}]),[draw]);
  await f.chapters[0].init();
  const plan=f.observed.plans[0],row=events(f).find(row=>row.event==='retry_scheduled');
  assert.deepEqual(ids(f),[1,1]);assert.equal(f.observed.plans.length,1);
  assert.equal(plan.baseMs,10000);assert.equal(plan.waitMs,expected);
  assert.equal(row.baseWaitMs,10000);assert.equal(row.waitMs,expected);
  assert.equal(f.state.starts[1].at-f.state.starts[0].at,expected);exactWait(f,plan,reasons.retry);
  assert.equal(f.chapters[0].status,queue.status.finished);assert.equal(f.state.timers.size,0);
});

for(const [draw,expected] of [[0,85000],[1,95000],[0.51234,90123]])
test(`a real unknown-page Chapter retry waits exactly${expected}ms after its20second timeout`,async()=>{
  const f=observe(queue.fixture([{id:1,vip:true,frameTimeout:'unknown',frameTimeoutFirst:true,pageMs:0,ocrMs:0}]),[draw]);
  await f.chapters[0].init();
  const plan=f.observed.plans[0],row=events(f).find(row=>row.event==='retry_scheduled');
  assert.deepEqual(ids(f),[1,1]);assert.equal(f.observed.plans.length,1);
  assert.equal(plan.baseMs,90000);assert.equal(plan.waitMs,expected);
  assert.equal(row.baseWaitMs,90000);assert.equal(row.waitMs,expected);
  assert.equal(f.state.starts[1].at-f.state.starts[0].at,20000+expected);exactWait(f,plan,reasons.page);
  assert.equal(f.chapters[0].status,queue.status.finished);assert.equal(f.state.timers.size,0);
});

test('real consecutive-page cooldowns independently sample10/20/40/60seconds and honor the sampled gaps',async()=>{
  const configs=Array.from({length:4},(_,index)=>({id:index+1,vip:false,requestError:500,pageMs:0}));
  configs.push({id:5,vip:false,pageMs:0});
  const f=observe(queue.fixture(configs),[0,1,0.25,0.6234]);f.window.qidianAdaptivePacingEnabled=true;
  f.state.onSave=chapter=>{if(chapter.chapterUrl.endsWith('/5'))for(const cfg of configs)delete cfg.requestError;};
  await f.run();
  const rows=events(f).filter(row=>row.event==='page_failure_cooldown' && row.recoveryRound===0);
  assert.deepEqual(rows.map(row=>row.baseWaitMs),[10000,20000,40000,60000]);
  assert.deepEqual(rows.map(row=>row.waitMs),[5000,25000,37500,61234]);
  for(let index=0;index<4;index++){
    const plan=f.observed.plans[index];assert.equal(plan.waitMs,rows[index].waitMs);
    assert.equal(f.state.starts[index+1].at-f.state.starts[index].at,plan.waitMs);exactWait(f,plan,reasons.failure);
  }
  assert.deepEqual(ids(f),[1,2,3,4,5,1,2,3,4]);assert(f.chapters.every(chapter=>chapter.status===queue.status.saved));
  assert.equal(f.window.stopFlag.aborted,false);
});

test('both real deferred rounds sample once and sleep the exact55–65/115–125second values including final slices',async()=>{
  const f=observe(queue.fixture([{id:1,vip:true,glyphFail:true,pageMs:0,ocrMs:0},{id:2,vip:true,pageMs:0,ocrMs:0}]),[0.0123,0.9876]);
  await f.run();
  const rows=events(f).filter(row=>row.event==='recovery_round_start');
  assert.deepEqual(ids(f),[1,2,1,1]);assert.equal(f.observed.plans.length,2);
  assert.deepEqual(rows.map(row=>row.baseWaitMs),[60000,120000]);assert.deepEqual(rows.map(row=>row.waitMs),[55123,124876]);
  for(let index=0;index<2;index++){
    const plan=f.observed.plans[index];assert.equal(plan.waitMs,rows[index].waitMs);exactWait(f,plan,reasons.deferred);
    assert.equal(f.state.starts[index+2].at,plan.at+plan.waitMs);
  }
  assert.equal(f.chapters[1].status,queue.status.saved);assert.equal(f.window.stopFlag.aborted,false);
});

for(const [draw,expected] of [[0,55000],[1,65000],[0.6234,61234]])
test(`manual Continue selects${expected}ms once and uses the same deadline for resumed requests and diagnostics`,async()=>{
  const configs=[{id:1,vip:true,accessTitle:'安全验证',pageMs:0,ocrMs:0},{id:2,vip:true,pageMs:0,ocrMs:0}];
  const f=observe(full.fixture(configs),[draw]),task=f.run();
  await full.until(()=>f.window.qidianAccessRecoveryGate);await full.drain();
  const gate=f.window.qidianAccessRecoveryGate,confirmedAt=f.state.now;
  assert.equal(f.observed.plans.length,0);assert.deepEqual(ids(f),[1]);
  configs[0].accessTitle=null;assert.equal(gate.continue(),true);
  assert.equal(f.window.qidianAccessResumeAfter,confirmedAt+expected);
  assert.equal(gate.continue(),false,'a repeated click cannot redraw or extend this deadline');
  await task;
  const plan=f.observed.plans[0],rows=events(f);
  assert.equal(f.observed.plans.length,1);assert.equal(plan.baseMs,60000);assert.equal(plan.waitMs,expected);
  const continued=rows.find(row=>row.event==='access_manual_continue'),retry=rows.find(row=>row.event==='access_chapter_retry');
  assert.equal(continued.baseWaitMs,60000);assert.equal(continued.waitMs,expected);assert.equal(retry.waitMs,expected);
  assert.equal(f.state.starts[1].at,confirmedAt+expected);exactWait(f,plan,reasons.manual);
  assert.deepEqual(ids(f),[1,1,2]);assert.equal(f.state.outputs.length,1);
  assert.deepEqual(f.state.outputs[0].map(chapter=>chapter.id),[1,2]);assert.equal(f.state.timers.size,0);
});

for(const page of [false,true])test(`Stop interrupts a sampled${page?'90':'10'}second Chapter retry before another request`,async()=>{
  const config=page ? {frameTimeout:'unknown'} : {shortFirst:true};
  const f=observe(queue.fixture([{id:1,vip:true,pageMs:0,ocrMs:0,...config}]),[1]);
  f.state.onSleep=()=>f.window.stopController.abort();await f.chapters[0].init();
  assert.deepEqual(ids(f),[1]);assert.equal(f.observed.plans.length,1);assert.equal(sum(f.state.waits),1000);
  assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[0].status,queue.status.aborted);assert.equal(f.state.timers.size,0);
});

for(const kind of ['failure','deferred'])test(`Stop interrupts a sampled scheduler${kind} cooldown before another chapter request`,async()=>{
  const configs=kind==='failure'
    ? [{id:1,vip:false,requestError:500,pageMs:0},{id:2,vip:false,pageMs:0}]
    : [{id:1,vip:true,glyphFail:true,pageMs:0,ocrMs:0},{id:2,vip:true,pageMs:0,ocrMs:0}];
  const f=observe(queue.fixture(configs),[1]);
  f.state.onSleep=()=>{if(f.window.qidianProgressState?.reason===reasons[kind])f.window.stopController.abort();};
  await f.run();
  assert.deepEqual(ids(f),kind==='failure'?[1]:[1,2]);assert.equal(f.observed.plans.length,1);
  const steps=f.observed.sleeps.filter(row=>row.reason===reasons[kind]);assert.equal(sum(steps.map(row=>row.ms)),1000);
  assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.state.timers.size,0);
  if(kind==='deferred')assert.equal(f.chapters[1].status,queue.status.saved);
});

test('Stop during randomized manual-resume cooling exports retained chapters and never retries or reaches a later chapter',async()=>{
  const configs=[{id:1,vip:true,pageMs:0,ocrMs:0},{id:2,vip:true,accessTitle:'安全验证',pageMs:0,ocrMs:0},{id:3,vip:true,pageMs:0,ocrMs:0}];
  const f=observe(full.fixture(configs),[1]),task=f.run();
  await full.until(()=>f.window.qidianAccessRecoveryGate);await full.drain();
  f.state.onSleep=()=>{if(f.window.qidianProgressState?.reason===reasons.manual)f.window.stopController.abort();};
  configs[1].accessTitle=null;assert.equal(f.window.qidianAccessRecoveryGate.continue(),true);await task;
  assert.deepEqual(ids(f),[1,2]);assert.equal(f.observed.plans.length,1);assert.equal(f.observed.plans[0].waitMs,65000);
  assert.equal(sum(f.observed.sleeps.filter(row=>row.reason===reasons.manual).map(row=>row.ms)),1000);
  assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.state.outputs.length,1);
  assert.deepEqual(f.state.outputs[0].map(chapter=>chapter.id),[1]);assert.equal(f.state.timers.size,0);
});

test('ordinary VIP request gaps and the upstream free cadence retain their original RNG and never draw cooldown jitter',async()=>{
  for(const normalDraw of [0,0.5,1]){
    const vip=observe(queue.fixture(Array.from({length:3},(_,index)=>({id:index+1,vip:true,pageMs:0,ocrMs:0}))),[],normalDraw);
    await vip.run();assert.equal(vip.observed.plans.length,0);
    assert.equal(vip.state.starts[1].at-vip.state.starts[0].at,normalDraw===0?10000:normalDraw===0.5?12000:16000);
    assert.equal(vip.state.starts[2].at-vip.state.starts[1].at,10000+normalDraw*10000);
    const free=observe(queue.fixture(Array.from({length:6},(_,index)=>({id:index+1,vip:false,pageMs:0}))),[],normalDraw);
    await free.run();assert.equal(free.observed.plans.length,0);
    assert.deepEqual(Array.from(free.state.starts).slice(1).map((row,index)=>row.at-free.state.starts[index].at),
      [50,100,150,200,250].map(base=>base+Math.round(normalDraw*base)));
  }
});

(async()=>{let failed=0;for(const {name,run} of tests){try{await run();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,'\n',error.stack);}}console.log(`${tests.length-failed}/${tests.length} randomized wait checks passed`);if(failed)process.exitCode=1;})().catch(error=>{console.error(error);process.exitCode=1;});
