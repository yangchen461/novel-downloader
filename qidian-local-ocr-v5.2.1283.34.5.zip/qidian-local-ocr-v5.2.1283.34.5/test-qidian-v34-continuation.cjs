// Execute the shipped parser and scheduler using deterministic browser/OCR I/O.
// No network requests, credentials or source novel text are used.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const directory = path.resolve(process.argv[2] || __dirname);
const fixtureSource = fs.readFileSync(path.join(directory, 'test-qidian-v19-resilience.cjs'), 'utf8');
const suite = vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('const tests=[];')) + '\n({fixture,status})',
  { require, __dirname: directory, AbortController, URL, console });
const tests = [];
const test = (name, run) => tests.push({ name, run });
const ids = f => Array.from(f.state.starts, row => row.id);
const events = f => Array.from(f.state.logs).filter(line => line.startsWith('[QidianDebug] '))
  .map(line => JSON.parse(line.slice(14)));

test('three consecutive unknown blank pages cannot block a later good chapter; only missing chapters get two bounded passes', async () => {
  const f = suite.fixture([
    { id: 1, vip: true, frameTimeout: 'blank' },
    { id: 2, vip: true, frameTimeout: 'blank' },
    { id: 3, vip: true, frameTimeout: 'blank' },
    { id: 4, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 1, 2, 3, 1, 2, 3]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert(!f.window.qidianPauseReason);
  assert.equal(f.chapters[3].status, suite.status.saved);
  assert.equal(f.chapters[3].qidianAttemptCount, 1);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第4章']);
  assert.deepEqual(Array.from(f.chapters.slice(0, 3), chapter => chapter.qidianAttemptCount), [3, 3, 3]);
  assert(f.chapters.slice(0, 3).every(chapter => chapter.status === suite.status.failed &&
    chapter.qidianFailureKind === 'page' && chapter.qidianSkipReason !== 'unsubscribed' && !chapter.contentText));
  const waits = events(f).filter(row => row.event === 'page_failure_cooldown');
  assert.equal(waits.length, 9);
  assert(waits.every(row => row.baseWaitMs === 10000 && row.waitMs === 5000 && row.taskPaused === false),'RNG=0 samples the 5s lower bound without pausing the task');
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 2);
  assert.equal(events(f).filter(row => row.event === 'page_failure_pause').length, 0);
  const report = f.validate().downloadReport;
  assert.equal(report.savedCount, 1);
  assert.equal(report.skippedCount, 0);
  assert.equal(report.missing.length, 3);
  assert(report.missing.every(chapter => !/尚未处理/.test(chapter.reason)));
});

test('three consecutive temporary blanks recover after the first pass without re-requesting a saved chapter', async () => {
  const f = suite.fixture([
    { id: 1, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 2, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 3, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true },
    { id: 4, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 1, 2, 3]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.progress.finishedChapterNumber, 4);
  assert(f.chapters.every(chapter => chapter.status === suite.status.saved));
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 1);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第4章', '第1章', '第2章', '第3章']);
});

test('consecutive ordinary frame timeouts retain bounded internal retries and still reach later good chapters', async () => {
  const f = suite.fixture([
    { id: 1, vip: true, frameTimeout: 'unknown' },
    { id: 2, vip: true, frameTimeout: 'unknown' },
    { id: 3, vip: true, frameTimeout: 'unknown' },
    { id: 4, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f).slice(0, 7), [1, 1, 2, 2, 3, 3, 4]);
  assert.equal(ids(f).length, 19);
  assert.deepEqual(Array.from(f.chapters, chapter => chapter.qidianAttemptCount), [6, 6, 6, 1]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert.equal(f.chapters[3].status, suite.status.saved);
  assert.equal(f.progress.finishedChapterNumber, 1);
  assert.equal(f.progress.qidianSkippedChapterNumber, 0);
  assert(f.chapters.slice(0, 3).every(chapter => chapter.qidianFailureKind === 'page' && !chapter.contentText));
  assert(events(f).filter(row => row.event === 'page_failure_cooldown').every(row => row.baseWaitMs === 10000 && row.waitMs === 5000));
});

test('explicit verification after ordinary failures still pauses immediately and never launches recovery', async () => {
  const f = suite.fixture([
    { id: 1, vip: true },
    { id: 2, vip: true, frameTimeout: 'blank' },
    { id: 3, vip: true, frameTimeout: 'blank' },
    { id: 4, vip: true, frameTimeout: 'blank' },
    { id: 5, vip: true, accessTitle: '安全验证' },
    { id: 6, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 3, 4, 5]);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.match(f.window.qidianPauseReason, /验证/);
  assert.equal(f.chapters[0].status, suite.status.saved);
  assert.equal(f.chapters[4].qidianFailureKind, 'access');
  assert.equal(f.chapters[5].status, suite.status.pending);
  assert.equal(events(f).filter(row => row.event === 'recovery_round_start').length, 0);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第1章']);
});

test('an ordinary cross-origin SecurityError stays a chapter failure without being inferred as a global access block', async () => {
  const f = suite.fixture([
    { id: 1, vip: true, requestError: 'Blocked a frame with origin from accessing a cross-origin frame', requestErrorName: 'SecurityError' },
    { id: 2, vip: true },
  ]);
  await f.run();
  assert.deepEqual(ids(f), [1, 2, 1, 1]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert(!f.window.qidianPauseReason);
  assert.equal(f.chapters[0].status, suite.status.failed);
  assert.equal(f.chapters[0].qidianFailureKind, 'page');
  assert.notEqual(f.chapters[0].qidianSkipReason, 'unsubscribed');
  assert.equal(f.chapters[1].status, suite.status.saved);
  assert.deepEqual(Array.from(f.state.saveCalls), ['第2章']);
});

test('a later task restores successful checkpoints before and after consecutive misses and requests only missing chapters', async () => {
  const checkpointSource = fs.readFileSync(path.join(directory, 'test-qidian-v27-catalog-skip.cjs'), 'utf8');
  const checkpointSuite = vm.runInNewContext(checkpointSource.slice(0, checkpointSource.indexOf('const tests=[];')) + '\n({fixture,statuses})',
    { require, __dirname: directory, AbortController, URL, console, TextEncoder, TextDecoder, structuredClone, Blob });
  const storage = new Map();
  const first = checkpointSuite.fixture([
    { id: 1 }, { id: 2, blank: true }, { id: 3, blank: true }, { id: 4, blank: true }, { id: 5 },
  ], { storage });
  await first.run();
  assert.equal(first.window.stopFlag.aborted, false);
  assert.deepEqual(Array.from(first.state.requests, row => row.id), [1, 2, 3, 4, 5, 2, 3, 4, 2, 3, 4]);
  assert.deepEqual(Array.from(first.state.saved), [1, 5]);
  assert.deepEqual(Array.from(storage.values()).filter(value => value?.chapterId).map(value => value.chapterId).sort(), ['1', '5']);
  const resumed = checkpointSuite.fixture([{ id: 1 }, { id: 2 }, { id: 3 }, { id: 4 }, { id: 5 }], { storage });
  await resumed.run();
  assert.deepEqual(Array.from(resumed.state.requests, row => row.id), [2, 3, 4]);
  assert.equal(resumed.book.qidianResumedCount, 2);
  assert.equal(resumed.progress.finishedChapterNumber, 5);
  assert(resumed.chapters.every(chapter => chapter.status === checkpointSuite.statuses.saved));
  assert.equal(resumed.chapters[0].contentText, first.chapters[0].contentText);
  assert.equal(resumed.chapters[4].contentText, first.chapters[4].contentText);
  assert.deepEqual(Array.from(resumed.state.saved), [2, 3, 4]);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack ?? error); }
  }
  console.log(`${tests.length - failed}/${tests.length} v34 continuation checks passed`);
  if (failed) process.exitCode = 1;
})();
