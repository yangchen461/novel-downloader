// The shipped loglevel wrapper and export function, using only synthetic logs.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname,'novel-downloader-qidian-range.user.js'),'utf8');
const helperStart=src.indexOf('// Bounded local debug diagnostics.');
assert(helperStart>=0, 'sanitizer must be shipped in the actual script');
const helper=src.slice(helperStart,src.indexOf('// End bounded local debug diagnostics.',helperStart));
const moduleStart=src.indexOf('/***/ "./src/log.ts"');
const start=src.indexOf('if (_setting__WEBPACK_IMPORTED_MODULE_2__',moduleStart);
const end=src.indexOf('\n\n\n/***/ },',start);
assert(moduleStart>=0&&start>moduleStart&&end>start);
const moduleCode=src.slice(start,end);
function fixture(host='www.qidian.com', failSave=false, failConsole=false) {
  const calls=[], saves=[], window={qidianDebugRun:{id:'fixture-run',startedAt:1000},qidianPauseReason:'fixture pause'};
  const logger={level:'trace',methodFactory:(method)=> (...args)=>{calls.push({method,args});if(failConsole)throw new Error('console failure');},
    setLevel(level){this.level=level;for(const method of ['trace','debug','info','warn','error'])this[method]=this.methodFactory(method,level,'fixture');},
    getLevel(){return this.level;}};
  const context=vm.createContext({Error,URL,WeakSet,Set,Blob,Date,console,window,document:{location:{hostname:host}},
    _setting__WEBPACK_IMPORTED_MODULE_2__:{Nw:{value:true}},loglevel__WEBPACK_IMPORTED_MODULE_1___default:()=>logger,
    file_saver__WEBPACK_IMPORTED_MODULE_0__:{saveAs(blob,name){if(failSave)throw new Error('save failed token=save-secret');saves.push({blob,name});}},
    qidianRunSummary:()=>({runId:window.qidianDebugRun.id,selected:3,saved:2,failed:1,pauseReason:window.qidianPauseReason}),
    qidianDebugEvent(logger,event,data){logger.info('[QidianDebug] '+JSON.stringify({schema:2,event,runId:window.qidianDebugRun.id,elapsedMs:200,...data}));}});
  vm.runInContext(helper+moduleCode+'\nthis.exportLog=saveLogTextToFile;this.getLog=getLogText;this.sanitize=qidianDebugSanitize;this.safeError=qidianDebugSafeError;',context);
  return {context,logger,calls,saves,window};
}
const tests=[]; const test=(name,fn)=>tests.push({name,fn});
test('redacts nested credentials, HTTP request data, body and DOM content in both destinations',()=>{
  const f=fixture();f.logger.warn('problem',{status:403,bodyTextLength:2000,contentPresent:true,
    cookie:'cookie-secret',headers:{Authorization:'auth-secret'},request:{data:'request-secret'},
    options:{password:'password-secret'},response:{body:'body-secret'},quality:{actualChars:2222,complete:false,reason:'below_expected_length'},
    contentText:'正文-secret',frameState:{readyState:'complete',bodyTextLength:2200}});
  const output=f.getLog?.()??f.context.getLog();
  for(const secret of ['cookie-secret','auth-secret','request-secret','password-secret','body-secret','正文-secret']){
    assert(!output.includes(secret));assert(!JSON.stringify(f.calls).includes(secret));
  }
  assert(output.includes('2222'));assert(output.includes('below_expected_length'));assert(output.includes('2200'));assert(output.includes('complete'));
});
test('retains every argument and readable error separation',()=>{
  const f=fixture();const error=new Error('parser failure');error.stack='Error: parser failure\n  at fixture (https://reader.qidian.com/a?token=secret#secret:2:1)';
  f.logger.error('prefix',error,{stage:'cleanup',durationMs:10});
  assert.equal(f.calls.at(-1).args.length,3);const output=f.context.getLog();
  assert(output.includes('prefix\nError\nparser failure\nError: parser failure\n'));
  assert(output.includes('durationMs'));assert(!output.includes('?token'));assert(!output.includes('#secret'));
});
test('URL query, fragments and user credentials disappear from string and objects',()=>{
  const f=fixture();f.logger.info('fetch https://reader:credential@www.qidian.com/chapter/1/2/?token=query-secret#fragment-secret',
    {url:'https://a:b@www.qidian.com/chapter/1/2/?token=query-secret#fragment-secret'});
  assert(f.context.getLog().includes('https://www.qidian.com/chapter/1/2/'));
  for(const secret of ['credential','query-secret','fragment-secret','a:b@'])assert(!f.context.getLog().includes(secret));
});
test('prefixed structured events and ordinary JSON settings are redacted recursively',()=>{
  const f=fixture();f.logger.info('[QidianDebug] '+JSON.stringify({schema:2,event:'fixture',reason:'failed',token:'event-secret',body:'body-secret'}));
  f.logger.info(JSON.stringify({token:'settings-secret',stage:'fixture'}));
  assert(!f.context.getLog().includes('event-secret'));assert(!f.context.getLog().includes('body-secret'));assert(!f.context.getLog().includes('settings-secret'));
  assert(f.context.getLog().includes('"event":"fixture"'));assert(f.context.getLog().includes('"stage":"fixture"'));
});
test('embedded settings JSON and plain credentials are redacted',()=>{
  const f=fixture();f.logger.info('[Init] settings '+JSON.stringify({password:'embedded-password',token:'embedded-token'})+' cookie=cookie-value');
  for(const secret of ['embedded-password','embedded-token','cookie-value'])assert(!f.context.getLog().includes(secret));
});
test('circular objects and throwing getters cannot recurse or interrupt chapter work',()=>{
  const f=fixture();const item={stage:'cleanup'};item.self=item;Object.defineProperty(item,'fault',{enumerable:true,get(){throw new Error('getter secret');}});
  assert.doesNotThrow(()=>f.logger.error('fixture error',item));assert.equal(f.calls.length,1);
  assert(f.context.getLog().includes('[circular]'));assert(f.context.getLog().includes('[unavailable]'));assert(!f.context.getLog().includes('getter secret'));
});
test('DOM nodes and raw multiline chapter text are omitted',()=>{
  const f=fixture();f.logger.debug({nodeType:1,textContent:'dom-secret'},'章节正文内容'.repeat(100)+'\n'+'后续章节正文'.repeat(100));
  assert(!f.context.getLog().includes('dom-secret'));assert(!f.context.getLog().includes('章节正文内容'));assert(f.context.getLog().includes('[redacted'));
});
test('error stack headers cannot restore redacted page HTML or chapter bodies',()=>{
  const f=fixture();const error=new Error('<main>stack-body-secret</main>');error.stack='Error: <main>stack-body-secret</main>\n  at parse (https://www.qidian.com/script.js?token=stack-secret:3:2)';f.logger.error(error);
  assert(!f.context.getLog().includes('stack-body-secret'));assert(!JSON.stringify(f.calls).includes('stack-body-secret'));assert(f.context.getLog().includes('at parse'));
  const chapterError=new Error('章节正文秘密'.repeat(100));chapterError.stack='Error: '+chapterError.message+'\n  at processChapter (fixture.js:1:2)';f.logger.error(chapterError);
  assert(!f.context.getLog().includes('章节正文秘密'));assert(f.context.getLog().includes('at processChapter'));
  f.logger.error({name:'Error',message:'fixture',stack:'Error: '+'对象正文秘密'.repeat(100)+'\n  at fixture (fixture.js:1:2)'});
  assert(!f.context.getLog().includes('对象正文秘密'));
});
test('does not mutate source diagnostic objects',()=>{
  const f=fixture();const data={url:'https://www.qidian.com/chapter/1/2/?token=secret',token:'secret',quality:{actualChars:100}};
  const before=JSON.stringify(data);f.logger.info(data);assert.equal(JSON.stringify(data),before);
});
test('unknown string fields are redacted while numerical diagnostics survive',()=>{
  const f=fixture();f.logger.info({unknownPayload:'secret text',unexpectedCount:7,unexpectedFlag:true});
  assert(!f.context.getLog().includes('secret text'));assert(f.context.getLog().includes('7'));assert(f.context.getLog().includes('true'));
});
test('new failure, runtime and frame metadata strings remain available',()=>{
  const f=fixture();const data={failureStage:'font_ready',errorName:'QidianFontReadyError',errorCode:'font_not_ready',stack:'Error: fixture\n  at parser (fixture.js:1:2)',
    scriptHandler:'Tampermonkey',managerVersion:'5.4',timestampISO:'2026-09-30T11:00:00.000Z',bookId:'123',rangeStart:'101',rangeEnd:'120',
    frameState:{readyState:'complete',addressKind:'requested',bodyTextLength:0,contentPresent:false}};
  f.logger.info(data);const logged=f.calls.at(-1).args[0];
  for(const key of ['failureStage','errorName','errorCode','stack','scriptHandler','managerVersion','timestampISO','bookId','rangeStart','rangeEnd'])assert.equal(logged[key],data[key],key);
  assert.equal(logged.frameState.addressKind,'requested');assert.equal(logged.frameState.readyState,'complete');assert.equal(logged.frameState.bodyTextLength,0);
});
test('ordinary message and stack lengths are bounded',()=>{
  const f=fixture();f.logger.warn('x'.repeat(20000));const error=new Error('e'.repeat(4000));error.stack=Array.from({length:25},(_,i)=>`  at f${i} (${'s'.repeat(800)})`).join('\n');f.logger.error(error);
  assert(f.context.getLog().length<5000);assert(f.context.getLog().includes('[truncated]'));assert(!f.context.getLog().includes('f24'));
});
test('buffer drops only old text at 4 Mi characters and reports it in exported metadata',async()=>{
  const f=fixture();for(let i=0;i<4600;i++)f.logger.debug(`${String(i).padStart(4,'0')} ${'x'.repeat(980)}`);
  assert.equal(f.context.getLog().length,4*1024*1024);assert(!f.context.getLog().startsWith('0000 '));
  f.exportLog?.()??f.context.exportLog();const exported=await f.saves[0].blob.text();
  const buffer=JSON.parse(exported.split('\n')[0].slice('[QidianLogBuffer] '.length));
  assert.equal(buffer.retainedChars,4*1024*1024);assert(buffer.droppedChars>0);
  assert(exported.includes('"event":"log_export"'));assert(exported.includes('"droppedChars":'));
});
test('export embeds requested event and current run summary before snapshot',async()=>{
  const f=fixture();f.logger.info('diagnostic');f.context.exportLog();assert.equal(f.saves.length,1);
  const exported=await f.saves[0].blob.text();const line=exported.split('\n').find(line=>line.startsWith('[QidianDebug] '));
  const event=JSON.parse(line.slice('[QidianDebug] '.length));assert.equal(event.event,'log_export');assert.equal(event.outcome,'download_requested');
  assert.equal(event.runId,'fixture-run');assert.equal(event.summary.failed,1);assert.equal(event.summary.pauseReason,'fixture pause');assert.equal(event.elapsedMs,200);
});
test('failed save is diagnosed with safe error and keeps previous throw semantics',()=>{
  const f=fixture('www.qidian.com',true);assert.throws(()=>f.context.exportLog(),/save failed/);
  assert(f.context.getLog().includes('download_failed'));assert(!f.context.getLog().includes('save-secret'));assert.equal(f.saves.length,0);
});
test('console method failures cannot break Qidian chapter processing',()=>{
  const f=fixture('www.qidian.com',false,true);assert.doesNotThrow(()=>f.logger.warn('chapter fixture warning'));
  assert(f.context.getLog().includes('[console log failed]'));assert(f.context.getLog().includes('chapter fixture warning'));
});
test('other sites preserve original console argument objects and uncapped semantics',()=>{
  const f=fixture('example.org');const item={token:'original',stage:'fixture'};f.logger.warn('prefix',item);
  assert.equal(f.calls[0].args[1],item);assert(f.context.getLog().includes('original'));assert(!f.context.getLog().includes('[redacted]'));
});
test('keeps ordinary 200-chapter summaries and explicitly marks excessive array truncation',()=>{
  const f=fixture();const chapters=Array.from({length:200},(_,i)=>({chapterId:String(i+1),title:`第${i+1}章`,failureStage:'content_check',status:2}));
  f.logger.info({chapters});assert(f.context.getLog().includes('第200章'));assert(!f.context.getLog().includes('omittedItems'));
  f.logger.info({chapters:Array.from({length:600},(_,i)=>({chapterId:String(i+1),status:2}))});
  assert(f.context.getLog().includes('diagnosticTruncated'));assert(f.context.getLog().includes('omittedItems'));
});
test('oversized structured diagnostics and excessively deep objects fail closed',()=>{
  const f=fixture();f.logger.info('[QidianDebug] '+JSON.stringify({token:'oversized-secret',reason:'x'.repeat(1100000)}));
  const item={};let node=item;for(let i=0;i<10;i++)node=node.next={};node.token='deep-secret';f.logger.info(item);
  assert(!f.context.getLog().includes('oversized-secret'));assert(!f.context.getLog().includes('deep-secret'));assert(f.context.getLog().includes('[depth limit]'));
});
test('unconvertible HTTP status metadata cannot replace the original error',()=>{
  const f=fixture();
  for (const status of [Symbol('status'), {valueOf(){throw new Error('bad status');}}]) {
    const error=new Error('original failure');error.status=status;
    const safe=f.context.safeError(error);
    assert.equal(safe.message,'original failure');assert(!('httpStatus' in safe));
    assert.doesNotThrow(()=>f.logger.error('diagnostic failure',error));
  }
});
(async()=>{let passed=0;for(const {name,fn}of tests){try{await fn();passed++;console.log('PASS '+name);}catch(error){console.error('FAIL '+name);console.error(error.stack);process.exitCode=1;}}console.log(`${passed}/${tests.length} bounded log/export checks passed`);})();
