// Run against the shipped script, or pass another version as the first argument.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const script = fs.readFileSync(process.argv[2] || 'novel-downloader-qidian-range.user.js', 'utf8');
const take = (start, end) => {
  const a = script.indexOf(start), b = script.indexOf(end, a);
  assert(a >= 0 && b > a, `Missing source boundary ${start}`);
  return script.slice(a, b);
};
const messages = [];
const logger = () => ({ info: m => messages.push(m), warn: m => messages.push(m), error: m => messages.push(m) });
function canvasFixture() {
  const canvas = { width: 0, height: 0, drawn: [] };
  const ctx = { canvas, setTransform() {}, fillRect() { canvas.drawn = []; }, fillText(c) { canvas.drawn.push(c); } };
  canvas.getContext = () => ctx;
  return { canvas, ctx };
}
const helpers = take('async function qidianRecoverUnmappedGlyph(', 'function extractRenderedText(');
const attemptHelpers = take('function qidianAttemptScope(', 'async function qidianStage(');
function recoveryFixture() {
  const context = { canvasToUint8Array: c => Buffer.from(c.drawn.join('')), _log__WEBPACK_IMPORTED_MODULE_6___default: logger };
  return vm.runInNewContext(helpers + '\n({recover:qidianRecoverUnmappedGlyph, single:ocrSingleChar})', context);
}
function mapFixture(engine, cache = new Map(), limit = 30000) {
  const canvases = [];
  const context = {
    qidianRestoreGlyphCache() {}, qidianGlyphCache: cache,
    qidianGlyphFingerprints: (_, chars) => new Map(chars.map(c => [c, `${c.codePointAt(0)}:0`])), window: {}, qidianOcrDecoder: engine,
    QIDIAN_GLYPH_CACHE_LIMIT: limit, qidianNewGlyphsSincePersist: 0,
    canvasToUint8Array: c => Buffer.from(c.drawn.join('')), _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
  };
  const build = vm.runInNewContext(
    attemptHelpers + take('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars) {', 'async function qidianRecoverUnmappedGlyph(') +
    helpers + '\nbuildFontDecodeMap', context
  );
  const doc = { createElement() { const { canvas } = canvasFixture(); canvases.push(canvas); return canvas; } };
  return { build: chars => build(doc, {}, 'FixtureFont', chars), cache, canvases, context };
}
function cacheFixture(write) {
  const context = { setTimeout, clearTimeout, qidianGlyphCache: new Map(), GM_getValue: () => [], GM_setValue: write, _log__WEBPACK_IMPORTED_MODULE_6___default: logger };
  const api = vm.runInNewContext(
    take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__') + take('const QIDIAN_STORED_GLYPH_LIMIT =', 'window.addEventListener("pagehide"') +
    '\n({persist:qidianPersistGlyphCache,dirty:()=>qidianNewGlyphsSincePersist,note:(n)=>qidianNewGlyphsSincePersist+=n})', context
  );
  return { ...api, map: context.qidianGlyphCache };
}
const tests = [];
const test = (name, fn) => tests.push({ name, fn });

test('single glyph OCR must not truncate a multi-character reading', async () => {
  const api = recoveryFixture(), { canvas, ctx } = canvasFixture();
  const engine = { decode: async () => ({ text: '罕' }), decodeFullText: async () => '罕罕' };
  assert.equal(await api.single(canvas, ctx, '甲', 'font', 48, 2, engine), null);
});
test('single glyph rejects punctuation and replacement characters', async () => {
  const api = recoveryFixture(), { canvas, ctx } = canvasFixture();
  for (const text of ['。', '?', '\ufffd', '\ue001', '口口', 'A', '罕。']) {
    const engine = { decode: async () => ({ text }), decodeFullText: async () => text };
    assert.equal(await api.single(canvas, ctx, '甲', 'font', 48, 2, engine), null, text);
  }
});
test('single glyph retains a supplementary-plane Han character', async () => {
  const api = recoveryFixture(), { canvas, ctx } = canvasFixture();
  const engine = { decode: async () => null, decodeFullText: async () => '\n𠮷 \n' };
  assert.equal(await api.single(canvas, ctx, '甲', 'font', 48, 2, engine), '𠮷');
});
test('conflicting isolated readings are not overridden by matching contexts', async () => {
  const api = recoveryFixture(), { canvas, ctx } = canvasFixture();
  let isolated = 0;
  const anchors = [['A', '的'], ['B', '人'], ['C', '是']];
  const read = data => {
    const chars = [...Buffer.from(data).toString()];
    return chars.length === 1 ? ['汉', '罕'][isolated++] : chars.map(c => ({ A:'的', B:'人', C:'是', X:'罕' })[c]).join('');
  };
  const engine = { decode: async data => ({ text: read(data) }), decodeFullText: async data => read(data) };
  assert.equal(await api.recover(canvas, ctx, 'X', 'font', engine, anchors), null);
});
test('one valid isolated result cannot be overwritten by conflicting context', async () => {
  const api = recoveryFixture(), { canvas, ctx } = canvasFixture();
  let isolated = 0;
  const anchors = [['A', '的'], ['B', '人'], ['C', '是']];
  const read = data => {
    const chars = [...Buffer.from(data).toString()];
    return chars.length === 1 ? (isolated++ === 0 ? '汉' : '') : chars.map(c => ({ A:'的', B:'人', C:'是', X:'罕' })[c]).join('');
  };
  const engine = { decode: async data => ({ text: read(data) }), decodeFullText: async data => read(data) };
  assert.equal(await api.recover(canvas, ctx, 'X', 'font', engine, anchors), null);
});
test('same-length garbage batch never becomes complete cached text', async () => {
  const fixture = mapFixture({ decodeFullText: async data => '?'.repeat([...data.toString()].length), decode: async () => ({ text: '？' }) });
  const map = await fixture.build(['甲', '乙']);
  assert.equal(map.size, 0); assert.equal(fixture.cache.size, 0);
});
test('transient batch OCR failure is recovered locally without abandoning later glyphs', async () => {
  let calls = 0;
  const full = async data => { if (++calls === 1) throw Error('transient engine error'); return data.toString(); };
  const fixture = mapFixture({ decodeFullText: full, decode: async data => ({ text: data.toString() }) });
  assert.equal((await fixture.build(['甲', '乙', '丙'])).size, 3);
});
test('persistent batch failure stops bounded recovery and releases canvases', async () => {
  let calls = 0;
  const fixture = mapFixture({ decodeFullText: async () => { calls++; throw Error('unavailable'); }, decode: async () => { throw Error('unavailable'); } });
  const chars = Array.from({ length: 30 }, (_, i) => String.fromCodePoint(0x4e00 + i));
  assert.equal((await fixture.build(chars)).size, 0);
  assert(calls <= 2);
  assert(fixture.canvases.every(c => c.width === 0 && c.height === 0));
});
test('invalid in-memory cache values are re-read instead of trusted', async () => {
  const cache = new Map([[`${'甲'.codePointAt(0)}:0`, '。']]);
  const fixture = mapFixture({ decodeFullText: async () => '你', decode: async () => ({ text: '你' }) }, cache);
  assert.equal((await fixture.build(['甲'])).get('甲'), '你');
});
test('LRU eviction retains a frequently reused old glyph', async () => {
  const key = c => `${c.codePointAt(0)}:0`;
  const cache = new Map([[key('甲'), '你'], [key('乙'), '好']]);
  const fixture = mapFixture({ decodeFullText: async () => '新', decode: async () => ({ text: '新' }) }, cache, 2);
  assert.equal((await fixture.build(['甲', '丙'])).size, 2);
  assert(cache.has(key('甲'))); assert(!cache.has(key('乙'))); assert(cache.has(key('丙')));
});
test('glyphs learned during an asynchronous write keep their dirty count', async () => {
  let release;
  const api = cacheFixture(() => new Promise(resolve => { release = resolve; }));
  api.map.set('1:1', '你'); api.note(100);
  const pending = api.persist();
  api.map.set('2:2', '好'); api.note(1);
  release(); await pending;
  assert.equal(api.dirty(), 1);
});
test('overlapping final flush is serialized and includes the latest glyph', async () => {
  const releases = []; let saved;
  const api = cacheFixture((key, entries) => new Promise(resolve => releases.push(() => { saved = entries; resolve(); })));
  api.map.set('1:1', '你'); api.note(100);
  const first = api.persist();
  api.map.set('2:2', '好'); api.note(1);
  const last = api.persist(true), writesBeforeRelease = releases.length;
  releases[0](); await first;
  for (let i = 0; i < 12 && releases.length < 2; i++) await Promise.resolve();
  assert.equal(releases.length, 2);
  releases[1](); await last;
  assert.equal(writesBeforeRelease, 1);
  assert.equal(api.dirty(), 0); assert(saved.some(([key]) => key === '2:2'));
});
test('failed cache writes remain retryable', async () => {
  let fail = true, saved;
  const api = cacheFixture((key, entries) => { if (fail) throw Error('disk error'); saved = entries; });
  api.map.set('1:1', '你'); api.note(100);
  await api.persist(); assert.equal(api.dirty(), 100);
  fail = false; await api.persist(true); assert.equal(api.dirty(), 0); assert.equal(saved.length, 1);
});
test('browser back/forward cache keeps warmed glyphs and model', async () => {
  let handler, closes = 0;
  const cache = new Map([['1:1', '你']]);
  vm.runInNewContext(take('window.addEventListener("pagehide"', 'function qidianGlyphFingerprint('), {
    window: { addEventListener(_, fn) { handler = fn; } }, qidianPersistGlyphCache: async () => {},
    qidianOcrDecoder: { async close() { closes++; } }, qidianGlyphCache: cache,
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
  });
  handler({ persisted: true }); await Promise.resolve();
  assert.equal(closes, 0); assert.equal(cache.size, 1);
});
test('page disposal does not empty a queued final cache snapshot', async () => {
  let handler, release, saved;
  const cache = new Map([['1:1', '你']]);
  const blocker = new Promise(resolve => { release = resolve; });
  vm.runInNewContext(take('window.addEventListener("pagehide"', 'function qidianGlyphFingerprint('), {
    window: { addEventListener(_, fn) { handler = fn; } },
    qidianPersistGlyphCache: async () => { await blocker; saved = [...cache]; },
    qidianOcrDecoder: { async close() {} }, qidianGlyphCache: cache,
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
  });
  handler({ persisted: false }); release(); await blocker; await Promise.resolve();
  assert.equal(saved.length, 1);
});
test('unmapped extended Han and PUA source glyphs reject the chapter', async () => {
  const element = () => ({ appendChild() {}, textContent: '' });
  const fn = vm.runInNewContext(take('function qidianContentIsComplete(', '/******/ 	var __webpack_modules__') + take('async function ocrContent(', 'async function buildFontDecodeMap(ownerDoc, ownerWin') + '\nocrContent', {
    document: { createElement: element }, _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
    collectPseudoContentRules: () => [], extractRenderedText: () => '甲\u9fff𠮷\ue123',
    buildFontDecodeMap: async () => new Map([['甲', '你']]),
  });
  const content = { ownerDocument: { defaultView: { document: {}, getComputedStyle: () => ({ fontFamily: 'font' }) } }, querySelectorAll: () => [{}] };
  assert.equal(await fn(content), null);
});
test('cache hits avoid OCR and emit timing counters', async () => {
  const fixture = mapFixture({ decodeFullText() { throw Error('OCR should not run'); } }, new Map([[`${'甲'.codePointAt(0)}:0`, '你']]));
  assert.equal((await fixture.build(['甲'])).get('甲'), '你');
  assert(messages.some(m => m.includes('[QidianOCRStats]') && m.includes('OCR calls 0')));
});
(async () => {
  let failures = 0;
  for (const { name, fn } of tests) {
    try { await fn(); console.log('PASS', name); }
    catch (error) { failures++; console.error('FAIL', name, '\n ', error.message); }
  }
  console.log(`${tests.length - failures}/${tests.length} focused regression checks passed`);
  if (failures) process.exitCode = 1;
})();
