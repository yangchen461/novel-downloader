// Live parser integration against the shipped code. The DOM tree is local;
// network, OCR inference and cleaner boundaries are fixtures with call counts.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a,b,from=0) {
  const start=src.indexOf(a,from),end=src.indexOf(b,start);
  assert(start>=0&&end>start,`Missing shipped boundary ${a}`);
  return src.slice(start,end);
}
const globals=take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const parser=take('  async chapterParse(', '\n}\n\n\n/***/',src.indexOf('class Qidian extends'));
const canonical=text=>String(text??'').replace(/\s/g,'');
class TextNode {
  constructor(text='') { this.nodeType=3;this.nodeName='#text';this.nodeValue=String(text);this.parentNode=null; }
  get textContent(){return this.nodeValue;}
  set textContent(value){this.nodeValue=String(value);}
  get parentElement(){return this.parentNode?.nodeType===1?this.parentNode:null;}
  cloneNode(){return new TextNode(this.nodeValue);}
  remove(){if(this.parentNode)this.parentNode.removeChild(this);}
}
class ElementNode {
  constructor(tag='div',text='',attributes={}) {
    this.nodeType=1;this.nodeName=this.tagName=tag.toUpperCase();this.childNodes=[];
    this.parentNode=null;this.attributes={};this.baseURI='https://www.qidian.com/chapter/1/39/';
    for(const [key,value] of Object.entries(attributes))this.setAttribute(key,value);
    if(text)this.appendChild(new TextNode(text));
  }
  get children(){return this.childNodes.filter(child=>child.nodeType===1);}
  get parentElement(){return this.parentNode?.nodeType===1?this.parentNode:null;}
  get className(){return this.getAttribute('class')??'';}
  set className(value){this.setAttribute('class',value);}
  get textContent(){return this.childNodes.map(child=>child.textContent).join('');}
  set textContent(value){for(const child of this.childNodes)child.parentNode=null;this.childNodes=[];if(String(value))this.appendChild(new TextNode(value));}
  get innerText(){return this.textContent;}
  set innerText(value){this.textContent=value;}
  get outerHTML(){return `<${this.nodeName.toLowerCase()}>${this.textContent}</${this.nodeName.toLowerCase()}>`;}
  setAttribute(key,value){this.attributes[key]=String(value);}
  getAttribute(key){return Object.hasOwn(this.attributes,key)?this.attributes[key]:null;}
  hasAttribute(key){return Object.hasOwn(this.attributes,key);}
  appendChild(child){child.remove();this.childNodes.push(child);child.parentNode=this;return child;}
  removeChild(child){this.childNodes=this.childNodes.filter(value=>value!==child);child.parentNode=null;return child;}
  remove(){if(this.parentNode)this.parentNode.removeChild(this);}
  cloneNode(deep){const cloned=new ElementNode(this.nodeName.toLowerCase(),'',this.attributes);cloned.baseURI=this.baseURI;if(deep)for(const child of this.childNodes)cloned.appendChild(child.cloneNode(true));return cloned;}
  matches(selector){
    return selector.split(',').some(raw=>{
      const part=raw.trim();
      if(part.startsWith('.'))return this.className.split(/\s+/).includes(part.slice(1));
      if(part.startsWith('#'))return this.getAttribute('id')===part.slice(1);
      const match=part.match(/^([a-zA-Z][\w-]*)(?:\.([\w-]+))?$/);
      return match&&this.nodeName.toLowerCase()===match[1].toLowerCase()&&(!match[2]||this.className.split(/\s+/).includes(match[2]));
    });
  }
  closest(selector){for(let node=this;node;node=node.parentElement)if(node.matches(selector))return node;return null;}
  querySelectorAll(selector){const found=[];const visit=node=>{for(const child of node.children??[]){if(child.matches(selector))found.push(child);visit(child);}};visit(this);return found;}
  querySelector(selector){return this.querySelectorAll(selector)[0]??null;}
}
function bodyWith(paragraphs) {
  const main=new ElementNode('main');const content=main.appendChild(new ElementNode('div','',{class:'content-text'}));
  for(const text of paragraphs)content.appendChild(new ElementNode('p',text));
  return {main,content};
}
function fixture(config={}) {
  const state={logs:[],htmlRequests:0,frameRequests:0,cleanCalls:[],ocrCalls:0,persistCalls:0,
    attachmentRequests:0,framesRemoved:0};
  const main=config.main??bodyWith(['甲'.repeat(1000),'乙'.repeat(1000)]).main;
  const author=config.author?new ElementNode('section','',{id:'r-authorSay'}):null;
  if(author)author.appendChild(new ElementNode('div','RAW_AUTHOR_UNCLEANED',{}));
  const cleanedAuthor=new ElementNode('div','AUTHOR_CLEANED_作者附言');
  const log={info:value=>state.logs.push(String(value)),warn:value=>state.logs.push(String(value)),error(){},debug(){}};
  const window={qidianTxtOnly:true,qidianDebugLogger:log,stopController:new AbortController()};
  window.stopFlag=window.stopController.signal;
  const doc={title:'第39章 测试',body:{textContent:main.textContent},querySelector(selector){
    if(selector==='main')return main;
    if(selector==='.content-text, .vip-limit-wrap')return main.querySelector('.content-text')??main;
    if(selector==='h1.title')return new ElementNode('h1','第39章 测试',{class:'title'});
    if(selector==='#r-authorSay')return author;
    return null;
  }};
  const ctx=vm.createContext({URL,window,document:{location:{hostname:'www.qidian.com'},createElement:tag=>new ElementNode(tag)},
    Date,AbortController,_log__WEBPACK_IMPORTED_MODULE_6___default:()=>log,
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async()=>{state.htmlRequests++;return doc;},Q2:async(_url,predicate)=>{
      state.frameRequests++;let removed=false;const frame={contentWindow:{document:doc},remove(){if(!removed){removed=true;state.framesRemoved++;}}};
      assert.equal(predicate(frame),true);return frame;
    }},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(selector,_deep,root){for(const found of root.querySelectorAll(selector))found.remove();},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{async an(root,_mode,options){
      state.cleanCalls.push({root,options});
      if(options?.skipDownloadAttachments!==true&&root.querySelector('img'))state.attachmentRequests++;
      if(root===author)return {dom:cleanedAuthor,text:cleanedAuthor.textContent,images:[]};
      const cleaned=config.cleanedDOM??root.cloneNode(true);
      const text=config.cleanedText??cleaned.textContent;
      if(config.mutateDuringClean)root.textContent='CLEANER_MUTATED_SOURCE';
      return {dom:cleaned,text,images:[]};
    },is(){}},
    async ocrContent(){state.ocrCalls++;return {contentText:config.ocrText??main.textContent,contentHTML:new ElementNode('div',config.ocrText??main.textContent)};},
    qidianGlyphCache:new Map(),async qidianPersistGlyphCache(){state.persistCalls++;}
  });
  vm.runInContext(globals+'\nclass Qidian {'+parser+'}\nthis.Qidian=Qidian;',ctx);
  const options={expectedChars:config.expected??2000};
  return {state,main,ctx,window,options,cleanedAuthor,async parse(vip=false){
    return new ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',vip,true,'UTF-8',options);
  },events(){return state.logs.filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14)));}};
}
function noExtraWork(f,vip=false) {
  assert.equal(f.state.htmlRequests,vip?0:1,'one chapter request only');
  assert.equal(f.state.frameRequests,vip?1:0,'one chapter frame only');
  assert.equal(f.state.ocrCalls,vip?1:0,'free recovery must never invoke OCR');
  assert.equal(f.state.attachmentRequests,0,'TXT-only must not download images');
  assert(f.state.cleanCalls.every(call=>call.options?.skipDownloadAttachments===true));
}
const tests=[];const test=(name,fn)=>tests.push({name,fn});
test('live free parser recovers 10 percent loss even when cleaned text still passes 50 percent',async()=>{
  const original=bodyWith(['甲'.repeat(1000),'乙'.repeat(1000)]);
  const cleaned=bodyWith(['甲'.repeat(1000),'乙'.repeat(800)]);
  const f=fixture({main:original.main,cleanedDOM:cleaned.main,cleanedText:cleaned.main.textContent,mutateDuringClean:true});
  const result=await f.parse();
  assert.equal(canonical(result.contentText),'甲'.repeat(1000)+'乙'.repeat(1000));
  assert.equal(canonical(result.contentHTML.textContent),'甲'.repeat(1000)+'乙'.repeat(1000));
  assert.equal(f.options.qidianValidation.actualChars,2000);
  assert.equal(f.main.textContent,'CLEANER_MUTATED_SOURCE','fixture must verify pre-cleanup capture');
  noExtraWork(f);
});
test('live free parser restores exact source paragraph order despite equal cleaned length',async()=>{
  const original=bodyWith(['甲'.repeat(1000),'乙'.repeat(1000)]);
  const cleaned=bodyWith(['乙'.repeat(1000),'甲'.repeat(1000)]);
  const f=fixture({main:original.main,cleanedDOM:cleaned.main,cleanedText:cleaned.main.textContent});
  const result=await f.parse();
  assert.equal(canonical(result.contentText),'甲'.repeat(1000)+'乙'.repeat(1000));
  assert.equal(canonical(result.contentHTML.textContent),'甲'.repeat(1000)+'乙'.repeat(1000));
  noExtraWork(f);
});
for(const hidden of [{hidden:''},{'aria-hidden':'true'},{style:'display:none !important'},{style:'visibility:hidden'}])
test(`live free parser rejects short source padded by hidden content ${JSON.stringify(hidden)}`,async()=>{
  const source=bodyWith(['中'.repeat(800)]);source.content.appendChild(new ElementNode('span','中'.repeat(3000),hidden));
  const f=fixture({main:source.main,cleanedText:source.main.textContent});
  await assert.rejects(()=>f.parse(),error=>error.name==='QidianContentError');
  assert.equal(f.options.qidianValidation.complete,false);
  assert.equal(f.window.stopFlag.aborted,false,'body failure stays local');
  noExtraWork(f);
});
test('live free parser rejects short body even if image URLs and alt text pad cleaned output',async()=>{
  const source=bodyWith(['中'.repeat(800)]);
  const url='https://images.example.invalid/'+'x'.repeat(3000)+'.png';
  source.content.appendChild(new ElementNode('img','',{src:url,alt:'中'.repeat(2000)}));
  const f=fixture({main:source.main,cleanedText:source.main.textContent+`![${url}](${url})`});
  await assert.rejects(()=>f.parse(),error=>error.name==='QidianContentError');
  assert.equal(f.options.qidianValidation.complete,false);
  assert.equal(f.window.stopFlag.aborted,false);noExtraWork(f);
});
test('free parser explicit body boundary excludes image markdown and author note from completeness',async()=>{
  const source=bodyWith(['甲'.repeat(1000),'乙'.repeat(1000)]);
  const url='https://images.example.invalid/source-image.png';
  source.content.appendChild(new ElementNode('img','',{src:url,alt:'IMG_ALT_UNWANTED'}));
  const f=fixture({main:source.main,author:true,cleanedText:source.main.textContent+`![${url}](${url})`});
  const result=await f.parse();
  assert(Number.isInteger(f.options.qidianBodyLength),'live parser must record the pre-footer body boundary');
  const body=f.ctx.qidianChapterBodyText({contentText:result.contentText,options:f.options});
  assert.equal(canonical(body),'甲'.repeat(1000)+'乙'.repeat(1000));
  assert(!body.includes(url));assert(!body.includes('AUTHOR_CLEANED'));
  assert(result.contentText.includes(url),'TXT image reference survives after the body boundary');
  assert(result.contentText.includes('AUTHOR_CLEANED'));assert.equal(f.options.qidianValidation.actualChars,2000);
  assert.equal(result.contentHTML.querySelector('.authorSay'),f.cleanedAuthor,'append sanitized author DOM');
  assert(!result.contentHTML.textContent.includes('RAW_AUTHOR_UNCLEANED'));
  noExtraWork(f);
});
test('VIP parser records body boundary and appends cleaned author DOM',async()=>{
  const f=fixture({author:true,ocrText:'中'.repeat(2000)});const result=await f.parse(true);
  assert.equal(f.options.qidianBodyLength,2000);
  assert.equal(f.ctx.qidianChapterBodyText({contentText:result.contentText,options:f.options}),'中'.repeat(2000));
  assert(result.contentText.includes('AUTHOR_CLEANED'));
  assert.equal(result.contentHTML.querySelector('.authorSay'),f.cleanedAuthor);
  assert(!result.contentHTML.textContent.includes('RAW_AUTHOR_UNCLEANED'));
  assert.equal(f.state.framesRemoved,1);noExtraWork(f,true);
});
for(const code of [0xe123,0xf0123,0x100123,0xfffd])test(`VIP parser rejects unresolved U+${code.toString(16)} despite sufficient length`,async()=>{
  const f=fixture({ocrText:'中'.repeat(2000)+String.fromCodePoint(code)});
  await assert.rejects(()=>f.parse(true),error=>error.name==='QidianContentError');
  assert.equal(f.options.qidianValidation.complete,false);
  assert.match(f.options.qidianValidation.reason,/private_use|replacement/);
  assert.equal(f.state.persistCalls,0,'never persist incomplete OCR as successful');
  assert.equal(f.state.framesRemoved,1);assert.equal(f.window.stopFlag.aborted,false);
  noExtraWork(f,true);
});
(async()=>{let failed=0;for(const {name,fn} of tests){try{await fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error);}}
console.log(`${tests.length-failed}/${tests.length} v24 live parser accuracy checks passed`);if(failed)process.exitCode=1;})();
