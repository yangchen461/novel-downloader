const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const take = (a, b) => { const i = src.indexOf(a), j = src.indexOf(b, i); assert(i >= 0 && j > i); return src.slice(i, j); };
const messages = [];
const logger = () => ({ info: s => messages.push(s), error: s => messages.push(s), warn: s => messages.push(s), trace() {}, debug() {} });
const tests = [];
const test = (name, run) => tests.push({ name, run });
const normalize = take('function qidianNormalizeGlyphReading(', 'async function ocrSingleChar(');
const helpers = take('async function qidianRecoverUnmappedGlyph(', 'function extractRenderedText(');
const attemptHelpers = take('function qidianAttemptScope(', 'async function qidianStage(');
const buildCode = take('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars)', 'async function qidianRecoverUnmappedGlyph(');
const ocrCode = take('async function ocrContent(', 'async function buildFontDecodeMap(');

// Deterministic RGBA raster fixture, including antialias-like intensities and
// oversized glyphs crossing cell edges. Checks the hashing/tiling algorithm;
// it does not substitute for a real browser font rasterizer.
function rasterFixture() {
  let width = 0, height = 0, pixels = new Uint8ClampedArray();
  let clip = null, pending = null; const stack = [];
  const canvas = {};
  const reset = () => { pixels = new Uint8ClampedArray(width * height * 4); clip = null; };
  Object.defineProperties(canvas, {
    width: { get: () => width, set: v => { width = v; reset(); } },
    height: { get: () => height, set: v => { height = v; reset(); } },
  });
  const ctx = {
    canvas, reads: 0, failTile: false,
    save() { stack.push(clip); }, restore() { clip = stack.pop(); },
    beginPath() {}, rect(x, y, w, h) { pending = { x, y, w, h }; }, clip() { clip = pending; },
    fillRect(x, y, w, h) {
      for (let row = y; row < y+h; row++) pixels.fill(255, (row * width+x) * 4, (row*width+x+w) * 4);
    },
    fillText(ch, cx, cy) {
      const code = ch.codePointAt(0), w = 31 + code % 100, h = 47 + code % 91;
      const left = cx - Math.floor(w / 2), top = cy - Math.floor(h / 2);
      for (let y = Math.max(0, top); y < Math.min(height, top+h); y++) {
        for (let x = Math.max(0, left); x < Math.min(width, left+w); x++) {
          if (clip && (x < clip.x || y < clip.y || x >= clip.x+clip.w || y >= clip.y+clip.h)) continue;
          const i = (y*width+x)*4, value = (code + (x-left)*31 + (y-top)*17) % 251;
          pixels[i] = value; pixels[i+1] = (value+37)%256; pixels[i+2] = (value+19)%256; pixels[i+3] = 255;
        }
      }
    },
    getImageData(x, y, w, h) {
      this.reads++;
      if (this.failTile && w > 80) throw Error('tile readback unavailable');
      const data = new Uint8ClampedArray(w*h*4);
      for (let row = 0; row < h; row++) {
        const start = ((y+row)*width+x)*4;
        data.set(pixels.subarray(start, start+w*4), row*w*4);
      }
      return { data };
    },
  };
  return ctx;
}
const fingerprintApi = new Function('_log__WEBPACK_IMPORTED_MODULE_6___default',
  take('function qidianGlyphFingerprint(', 'async function ocrContent(') + '\nreturn {single:qidianGlyphFingerprint,tiled:qidianGlyphFingerprints};')(logger);
test('tiled RGB hashes equal legacy hashes, including clipped oversized glyphs', () => {
  const a = rasterFixture(), b = rasterFixture();
  const chars = Array.from({ length: 800 }, (_, i) => String.fromCodePoint(0x4e00+i));
  const old = new Map(chars.map(c => [c, fingerprintApi.single(a, c, 'fixture')]));
  const next = fingerprintApi.tiled(b, chars, 'fixture');
  assert.deepEqual(next, old);
  assert.equal(a.reads, 800); assert.equal(b.reads, 16, '13 tiled readbacks plus 3 legacy spot checks');
  for (const n of [0, 1, 7, 8, 63, 64, 65, 129]) {
    const subset = chars.slice(0, n);
    assert.deepEqual(fingerprintApi.tiled(b, subset, 'fixture'), new Map(subset.map(c => [c, old.get(c)])));
  }
});
test('tile failure falls back to legacy hashing without leaking clipping state', () => {
  const a = rasterFixture(), b = rasterFixture(); b.failTile = true;
  const chars = ['甲', '乙', '丙', '丁', '戊'];
  assert.deepEqual(fingerprintApi.tiled(b, chars, 'fixture'), new Map(chars.map(c => [c, fingerprintApi.single(a, c, 'fixture')])));
});
test('runtime sample mismatch discards tiled hashes and uses the legacy renderer', () => {
  const a = rasterFixture(), b = rasterFixture();
  const read = b.getImageData.bind(b);
  b.getImageData = (...args) => {
    const result = read(...args);
    if (args[2] > 80) result.data[0] ^= 127;
    return result;
  };
  const chars = ['甲', '乙', '丙', '丁', '戊'];
  assert.deepEqual(fingerprintApi.tiled(b, chars, 'fixture'), new Map(chars.map(c => [c, fingerprintApi.single(a, c, 'fixture')])));
  assert(messages.some(s => s.includes('Tiled pixels differ')));
});

function mapFixture({ missing = 5, read = () => '', cached = true, timePerRecovery = 0, abortAfter = Infinity } = {}) {
  const cache = new Map(cached ? [['fp的', '的'], ['fp人', '人']] : []);
  const chars = [...(cached ? ['的', '人'] : []), ...Array.from({ length: missing }, (_, i) => String.fromCodePoint(0x4e00+i))];
  let now = 0, localCalls = 0, engineCalls = 0;
  const window = { stopFlag: { aborted: false } };
  const canvases = [];
  const doc = { createElement() {
    const canvas = { width: 0, height: 0, drawn: [] };
    const ctx = { canvas, setTransform() {}, fillRect() { canvas.drawn = []; }, fillText(c) { canvas.drawn.push(c); } };
    canvas.getContext = () => ctx; canvas.ctx = ctx; canvases.push(canvas); return canvas;
  } };
  const context = {
    window, Date: { now: () => now }, qidianRestoreGlyphCache() {}, qidianGlyphCache: cache,
    qidianGlyphFingerprints: (_, chars) => new Map(chars.map(c => [c, 'fp'+c])),
    qidianNewGlyphsSincePersist: 0, QIDIAN_GLYPH_CACHE_LIMIT: 30000,
    qidianOcrDecoder: { async decodeFullText(data) {
      engineCalls++;
      if (!data.font.startsWith('48px')) {
        now += timePerRecovery; localCalls++;
        if (localCalls >= abortAfter) window.stopFlag.aborted = true;
        return read(data);
      }
      return '';
    } },
    canvasToUint8Array: c => ({ text: c.drawn.join(''), font: c.ctx.font }),
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
  };
  const build = vm.runInNewContext(attemptHelpers + buildCode + helpers + '\nbuildFontDecodeMap', context);
  return { run: () => build(doc, {}, 'Fixture', chars), cache, chars, context, canvases, localCalls: () => localCalls, engineCalls: () => engineCalls };
}
test('five missing glyphs receive corroborated recovery in the same map', async () => {
  const f = mapFixture({ read: data => data.text });
  const map = await f.run();
  assert.equal(map.size, 7); assert.equal(f.localCalls(), 10);
  assert.equal(map.get('的'), '的'); assert.equal(map.qidianLocalRecoveryFinished, true);
  assert(f.canvases.every(c => c.width === 0 && c.height === 0));
});
test('eight stubborn glyphs stop at 32 local OCR calls', async () => {
  const f = mapFixture({ missing: 8 }); const map = await f.run();
  assert.equal(map.size, 2); assert.equal(f.localCalls(), 32);
  assert.equal(map.qidianLocalRecoveryFinished, true);
  assert.equal(f.cache.size, 2);
});
test('local time budget is checked before each inference', async () => {
  const f = mapFixture({ missing: 5, timePerRecovery: 20000 });
  assert.equal((await f.run()).size, 2);
  assert.equal(f.localCalls(), 3, 'in-flight call may finish after 45s; do not start a fourth');
});
test('user stop prevents another local recovery inference', async () => {
  const f = mapFixture({ abortAfter: 1, read: data => data.text });
  assert.equal((await f.run()).size, 2); assert.equal(f.localCalls(), 1);
});
test('large incomplete maps do not start unbounded rare-glyph recovery', async () => {
  const f = mapFixture({ missing: 9 }); const map = await f.run();
  assert.equal(map.size, 2); assert.equal(f.localCalls(), 0);
  assert.equal(map.qidianLocalRecoveryFinished, true);
});
test('persistent engine exception keeps the existing generic retry path', async () => {
  const f = mapFixture({ missing: 30, cached: false });
  f.context.qidianOcrDecoder.decodeFullText = async () => { throw Error('engine unavailable'); };
  const map = await f.run();
  assert.equal(map.qidianLocalRecoveryFinished, undefined);
  assert(f.canvases.every(c => c.width === 0 && c.height === 0));
});

function contentFixture(map, text = '甲乙') {
  const context = {
    document: { createElement: () => ({ appendChild() {} }) },
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger,
    collectPseudoContentRules: () => [], extractRenderedText: () => text,
    buildFontDecodeMap: async () => map,
  };
  const fn = vm.runInNewContext(take('function qidianContentIsComplete(', '/******/ 	var __webpack_modules__') + ocrCode + '\nocrContent', context);
  const content = { querySelectorAll: () => [{}], ownerDocument: { defaultView: { document: {}, getComputedStyle: () => ({ fontFamily: 'fixture' }) } } };
  return { run: () => fn(content), context, content };
}
const tooManyUnknowns = '甲' + Array.from({ length: 11 }, (_, i) => String.fromCodePoint(0xE001 + i)).join('');
test('exhausted local recovery beyond ten distinct unknown glyphs rejects the whole chapter as QidianGlyphError', async () => {
  const map = new Map([['甲', '你']]); map.qidianLocalRecoveryFinished = true;
  await assert.rejects(contentFixture(map, tooManyUnknowns).run(), e => e.name === 'QidianGlyphError');
});
test('generic mapping failure stays retryable; complete text keeps source order', async () => {
  assert.equal(await contentFixture(new Map([['甲', '你']])).run(), null);
  const map = new Map([['甲', '你'], ['乙', '好']]); map.qidianLocalRecoveryFinished = true;
  assert.equal((await contentFixture(map).run()).contentText, '你好');
});
test('actual parser records failure, completes later chapter and frees frames from bounded recovery', async () => {
  const statuses = { pending: 0, downloading: 1, failed: 2, finished: 3, aborted: 4, saved: 5 };
  const map = new Map([['甲', '你']]); map.qidianLocalRecoveryFinished = true;
  const c = contentFixture(map, tooManyUnknowns);
  const window = { stopController: new AbortController(), failedCount: 0 };
  window.stopFlag = window.stopController.signal;
  let frames = 0, removed = 0, rawCalls = 0, now = 1000; const waits = [];
  const doc = { querySelector: s => s === 'main' ? c.content : null };
  const sleep = async ms => { waits.push(ms); now += ms; };
  const ctx = vm.createContext({
    ...c.context, window, document: { ...c.context.document, location: { hostname: 'www.qidian.com' } },
    Date: { now: () => now }, Math: Object.assign(Object.create(Math), { random: () => 0 }),
    setTimeout: () => 1, clearTimeout() {}, alert() {}, AbortController,
    _main__WEBPACK_IMPORTED_MODULE_3__: { nW: statuses }, main: { nW: statuses, K5: Error },
    _log__WEBPACK_IMPORTED_MODULE_1___default: logger, loglevel_default: logger,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__: { yy: sleep }, misc: { yy: sleep },
    setting: { Zz: { value: false }, Nw: { value: false } },
    progress: { vm: { updateRequestTime() {}, updateQidianTiming() {}, finishedChapterNumber: 0 } },
    _lib_http__WEBPACK_IMPORTED_MODULE_2__: { Q2: async () => { frames++; return { contentWindow: { document: doc }, remove() { removed++; } }; } },
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__: { rm() {} },
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__: { an() { rawCalls++; throw Error('raw body forbidden'); } },
    qidianGlyphCache: new Map(), qidianPersistGlyphCache: async () => {},
  });
  const globals = take('function qidianContentIsComplete', '/******/ \tvar __webpack_modules__');
  const chapter = take('class ChapterAbortError', '\n\n/***/ },');
  const parseStart = src.indexOf('  async chapterParse(', src.indexOf('class Qidian extends'));
  const parseEnd = src.indexOf('\n}\n\n\n/***/', parseStart);
  const scheduler = take('  async initChapters(book,', '\n  postHook()');
  vm.runInContext(globals + ocrCode + chapter + '\nclass Qidian {' + src.slice(parseStart, parseEnd) +
    '}\nclass Rule {' + scheduler + '}\nthis.Chapter=Chapter;this.Qidian=Qidian;this.Rule=Rule;', ctx);
  const parser = new ctx.Qidian(); const starts = [];
  const first = new ctx.Chapter({ chapterName: '第318章', chapterUrl: 'https://www.qidian.com/chapter/1/318', chapterNumber: 318,
    isVIP: true, isPaid: true, options: {}, chapterParse: async (...args) => { starts.push(now); return parser.chapterParse(...args); } });
  const next = new ctx.Chapter({ chapterName: '第319章', chapterUrl: 'https://www.qidian.com/chapter/1/319', chapterNumber: 319,
    options: {}, chapterParse: async () => { starts.push(now); return { chapterName:'第319章', contentText: '正文'.repeat(1000), contentHTML:{}, contentImages: [] }; } });
  const rule = new ctx.Rule(); rule.concurrencyLimit = 1; rule.sleepTime = 8000; rule.maxSleepTime = 20000;
  const saved = [];
  await rule.initChapters({ chapters: [first, next] }, { addChapter: async ch => { if (ch.contentText) saved.push(ch.chapterName); } });
  assert.equal(frames, 3); assert.equal(removed, 3); assert.equal(rawCalls, 0);
  assert.equal(first.status, statuses.failed); assert.match(first.errorMessage, /跳过整章重载/);
  assert.equal(first.contentText, null); assert.equal(window.failedCount, 3);
  assert.equal(starts.length, 4); assert(starts[1]-starts[0] >= 10000);
  assert.equal(window.stopFlag.aborted, false); assert.equal(next.status, statuses.finished);
  assert.deepEqual(saved, ['第319章']);
  assert(messages.some(s => s.includes('[QidianPerf] 第318章')));
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, error); }
  }
  console.log(`${tests.length-failed}/${tests.length} v16 checks passed`);
  if (failed) process.exitCode = 1;
})();
