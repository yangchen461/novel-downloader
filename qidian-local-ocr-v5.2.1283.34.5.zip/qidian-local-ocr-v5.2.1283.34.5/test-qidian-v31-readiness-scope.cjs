// Execute shipped functions and parser boundaries, including failure cases on .30.
// No network, novel text, credentials, browser account or OCR model is required.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const directory = path.resolve(process.argv[2] || __dirname);
const source = fs.readFileSync(path.join(directory, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a,b,from=0) {
  const start=source.indexOf(a,from),end=source.indexOf(b,start);
  assert(start>=0&&end>start, `Missing actual implementation: ${a}`);
  return source.slice(start,end);
}
const globals=take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
function existingFixture(file, expression) {
  const code=fs.readFileSync(path.join(directory,file),'utf8');
  const end=code.search(/const tests\s*=\s*\[\];/);
  assert(end>0);
  return vm.runInNewContext(code.slice(0,end)+'\n'+expression,
    {require,__dirname:directory,AbortController,URL,console,process});
}
const free=existingFixture('test-qidian-v24-parser-accuracy.cjs','({fixture,bodyWith,ElementNode})');
const frameParser=existingFixture('test-qidian-v18-frame.cjs','fixture');
const tests=[];
const test=(name,run)=>tests.push({name,run});
function frameFixture(config={}) {
  const state={now:0,next:0,timers:new Map(),frames:[],logs:[],removed:0,queued:[]};
  const timer=(fn,ms,interval=false)=>{const id=++state.next;state.timers.set(id,{fn,at:state.now+ms,interval:interval?ms:0});return id;};
  const window={setInterval:(fn,ms)=>timer(fn,ms,true),setTimeout:(fn,ms)=>timer(fn,ms),
    clearInterval:id=>state.timers.delete(id),clearTimeout:id=>state.timers.delete(id)};
  const doc={URL:'https://www.qidian.com/chapter/1/2/',readyState:'complete',title:'',
    body:{innerText:'',childElementCount:2},querySelector:()=>null,querySelectorAll:()=>[]};
  const document={body:{appendChild(frame){
    state.queued=[...state.timers.values()].map(timer=>timer.fn);
    if(config.appendThrows)throw Error('synthetic append failure');
    if(config.load!==false)frame.dispatch('load');
  }},createElement(){
    const listeners=new Map();
    const frame={contentWindow:{document:doc},sandbox:{add(){}},listeners,
      addEventListener(type,fn){if(!listeners.has(type))listeners.set(type,new Set());listeners.get(type).add(fn);},
      removeEventListener(type,fn){listeners.get(type)?.delete(fn);},
      dispatch(type){for(const fn of [...listeners.get(type)||[]])fn();},
      remove(){state.removed++;}};
    state.frames.push(frame);return frame;
  }};
  const logger={debug(){},error(){}};
  const ctx=vm.createContext({window,document,URL,_log__WEBPACK_IMPORTED_MODULE_0___default:()=>logger});
  vm.runInContext(take('async function getFrameContentConditionWithWindow(', '\n\n\n/***/'),ctx);
  async function drain(promise) {
    let done=false,result,error;
    promise.then(value=>{done=true;result=value;},failure=>{done=true;error=failure;});
    for(let i=0;!done&&i<100;i++) {
      for(let j=0;j<10;j++)await Promise.resolve();
      if(done)break;
      const next=[...state.timers].sort((a,b)=>a[1].at-b[1].at)[0];
      assert(next,'Promise must settle or have a pending timer');
      const [id,t]=next;state.now=t.at;
      if(t.interval)t.at+=t.interval;else state.timers.delete(id);
      t.fn();
    }
    assert(done,'Virtual deadline exceeded');if(error)throw error;return result;
  }
  const request=(predicate,options={checkOnLoad:true})=>ctx.getFrameContentConditionWithWindow(doc.URL,predicate,undefined,20000,options);
  return {state,request,drain,doc};
}
test('a ready load uses the readiness predicate without waiting one poll interval',async()=>{
  const f=frameFixture();let checks=0;
  const frame=await f.drain(f.request(()=>{checks++;return true;}));
  assert.equal(f.state.now,0);assert.equal(checks,1);assert.equal(frame,f.state.frames[0]);
  assert.equal(f.state.frames.length,1);assert.equal(f.state.timers.size,0);
  assert.equal([...frame.listeners.values()].reduce((sum,set)=>sum+set.size,0),0);
});
test('other sites retain the existing one-second polling schedule unless opted in',async()=>{
  const f=frameFixture();await f.drain(f.request(()=>true,{}));assert.equal(f.state.now,1000);
});
test('a load without ready content does not accept a blank page or reload it',async()=>{
  const f=frameFixture();await assert.rejects(f.drain(f.request(()=>false)),error=>{
    assert.equal(error.frameState.loadEvents,1);assert.equal(error.frameState.addressKind,'requested');return true;
  });
  assert.equal(f.state.now,20000);assert.equal(f.state.frames.length,1);assert.equal(f.state.removed,1);
  assert.equal(f.state.timers.size,0);
});
test('a late ready predicate still works when the load event was too early',async()=>{
  const f=frameFixture();await f.drain(f.request(()=>f.state.now>=3000));assert.equal(f.state.now,3000);
});
test('queued callbacks after resolution cannot remove the frame during OCR or recheck it',async()=>{
  const f=frameFixture();let checks=0;
  await f.drain(f.request(()=>{checks++;return true;}));
  const before=checks;for(const callback of f.state.queued)callback();
  assert.equal(checks,before);assert.equal(f.state.removed,0);assert.equal(f.state.timers.size,0);
});
test('a predicate error cleans listeners and timers and propagates once',async()=>{
  const f=frameFixture();const failure=Error('synthetic readiness failure');
  await assert.rejects(f.drain(f.request(()=>{throw failure;})),error=>error===failure);
  assert.equal(f.state.now,0);assert.equal(f.state.removed,1);assert.equal(f.state.timers.size,0);
  for(const callback of f.state.queued)callback();assert.equal(f.state.removed,1);
});
test('insertion failure also cleans pending timers and the frame',async()=>{
  const f=frameFixture({appendThrows:true});await assert.rejects(f.drain(f.request(()=>true)),/append failure/);
  assert.equal(f.state.timers.size,0);assert.equal(f.state.removed,1);
});
test('a previous request snapshot cannot overwrite a fresh blank-page timeout',async()=>{
  const f=frameParser();
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.Q2=async()=>{
    const error=Error('Frame Timeout!');error.frameState={addressKind:'requested',readyState:'complete',
      bodyPresent:true,bodyTextLength:0,contentPresent:false,mainParagraphs:0,loadEvents:1,errorEvents:0};throw error;
  };
  const options={expectedChars:2000,qidianLastFrameState:{readyState:'loading',bodyTextLength:1000,mainParagraphs:4}};
  await assert.rejects(new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/119/','第119章',true,true,'UTF-8',options,1),error=>{
    assert.equal(error.name,'QidianChapterPageError');assert.equal(error.frameState.bodyTextLength,0);return true;
  });
  assert.equal(options.qidianLastFrameState.readyState,'complete');
});
for(const hidden of [{hidden:''},{'aria-hidden':'true'},{style:'display:none!important'}]) {
  test(`an explicitly hidden first root cannot hide the readable second root: ${JSON.stringify(hidden)}`,async()=>{
    const first=free.bodyWith(['隐藏副本']);Object.assign(first.content.attributes,hidden);
    const live=free.bodyWith(['甲'.repeat(1000),'乙'.repeat(1000)]);
    first.main.appendChild(live.content);
    const f=free.fixture({main:first.main});const result=await f.parse();
    assert.equal(result.contentText.replace(/\s/g,''),'甲'.repeat(1000)+'乙'.repeat(1000));
    assert.equal(f.state.htmlRequests,1);assert.equal(f.state.ocrCalls,0);
    const check=f.events().find(row=>row.event==='content_check');
    assert.equal(check.rootSelection.eligibleRootCount,1);assert.equal(check.rootSelection.contentRootCount,2);
  });
}
test('two independent readable roots are reported as ambiguous, never concatenated or silently truncated',async()=>{
  const first=free.bodyWith(['甲'.repeat(2000)]),second=free.bodyWith(['乙'.repeat(2000)]);
  first.main.appendChild(second.content);const f=free.fixture({main:first.main});
  await assert.rejects(f.parse(),error=>error.name==='QidianContentError');
  const check=f.events().find(row=>row.event==='content_check');
  assert.equal(check.quality.complete,false);assert.equal(check.quality.reason,'ambiguous_content_roots');
  assert.equal(check.rootSelection.eligibleRootCount,2);assert.equal(f.state.htmlRequests,1);
});
test('a nested content root is captured once in original paragraph order',async()=>{
  const outer=free.bodyWith(['甲'.repeat(1000)]),inner=free.bodyWith(['乙'.repeat(1000)]);
  outer.content.appendChild(inner.content);const f=free.fixture({main:outer.main});
  const result=await f.parse();assert.equal(result.contentText.replace(/\s/g,''),'甲'.repeat(1000)+'乙'.repeat(1000));
  assert.equal(f.events().find(row=>row.event==='content_check').rootSelection.eligibleRootCount,1);
});
test('content roots inside navigation are excluded when a single real body is available',async()=>{
  const outer=free.bodyWith(['甲'.repeat(2000)]);
  const nav=new free.ElementNode('nav');nav.appendChild(free.bodyWith(['导航副本']).content);
  const main=new free.ElementNode('main');main.appendChild(nav);main.appendChild(outer.content);
  const f=free.fixture({main});assert.equal((await f.parse()).contentText,'甲'.repeat(2000));
});
test('a root already scoped to content-text retains its own text around a nested root',()=>{
  const root=free.bodyWith(['甲'.repeat(1000)]).content;
  root.appendChild(free.bodyWith(['乙'.repeat(1000)]).content);
  const f=free.fixture();const snapshot=f.ctx.qidianCaptureFreeBody(root);
  assert.equal(snapshot.canonical,'甲'.repeat(1000)+'乙'.repeat(1000));
  assert.equal(f.ctx.qidianCaptureFreeBody(snapshot.dom).canonical,snapshot.canonical);
});
test('frame diagnostics report probe installation state and document generation without page text',async()=>{
  const f=frameParser();await f.drain(f.makeChapter(119).init());
  const rows=f.state.logs.filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14)));
  const row=rows.find(row=>row.event==='frame_reader_diagnostics');
  assert.equal(row.documentGeneration,1);assert.equal(row.probeInstallState.readyState,'complete');
  assert(!JSON.stringify(row).includes('must-not-be-logged'));
});
test('short free text still fails and has a stable, bounded diagnostic fingerprint',async()=>{
  const digests=[];
  for(let i=0;i<2;i++) {
    const f=free.fixture({expected:5000});await assert.rejects(f.parse(),error=>error.name==='QidianContentError');
    const check=f.events().find(row=>row.event==='content_check');
    assert.equal(check.quality.reason,'below_expected_length');assert.equal(check.sourceMatched,null);
    assert.equal(check.quality.actualChars,2000);assert.equal(check.quality.minimumChars,2500);
    assert.match(check.sourceFingerprint.digest,/^2000:[0-9a-f]{1,8}:[0-9a-f]{1,8}$/);
    digests.push(check.sourceFingerprint.digest);
    assert(!JSON.stringify(check).includes('甲甲甲'));assert.equal(f.state.htmlRequests,1);
  }
  assert.equal(digests[0],digests[1]);
});
test('a different body with the same character count has a different diagnostic fingerprint',async()=>{
  const a=free.fixture(),b=free.fixture({main:free.bodyWith(['乙'.repeat(1000),'甲'.repeat(1000)]).main});
  await a.parse();await b.parse();
  const digest=f=>f.events().find(row=>row.event==='content_check').sourceFingerprint.digest;
  assert.notEqual(digest(a),digest(b));
});
test('zero percent is visible while the first selected chapter is pending, with no fake success',()=>{
  const code=take('function formatETA(', 'app.config.compilerOptions');
  const options=vm.runInNewContext(code+'\napp',{external_Vue_:{createApp:o=>o},ui_progress:''});
  const state=Object.assign(options.data(),{isQidianRun:true,totalChapterNumber:10});
  for(const [name,method] of Object.entries(options.methods))state[name]=method.bind(state);
  for(const [name,compute] of Object.entries(options.computed))Object.defineProperty(state,name,{get:()=>compute.call(state)});
  assert.equal(state.chapterProgressSeen,true);assert.equal(state.ntProgressSeen,true);
  assert.equal(state.chapterPercent,0);assert.equal(state.completedChapterNumber,0);
  options.methods.reset.call(state);assert.equal(state.chapterProgressSeen,false);
});
(async()=>{let failed=0;for(const {name,run} of tests){try{await run();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,'\n',error.stack??error);}}
  console.log(`${tests.length-failed}/${tests.length} v31 readiness/body-scope checks passed`);if(failed)process.exitCode=1;
})();
