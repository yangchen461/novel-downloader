// Exercise the shipped parser/scheduler and optional waits. Browser, network,
// rasterization/inference and GM boundaries are fixtures; their callers are real.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b, from = 0) {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing shipped boundary: ${a}`);
  return src.slice(start, end);
}
const statuses = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode = take('class ChapterAbortError', '\n\n/***/ },');
const scheduler = take('  async initChapters(book,', '\n  postHook()');
const parser = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const saveCode = take('  async addChapter(chapter) {', '\n  async save()', src.indexOf('class SaveBook'));
const glyphPersistence = take('// One ONNX engine per page:', 'window.addEventListener("pagehide"');
const ocrContent = take('async function ocrContent(', '\nasync function buildFontDecodeMap(', src.indexOf('// One ONNX engine per page:'));
const progressCode = take('function formatETA(', 'app.config.compilerOptions');
const progressOptions = vm.runInNewContext(progressCode + '\napp', { external_Vue_:{createApp:options=>options}, ui_progress:'' });

function node(tag='div') {
  return { tagName:tag.toUpperCase(), children:[], appendChild(child) { this.children.push(child); return child; } };
}
function fixture(configs, options = {}) {
  const state = { now:1000, logs:[], requests:[], waits:[], storageWrites:[], saved:[],
    timers:new Map(), nextTimer:0, firedTimers:[], cleanedFrames:[], ocrStarts:[], settled:false };
  const log = Object.fromEntries(['info','warn','error','trace','debug'].map(level=>[level,
    value=>state.logs.push({level,text:String(value?.message ?? value)})]));
  const window = { stopController:new AbortController(), failedCount:0, qidianTxtOnly:true };
  window.stopFlag = window.stopController.signal;
  window.qidianDebugLogger = log;
  const progress = progressOptions.data(); Object.assign(progress, progressOptions.methods);
  const byId = new Map(configs.map(cfg=>[cfg.id,cfg]));
  const fullText = '正文内容完整，字数符合目录。'.repeat(200);
  function makeDoc(cfg) {
    const paragraphs = [fullText.slice(0,700),fullText.slice(700,1400),fullText.slice(1400)];
    const main = { cfg, textContent:fullText, querySelectorAll:selector=>selector==='p'?paragraphs.map(text=>({text})):[],
      querySelector:selector=>selector==='.content-text'?main:null };
    const fonts = { ready:cfg.fontHang ? new Promise(()=>{}) : Promise.resolve() };
    const doc = { title:`第${cfg.id}章`, fonts, body:{textContent:fullText},
      querySelector(selector) {
        if (selector === 'main' || selector === '.content-text' || selector === '.content-text, .vip-limit-wrap') return main;
        if (selector === 'h1.title') return {innerText:`第${cfg.id}章`};
        return null;
      }, defaultView:null };
    doc.defaultView = { document:doc, getComputedStyle:()=>({fontFamily:'fixture-glyph-font'}) };
    main.ownerDocument = doc;
    return {doc,main};
  }
  const request = async (url, frame, predicate) => {
    const id = Number(String(url).split('/').filter(Boolean).at(-1)), cfg = byId.get(id);
    assert(cfg,`Unexpected chapter request ${url}`);
    state.requests.push({id,at:state.now}); state.now += 700;
    const {doc,main} = makeDoc(cfg);
    if (!frame) return doc;
    let removed = false;
    const element = {contentWindow:{document:doc},remove() {
      if (!removed) { removed=true; state.cleanedFrames.push(id); }
    }};
    assert.equal(predicate(element),true); return element;
  };
  class ClockDate extends Date { static now() { return state.now; } }
  const ctx = vm.createContext({
    window, unsafeWindow:window, URL, Date:ClockDate, Promise, Map, Set, AbortController,
    document:{location:{hostname:'www.qidian.com'},createElement:node},
    Math:Object.assign(Object.create(Math),{random:()=>0}), console:log, alert(){},
    setTimeout:(fn,ms)=>{const id=++state.nextTimer;state.timers.set(id,{fn,ms});return id;},
    clearTimeout:id=>state.timers.delete(id),
    GM_getValue:(_key,fallback)=>fallback,
    GM_setValue:(key,value)=>{state.storageWrites.push({key,value});return options.storageHang ? new Promise(()=>{}) : undefined;},
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:statuses}, main:{nW:statuses,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log,
    _log__WEBPACK_IMPORTED_MODULE_6___default:()=>log, loglevel_default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:async ms=>{state.waits.push(ms);state.now+=ms;}},
    misc:{yy:async ms=>{state.waits.push(ms);state.now+=ms;}},
    setting:{Zz:{value:false},Nw:{value:false}},progress:{vm:progress},log:{M6(){}},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async url=>request(url,false),Q2:async(url,predicate)=>request(url,true,predicate)},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(){},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{an:async main=>({dom:node(),text:main.textContent,images:[]}),is(){}},
    collectPseudoContentRules:()=>[], extractRenderedText:p=>p.text,
    buildFontDecodeMap:async(_doc,_win,_font,chars)=>{
      state.ocrStarts.push(state.requests.at(-1).id);
      if(options.inferenceHang)return new Promise(()=>{});
      return new Map(chars.map(ch=>[ch,ch]));
    }
  });
  vm.runInContext(globals+glyphPersistence+ocrContent+chapterCode+
    '\nclass Rule {'+scheduler+'}\nclass Qidian {'+parser+'}\nclass Save {'+saveCode+'}'+
    '\nthis.Chapter=Chapter;this.Rule=Rule;this.Qidian=Qidian;this.Save=Save;'+
    '\nthis.setDirty=n=>{qidianNewGlyphsSincePersist=n; qidianGlyphCache.set("1:1","字");};'+
    '\nthis.glyphState=()=>({dirty:qidianNewGlyphsSincePersist,cacheSize:qidianGlyphCache.size});',ctx);
  const qidian = new ctx.Qidian();
  const chapters = configs.map(cfg=>new ctx.Chapter({bookUrl:'https://www.qidian.com/book/1/',
    chapterUrl:`https://www.qidian.com/chapter/1/${cfg.id}/`,chapterName:`第${cfg.id}章`,
    chapterNumber:cfg.id,isVIP:cfg.vip ?? true,isPaid:true,charset:'UTF-8',options:{expectedChars:2000},
    chapterParse:cfg.syncThrow ? ()=>{throw new Error('synchronous parser failure');}
      : cfg.missingParser ? undefined : qidian.chapterParse.bind(qidian)}));
  const rule = new ctx.Rule(); Object.assign(rule,{concurrencyLimit:1,sleepTime:8000,maxSleepTime:20000});
  const saver = new ctx.Save(); saver.saveType={txt:true,epub:false};
  const originalAdd = saver.addChapter.bind(saver);
  saver.addChapter=async chapter=>{state.saved.push(chapter.chapterName);return originalAdd(chapter);};
  const book={chapters};
  async function run() {
    let failure;
    const task=rule.initChapters(book,saver).then(()=>{state.settled=true;},error=>{failure=error;state.settled=true;});
    // Let immediate browser/DOM work settle before advancing the earliest wait.
    // The 600s timer is retained as a fallback: an unbounded wait must fail this
    // test through the actual watchdog rather than hanging the test runner.
    for(let step=0;step<12&&!state.settled;step++) {
      // Stage instrumentation adds settled promise continuations. Drain them
      // before firing a real outstanding wait, keeping the same timer checks.
      for(let turn=0;turn<500;turn++)await Promise.resolve();
      if(state.settled)break;
      const pending=[...state.timers.entries()].sort((a,b)=>a[1].ms-b[1].ms);
      // A resolved retry sleep may be between attempts for one microtask;
      // allow immediate continuations to install/clear their next timer.
      if(!pending.length)continue;
      const [id,timer]=pending[0];state.timers.delete(id);state.now+=timer.ms;
      state.firedTimers.push(timer.ms);timer.fn();
    }
    assert(state.settled,'fixture did not settle after bounded timer advances');
    await task;
    if(failure&&!window.stopFlag.aborted)throw failure;
    return book;
  }
  return {state,window,ctx,chapters,book,progress,run};
}

const tests=[];const test=(name,fn)=>tests.push({name,fn});
for(const invalid of ['syncThrow','missingParser'])test(`${invalid}: isolated failure cleans every watchdog; next chapter is saved`,async()=>{
  const f=fixture([{id:1,[invalid]:true},{id:2}]);await f.run();
  assert.equal(f.chapters[0].status,statuses.failed);assert(f.chapters[0].errorMessage);
  assert.equal(f.chapters[1].status,statuses.saved);
  assert.equal(f.window.stopFlag.aborted,false);
  assert.deepEqual(f.state.requests.map(request=>request.id),[2]);
  assert.equal(f.state.timers.size,0,'a failed chapter must leave no orphan watchdog');
  assert.deepEqual(f.state.firedTimers,[],'ordinary synchronous failures must not wait for watchdog');
  assert.equal(f.progress.processedChapterIndex,2);
});

test('hanging optional glyph-cache write times out once; valid VIP body and following VIP survive',async()=>{
  const f=fixture([{id:1},{id:2}],{storageHang:true});f.ctx.setDirty(100);await f.run();
  assert.deepEqual(f.state.requests.map(request=>request.id),[1,2]);
  assert.deepEqual(f.state.saved,['第1章','第2章']);
  assert.equal(f.window.stopFlag.aborted,false);
  assert.deepEqual(f.state.firedTimers,[5000]);
  assert.equal(f.state.storageWrites.length,1,'after an uncancellable timeout, do not start overlapping cache writes');
  assert.equal(f.ctx.glyphState().cacheSize,1,'in-memory glyph readings remain available');
  assert.equal(f.ctx.glyphState().dirty,100,'failed persistence must not erase dirty progress');
  assert.deepEqual(f.state.cleanedFrames,[1,2]);
  assert.equal(f.state.timers.size,0);
  assert(f.state.logs.some(entry=>/cache|字形|glyph|Font/i.test(entry.text)&&/timed out|timeout|超时/i.test(entry.text)),
    'optional cache timeout should leave a diagnostic');
});

test('hanging frame-font readiness fails only current chapter before OCR; next chapter succeeds',async()=>{
  const f=fixture([{id:1,fontHang:true},{id:2}]);await f.run();
  assert.deepEqual(f.state.requests.map(request=>request.id),[1,2,1,1],'finish later chapters before two bounded font-readiness recovery rounds');
  assert.equal(f.chapters[0].status,statuses.failed);
  assert.equal(f.chapters[0].qidianFailureKind,'local');
  assert.match(f.chapters[0].errorMessage,/font|字体|字形/i);
  assert.equal(f.chapters[0].retryTime,1);
  assert.equal(f.chapters[1].status,statuses.saved);
  assert.equal(f.window.stopFlag.aborted,false);
  assert.deepEqual(f.state.firedTimers,[20000,20000,20000]);
  assert.deepEqual(f.state.ocrStarts,[2],'never infer using an unloaded fallback font');
  assert.deepEqual(f.state.cleanedFrames,[1,2,1,1],'font failure must release every attempted frame');
  assert.equal(f.state.timers.size,0);
});

test('unresolved in-flight OCR fails its chapter without retry and the following free chapter is saved',async()=>{
  const f=fixture([{id:1},{id:2,vip:false}],{inferenceHang:true});await f.run();
  assert.deepEqual(f.state.requests.map(request=>request.id),[1,2]);
  assert.deepEqual(f.state.ocrStarts,[1]);
  assert.equal(f.window.stopFlag.aborted,false);
  assert.deepEqual(f.state.firedTimers,[600000]);
  assert(!f.window.qidianPauseReason);
  assert.equal(f.chapters[0].status,statuses.failed);
  assert.equal(f.chapters[0].qidianNoAutoRetry,true);
  assert.equal(f.chapters[1].status,statuses.saved);
  assert.deepEqual(f.state.saved,['第2章']);
});

(async()=>{let failed=0;for(const {name,fn} of tests){try{await fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error);}}
console.log(`${tests.length-failed}/${tests.length} v24 failure isolation checks passed`);if(failed)process.exitCode=1;})();
