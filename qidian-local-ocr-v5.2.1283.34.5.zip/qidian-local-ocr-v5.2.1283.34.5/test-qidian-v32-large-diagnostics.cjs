// Exercise the shipped event helper through the shipped logger, including its
// second privacy pass. Synthetic metadata only; no browser or novel content.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const helper = src.slice(src.indexOf('// Bounded local debug diagnostics.'), src.indexOf('function qidianErrorDiagnostic('));
// The production event helper also updates numeric whole-run diagnostics.
// Include that shipped dependency rather than suppressing it with a stub.
const performanceHelpers = src.slice(src.indexOf('function qidianPerformanceCreateState('), src.indexOf('async function qidianStage('));
const logModule = src.indexOf('/***/ "./src/log.ts"');
const start = src.indexOf('if (_setting__WEBPACK_IMPORTED_MODULE_2__', logModule);
const loggerCode = src.slice(start, src.indexOf('\n\n\n/***/ },', start));
assert(helper.includes('function qidianDebugEvent(') && start > logModule);
assert(performanceHelpers.includes('function qidianPerformanceRecordEvent('));
function fixture() {
  const calls = [], saves = [], window = {qidianDebugRun:{id:'large-summary-v32', startedAt:Date.now()-1000}};
  const logger = {level:'info', methodFactory:()=> (...args)=>calls.push(args),
    setLevel(value) { this.level=value; for (const name of ['debug','info','warn','error']) this[name]=this.methodFactory(name); },
    getLevel() { return this.level; }};
  const context = vm.createContext({Error, URL, WeakSet, Set, Blob, Date, window,
    document:{location:{hostname:'www.qidian.com'}},
    _setting__WEBPACK_IMPORTED_MODULE_2__:{Nw:{value:true}},
    loglevel__WEBPACK_IMPORTED_MODULE_1___default:()=>logger,
    file_saver__WEBPACK_IMPORTED_MODULE_0__:{saveAs:(blob,name)=>saves.push({blob,name})},
    qidianRunSummary:()=>context.summary});
  vm.runInContext(helper + performanceHelpers + loggerCode + '\nthis.emit=qidianDebugEvent;this.exportLog=saveLogTextToFile;this.getLog=getLogText;', context);
  return {context, logger, calls, saves, events:()=>context.getLog().split('\n').filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14)))};
}
function row(index, statusName='pending') {
  return {chapterId:String(900000+index), catalogNumber:index+1, title:`第${index+1}章 测试`,
    mode:'vip-ocr', source:'live', attempts:statusName==='failed'?3:0, attempt:statusName==='failed'?3:0,
    status:statusName==='failed'?2:0, statusName, failureKind:null, catalogLocked:false, catalogMarkedPaid:true,
    skipReason:null, accessEvidence:null, stage:statusName==='failed'?'page_load':null,
    errorCode:statusName==='failed'?'page_timeout':null, errorName:statusName==='failed'?'QidianPageTimeoutError':null,
    httpStatus:null, reason:statusName==='failed'?'等待阅读页超时':null, validationAttempt:null,
    quality:{expectedChars:2200,actualChars:0,cjkChars:0,minimumChars:1870,minimumCjk:55,
      unresolvedPrivateUseChars:0,replacementChars:0,complete:false,reason:'below_expected_length'},
    token:'TOKEN_SECRET', contentText:'BODY_SECRET', headers:{cookie:'COOKIE_SECRET'}};
}
function summary(count=749) {
  return {outcome:'paused',selectedCount:count+128,savedCount:128,exportedCount:128,failedCount:1,
    abortedCount:0,unprocessedCount:count-1,inProgressCount:0,resumedCount:125,liveSuccessCount:3,attemptCount:6,
    formatFailureCount:0,skippedCount:0,skipped:[],missingCount:count,
    missing:Array.from({length:count},(_,index)=>row(index,index===0?'failed':'pending')),
    pauseReason:'等待阅读页多次超时，已暂停',error:null,durationMs:10000,
    checkpointStats:{restored:125,written:3,writeFailed:0}};
}
const tests = [];
const test = (name, fn)=>tests.push({name,fn});
test('749 missing chapter rows survive once without losing the summary envelope or filling the ring buffer', async()=>{
  const f=fixture(), data=summary(), before=JSON.stringify(data); f.context.summary=data;
  for (const event of ['selection_result','export_begin','txt_export','export_end','completion_notice','run_summary']) f.context.emit(f.logger,event,data);
  f.context.exportLog();
  const events=f.events(), final=events.find(event=>event.event==='run_summary');
  assert.equal(final.runId,'large-summary-v32'); assert.equal(final.pauseReason,data.pauseReason);
  assert.equal(final.selectedCount,877); assert.equal(final.savedCount,128); assert.equal(final.missingCount,749);
  assert.equal(final.missing.length,12); assert.equal(final.missingOmitted,737); assert.equal(final.missingTotal,749);
  const chunks=events.filter(event=>event.event==='run_details'); assert.equal(chunks.length,19);
  assert.equal(final.detailChunkCount,chunks.length);
  const complete=[...final.missing];
  for (const [index,chunk] of chunks.entries()) {
    assert.equal(chunk.summarySeq,final.seq); assert.equal(chunk.kind,'missing'); assert.equal(chunk.total,749);
    assert.equal(chunk.offset,12+index*40); assert(chunk.missing.length<=40); complete.push(...chunk.missing);
  }
  assert.equal(complete.length,749); assert.deepEqual(complete.map(item=>item.chapterId),data.missing.map(item=>item.chapterId));
  assert(events.every(event=>event.event && event.runId==='large-summary-v32' && Number.isInteger(event.seq)));
  assert(events.filter(event=>event.event!=='run_details').every(event=>(event.missing ?? event.summary?.missing ?? []).length<=12));
  const text=await f.saves[0].blob.text(), buffer=JSON.parse(text.split('\n')[0].slice('[QidianLogBuffer] '.length));
  assert.equal(buffer.droppedChars,0); assert(text.length<900000,`oversized final snapshots: ${text.length}`);
  assert(!text.includes('[node limit]')); for (const secret of ['TOKEN_SECRET','BODY_SECRET','COOKIE_SECRET']) assert(!text.includes(secret));
  assert.equal(JSON.stringify(data),before,'full report objects must stay intact for TXT export');
});
test('more than 750 missing and skipped rows are chunked separately without repeats in export snapshots',()=>{
  const f=fixture(), data=summary(1250); data.skipped=Array.from({length:88},(_,index)=>({...row(5000+index),statusName:'skipped',skipReason:'unsubscribed'})); data.skippedCount=88;
  f.context.emit(f.logger,'run_summary',data); f.context.emit(f.logger,'log_export',{summary:data});
  const events=f.events(), main=events[0];
  for (const key of ['missing','skipped']) {
    const rows=[...main[key],...events.filter(event=>event.event==='run_details'&&event.kind===key).flatMap(event=>event[key])];
    assert.equal(rows.length,data[key].length); assert.equal(new Set(rows.map(item=>item.chapterId)).size,rows.length);
  }
  assert.equal(events.at(-1).summary.missing.length,12); assert.equal(events.at(-1).summary.skipped.length,12);
  assert.equal(events.at(-1).summary.pauseReason,data.pauseReason); assert(!f.context.getLog().includes('[node limit]'));
});
test('unrelated oversized data cannot consume the event envelope or top-level outcome',()=>{
  const f=fixture(); const large=Array.from({length:500},()=>Object.fromEntries(Array.from({length:40},(_,i)=>['count'+i,i])));
  f.logger.info('[QidianDebug] '+JSON.stringify({large,pauseReason:'retained pause',outcome:'paused',event:'fixture',runId:'raw-large-run',schema:2,seq:99}));
  const event=f.events()[0]; assert.equal(event.event,'fixture'); assert.equal(event.runId,'raw-large-run'); assert.equal(event.seq,99);
  assert.equal(event.pauseReason,'retained pause'); assert.equal(event.outcome,'paused');
});
test('small final summaries retain their complete existing shape and issue no detail chunks',()=>{
  const f=fixture(); f.context.emit(f.logger,'run_summary',summary(3));
  const events=f.events(); assert.equal(events.length,1); assert.equal(events[0].missing.length,3);
  assert(!('missingOmitted' in events[0])); assert(!('detailChunkCount' in events[0]));
});
(async()=>{ let passed=0; for (const {name,fn} of tests) {try {await fn(); passed++; console.log('PASS '+name);}catch(error){console.error('FAIL '+name+'\n'+error.stack);process.exitCode=1;}} console.log(`${passed}/${tests.length} v32 large diagnostic checks passed`); })();
