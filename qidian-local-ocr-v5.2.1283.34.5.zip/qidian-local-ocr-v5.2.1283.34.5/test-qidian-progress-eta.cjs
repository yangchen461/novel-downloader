const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const script = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const helperStart = script.indexOf('function formatETA(');
const appStart = script.indexOf('const app = (0,external_Vue_.createApp)({', helperStart);
const appEnd = script.indexOf('app.config.compilerOptions', appStart);
assert.ok(helperStart > 0 && appStart > helperStart && appEnd > appStart);

const options = vm.runInNewContext(
  script.slice(helperStart, appEnd) + '\napp',
  {external_Vue_: {createApp: options => options}, ui_progress: ''}
);
const state = options.data();
Object.assign(state, options.methods);
for (const [key, computed] of Object.entries(options.computed)) {
  Object.defineProperty(state, key, {get: () => computed.call(state)});
}
state.isQidianRun = true;
state.totalChapterNumber = 40;
state.finishedChapterNumber = 1;
state.totalRequestTime = 65000;
assert.equal(options.computed.etaText.call(state), '估算中',
  'one slow first paid chapter must not become a 40-chapter extrapolation');

// The initial OCR model load is expensive; later chapters overlap the
// request-start interval with OCR rather than sleeping for a second 10 s.
for (const [duration, gap] of [[40000,null], [8000,41000], [7000,16000], [6000,15000], [5000,14000]]) {
  state.updateQidianTiming(duration, gap);
}
state.finishedChapterNumber = 5;
assert.equal(options.computed.etaText.call(state), '~8m54s',
  'recent start gaps plus final chapter time should give the remaining ETA');
state.qidianOtherTypePending = true;
assert.equal(options.computed.etaText.call(state), '估算中',
  'current route samples must not estimate a pending different route');

state.reset();
assert.equal(state.qidianStartGaps.length, 0);
assert.equal(state.qidianChapterTimes.length, 0);
assert.equal(state.isQidianRun, false, 'subsequent non-Qidian downloads keep their own ETA');
assert.equal(state.qidianOtherTypePending, false);

console.log('PASS Qidian ETA: cold OCR omitted until samples, overlapping wait counted once, state reset');
