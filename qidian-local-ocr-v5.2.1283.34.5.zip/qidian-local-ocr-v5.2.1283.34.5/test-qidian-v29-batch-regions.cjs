const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');

const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const attemptStart = source.indexOf('function qidianAttemptScope(');
const attemptEnd = source.indexOf('async function qidianStage(', attemptStart);
assert.ok(attemptStart >= 0 && attemptEnd > attemptStart);
const attemptHelpers = source.slice(attemptStart, attemptEnd);
function block(text, start) {
  const from = text.indexOf(start);
  assert(from >= 0, `Missing shipped source block: ${start}`);
  const first = text.indexOf('{', from);
  let depth = 0;
  for (let i = first; i < text.length; i++) {
    if (text[i] === '{') depth++;
    if (text[i] === '}' && --depth === 0) return text.slice(from, i + 1);
  }
  throw new Error(`Unterminated source block: ${start}`);
}
const normalizeCode = block(source, 'function qidianNormalizeGlyphReading(');
const alignedCode = block(source, 'function qidianAlignedBatchReadings(');
const decoderCode = block(source, 'async decodeTextRegions(imageData) {');
const helperContext = vm.createContext({});
vm.runInContext(normalizeCode + alignedCode + '\nthis.align = qidianAlignedBatchReadings;', helperContext);
const align = helperContext.align;
const clone = value => JSON.parse(JSON.stringify(value));
const tests = [];
const test = (name, run) => tests.push({name, run});
const geometry = (count, scale = 2) => ({canvasWidth:80*scale, canvasHeight:(count*64+32)*scale, rowHeight:64, padding:16, scale});
function region(text, row, scale = 2) {
  const top = (16+row*64+8)*scale, bottom = top+48*scale;
  return {text, box:[[16*scale,top],[64*scale,top],[64*scale,bottom],[16*scale,bottom]]};
}
function rejected(regions, count = 3, shape = geometry(count)) {
  const actual = align(regions, count, shape);
  assert.equal(actual.aligned, false);
  assert.deepEqual(clone(actual.readings), [], 'rejected positioning must expose no reusable readings');
  assert.equal(typeof actual.reasonCode, 'string');
  return actual;
}

test('previous decodeFullText implementation remains byte-for-byte unchanged', () => {
  const checksum=crypto.createHash('sha256').update(block(source, 'async decodeFullText(imageData) {')).digest('hex');
  assert.equal(checksum,'739e02678aecbf7d958785d717b3fc77e7f370f4c182485d3679b2f1c63a0288');
});
test('new decoder uses one existing inference and preserves complete text and original four points', async () => {
  const Decoder = vm.runInNewContext('(class RegionDecoder {' + decoderCode + '})');
  const decoder = new Decoder(), steps = [];
  const pixels = {width:160,height:448};
  const engineResult = {parragraphs:[region('甲',1),region('  两字  ',0),{text:'?',box:null}]};
  const saved = clone(engineResult);
  decoder.ensureModelLoaded = async () => {steps.push('load');decoder.modelLoaded=true;};
  decoder.uint8ArrayToImageData = async data => {steps.push('convert');assert.equal(data,'image');return pixels;};
  decoder.ocrEngine = {ocr:async data => {steps.push('infer');assert.equal(data,pixels);return engineResult;}};
  const output = await decoder.decodeTextRegions('image'), regions=output.regions;
  assert.deepEqual(steps,['load','convert','infer']);
  assert.equal(regions[1].text,'两字','full result must not truncate an uncertain multi-character reading');
  assert.equal(output.text,'?\n两字\n甲','same-inference full text preserves previous Y ordering and complete text');
  assert.equal(output.regionSource,'paragraph_regions');
  assert.deepEqual(clone(regions[0].box), saved.parragraphs[0].box, 'do not rescale, sort, or replace image coordinates');
  assert.notEqual(regions[0].box,engineResult.parragraphs[0].box);
  regions[0].box[0][0] = 999;
  assert.deepEqual(engineResult,saved,'returned data must not mutate OCR engine output');
});
test('decoder keeps absent or malformed boxes untrusted and propagates inference failure', async () => {
  const Decoder = vm.runInNewContext('(class RegionDecoder {' + decoderCode + '})');
  const decoder = new Decoder();
  decoder.ensureModelLoaded = async () => {decoder.modelLoaded=true;};
  decoder.uint8ArrayToImageData = async () => ({width:1,height:1});
  decoder.ocrEngine = {ocr:async () => ({parragraphs:[
    {text:'甲'}, {text:'乙',box:[[0,0],[1,0],[1,1]]},
    {text:'丙',box:[[0,0],[1,0],[1,Infinity],[0,1]]},
    {text:'丁',box:[['0',0],[1,0],[1,1],[0,1]]}, {text:123,box:region('甲',0).box},
  ]})};
  const result = (await decoder.decodeTextRegions(new Uint8Array([1]))).regions;
  assert(result.slice(0,4).every(item => item.box === null));
  assert.equal(result[4].text,'');
  decoder.ocrEngine.ocr = async () => ({parragraphs:null});
  assert.deepEqual(clone((await decoder.decodeTextRegions('image')).regions), []);
  decoder.ocrEngine.ocr = async () => {throw new Error('synthetic inference failure');};
  await assert.rejects(decoder.decodeTextRegions('image'), /synthetic inference failure/);
  decoder.modelLoaded=false;
  decoder.ensureModelLoaded=async () => {};
  await assert.rejects(decoder.decodeTextRegions('image'), /model not available/);
  decoder.modelLoaded=true;
  decoder.uint8ArrayToImageData=async () => null;
  await assert.rejects(decoder.decodeTextRegions('image'), /convert image data/);
});
test('decoder prefers original detected src regions to merged paragraph layout', async () => {
  const Decoder = vm.runInNewContext('(class RegionDecoder {' + decoderCode + '})');
  const decoder=new Decoder();
  decoder.ensureModelLoaded=async()=>{decoder.modelLoaded=true;};
  decoder.uint8ArrayToImageData=async()=>({width:160,height:448});
  let docDir=0;
  decoder.ocrEngine={ocr:async()=>({docDir,src:[region('甲',0),region('?',1),region('丙',2)],parragraphs:[{text:'甲\n?\n丙',box:[[32,48],[128,48],[128,416],[32,416]]}]})};
  const output=await decoder.decodeTextRegions('image');
  assert.equal(output.text,'甲\n?\n丙');
  assert.equal(output.regions.length,3,'merged paragraph boxes cannot replace actual detected lines');
  assert.equal(output.regionSource,'source_regions');
  const aligned=align(output.regions,3,geometry(3));
  assert.equal(aligned.aligned,true);
  assert.deepEqual(clone(aligned.readings),['甲',null,'丙']);
  for (const rotation of [90,180,270,'0']) {
    docDir=rotation;
    const rotated=await decoder.decodeTextRegions('image');
    assert.equal(rotated.text,'甲\n?\n丙','rotation must not alter the old complete text API');
    assert.equal(rotated.regionSource,'rotated_coordinates');
    assert(rotated.regions.every(item=>item.box===null));
    rejected(rotated.regions);
  }
});
test('valid complete row positioning safely reorders regions and marks uncertain text only', () => {
  const input = [region('丙',2),region('多字',1),region('甲',0)], saved=clone(input);
  const actual = align(input,3,geometry(3));
  assert.equal(actual.aligned,true);
  assert.deepEqual(clone(actual.readings),['甲',null,'丙']);
  assert.equal(actual.reasonCode,'aligned');
  assert.deepEqual(input,saved);
  for (const value of ['?', '', '\uE000', '甲乙', '漢?']) {
    const result=align([region('甲',0),region(value,1),region('丙',2)],3,geometry(3));
    assert.equal(result.aligned,true);
    assert.equal(result.readings[1],null,'position confidence must not turn an invalid reading into a Han glyph');
  }
});
test('supplementary Han readings and differently scaled original image boxes are preserved', () => {
  for (const scale of [1,2,3]) {
    const result=align([region('\u{20000}',0,scale),region('乙',1,scale)],2,geometry(2,scale));
    assert.equal(result.aligned,true);
    assert.deepEqual(clone(result.readings),['\u{20000}','乙']);
  }
});
test('equal line count cannot authorize duplicate or omitted rows', () => {
  rejected([region('甲',0),region('错',0),region('丙',2)]);
  rejected([region('甲',0),region('乙',1)]);
  rejected([region('甲',0),region('乙',1),region('丙',2),region('错',2)]);
  rejected(null);
  rejected([]);
});
test('cross-row, blank-padding and out-of-canvas boxes reject every batch reading', () => {
  const cross=region('乙',1); cross.box[2][1]=cross.box[3][1]=geometry(3).scale*(16+2*64+1);
  rejected([region('甲',0),cross,region('丙',2)]);
  const padding=region('乙',1); padding.box=padding.box.map(([x])=>[x,0]);
  rejected([region('甲',0),padding,region('丙',2)]);
  for (const coordinate of [-1,geometry(3).canvasWidth+1]) {
    const outside=region('乙',1);outside.box[0][0]=coordinate;
    rejected([region('甲',0),outside,region('丙',2)]);
  }
  const high=region('丙',2);high.box=high.box.map(([x,y])=>[x,y+1000]);
  rejected([region('甲',0),region('乙',1),high]);
});
test('self-intersecting, collapsed, repeated, nonnumeric or exceptional boxes cannot be aligned', () => {
  const boxes=[
    null, [[32,176],[128,272],[128,176],[32,272]],
    [[32,176],[128,176],[128,176],[32,272]],
    [[32,176],[64,176],[96,176],[128,176]],
    [[32,176],[128,176],[128,NaN],[32,272]],
    [[32,176],[128,176],[128,'272'],[32,272]],
  ];
  for (const box of boxes) rejected([region('甲',0),{text:'乙',box},region('丙',2)]);
  rejected([region('甲',0),{get box(){throw new Error('untrusted accessor');}},region('丙',2)]);
  for (const shape of [{...geometry(3),scale:0},{...geometry(3),rowHeight:NaN},{...geometry(3),padding:-1},{...geometry(3),canvasHeight:1}]) {
    rejected([region('甲',0),region('乙',1),region('丙',2)],3,shape);
  }
});

function mapFixture({invalidPosition=false, singleResult='乙', corruptReading=false, legacyComplete=false}={}) {
  const calls={regions:[],single:[],network:0}, cache=new Map(), messages=[];
  const logger=()=>({info:value=>messages.push(value),warn:value=>messages.push(value),error:value=>messages.push(value)});
  const buildCode=block(source,'async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars)');
  const neighborCode=block(source,'function qidianGlyphNeighborContexts(');
  const doc={createElement:()=>{
    const canvas={width:0,height:0,drawn:[]};
    const ctx={canvas,setTransform(){},fillRect(){canvas.drawn=[];},fillText(ch){canvas.drawn.push(ch);}};
    canvas.getContext=()=>ctx;
    return canvas;
  }};
  const readInput=data=>JSON.parse(Buffer.from(data).toString('utf8'));
  const context=vm.createContext({
    window:{stopFlag:{aborted:false}}, URL, Uint8Array,
    qidianNormalizeGlyphReading:helperContext.qidianNormalizeGlyphReading,
    qidianAlignedBatchReadings:align,
    qidianRestoreGlyphCache(){},qidianGlyphCache:cache,qidianNewGlyphsSincePersist:0,QIDIAN_GLYPH_CACHE_LIMIT:30000,
    qidianGlyphFingerprints(_,chars){return new Map(chars.map(ch=>[ch,'fp:'+ch]));},
    _log__WEBPACK_IMPORTED_MODULE_6___default:logger,
    canvasToUint8Array:canvas=>Buffer.from(JSON.stringify(canvas.drawn)),
    qidianDebugEvent(){},qidianStageMetadata(){return {};},
    qidianRecoverUnmappedGlyph:async()=>null,
    fetch(){calls.network++;throw new Error('No page request is permitted in local OCR');},
    qidianOcrDecoder:{
      async decodeTextRegions(data){
        const chars=readInput(data);calls.regions.push(chars.slice());
        return {
          text:chars.map(ch=>legacyComplete?ch:ch==='乙'?'?':ch).join('\n'),
          regions:chars.map((ch,index)=>region(corruptReading?'错':ch==='乙'?'?':ch,invalidPosition?0:index)),
          regionSource:'source_regions',
        };
      },
      async decodeFullText(data){
        const chars=readInput(data);calls.single.push(chars.slice());
        assert.equal(chars.length,1,'a rejected positioned batch must use smaller/isolated inference, not repeat the entire batch');
        return chars[0]==='乙'?singleResult:chars[0];
      },
    },
    ocrSingleChar:async(canvas,ctx,ch,fontFamily,charSize,scale,decoder)=>{
      canvas.drawn=[ch];
      return helperContext.qidianNormalizeGlyphReading(await decoder.decodeFullText(Buffer.from(JSON.stringify([ch]))));
    },
  });
  vm.runInContext(attemptHelpers+neighborCode+buildCode+'\nthis.build=buildFontDecodeMap;',context);
  return {build:()=>context.build(doc,{},'fixture',['甲','乙','丙']),calls,cache,messages};
}
test('actual map builder reuses proven good rows and performs only one isolated retry', async () => {
  const fixture=mapFixture(),map=await fixture.build();
  assert.equal(map.qidianBuildError,undefined,'complete map must not hide an exception');
  assert.deepEqual(clone([...map].sort()),[['乙','乙'],['丙','丙'],['甲','甲']].sort());
  assert.equal(fixture.calls.regions.length,1);
  assert.deepEqual(fixture.calls.single,[['乙']], 'two already-positioned valid rows should not be inferred again');
  assert.equal(fixture.calls.network,0);
  assert.equal(map.qidianMetrics.ocrCalls,2,'region and single-glyph inference both count toward actual OCR work');
});
test('actual map builder refuses all readings of a wrongly positioned batch', async () => {
  const fixture=mapFixture({invalidPosition:true,corruptReading:true}),map=await fixture.build();
  assert.equal(map.qidianBuildError,undefined,'positional rejection should use the normal fallback');
  assert.equal(map.get('甲'),'甲');assert.equal(map.get('乙'),'乙');assert.equal(map.get('丙'),'丙');
  assert.equal(fixture.calls.regions.length,1);
  assert.equal(fixture.calls.single.length,3,'uncertain positioning requires local fallback for each small-batch source');
  assert(fixture.calls.single.every(chars=>chars.length===1));
  assert.equal(fixture.calls.network,0);
  assert(![...fixture.cache.values()].includes('错'),'bad positional guesses must never enter glyph cache');
});
test('original complete batch path remains available without another full-image inference', async () => {
  const fixture=mapFixture({invalidPosition:true,legacyComplete:true}),map=await fixture.build();
  assert.equal(map.qidianBuildError,undefined);
  assert.equal(map.size,3);
  assert.equal(fixture.calls.regions.length,1);
  assert.equal(fixture.calls.single.length,0,'old complete valid output must not be re-inferred because optional boxes are unusable');
  assert.equal(map.qidianMetrics.ocrCalls,1);
  assert.equal(fixture.calls.network,0);
});
test('repeated incomplete local builds retain successful mappings and never cache the unresolved row', async () => {
  const fixture=mapFixture({singleResult:''});
  for (let attempt=0;attempt<2;attempt++) {
    const map=await fixture.build();
    assert.equal(map.qidianBuildError,undefined,'an unresolved row is a classified mapping result, not a fixture exception');
    assert.equal(map.size,2);assert.equal(map.has('乙'),false);
    assert.equal(map.qidianLocalRecoveryFinished,true);
  }
  assert.deepEqual(fixture.calls.regions,[['甲','乙','丙'],['乙']]);
  assert.deepEqual(fixture.calls.single,[['乙'],['乙']]);
  assert.equal(fixture.cache.size,2);
  assert.equal(fixture.cache.has('fp:乙'),false);
  assert.equal(fixture.calls.network,0);
});

(async()=>{
  let failed=0;
  for (const {name,run} of tests) {
    try{await run();console.log('PASS',name);}
    catch(error){failed++;console.error('FAIL',name,'\n',error.stack??error);}
  }
  console.log(`${tests.length-failed}/${tests.length} v29 positioned batch OCR checks passed`);
  if(failed)process.exitCode=1;
})();
