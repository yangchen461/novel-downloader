async function buildFontDecodeMap(fontFamily, uniqueChars) {
  const map = /* @__PURE__ */ new Map();
  const ocrDecoder = new OCRDecoder/* OCRDecoder */.T();
  try {
    const BATCH_SIZE = 30;
    const CHAR_SIZE = 48;
    const ROW_HEIGHT = 64;
    const PADDING = 16;
    const CANVAS_WIDTH = CHAR_SIZE + PADDING * 2;
    const SCALE = 2;
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    for (let i = 0; i < uniqueChars.length; i += BATCH_SIZE) {
      const batch = uniqueChars.slice(i, i + BATCH_SIZE);
      const canvasHeight = batch.length * ROW_HEIGHT + PADDING * 2;
      canvas.width = CANVAS_WIDTH * SCALE;
      canvas.height = canvasHeight * SCALE;
      ctx.setTransform(SCALE, 0, 0, SCALE, 0, 0);
      ctx.fillStyle = "white";
      ctx.fillRect(0, 0, CANVAS_WIDTH, canvasHeight);
      ctx.font = `${CHAR_SIZE}px "${fontFamily}"`;
      ctx.fillStyle = "black";
      ctx.textBaseline = "middle";
      ctx.textAlign = "center";
      for (let j = 0; j < batch.length; j++) {
        const x = CANVAS_WIDTH / 2;
        const y = PADDING + j * ROW_HEIGHT + ROW_HEIGHT / 2;
        ctx.fillText(batch[j], x, y);
      }
      let batchOcrOk = false;
      try {
        const pngData = canvasToUint8Array(canvas);
        const ocrText = await ocrDecoder.decodeFullText(pngData);
        const ocrChars = [...ocrText.replace(/[\s\n\r]/g, "")];
        if (ocrChars.length === batch.length) {
          for (let j = 0; j < batch.length; j++) {
            map.set(batch[j], ocrChars[j]);
          }
          batchOcrOk = true;
        }
      } catch (batchErr) {
        loglevel_default().warn(
          `[jjwxc-font-ocr]\u6279\u6B21 ${i}: \u5168\u6587OCR\u5931\u8D25\uFF0C\u56DE\u9000\u5230\u9010\u5B57: ${batchErr instanceof Error ? batchErr.message : String(batchErr)}`
        );
      }
      if (!batchOcrOk) {
        loglevel_default().warn(
          `[jjwxc-font-ocr]\u6279\u6B21 ${i}: \u671F\u671B ${batch.length} \u4E2A\u5B57\u7B26, \u56DE\u9000\u5230\u9010\u5B57OCR.`
        );
        for (const ch of batch) {
          if (map.has(ch)) continue;
          const single = await ocrSingleChar(
            canvas,
            ctx,
            ch,
            fontFamily,
            CHAR_SIZE,
            SCALE,
            ocrDecoder
          );
          if (single) {
            map.set(ch, single);
          }
        }
      }
      if ((i + BATCH_SIZE) % 150 === 0 || i + BATCH_SIZE >= uniqueChars.length) {
        loglevel_default().info(
          `[jjwxc-font-ocr]\u6620\u5C04\u8FDB\u5EA6: ${Math.min(i + BATCH_SIZE, uniqueChars.length)}/${uniqueChars.length}`
        );
      }
    }
    canvas.width = 0;
    canvas.height = 0;
    return map;
  } catch (e) {
    loglevel_default().error(
      `[jjwxc-font-ocr]\u6784\u5EFA\u89E3\u7801\u6620\u5C04\u8868\u51FA\u9519: ${e instanceof Error ? e.message : String(e)}`
    );
    return map;
  } finally {
    await ocrDecoder.close();
  }
}
