// Frozen .17 fingerprint reference, for offline regression/benchmark only.
// Extracted from the user-provided novel-downloader derivative.
module.exports = function makeLegacy(Math = globalThis.Math, log = () => ({ warn() {} })) {
  const _log__WEBPACK_IMPORTED_MODULE_6___default = log;
function qidianGlyphFingerprint(ctx, ch, fontFamily) {
  const canvas = ctx.canvas;
  // Resetting width/height reallocates the backing bitmap for every character.
  if (canvas.width !== 80) canvas.width = 80;
  if (canvas.height !== 96) canvas.height = 96;
  ctx.fillStyle = "white";
  ctx.fillRect(0, 0, 80, 96);
  ctx.font = `48px ${fontFamily}`;
  ctx.fillStyle = "black";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(ch, 40, 48);
  const pixels = ctx.getImageData(0, 0, 80, 96).data;
  let h1 = 2166136261;
  let h2 = 5381;
  // Read the complete rendered glyph, including antialiasing; the character
  // code and CSS family are deliberately not part of the cross-chapter key.
  for (let i = 0; i < pixels.length; i += 4) {
    const intensity = pixels[i] | pixels[i + 1] << 8 | pixels[i + 2] << 16;
    h1 = Math.imul(h1 ^ intensity, 16777619);
    h2 = Math.imul(h2, 33) ^ intensity;
  }
  return `${h1 >>> 0}:${h2 >>> 0}`;
}
function qidianGlyphFingerprints(ctx, uniqueChars, fontFamily) {
  // Render independent, clipped 80x96 cells in integer-aligned tiles. Their
  // Preserve the original RGB hash algorithm and sample-check against the
  // single-glyph renderer. No fuzzy, source-code-point, or CSS-family key.
  const result = new Map();
  if (!uniqueChars.length) return result;
  const columns = 8;
  const rows = 8;
  const cellWidth = 80;
  const cellHeight = 96;
  const tileWidth = columns * cellWidth;
  try {
    ctx.canvas.width = tileWidth;
    ctx.canvas.height = rows * cellHeight;
    ctx.font = `48px ${fontFamily}`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    for (let start = 0; start < uniqueChars.length; start += columns * rows) {
      const count = Math.min(columns * rows, uniqueChars.length - start);
      const tileHeight = Math.ceil(count / columns) * cellHeight;
      ctx.fillStyle = "white";
      ctx.fillRect(0, 0, tileWidth, tileHeight);
      ctx.fillStyle = "black";
      for (let i = 0; i < count; i++) {
        const x = (i % columns) * cellWidth;
        const y = Math.floor(i / columns) * cellHeight;
        ctx.save();
        try {
          ctx.beginPath();
          ctx.rect(x, y, cellWidth, cellHeight);
          ctx.clip();
          ctx.fillText(uniqueChars[start + i], x + 40, y + 48);
        } finally {
          ctx.restore();
        }
      }
      // One readback for up to 64 glyphs, instead of a readback per glyph.
      const pixels = ctx.getImageData(0, 0, tileWidth, tileHeight).data;
      for (let i = 0; i < count; i++) {
        const x = (i % columns) * cellWidth;
        const y = Math.floor(i / columns) * cellHeight;
        let h1 = 2166136261;
        let h2 = 5381;
        for (let row = 0; row < cellHeight; row++) {
          const from = ((y + row) * tileWidth + x) * 4;
          const to = from + cellWidth * 4;
          for (let p = from; p < to; p += 4) {
            const intensity = pixels[p] | pixels[p + 1] << 8 | pixels[p + 2] << 16;
            h1 = Math.imul(h1 ^ intensity, 16777619);
            h2 = Math.imul(h2, 33) ^ intensity;
          }
        }
        result.set(uniqueChars[start + i], `${h1 >>> 0}:${h2 >>> 0}`);
      }
    }
    for (const index of new Set([0, Math.floor(uniqueChars.length / 2), uniqueChars.length - 1])) {
      const ch = uniqueChars[index];
      if (qidianGlyphFingerprint(ctx, ch, fontFamily) !== result.get(ch)) {
        throw new Error("Tiled pixels differ from single glyph rendering");
      }
    }
    return result;
  } catch (error) {
    // A canvas/readback limitation must not become a new OCR failure mode.
    _log__WEBPACK_IMPORTED_MODULE_6___default().warn(`[QidianFont] Tiled fingerprint unavailable; using single glyphs: ${error?.message ?? error}`);
    result.clear();
    for (const ch of uniqueChars) result.set(ch, qidianGlyphFingerprint(ctx, ch, fontFamily));
    return result;
  }
}

return {single:qidianGlyphFingerprint,tiled:qidianGlyphFingerprints};
};
