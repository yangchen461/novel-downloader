const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '..', 'novel-downloader-qidian-range.user.js'), 'utf8');
const globals = source.slice(source.indexOf('function qidianContentIsComplete('), source.indexOf('/******/ \tvar __webpack_modules__'));
const html = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>恢复按钮浏览器测试</title>
<style>body{font:17px/1.7 sans-serif;margin:50px;max-width:900px}button{font:inherit}#status{padding:20px;background:#eaf1f5;border-radius:8px}</style>
<h1>恢复按钮浏览器测试</h1><p>这是本地合成页面，使用交付脚本的实际恢复函数，没有请求起点。</p>
<p id="status">准备测试</p><button id="start">模拟访问拦截</button><script>
${globals.replace(/<\/script/gi, '<\\/script')}
window.qidianProgressSink = function(s) { document.getElementById('status').textContent = '阶段：' + s.state + '；' + (s.reason || ''); };
window.stopController = new AbortController(); window.stopFlag = window.stopController.signal;
window.qidianAccessRecoveryRun = {}; window.qidianAccessRecoveryEnabled = true;
window.qidianDebugLogger = {info:console.log};
document.getElementById('start').onclick = function() {
  qidianPauseDownload('检测到网站验证，等待手动恢复。', {accessKind:'verification_required',accessEvidence:'blocked_page'});
  var gate = window.qidianAccessRecoveryGate;
  gate.promise.then(function(continued) { document.getElementById('status').textContent = continued ? '恢复成功：队列保留；随机冷却后继续剩余章节。' : '已停止：队列可结束并导出已有章节。'; });
};
</script></html>`;
fs.writeFileSync(path.join(__dirname, 'qa-access-dialog.html'), html);
