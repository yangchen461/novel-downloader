const fs = require('node:fs');
const path = require('node:path');
const source = fs.readFileSync(path.join(__dirname, '..', 'novel-downloader-qidian-range.user.js'), 'utf8');
const globals = source.slice(source.indexOf('function qidianContentIsComplete('), source.indexOf('/******/ \tvar __webpack_modules__'));
const start = source.indexOf('function extractRenderedText(');
const renderer = source.slice(start, source.indexOf('function canvasToUint8Array(', start));
const escape = s => s.replaceAll('&','&amp;').replaceAll('"','&quot;').replaceAll('<','&lt;');
const page = (pseudo, notes, raw = 2066) => `<meta charset="utf-8"><style>p::before{content:"${'乙'.repeat(pseudo)}"}body{font:14px/1.6 sans-serif}</style><h1 class="title">测试章节</h1><main><div class="content-text"><p>${'甲'.repeat(raw)}</p></div><aside class="author-say">${'作者的话'.repeat(notes)}</aside></main>`;
const paragraphPage = '<meta charset="utf-8"><style>body{font:14px/1.6 sans-serif}' +
  Array.from({length:54},(_,i)=>`p:nth-child(${i+1})::before{content:"${'乙'.repeat(37+(i<2?1:0))}"}`).join('') +
  '</style><h1 class="title">逐段正文标记</h1><main>' +
  Array.from({length:54},(_,i)=>`<p><span class="content-text">${'甲'.repeat(38+(i<14?1:0))}</span></p>`).join('') +
  '<aside><p>作者的话</p></aside></main>';
const html = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>章节渲染与完整性验证</title>
<style>body{font:16px/1.7 sans-serif;margin:35px;max-width:1000px}button{font:inherit;padding:10px 20px}iframe{width:30%;height:210px}pre{white-space:pre-wrap;background:#edf3ef;padding:20px}</style>
<h1>章节渲染与完整性验证</h1><p>本地合成页面；使用交付脚本的实际正文提取和校验函数。未访问起点。</p>
<p>依次为CSS完整正文、实际半章与作者的话、54个段落各自标记正文。完整案例原始2066字、CSS生成2000字。</p>
<iframe title="CSS完整正文" srcdoc="${escape(page(2000,0))}"></iframe><iframe title="低于50%的正文与作者的话" srcdoc="${escape(page(0,700,1200))}"></iframe><iframe title="逐段正文标记" srcdoc="${escape(paragraphPage)}"></iframe>
<p><button id="run">验证正文提取</button></p><pre id="result">等待验证</pre><script>
${(globals+'\n'+renderer).replace(/<\/script/gi,'<\\/script')}
document.getElementById('run').onclick=async function(){
  document.getElementById('result').textContent='验证中…';
  const results=[];
  for(const frame of document.querySelectorAll('iframe')){
    const doc=frame.contentDocument, main=doc.querySelector('main'), observation={};
    const capture=()=>qidianCaptureRenderedBody(main,(root,win,owner)=>extractRenderedText(root,win,collectPseudoContentRules(owner),{preserveBlocks:true,exclude:node=>qidianFreeBodyExcluded(node)||['IMG','SOURCE'].includes(node?.tagName)}));
    const body=capture(), firstDiagnostics={};
    const first=qidianReaderBodyIsReady(doc,4013,true,observation,body,firstDiagnostics);
    await new Promise(resolve=>setTimeout(resolve,1100));
    const stableDiagnostics={}, stable=qidianReaderBodyIsReady(doc,4013,true,observation,capture(),stableDiagnostics);
    const check=qidianContentCheck(body.text,4013,true);
    const warning=qidianCreateLengthWarning(body.text,4013,true);
    const savedQuality=qidianChapterContentCheck({contentText:body.text,isVIP:true,options:{expectedChars:4013,qidianLengthWarning:warning}});
    const scope=qidianSelectOcrParagraphs(main,doc.defaultView);
    const ocrText=scope.paragraphs.map(p=>extractRenderedText(p,doc.defaultView,collectPseudoContentRules(doc),{exclude:scope.excluded})).join('');
    results.push({case:frame.title,raw:body.rawBodyChars,rendered:body.text.replace(/\\s/g,'').length,ocrParagraphs:scope.paragraphs.length,ocrSourceChars:ocrText.replace(/\\s/g,'').length,first,stable,bodyAccepted:check.complete,exportable:savedQuality.exportable,lengthUncertain:savedQuality.lengthUncertain,reason:check.reason,authorNotesIncluded:body.text.includes('作者的话')});
  }
  const pass=results[0].raw===2066&&results[0].rendered===4066&&results[0].first&&results[0].bodyAccepted&&results[1].rendered===1200&&results[1].stable&&!results[1].bodyAccepted&&results[1].exportable&&results[1].lengthUncertain&&!results[1].authorNotesIncluded&&results[2].raw===2066&&results[2].rendered===4066&&results[2].bodyAccepted&&results[2].ocrParagraphs===54&&results[2].ocrSourceChars===4066;
  document.getElementById('result').textContent=(pass?'PASS':'FAIL')+'\\n'+JSON.stringify(results,null,2);
};
</script></html>`;
fs.writeFileSync(path.join(__dirname,'qa-rendered-body.html'),html);
