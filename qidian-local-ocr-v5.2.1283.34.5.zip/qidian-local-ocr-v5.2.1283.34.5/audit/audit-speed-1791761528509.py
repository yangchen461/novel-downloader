"""Read-only speed audit of the supplied Qidian run; report metadata, not prose."""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import datetime, timezone, timedelta
import json
import statistics

ROOT = Path(__file__).resolve().parent
LOG = Path(r'C:/Users/CY/Desktop/novel-downloader-1791761528509.log')
TXT = Path(r'C:/Users/CY/Desktop/[作者_北冥清烟]武动之大千主宰 [1-755] [部分下载_745章] [含OCR占位_2章].txt')
rows = LOG.read_text('utf-8-sig').splitlines()
events = []
for line_no, line in enumerate(rows, 1):
    if line.startswith('[QidianDebug] '):
        try:
            item = json.loads(line[14:])
            item['_line'] = line_no
            events.append(item)
        except json.JSONDecodeError:
            pass
summary = next(x for x in reversed(events) if x['event'] == 'run_summary')
buf = json.loads(rows[0].split('] ', 1)[1])
begin, end = events[0]['elapsedMs'], summary['elapsedMs']

def stats(values):
    values = sorted(values)
    return {'count': len(values), 'sumMs': sum(values), 'medianMs': statistics.median(values),
            'p95Ms': values[max(0, int(len(values) * .95) - 1)], 'maxMs': max(values)} if values else {}

stage = defaultdict(list)
for x in events:
    if x['event'] == 'chapter_stage_end':
        stage[x['stage']].append(x.get('durationMs', 0))
pacing = [x for x in events if x['event'] == 'request_pacing']
retry = [x for x in events if x['event'] == 'retry_scheduled']
ocr = [x for x in events if x['event'] == 'ocr_metrics']
ocr_profiles = {}
for profile in sorted({x.get('renderProfile') for x in ocr}):
    xs = [x for x in ocr if x.get('renderProfile') == profile]
    ocr_profiles[profile] = {
        'count': len(xs), 'duration': stats([x['totalMs'] for x in xs]),
        'uniqueGlyphs': sum(x['uniqueGlyphs'] for x in xs),
        'cachedGlyphs': sum(x['cachedGlyphs'] for x in xs),
        'ocrCalls': sum(x['ocrCalls'] for x in xs),
        'zeroOcrCallsCount': sum(x['ocrCalls'] == 0 for x in xs),
    }
    ocr_profiles[profile]['weightedCacheHitRatio'] = ocr_profiles[profile]['cachedGlyphs'] / ocr_profiles[profile]['uniqueGlyphs']

lines = TXT.read_text('utf-8-sig').splitlines()
headers = [lines[i + 1] for i, text in enumerate(lines[:-1]) if text == '…' * 30]
glyph_metadata = []
for line in lines:
    if line.startswith('{"chapterUrl":'):
        entry = json.loads(line)
        tolerance = entry.get('qidianGlyphTolerance', {})
        glyph_metadata.append({'catalogTitle': entry['catalogTitle'], 'distinctCount': tolerance.get('distinctCount'),
                               'occurrenceCount': tolerance.get('occurrenceCount'), 'bodyDigest': tolerance.get('bodyDigest')})
report = {
    'sources': {'log': str(LOG), 'txt': str(TXT)},
    'actualRunVersion': summary['version'],
    'runId': summary['runId'],
    'timeline': {
        'startedLocal': datetime.fromtimestamp((summary['timestampMs']-summary['elapsedMs'])/1000, timezone(timedelta(hours=8))).isoformat(),
        'finishedLocal': datetime.fromtimestamp(summary['timestampMs']/1000, timezone(timedelta(hours=8))).isoformat(),
        'durationMs': summary['durationMs'],
        'earliestRetainedElapsedMs': begin, 'retainedWindowMs': end-begin,
    },
    'truncation': {**buf, 'earliestRetainedSeq': events[0]['seq'], 'lastSummarySeq': summary['seq'], 'retainedDebugRecords': len(events),
                   'limitation': 'Only the final 56m18s are retained, beginning partway through recovery round 1. Earlier failure causes and full-run phase totals are unavailable.'},
    'summary': {k:summary.get(k) for k in ['outcome','selectedCount','savedCount','exportedCount','failedCount','unprocessedCount','inProgressCount',
        'abortedCount','skippedCount','resumedCount','liveSuccessCount','attemptCount','formatFailureCount','toleratedCount','pauseReason','checkpointStats']},
    'missing': [{k:x.get(k) for k in ['catalogNumber','chapterId','title','attempts','errorCode','stage','quality']} for x in summary.get('missing',[])],
    'retainedWindow': {
        'stageDurations': {k:stats(v) for k,v in stage.items()},
        'overlapWarning': 'chapter_init contains chapter_parse and immediate retry waits. chapter_parse contains page_load, ocr, body_check and author_note. ocr contains font_ready and glyph_decode. Do not add parent and child totals.',
        'pacing': {k:stats([x.get(k,0) for x in pacing]) for k in ['waitMs','plannedDelayMs','requestGapMs']},
        'pacingInterpretation': 'waitMs is the additional sleep. plannedDelayMs is the target request-start interval and overlaps processing; requestGapMs includes processing and other delays.',
        'immediateRetryWaits': stats([x['waitMs'] for x in retry]),
        'retryErrorCodes': dict(Counter(x.get('errorCode') for x in retry)),
        'recoveryRounds': [{k:x.get(k) for k in ['event','seq','elapsedMs','recoveryRound','pendingCount','repairCount','savedCount','waitMs','baseWaitMs']} for x in events if x['event'] in ['recovery_round_start','recovery_pass_end']],
        'ocrProfiles': ocr_profiles,
        'ocrWeightedCacheHitRatio': sum(x['cachedGlyphs'] for x in ocr)/sum(x['uniqueGlyphs'] for x in ocr),
        'ocrZeroCallCount': sum(x['ocrCalls']==0 for x in ocr),
        'glyphRepair': {'attempts': sum(x['event']=='glyph_repair_result' for x in events),
                        'improvements': sum(x['event']=='glyph_repair_result' and x.get('improved') for x in events)},
        'recoveredChapter157to299Count': len({x['chapterId'] for x in events if x['event']=='chapter_result' and x.get('statusName')=='saved' and 157<=x.get('catalogNumber',0)<=299}),
    },
    'counterfactual': {
        'description': 'Same retained VIP pacing samples, target interval reduced by 5 seconds, all processing timings and failures held constant. This is an offline estimate, not a measured whole-book speedup.',
        'vipPacingSamples': sum(x['mode']=='vip-ocr' for x in pacing),
        'maximumSavedWaitMsFor5sOffset': sum(min(5000,x['waitMs']) for x in pacing if x['mode']=='vip-ocr'),
    },
    'txt': {'headerCount': len(headers), 'uniqueHeaderCount': len(set(headers)), 'glyphMetadata': glyph_metadata,
            'note': 'The supplied TXT has 745 unique chapter blocks. This structural audit is not a word-for-word proof of transcription accuracy.'},
    'recommendations': [
        'Use the newer 50% threshold already implemented in V34.4: all 9 final missing chapter lengths clear it, avoiding repeated rejection of identical usable captures.',
        'Import the supplied 745-chapter TXT or retain the native checkpoint before resuming; this run restored zero chapters, which forced full work again.',
        'Consider reducing only the ordinary successful VIP request interval with bounded random jitter and adaptive backoff after failures; keep manual access handling, repair rounds and body/font validation.',
        'Keep the persistent fingerprint cache; it eliminated OCR calls on 110 of 190 retained OCR attempts. Custom fonts are the expensive minority, so do not discard fonts readiness or unresolved-glyph recovery to obtain a speed claim.',
        'Persist compact per-run phase totals and outcome counters separately from the rolling log to diagnose the first 6h42m on future runs.',
    ],
}
out = ROOT / 'qidian-speed-1791761528509-audit.json'
out.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', 'utf-8')
print(json.dumps({'report': str(out), 'version': report['actualRunVersion'], 'durationMs': summary['durationMs'],
                  'tailMs': end-begin, 'txtHeaders': len(headers), 'saveWaitMs': report['counterfactual']['maximumSavedWaitMsFor5sOffset']}, ensure_ascii=True))
