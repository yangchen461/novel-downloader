"""Generate an original synthetic font for canvas tests; contains no site fonts."""
from pathlib import Path
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.ttGlyphPen import TTGlyphPen

out = Path(__file__).with_name('fixtures')
out.mkdir(exist_ok=True)
glyphs = {}
names = ['.notdef'] + [f'g{i}' for i in range(800)]
for i, name in enumerate(names):
    pen = TTGlyphPen(None)
    x = -500 if i % 11 == 0 else 35 + i % 9 * 21
    y = -600 if i % 13 == 0 else i % 7 * 19
    w = 1950 if i % 17 == 0 else 230 + i % 37 * 11
    h = 2100 if i % 19 == 0 else 350 + i % 23 * 13
    pen.moveTo((x, y))
    pen.lineTo((x + w, y + 37))
    pen.lineTo((x + w - 45, y + h))
    pen.lineTo((x + 70, y + h - 25))
    pen.closePath()
    glyphs[name] = pen.glyph()
fb = FontBuilder(1000, isTTF=True)
fb.setupGlyphOrder(names)
fb.setupCharacterMap({0x4e00 + i: names[i+1] for i in range(800)})
fb.setupGlyf(glyphs)
fb.setupHorizontalMetrics({name: (1000, 0) for name in names})
fb.setupHorizontalHeader(ascent=800, descent=-200)
fb.setupNameTable({'familyName': 'QidianLocalTest', 'styleName': 'Regular',
                   'uniqueFontIdentifier': 'QidianLocalTest-1',
                   'fullName': 'QidianLocalTest', 'psName': 'QidianLocalTest'})
fb.setupOS2(sTypoAscender=800, sTypoDescender=-200, usWinAscent=2400, usWinDescent=800)
fb.setupPost()
fb.setupMaxp()
fb.save(out / 'synthetic-glyphs.ttf')
print('Created synthetic font fixture (not a Qidian font).')
