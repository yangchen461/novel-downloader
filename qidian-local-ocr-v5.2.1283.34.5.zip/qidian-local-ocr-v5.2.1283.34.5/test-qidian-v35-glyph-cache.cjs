// Exercise the shipped cache, storage timeout, OCR cache-hit path and final flush.
// All data is synthetic. No network, account data or real OCR engine is used.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(start, end, from = 0) {
  const a = source.indexOf(start, from), b = source.indexOf(end, a);
  assert(a >= 0 && b > a, `Missing source boundary: ${start}`);
  return source.slice(a, b);
}
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const cacheCode = take('let qidianOcrDecoder;', 'function qidianGlyphFingerprint(');
const mapCode = take('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars) {', 'async function ocrSingleChar(');
const key = index => `${index + 1}:${index + 2}`;
const entries = (count, start = 0) => Array.from({ length: count }, (_, i) => [key(start + i), '字']);
const tests = [];
const test = (name, run) => tests.push({ name, run });
async function settleUntil(predicate) {
  for (let i = 0; i < 40 && !predicate(); i++) await Promise.resolve();
  assert(predicate(), 'Expected asynchronous state did not settle');
}
function fixture(options = {}) {
  let stored = options.stored ?? [], reads = 0, calls = 0;
  const writes = [], logs = [], events = [], handlers = {};
  const timers = new Map();
  let timerId = 0;
  const log = { info() {}, error() {}, warn(message) { logs.push(message); } };
  const context = vm.createContext({
    Map, Set, Promise, Date, Math, URL, AbortController, structuredClone,
    window: { addEventListener(name, handler) { handlers[name] = handler; } },
    setTimeout: options.manualTimers ? (fn, ms) => { const id = ++timerId; timers.set(id, { fn, ms }); return id; } : setTimeout,
    clearTimeout: options.manualTimers ? id => timers.delete(id) : clearTimeout,
    GM_getValue(storageKey) { reads++; if (options.readError) throw options.readError; assert.equal(storageKey, 'qidian-rendered-glyph-ocr-v1'); return structuredClone(stored); },
    GM_setValue(storageKey, value) {
      calls++;
      assert.equal(storageKey, 'qidian-rendered-glyph-ocr-v1');
      const snapshot = structuredClone(value);
      writes.push(snapshot);
      return options.write ? options.write(snapshot, calls, next => { stored = next; }) : void (stored = snapshot);
    },
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => log,
    _lib_decoders_OCRDecoder__WEBPACK_IMPORTED_MODULE_11__: { T: class { decodeFullText() { throw Error('Unexpected OCR cache miss'); } } }
  });
  vm.runInContext(globals + cacheCode + '\nthis.cacheApi = {\n' +
    'restore: qidianRestoreGlyphCache, persist: qidianPersistGlyphCache, map: qidianGlyphCache,\n' +
    'note: count => { qidianNewGlyphsSincePersist += count; }, dirty: () => qidianNewGlyphsSincePersist,\n' +
    'disabled: () => qidianGlyphPersistDisabled, limit: QIDIAN_STORED_GLYPH_LIMIT\n};', context);
  context.qidianDebugEvent = (_logger, event, data) => events.push({ event, ...data });
  return { ...context.cacheApi, context, writes, logs, events, handlers, timers,
    stored: () => structuredClone(stored), reads: () => reads, calls: () => calls };
}

test('legacy 5000-entry pixel cache restores once under the unchanged storage key', () => {
  const f = fixture({ stored: entries(5000) });
  f.restore(); f.restore();
  assert.equal(f.reads(), 1);
  assert.equal(f.map.size, 5000);
  assert.equal(f.map.get(key(0)), '字');
  assert.equal(f.map.get(key(4999)), '字');
});

test('restoring an oversized cache retains only the newest 30000 valid entries', () => {
  const f = fixture({ stored: entries(30009) });
  f.restore();
  assert.equal(f.limit, 30000);
  assert.equal(f.map.size, 30000);
  assert(!f.map.has(key(8)));
  assert.equal(f.map.get(key(9)), '字');
  assert.equal(f.map.get(key(30008)), '字');
});

test('restored and persisted entries reject placeholders and malformed values but retain supplementary Han', async () => {
  const f = fixture({ stored: [
    ['1:2', '好'], ['3:4', '𠮷'], ['5:6', '□'], ['7:8', '\uFFFD'], ['9:10', '\uE001'],
    ['11:12', '两个'], ['13:14', '。'], ['bad', '字'], ['12345678901:1', '字'], null
  ] });
  f.restore();
  assert.deepEqual([...f.map], [['1:2', '好'], ['3:4', '𠮷']]);
  f.map.set('15:16', '□'); f.map.set('17:18', '多个'); f.map.set('invalid', '字');
  f.note(100); await f.persist();
  assert.deepEqual(f.stored(), [['1:2', '好'], ['3:4', '𠮷']]);
});

test('a refreshed page retains the formerly discarded old 10000 mappings and still fingerprints every glyph before reuse', async () => {
  const first = fixture();
  for (const [hash, char] of entries(15000)) first.map.set(hash, char);
  first.map.set(key(0), '你'); first.map.set(key(9999), '好');
  first.note(15000); await first.persist(true);
  const next = fixture({ stored: first.stored() }); next.restore();
  assert.equal(next.map.size, 15000);
  let fingerprintCalls = 0, seenChars;
  next.context.qidianGlyphFingerprints = (_ctx, chars) => {
    fingerprintCalls++; seenChars = [...chars];
    return new Map([['甲', key(0)], ['乙', key(9999)]]);
  };
  vm.runInContext(mapCode + '\nthis.buildMap = buildFontDecodeMap;', next.context);
  const doc = { createElement: () => ({ width: 0, height: 0, getContext: () => ({}) }) };
  const map = await next.context.buildMap(doc, {}, 'same-css-family-is-not-a-cache-key', ['甲', '乙']);
  assert.equal(fingerprintCalls, 1);
  assert.deepEqual(seenChars, ['甲', '乙']);
  assert.equal(map.get('甲'), '你'); assert.equal(map.get('乙'), '好');
  assert.equal(map.qidianMetrics.ocrCalls, 0);
});

test('persistence stays bounded at 30000 entries and preserves their LRU order', async () => {
  const f = fixture();
  for (const [hash, char] of entries(30004)) f.map.set(hash, char);
  // Cache hits promote an older entry using the same Map delete/set operation.
  f.map.delete(key(0)); f.map.set(key(0), '新');
  f.note(30004); await f.persist(true);
  const saved = f.stored();
  assert.equal(saved.length, 30000);
  assert.deepEqual(saved[0], [key(5), '字']);
  assert.deepEqual(saved.at(-1), [key(0), '新']);
  assert.equal(f.dirty(), 0);
});

test('small batches defer writes and final flush includes the remaining glyphs', async () => {
  const f = fixture();
  f.map.set('1:2', '字'); f.note(99);
  await f.persist(); assert.equal(f.calls(), 0);
  await f.persist(true); assert.equal(f.calls(), 1); assert.equal(f.dirty(), 0);
  await f.persist(true); assert.equal(f.calls(), 1);
});

test('an overlapping final flush serializes snapshots and includes glyphs learned during the first write', async () => {
  const releases = [];
  const f = fixture({ write(snapshot, _call, save) { return new Promise(resolve => releases.push(() => { save(snapshot); resolve(); })); } });
  f.map.set('1:2', '你'); f.note(100);
  const first = f.persist();
  f.map.set('3:4', '好'); f.note(1);
  const last = f.persist(true);
  assert.equal(f.calls(), 1);
  releases[0](); await first;
  await settleUntil(() => releases.length === 2);
  assert.equal(f.dirty(), 1, 'first snapshot must not clear the later glyph');
  releases[1](); await last;
  assert.deepEqual(f.stored(), [['1:2', '你'], ['3:4', '好']]);
  assert.equal(f.dirty(), 0);
});

test('ordinary storage failure is nonfatal and a later final flush can recover', async () => {
  const f = fixture({ write(snapshot, call, save) { if (call === 1) throw Error('temporary storage fault'); save(snapshot); } });
  f.map.set('1:2', '字'); f.note(100);
  await f.persist();
  assert.equal(f.map.get('1:2'), '字'); assert.equal(f.dirty(), 100); assert.equal(f.disabled(), false);
  await f.persist(true);
  assert.equal(f.dirty(), 0); assert.deepEqual(f.stored(), [['1:2', '字']]);
});

for (const name of ['QuotaExceededError', 'NS_ERROR_DOM_QUOTA_REACHED']) {
  test(`${name} disables optional writes and retains usable in-memory mappings`, async () => {
    const f = fixture({ write() { const error = new Error('storage quota'); error.name = name; throw error; } });
    f.map.set('1:2', '字'); f.note(100);
    await f.persist();
    assert.equal(f.disabled(), true); assert.equal(f.dirty(), 100); assert.equal(f.map.get('1:2'), '字');
    f.map.set('3:4', '新'); f.note(1);
    await f.persist(true); assert.equal(f.calls(), 1); assert.equal(f.map.size, 2);
    assert(f.events.some(event => event.event === 'glyph_cache_storage_error' && event.persistenceDisabled));
  });
}

test('a real storage timeout settles without rejecting or queuing more optional writes', async () => {
  const f = fixture({ manualTimers: true, write: () => new Promise(() => {}) });
  f.map.set('1:2', '字'); f.note(100);
  const pending = f.persist();
  assert.equal(f.timers.size, 1);
  const timer = [...f.timers.values()][0]; assert.equal(timer.ms, 5000);
  timer.fn(); await pending;
  assert.equal(f.disabled(), true); assert.equal(f.map.get('1:2'), '字'); assert.equal(f.dirty(), 100);
  assert.equal(f.timers.size, 0);
  await f.persist(true); assert.equal(f.calls(), 1);
});

test('page disposal preserves the live map until a queued final flush includes its newest glyph', async () => {
  const releases = [];
  const f = fixture({ write(snapshot, _call, save) { return new Promise(resolve => releases.push(() => { save(snapshot); resolve(); })); } });
  f.map.set('1:2', '你'); f.note(100);
  const first = f.persist();
  f.map.set('3:4', '好'); f.note(1);
  f.handlers.pagehide({ persisted: false });
  assert.equal(f.map.size, 2);
  releases[0](); await first;
  await settleUntil(() => releases.length === 2);
  releases[1]();
  await settleUntil(() => f.dirty() === 0);
  assert.deepEqual(f.stored(), [['1:2', '你'], ['3:4', '好']]);
});

test('the production run wrapper flushes after an early stop without swallowing its stop reason', async () => {
  const f = fixture();
  f.map.set('1:2', '字'); f.note(1);
  const wrapper = take('  async initChapters(book, saveBookObj) {', '  prewarmVipOCR() {', source.indexOf('class Qidian extends'));
  f.context.Base = class { async initChapters() { throw Error('user stopped'); } };
  const Rule = vm.runInContext(`(class extends Base { ${wrapper} })`, f.context);
  await assert.rejects(new Rule().initChapters({}, {}), /user stopped/);
  assert.equal(f.calls(), 1); assert.equal(f.dirty(), 0); assert.deepEqual(f.stored(), [['1:2', '字']]);
});

(async () => {
  let passed = 0;
  for (const { name, run } of tests) {
    try { await run(); passed++; console.log(`PASS ${name}`); }
    catch (error) { console.error(`FAIL ${name}`); throw error; }
  }
  console.log(`Glyph cache regression: ${passed}/${tests.length} passed`);
})().catch(error => { console.error(error); process.exitCode = 1; });
