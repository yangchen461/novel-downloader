// ==UserScript==
// @name         起点阅读页面诊断（不下载正文）
// @namespace    local-qidian-reader-diagnostics
// @version      5.2.1283.31
// @description  点击按钮导出阅读页结构和固定类别错误，仅供本地排查。
// @match        https://www.qidian.com/chapter/*
// @match        https://read.qidian.com/chapter/*
// @run-at       document-idle
// @noframes
// @grant        none
// ==/UserScript==
(() => {
'use strict';
// Reader diagnostics contain structure and fixed categories, never page text.
function qidianReaderDiagnostics(doc) {
  const nodeText = (node) => {
    try { return String(node?.innerText ?? node?.textContent ?? ""); } catch (_) { return ""; }
  };
  const visible = (node) => {
    try {
      if (!node) return false;
      for (let current = node, depth = 0; current && depth < 12; current = current.parentElement, depth++) {
        if (current.hidden || current.getAttribute?.("aria-hidden") === "true" ||
            current.style?.display === "none" || current.style?.visibility === "hidden") return false;
        const style = doc?.defaultView?.getComputedStyle?.(current);
        if (style?.display === "none" || style?.visibility === "hidden") return false;
      }
      return true;
    } catch (_) { return false; }
  };
  const query = (selector) => { try { return doc?.querySelector?.(selector) ?? null; } catch (_) { return null; } };
  const main = query("main"), body = query(".content-text"), gate = query(".vip-limit-wrap");
  let roots = [];
  try { roots = Array.from(doc?.querySelectorAll?.("main .content-text") ?? []); } catch (_) {}
  const result = { mainTextLength: nodeText(main).trim().length,
    mainNonWhitespaceChars: nodeText(main).replace(/\s/g, "").length,
    contentRootCount: roots.length, visibleContentRootCount: roots.filter(visible).length,
    contentTextLength: nodeText(body).replace(/\s/g, "").length,
    contentRootPresent: !!body, contentRootVisible: visible(body), vipLimitPresent: !!gate, vipLimitVisible: visible(gate),
    purchaseControlCount: 0, genericSubscribeControlCount: 0, loginControlCount: 0,
    verificationControlCount: 0, loadingControlCount: 0, controlCount: 0, omittedControls: 0, controls: [] };
  let nodes = [];
  try { nodes = Array.from(doc?.querySelectorAll?.("main button, main a, main [role='button'], main [role='alert'], main [class*='subscribe'], main [class*='purchase'], main [class*='limit'], main [class*='login'], main [class*='loading'], .vip-limit-wrap, .chapter-subscribe, .chapter-subscribe-wrap, .read-subscribe-wrap, .subscribe-wrap, .subscribe-tip") ?? []); } catch (_) {}
  const seen = new Set();
  for (const node of nodes) {
    if (!node || seen.has(node)) continue;
    seen.add(node);
    if (result.controlCount >= 40) { result.omittedControls++; continue; }
    try {
      const text = nodeText(node).trim();
      let labelKind = "unclassified";
      if (text.length <= 120) {
        if (/(?:自动订阅|取消订阅|已订阅)/.test(text)) labelKind = "subscription_setting";
        else if (/(?:请先登录|登录后(?:阅读|订阅)|^登录$)/.test(text)) labelKind = "login";
        else if (/(?:安全验证|人机验证|身份验证|请完成验证)/.test(text)) labelKind = "verification";
        else if (/(?:本章(?:尚)?未订阅|未订阅本章|订阅(?:本章|后阅读|后继续阅读|后即可)|购买(?:本章|后阅读)|解锁本章|付费后阅读)/.test(text)) labelKind = "chapter_purchase";
        else if (/^(?:立即)?(?:订阅|购买|解锁)(?:章节)?(?:\s*[（(]?\d+\s*(?:起点币|点币)[）)]?)?$/.test(text)) labelKind = "generic_purchase";
        else if (/^(?:正在)?(?:加载|读取)(?:中|失败|\.\.\.|…)*$/.test(text)) labelKind = "loading";
      }
      const isVisible = visible(node);
      const inContent = !!node.closest?.(".content-text");
      const inNavigation = !!node.closest?.("nav, aside, header, footer, #r-authorSay, .authorSay");
      const classes = String(node.className ?? "").split(/\s+/).filter((name) =>
        /^[a-z][a-z0-9_-]{0,59}$/i.test(name) && !/\d{6,}/.test(name) &&
        /subscribe|purchase|vip|limit|read|content|login|verif|loading|btn|button|pay|chapter|unlock/i.test(name) &&
        !/cookie|credential|token|secret|password|passwd|csrf|session/i.test(name)).slice(0, 6);
      const tagName = /^[a-z]{1,12}$/i.test(String(node.tagName ?? "")) ? String(node.tagName).toLowerCase() : "unknown";
      result.controls.push({ tagName, classes, labelKind, visible: isVisible, inContent, inNavigation });
      result.controlCount++;
      if (isVisible && !inContent && !inNavigation) {
        if (labelKind === "chapter_purchase") result.purchaseControlCount++;
        if (labelKind === "generic_purchase") result.genericSubscribeControlCount++;
        if (labelKind === "login") result.loginControlCount++;
        if (labelKind === "verification") result.verificationControlCount++;
        if (labelKind === "loading") result.loadingControlCount++;
      }
    } catch (_) { /* A diagnostic getter must not interrupt page processing. */ }
  }
  return result;
}
function qidianCreatePageErrorProbe(ownerWindow) {
  const probe = { startedAt: Date.now(), available: false, events: [], totalEvents: 0, droppedEvents: 0 };
  let stopped = false;
  const category = (value) => {
    const message = typeof value === "string" ? value : "";
    return /blocked by client|ERR_BLOCKED_BY_CLIENT/i.test(message) ? "blocked_by_client" :
      /chunkload|loading chunk|dynamically imported module|failed to fetch.*module/i.test(message) ? "module_load_failed" :
      /cors|cross.origin/i.test(message) ? "cross_origin_failed" :
      /network|failed to fetch|load failed/i.test(message) ? "network_failed" : "unclassified";
  };
  const record = (event, rejection) => {
    if (stopped) return;
    if (probe.totalEvents >= 12) { probe.droppedEvents++; return; }
    try {
      const target = event?.target;
      const tag = String(target?.tagName ?? "").toLowerCase();
      const resource = !rejection && ["script", "link", "img", "source", "video", "audio"].includes(tag);
      const error = rejection ? event?.reason : event?.error;
      const names = ["Error", "TypeError", "ReferenceError", "SyntaxError", "RangeError", "URIError", "EvalError", "SecurityError", "ChunkLoadError", "AbortError", "NetworkError", "NotAllowedError", "QuotaExceededError"];
      const errorName = names.includes(error?.name) ? error.name : "Error";
      probe.totalEvents++;
      probe.events.push({ reasonCode: rejection ? "unhandled_rejection" : resource ? "resource_error" : "runtime_error",
        errorName, resourceKind: resource ? tag === "link" ? "style" : tag === "img" ? "image" : tag : "none",
        messageKind: category(typeof error?.message === "string" ? error.message : event?.message ?? (typeof error === "string" ? error : "")),
        elapsedMs: Math.max(0, Date.now() - probe.startedAt) });
    } catch (_) { /* Do not retain the original page error object. */ }
  };
  const onError = (event) => record(event, false), onRejection = (event) => record(event, true);
  probe.drain = () => probe.events.splice(0);
  probe.dispose = () => {
    if (stopped) return;
    stopped = true;
    try { ownerWindow?.removeEventListener?.("error", onError, true); } catch (_) {}
    try { ownerWindow?.removeEventListener?.("unhandledrejection", onRejection, false); } catch (_) {}
  };
  try {
    if (typeof ownerWindow?.addEventListener === "function") {
      ownerWindow.addEventListener("error", onError, true);
      ownerWindow.addEventListener("unhandledrejection", onRejection, false);
      probe.available = true;
    }
  } catch (_) { probe.dispose(); }
  return probe;
}


const probe = qidianCreatePageErrorProbe(window);
const button = document.createElement('button');
button.textContent = '导出页面诊断';
button.style.cssText = 'position:fixed;right:20px;bottom:20px;z-index:2147483647;padding:12px;border:1px solid #888;border-radius:8px;background:#fff;color:#222';
button.addEventListener('click', () => {
  const identity = String(location.pathname ?? '').match(/\/chapter\/(\d+)\/(\d+)/);
  const report = {schema:1,version:'5.2.1283.31',event:'manual_reader_diagnostics',
    timestampISO:new Date().toISOString(),bookId:identity?.[1]??null,chapterId:identity?.[2]??null,
    readyState:document.readyState,readerDiagnostics:qidianReaderDiagnostics(document),
    pageErrorProbeAvailable:probe.available,observationMs:Date.now()-probe.startedAt,
    capturedPageErrors:probe.totalEvents,droppedPageErrors:probe.droppedEvents,pageErrors:probe.events.slice(),
    note:'Only fixed categories and structural metadata. No chapter text or credentials. Errors before observation are unknown.'};
  const url=URL.createObjectURL(new Blob([JSON.stringify(report,null,2)],{type:'application/json;charset=utf-8'}));
  const anchor=document.createElement('a');
  anchor.href=url;anchor.download='qidian-reader-diagnostic-'+(report.chapterId??'unknown')+'-'+Date.now()+'.json';
  document.body.appendChild(anchor);anchor.click();anchor.remove();
  setTimeout(()=>URL.revokeObjectURL(url),1000);
});
document.body.appendChild(button);
window.addEventListener('pagehide',()=>probe.dispose(),{once:true});
})();
