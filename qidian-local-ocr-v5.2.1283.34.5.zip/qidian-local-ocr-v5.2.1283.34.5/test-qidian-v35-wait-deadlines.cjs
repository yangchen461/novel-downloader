// Real scheduler/Chapter code with deliberately late browser timer callbacks.
// A requested 1 s slice may actually wake after 4, 30 or 120 seconds.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
function suite(file, expression) {
  const code = fs.readFileSync(path.join(__dirname, file), 'utf8');
  const end = code.search(/^const tests\s*=\s*\[\];/m);
  assert(end > 0, file);
  return vm.runInNewContext(code.slice(0, end) + '\n(' + expression + ')',
    { require, __dirname, AbortController, URL, console });
}
const queue = suite('test-qidian-v19-resilience.cjs', '{fixture,status}');
const full = suite('test-qidian-v34-access-qa.cjs', '{fixture,drain,until}');
const tests = [];
const test = (name, run) => tests.push({ name, run });
const input = count => Array.from({ length: count }, (_, index) =>
  ({ id: index + 1, vip: true, pageMs: 0, ocrMs: 0 }));
const ids = f => Array.from(f.state.starts, row => row.id);
const events = f => Array.from(f.state.logs).filter(line => line.startsWith('[QidianDebug] '))
  .map(line => JSON.parse(line.slice(14)));
const roundedWake = (duration, lateMs) => Math.ceil(duration / lateMs) * lateMs;
const reasons = {
  normal: '章节请求间隔', fast: '连续读取稳定，缩短章节间隔',
  ordinary: '当前章读取失败，等待后重试', page: '当前章页面超时，等待后重试',
  deferred: '准备补试缺章、缺字及字数待核验章节',
  manual: '已确认验证完成，冷却后继续剩余章节'
};
function delayed(f, lateMs, draw = 0) {
  f.ctx.Math.random = () => draw;
  const sleeps = [];
  const sleep = async ms => {
    assert(ms > 0 && ms <= 1000, `countdown requests a cancellable slice: ${ms}`);
    const status = f.window.qidianProgressState ?? {};
    const row = { requestedMs: ms, start: f.state.now, reason: status.reason,
      deadline: status.waitUntil, title: status.title };
    f.state.waits.push(ms);
    f.state.now += Math.max(ms, lateMs);
    row.end = f.state.now; sleeps.push(row);
    f.state.onSleep?.(ms);
  };
  f.ctx.misc.yy = sleep; f.ctx._lib_misc__WEBPACK_IMPORTED_MODULE_0__.yy = sleep;
  return Object.assign(f, { sleeps });
}
function checkDeadline(rows, plannedMs, lateMs) {
  assert.equal(rows.length, Math.ceil(plannedMs / lateMs), 'wake-ups account for real elapsed time');
  assert.equal(rows.at(-1).end - rows[0].start, roundedWake(plannedMs, lateMs));
  assert.equal(rows[0].deadline - rows[0].start, plannedMs);
  assert(rows.every(row => row.deadline === rows[0].deadline), 'UI preserves one absolute deadline');
  assert(rows.at(-1).end >= rows[0].deadline, 'the requested minimum has elapsed');
}

for (const lateMs of [4000, 30000, 120000]) {
  test(`normal VIP spacing uses real elapsed time when each timer wakes after ${lateMs} ms`, async () => {
    const f = delayed(queue.fixture(input(3)), lateMs); await f.run();
    assert.deepEqual(ids(f), [1, 2, 3]);
    assert.equal(f.sleeps.length, 3 * Math.ceil(10000 / lateMs));
    assert.equal(f.state.starts[1].at - f.state.starts[0].at, roundedWake(10000, lateMs));
    assert.equal(f.state.starts[2].at - f.state.starts[1].at, roundedWake(10000, lateMs));
    for (const title of ['第1章', '第2章', '第3章'])
      checkDeadline(f.sleeps.filter(row => row.title === title), 10000, lateMs);
    assert(f.chapters.every(chapter => chapter.status === queue.status.saved));
    assert.equal(f.state.timers.size, 0);
  });

  test(`ordinary retry waits to its 10 second deadline with ${lateMs} ms timer callbacks`, async () => {
    const cfg = input(1); cfg[0].shortFirst = true;
    const f = delayed(queue.fixture(cfg), lateMs, 0.5); await f.chapters[0].init();
    assert.deepEqual(ids(f), [1, 1]);
    assert.equal(f.state.starts[1].at - f.state.starts[0].at, roundedWake(10000, lateMs));
    checkDeadline(f.sleeps.filter(row => row.reason === reasons.ordinary), 10000, lateMs);
    assert.equal(f.chapters[0].status, queue.status.finished);
    assert.equal(f.state.timers.size, 0);
  });

  test(`page timeout retry waits to its 90 second deadline with ${lateMs} ms timer callbacks`, async () => {
    const cfg = input(1); Object.assign(cfg[0], { frameTimeout: 'unknown', frameTimeoutFirst: true });
    const f = delayed(queue.fixture(cfg), lateMs, 0.5); await f.chapters[0].init();
    assert.deepEqual(ids(f), [1, 1]);
    assert.equal(f.state.starts[1].at - f.state.starts[0].at, 20000 + roundedWake(90000, lateMs));
    checkDeadline(f.sleeps.filter(row => row.reason === reasons.page), 90000, lateMs);
    assert.equal(f.chapters[0].status, queue.status.finished);
    assert.equal(f.state.timers.size, 0);
  });

  test(`both deferred rounds honor 55 and 115 second deadlines with ${lateMs} ms callbacks`, async () => {
    const cfg = input(2); cfg[0].glyphFail = true;
    const f = delayed(queue.fixture(cfg), lateMs); await f.run();
    assert.deepEqual(ids(f), [1, 2, 1, 1]);
    const rounds = events(f).filter(row => row.event === 'recovery_round_start');
    assert.deepEqual(rounds.map(row => row.waitMs), [55000, 115000]);
    const sleeps = f.sleeps.filter(row => row.reason === reasons.deferred);
    const firstCount = Math.ceil(55000 / lateMs);
    checkDeadline(sleeps.slice(0, firstCount), 55000, lateMs);
    checkDeadline(sleeps.slice(firstCount), 115000, lateMs);
    assert.equal(f.state.starts[2].at - f.state.starts[1].at, roundedWake(55000, lateMs));
    assert.equal(f.state.starts[3].at - f.state.starts[2].at, roundedWake(115000, lateMs));
    assert.equal(f.chapters[1].status, queue.status.saved);
    assert.equal(f.window.stopFlag.aborted, false);
  });

  test(`manual Continue uses a 55 second absolute cooldown with ${lateMs} ms callbacks`, async () => {
    const cfg = input(2); cfg[0].accessTitle = '安全验证';
    const f = delayed(full.fixture(cfg), lateMs), task = f.run();
    await full.until(() => f.window.qidianAccessRecoveryGate); await full.drain();
    assert.deepEqual(ids(f), [1]);
    f.state.now += 15 * 60 * 1000; // user takes time to complete the website's challenge
    const confirmedAt = f.state.now;
    cfg[0].accessTitle = null;
    assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
    await task;
    const sleeps = f.sleeps.filter(row => row.reason === reasons.manual);
    checkDeadline(sleeps, 55000, lateMs);
    assert.deepEqual(ids(f), [1, 1, 2]);
    assert.equal(f.state.starts[1].at, confirmedAt + roundedWake(55000, lateMs));
    assert.equal(f.state.outputs.length, 1);
    assert.deepEqual(f.state.outputs[0].map(chapter => chapter.id), [1, 2]);
  });
}

test('fast-mode countdowns also end after wall-clock expiry', async () => {
  const f = delayed(queue.fixture(input(7)), 4000); await f.run();
  const fast = f.sleeps.filter(row => row.reason === reasons.fast);
  assert.equal(fast.length, 4, 'two 5 s waits need two delayed 4 s callbacks each');
  assert.equal(f.state.starts[5].at - f.state.starts[4].at, 8000);
  assert.equal(f.state.starts[6].at - f.state.starts[5].at, 8000);
  checkDeadline(fast.slice(0, 2), 5000, 4000);
  checkDeadline(fast.slice(2), 5000, 4000);
});

test('an already-expired manual cooldown is not slept again after a suspended browser resumes', async () => {
  const cfg = input(2); cfg[0].accessTitle = '安全验证';
  const f = delayed(full.fixture(cfg), 30000), task = f.run();
  await full.until(() => f.window.qidianAccessRecoveryGate); await full.drain();
  cfg[0].accessTitle = null;
  const confirmedAt = f.state.now;
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  f.state.now += 120000; // timer/event loop was suspended after the user's click
  await task;
  assert.deepEqual(ids(f), [1, 1, 2]);
  assert.equal(f.state.starts[1].at, confirmedAt + 120000);
  assert.equal(f.sleeps.filter(row => row.reason === reasons.manual).length, 0);
  assert.equal(f.state.outputs.length, 1);
});

test('access pause time expires an old spacing plan and only the new Continue cooldown remains', async () => {
  const f = delayed(full.fixture(input(3)), 4000);
  let challenged = false;
  f.state.onSleep = () => {
    if (f.state.starts.length !== 1 || challenged) return;
    challenged = true; f.ctx.document.title = '安全验证'; f.tick();
  };
  const task = f.run();
  await full.until(() => f.window.qidianAccessRecoveryGate); await full.drain();
  assert.deepEqual(ids(f), [1]);
  f.state.now += 120000;
  const confirmedAt = f.state.now;
  f.ctx.document.title = '章节目录';
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  await task;
  assert.deepEqual(ids(f), [1, 2, 3]);
  assert.equal(f.state.starts[1].at, confirmedAt + 56000);
  checkDeadline(f.sleeps.filter(row => row.reason === reasons.manual), 55000, 4000);
  assert.equal(f.state.outputs.length, 1);
});

for (const kind of ['ordinary', 'page']) {
  test(`Stop after a delayed ${kind} retry tick prevents a request even after the deadline passed`, async () => {
    const cfg = input(1);
    if (kind === 'ordinary') cfg[0].shortFirst = true;
    else Object.assign(cfg[0], { frameTimeout: 'unknown', frameTimeoutFirst: true });
    const f = delayed(queue.fixture(cfg), 120000, 0.5);
    f.state.onSleep = () => f.window.stopController.abort();
    await f.chapters[0].init();
    assert.deepEqual(ids(f), [1]);
    assert.equal(f.sleeps.length, 1);
    assert.equal(f.chapters[0].status, queue.status.aborted);
    assert.equal(f.state.timers.size, 0);
  });
}

test('Stop after an overdue normal tick keeps the saved body and prevents the next chapter', async () => {
  const f = delayed(queue.fixture(input(3)), 120000);
  f.state.onSleep = () => { if (f.state.starts.length === 1) f.window.stopController.abort(); };
  await f.run();
  assert.deepEqual(ids(f), [1]);
  assert.equal(f.chapters[0].status, queue.status.saved);
  assert.equal(f.chapters[1].status, queue.status.pending);
  assert.equal(f.window.stopFlag.aborted, true);
  assert.equal(f.state.timers.size, 0);
});

test('Stop after an overdue manual cooling tick exports the previous chapter without resuming', async () => {
  const cfg = input(3); cfg[1].accessTitle = '安全验证';
  const f = delayed(full.fixture(cfg), 120000), task = f.run();
  await full.until(() => f.window.qidianAccessRecoveryGate); await full.drain();
  f.state.onSleep = () => {
    if (f.window.qidianProgressState?.reason === reasons.manual) f.window.stopController.abort();
  };
  cfg[1].accessTitle = null;
  assert.equal(f.window.qidianAccessRecoveryGate.continue(), true);
  await task;
  assert.deepEqual(ids(f), [1, 2]);
  assert.equal(f.sleeps.filter(row => row.reason === reasons.manual).length, 1);
  assert.equal(f.state.outputs.length, 1);
  assert.deepEqual(f.state.outputs[0].map(chapter => chapter.id), [1]);
  assert.equal(f.window.stopFlag.aborted, true);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, '\n', error.stack); }
  }
  console.log(`${tests.length - failed}/${tests.length} deadline wait checks passed`);
  if (failed) process.exitCode = 1;
})().catch(error => { console.error(error); process.exitCode = 1; });
