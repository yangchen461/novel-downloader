// Run the shipped diagnostics on inert local fixtures. No site is contacted.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b) {
  const start = source.indexOf(a), end = source.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing shipped source boundary: ${a}`);
  return source.slice(start, end);
}
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const normalize = value => JSON.parse(JSON.stringify(value));
const forbidden = ['BODY_CONTENT_SENTINEL', 'COOKIE_CREDENTIAL_SENTINEL', 'QUERY_CREDENTIAL_SENTINEL',
  'RAW_LABEL_SENTINEL', 'ERROR_SECRET_SENTINEL', 'RESOURCE_QUERY_SENTINEL'];
function safe(value) {
  const text = JSON.stringify(value);
  for (const secret of forbidden) assert(!text.includes(secret), `Diagnostic leaked ${secret}`);
  return value;
}
function context(extra = {}) {
  const logs = [];
  const logger = { info: message => logs.push(String(message)), warn() {}, error() {}, debug() {} };
  const window = { qidianDebugLogger: logger, stopController: new AbortController() };
  window.stopFlag = window.stopController.signal;
  const ctx = vm.createContext({ window, URL, Date, AbortController, console: logger,
    GM_getValue: (_key, fallback) => fallback,
    document: { location: { hostname: 'www.qidian.com' } }, ...extra });
  vm.runInContext(globals, ctx);
  return { ctx, window, logs };
}
function control(label, config = {}) {
  const attrs = { class: config.className ?? 'reader-control primary', 'aria-hidden': config.ariaHidden ? 'true' : null };
  return { tagName: (config.tagName ?? 'button').toUpperCase(), textContent: label, innerText: label,
    className: attrs.class, classList: attrs.class.split(/\s+/), hidden: !!config.hidden,
    style: config.style ?? {}, parentElement: null,
    getAttribute: name => attrs[name] ?? null,
    closest(selector) {
      if (config.navigation && /nav|header|footer|aside/.test(selector)) return {};
      if (config.inContent && selector.includes('.content-text')) return {};
      return null;
    }, contains: () => false };
}
function readerDoc(config = {}) {
  const bodyText = 'BODY_CONTENT_SENTINEL正文内容。'.repeat(100);
  const controls = config.controls ?? [];
  const root = config.content === false ? null : { tagName: 'DIV', innerText: bodyText,
    textContent: bodyText, className: 'content-text', style: {}, hidden: false, getAttribute: () => null,
    closest: () => null, querySelectorAll: () => [], contains: node => !!node.inContent };
  const main = config.main === false ? null : { tagName: 'MAIN', innerText: bodyText, textContent: bodyText,
    querySelectorAll: selector => selector === 'p' ? Array(5).fill({}) : controls,
    querySelector: selector => selector.includes('.content-text') ? root : null };
  const gate = config.gate ? { tagName: 'DIV', innerText: 'VIP 未订阅 RAW_LABEL_SENTINEL',
    textContent: 'VIP 未订阅 RAW_LABEL_SENTINEL', hidden: false, style: {}, className: 'vip-limit-wrap',
    getAttribute: () => null, closest: () => null, contains: () => false,
    querySelectorAll: () => controls } : null;
  const doc = { title: '测试章节', cookie: 'COOKIE_CREDENTIAL_SENTINEL',
    URL: 'https://www.qidian.com/chapter/1/119/?token=QUERY_CREDENTIAL_SENTINEL', readyState: 'complete',
    body: { innerText: bodyText, textContent: bodyText }, defaultView: { getComputedStyle: node => node.style ?? {} },
    querySelector(selector) {
      for (const part of selector.split(',').map(value => value.trim())) {
        if (part === 'main') return main;
        if (part === '.content-text') return root;
        if (part === '.vip-limit-wrap') return gate;
      }
      return null;
    },
    querySelectorAll(selector) {
      if (/button|\[role/.test(selector) || /(?:^|[,\s])a(?:$|[,\s])/.test(selector)) return controls;
      if (selector === '.vip-limit-wrap') return gate ? [gate] : [];
      return [];
    } };
  return doc;
}
function eventTarget() {
  const listeners = new Map(), added = [], removed = [];
  const win = { addEventListener(type, fn, options) {
    if (!listeners.has(type)) listeners.set(type, new Set());
    listeners.get(type).add(fn); added.push({ type, fn, options });
  }, removeEventListener(type, fn, options) {
    listeners.get(type)?.delete(fn); removed.push({ type, fn, options });
  }, dispatch(type, event) { for (const fn of listeners.get(type) ?? []) fn(event); },
  fetch() { throw new Error('diagnostics must not fetch'); },
  XMLHttpRequest() { throw new Error('diagnostics must not request'); } };
  return { win, added, removed, count: type => type ? listeners.get(type)?.size ?? 0 : [...listeners.values()].reduce((sum, set) => sum + set.size, 0) };
}
function companionFixture() {
  const sourcePath = path.join(__dirname, 'qidian-reader-diagnostics.user.js');
  assert(fs.existsSync(sourcePath), 'the shipped optional diagnostic script must exist');
  const source = fs.readFileSync(sourcePath, 'utf8');
  const target = eventTarget();
  const state = { created: [], downloads: [], objects: new Map(), revoked: [], timers: [], requests: 0, cookieReads: 0 };
  const doc = readerDoc({ controls: [control('订阅'), control('RAW_LABEL_SENTINEL')] });
  Object.defineProperty(doc, 'cookie', { get() { state.cookieReads++; throw new Error('credentials are unnecessary'); } });
  doc.body.appendChild = node => { state.created.push(node); return node; };
  doc.createElement = tag => {
    assert(['button', 'a'].includes(tag), `diagnostic script must not create requesting elements: ${tag}`);
    const node = { tagName: tag.toUpperCase(), style: {}, listeners: {}, removed: false,
      addEventListener(type, fn) { this.listeners[type] = fn; },
      remove() { this.removed = true; },
      click() {
        if (tag === 'a') state.downloads.push({ name: this.download, blob: state.objects.get(this.href) });
        else this.listeners.click?.({ target: this });
      } };
    return node;
  };
  class ObjectURL extends URL {
    static createObjectURL(blob) { const id = 'blob:local-fixture-' + state.objects.size; state.objects.set(id, blob); return id; }
    static revokeObjectURL(id) { state.revoked.push(id); }
  }
  const request = () => { state.requests++; throw new Error('manual diagnostics must not request'); };
  const ctx = vm.createContext({ window: target.win, document: doc, URL: ObjectURL, Date, Blob,
    location: { pathname: '/chapter/1/119/', search: '?token=QUERY_CREDENTIAL_SENTINEL' },
    setTimeout: fn => state.timers.push(fn), fetch: request, XMLHttpRequest: request,
    GM_xmlhttpRequest: request, GM_download: request, console: { log() {}, error() {}, warn() {} } });
  vm.runInContext(source, ctx);
  const button = state.created.find(node => node.tagName === 'BUTTON');
  assert(button, 'manual diagnostic button is created');
  return { state, target, button };
}
function parserFixture(mode) {
  const parserStart = source.indexOf('  async chapterParse(', source.indexOf('class Qidian extends'));
  const parserEnd = source.indexOf('\n}\n\n\n/***/', parserStart);
  assert(parserStart > 0 && parserEnd > parserStart, 'shipped Qidian parser boundary');
  const target = eventTarget();
  const doc = readerDoc({ main: mode !== 'timeout', content: mode !== 'timeout', controls: [control('订阅')] });
  const state = { requests: 0, removed: 0 };
  const frame = { contentWindow: Object.assign(target.win, { document: doc }),
    remove() { if (!this.removed) { this.removed = true; state.removed++; } } };
  const node = () => ({ children: [], appendChild(child) { this.children.push(child); return child; } });
  const { ctx, logs, window } = context();
  const logger = window.qidianDebugLogger;
  Object.assign(ctx, { document: { location: { hostname: 'www.qidian.com' }, createElement: node },
    _log__WEBPACK_IMPORTED_MODULE_6___default: () => logger,
    _lib_http__WEBPACK_IMPORTED_MODULE_2__: { async Q2(_url, predicate) {
      state.requests++;
      assert.equal(predicate(frame), mode !== 'timeout');
      target.win.dispatch('error', { error: new Error('Loading chunk failed ERROR_SECRET_SENTINEL') });
      if (mode === 'timeout') {
        frame.remove();
        const error = new Error('Frame Timeout!');
        error.frameState = { addressKind: 'requested', readyState: 'complete', bodyPresent: true, bodyTextLength: 100, contentPresent: false, mainParagraphs: 0 };
        throw error;
      }
      return frame;
    } },
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__: { rm() {} },
    qidianGlyphCache: new Map(), qidianPersistGlyphCache: async () => {},
    async ocrContent() {
      if (mode === 'ocr-failed') throw new Error('local OCR failed');
      return { contentText: '完整正常正文内容。'.repeat(350), contentHTML: node() };
    } });
  vm.runInContext('class Qidian {' + source.slice(parserStart, parserEnd) + '}\nthis.Qidian=Qidian;', ctx);
  const parser = new ctx.Qidian(), options = { expectedChars: 2000 };
  return { state, target, options, logs,
    parse: () => parser.chapterParse('https://www.qidian.com/chapter/1/119/', '第119章', true, true, 'UTF-8', options),
    events: () => logs.filter(row => row.startsWith('[QidianDebug] ')).map(row => JSON.parse(row.slice('[QidianDebug] '.length))) };
}
const tests = [];
const test = (name, fn) => tests.push({ name, fn });

test('reader snapshot exposes counts and fixed classifications without page or credential text', () => {
  const { ctx } = context();
  const doc = readerDoc({ controls: [control('RAW_LABEL_SENTINEL'), control('订阅本章'), control('订阅'),
    control('登录'), control('安全验证'), control('加载中')] });
  const snapshot = safe(normalize(ctx.qidianReaderDiagnostics(doc)));
  for (const key of ['mainTextLength', 'contentTextLength', 'purchaseControlCount', 'genericSubscribeControlCount',
    'loginControlCount', 'verificationControlCount', 'loadingControlCount']) {
    assert.equal(typeof snapshot[key], 'number', `${key} must be numeric`);
    assert(Number.isFinite(snapshot[key]) && snapshot[key] >= 0);
  }
  assert.equal(snapshot.mainTextLength, doc.querySelector('main').textContent.length);
  assert.equal(snapshot.contentTextLength, doc.querySelector('.content-text').textContent.length);
  assert.equal(snapshot.contentRootPresent, true);
  assert.equal(snapshot.vipLimitPresent, false);
  assert.equal(snapshot.purchaseControlCount, 1);
  assert.equal(snapshot.genericSubscribeControlCount, 1);
  assert.equal(snapshot.loginControlCount, 1);
  assert.equal(snapshot.verificationControlCount, 1);
  assert.equal(snapshot.loadingControlCount, 1);
  assert.equal(snapshot.controls.length, 6);
  for (const row of snapshot.controls) {
    assert.equal(typeof row.labelKind, 'string');
    assert(row.labelKind.length <= 40);
    assert.equal(typeof row.visible, 'boolean');
    assert.equal(typeof row.inContent, 'boolean');
    assert.equal(typeof row.inNavigation, 'boolean');
    assert(Array.isArray(row.classes));
    assert(!Object.hasOwn(row, 'label') && !Object.hasOwn(row, 'text'));
  }
});

test('reader control flags preserve hidden, body and navigation evidence without reclassifying access', () => {
  const { ctx } = context();
  const snapshot = safe(normalize(ctx.qidianReaderDiagnostics(readerDoc({ content: false, controls: [
    control('订阅', { hidden: true }), control('订阅', { inContent: true }), control('订阅', { navigation: true }) ] }))));
  assert.equal(snapshot.controls[0].visible, false);
  assert.equal(snapshot.controls[1].inContent, true);
  assert.equal(snapshot.controls[2].inNavigation, true);
  assert.equal(snapshot.contentRootPresent, false);
  assert.equal(snapshot.contentTextLength, 0);
  const generic = readerDoc({ content: false, controls: [control('订阅')] });
  assert.equal(normalize(ctx.qidianChapterAccessState(generic, true, 2000)).kind, 'unknown');
  ctx.qidianReaderDiagnostics(generic);
  assert.equal(normalize(ctx.qidianChapterAccessState(generic, true, 2000)).kind, 'unknown',
    'diagnostic discovery cannot change the subscription policy');
});

test('reader snapshots are bounded and tolerate absent or hostile DOM metadata', () => {
  const { ctx } = context();
  const snapshot = safe(normalize(ctx.qidianReaderDiagnostics(readerDoc({ controls: Array.from({ length: 150 }, () => control('订阅')) }))));
  assert(snapshot.controls.length <= 40, 'control snapshot is bounded at 40');
  assert.doesNotThrow(() => ctx.qidianReaderDiagnostics(null));
  const hostile = { get body() { throw new Error('RAW_LABEL_SENTINEL'); }, querySelector() { throw new Error('BODY_CONTENT_SENTINEL'); } };
  assert.doesNotThrow(() => safe(normalize(ctx.qidianReaderDiagnostics(hostile))));
});

test('structured reader snapshots retain useful enum fields after the actual logger sanitizer', () => {
  const { ctx, logs } = context();
  const snapshot = ctx.qidianReaderDiagnostics(readerDoc({ controls: [control('订阅')] }));
  ctx.qidianDebugEvent(null, 'frame_reader_diagnostics', snapshot);
  assert.equal(logs.length, 1);
  const logged = safe(JSON.parse(logs[0].slice('[QidianDebug] '.length)));
  assert.equal(logged.controls[0].labelKind, normalize(snapshot).controls[0].labelKind);
  assert.notEqual(logged.controls[0].tagName, '[redacted]');
  assert.equal(logged.genericSubscribeControlCount, 1);
});

test('CSS evidence retains reader tokens and discards credential or arbitrary identifiers', () => {
  const { ctx } = context();
  const snapshot = safe(normalize(ctx.qidianReaderDiagnostics(readerDoc({ controls: [control('订阅', {
    className: 'read-subscribe COOKIE_CREDENTIAL_SENTINEL subscribe-token-secret reader123456789 unrelatedIdentifier bad=QUERY_CREDENTIAL_SENTINEL'
  })] }))));
  assert.deepEqual(snapshot.controls[0].classes, ['read-subscribe']);
  assert(snapshot.controls[0].classes.length <= 6);
});

test('passive page errors capture bounded classifications and never suppress or retry requests', () => {
  const { ctx } = context(), target = eventTarget();
  const probe = ctx.qidianCreatePageErrorProbe(target.win);
  assert.equal(target.count(), 2);
  assert(target.added.some(row => row.type === 'error'));
  assert(target.added.some(row => row.type === 'unhandledrejection'));
  let prevented = 0;
  const error = new Error('ERROR_SECRET_SENTINEL authorization=COOKIE_CREDENTIAL_SENTINEL');
  target.win.dispatch('error', { message: error.message, error,
    filename: 'https://site.example/script.js?token=RESOURCE_QUERY_SENTINEL',
    target: target.win, preventDefault() { prevented++; } });
  target.win.dispatch('unhandledrejection', { reason: error, preventDefault() { prevented++; } });
  target.win.dispatch('error', { target: { tagName: 'SCRIPT', src: 'https://site.example/a.js?token=RESOURCE_QUERY_SENTINEL' },
    preventDefault() { prevented++; } });
  assert.equal(prevented, 0);
  const rows = safe(normalize(probe.drain()));
  assert.equal(rows.length, 3);
  for (const row of rows) {
    assert.equal(typeof row.reasonCode, 'string');
    assert(!Object.hasOwn(row, 'message') && !Object.hasOwn(row, 'filename') && !Object.hasOwn(row, 'url'));
  }
  assert.deepEqual(normalize(probe.drain()), []);
  probe.dispose();
  assert.equal(target.count(), 0);
  target.win.dispatch('error', { message: 'ERROR_SECRET_SENTINEL' });
  assert.deepEqual(normalize(probe.drain()), []);
  assert.doesNotThrow(() => probe.dispose());
});

test('error probe drops overflow and tolerates hostile event getters', () => {
  const { ctx } = context(), target = eventTarget();
  const probe = ctx.qidianCreatePageErrorProbe(target.win);
  for (let i = 0; i < 250; i++) target.win.dispatch('error', { message: 'ERROR_SECRET_SENTINEL' });
  assert(probe.events.length <= 40, 'passive error queue remains bounded');
  assert(probe.droppedEvents > 0);
  const hostile = { get message() { throw new Error('ERROR_SECRET_SENTINEL'); }, get error() { throw new Error('ERROR_SECRET_SENTINEL'); } };
  assert.doesNotThrow(() => target.win.dispatch('error', hostile));
  safe(normalize(probe.drain()));
  probe.dispose(); assert.equal(target.count(), 0);
});

test('a partial listener installation is cleaned up without replacing a reader failure', () => {
  const { ctx } = context(), target = eventTarget();
  const original = target.win.addEventListener;
  target.win.addEventListener = function (type, fn, options) {
    if (type === 'unhandledrejection') throw new Error('installation unavailable');
    return original.call(this, type, fn, options);
  };
  const probe = ctx.qidianCreatePageErrorProbe(target.win);
  assert.equal(probe.available, false);
  assert.equal(target.count(), 0);
  assert.doesNotThrow(() => probe.dispose());
  const unsupported = ctx.qidianCreatePageErrorProbe(null);
  assert.equal(unsupported.available, false);
  assert.deepEqual(normalize(unsupported.drain()), []);
  assert.doesNotThrow(() => unsupported.dispose());
});

test('unexpected error names cannot smuggle page or credential text into passive diagnostics', () => {
  const { ctx } = context(), target = eventTarget();
  const probe = ctx.qidianCreatePageErrorProbe(target.win);
  target.win.dispatch('error', { error: { name: 'COOKIE_CREDENTIAL_SENTINEL', message: 'ERROR_SECRET_SENTINEL' } });
  const rows = safe(normalize(probe.drain()));
  assert.equal(rows.length, 1);
  assert.equal(rows[0].errorName, 'Error');
  probe.dispose();
});

test('passive error categories are descriptive and never change download access decisions', () => {
  const { ctx, window } = context(), target = eventTarget();
  const probe = ctx.qidianCreatePageErrorProbe(target.win);
  const examples = [
    ['net::ERR_BLOCKED_BY_CLIENT QUERY_CREDENTIAL_SENTINEL', 'blocked_by_client'],
    ['Loading chunk 123 failed ERROR_SECRET_SENTINEL', 'module_load_failed'],
    ['CORS request failed COOKIE_CREDENTIAL_SENTINEL', 'cross_origin_failed'],
    ['Failed to fetch ERROR_SECRET_SENTINEL', 'network_failed'],
    ['403 please subscribe COOKIE_CREDENTIAL_SENTINEL', 'unclassified']
  ];
  for (const [message] of examples) target.win.dispatch('error', { message });
  const rows = safe(normalize(probe.drain()));
  assert.deepEqual(rows.map(row => row.messageKind), examples.map(row => row[1]));
  assert(rows.every(row => row.reasonCode === 'runtime_error'));
  assert.equal(window.stopFlag.aborted, false);
  assert.equal(window.qidianPauseReason, undefined);
  assert.equal(window.failedCount, undefined);
  probe.dispose();
});

test('probe lifetime event cap cannot be bypassed by periodic drains', () => {
  const { ctx } = context(), target = eventTarget();
  const probe = ctx.qidianCreatePageErrorProbe(target.win);
  let captured = 0;
  for (let i = 0; i < 50; i++) {
    target.win.dispatch('error', { message: 'ERROR_SECRET_SENTINEL' });
    captured += probe.drain().length;
  }
  assert.equal(captured, 12);
  assert.equal(probe.totalEvents, 12);
  assert.equal(probe.droppedEvents, 38);
  probe.dispose();
});

test('optional diagnostic script makes no startup request or download and only exports local JSON on click', async () => {
  const f = companionFixture();
  assert.equal(f.button.textContent, '导出页面诊断');
  assert.equal(f.state.downloads.length, 0);
  assert.equal(f.state.objects.size, 0);
  assert.equal(f.state.requests, 0);
  assert.equal(f.state.cookieReads, 0);
  f.target.win.dispatch('error', { error: { name: 'COOKIE_CREDENTIAL_SENTINEL', message: 'ERROR_SECRET_SENTINEL' } });
  f.button.click();
  assert.equal(f.state.downloads.length, 1);
  const downloaded = f.state.downloads[0];
  assert.match(downloaded.name, /^qidian-reader-diagnostic-119-\d+\.json$/);
  assert(downloaded.blob instanceof Blob);
  assert.equal(downloaded.blob.type, 'application/json;charset=utf-8');
  const report = safe(JSON.parse(await downloaded.blob.text()));
  assert.equal(report.version, '5.2.1283.31');
  assert.equal(report.event, 'manual_reader_diagnostics');
  assert.equal(report.bookId, '1');
  assert.equal(report.chapterId, '119');
  assert.equal(report.readerDiagnostics.genericSubscribeControlCount, 1);
  assert.equal(report.pageErrors.length, 1);
  assert.equal(report.pageErrors[0].errorName, 'Error');
  assert.equal(f.state.requests, 0);
  assert.equal(f.state.cookieReads, 0);
  for (const timer of f.state.timers) timer();
  assert.equal(f.state.revoked.length, 1);
});

test('manual snapshots keep prior fixed-category errors across clicks and pagehide removes observers', async () => {
  const f = companionFixture();
  f.target.win.dispatch('unhandledrejection', { reason: new Error('Loading chunk failed ERROR_SECRET_SENTINEL') });
  for (let i = 0; i < 4; i++) f.button.click();
  assert.equal(f.state.downloads.length, 4);
  for (const row of f.state.downloads) {
    const report = safe(JSON.parse(await row.blob.text()));
    assert.equal(report.capturedPageErrors, 1);
    assert.equal(report.pageErrors.length, 1);
    assert.equal(report.pageErrors[0].messageKind, 'module_load_failed');
  }
  assert.equal(f.target.count('error'), 1);
  assert.equal(f.target.count('unhandledrejection'), 1);
  f.target.win.dispatch('pagehide', {});
  assert.equal(f.target.count('error'), 0);
  assert.equal(f.target.count('unhandledrejection'), 0);
  f.target.win.dispatch('error', { message: 'ERROR_SECRET_SENTINEL' });
  f.button.click();
  const final = safe(JSON.parse(await f.state.downloads.at(-1).blob.text()));
  assert.equal(final.capturedPageErrors, 1);
  assert.equal(final.pageErrors.length, 1);
  assert.equal(f.state.requests, 0);
  assert.equal(f.state.cookieReads, 0);
});

for (const mode of ['success', 'ocr-failed', 'timeout']) test(`VIP parser final diagnostics and observer cleanup survive ${mode}`, async () => {
  const f = parserFixture(mode);
  if (mode === 'success') {
    const chapter = await f.parse();
    assert(chapter.contentText.length >= 2000);
  } else await assert.rejects(f.parse(), error => mode === 'timeout' ? error.name === 'QidianPageTimeoutError' : error.message === 'local OCR failed');
  assert.equal(f.state.requests, 1, 'local diagnostic collection adds no chapter request');
  assert.equal(f.state.removed, 1);
  assert.equal(f.target.count(), 0, 'finally removes both observers on every exit');
  const events = safe(f.events());
  const errors = events.filter(row => row.event === 'frame_page_error');
  assert.equal(errors.length, 1);
  assert.equal(errors[0].messageKind, 'module_load_failed');
  assert.equal(errors[0].chapterId, '119');
  const final = events.filter(row => row.event === 'frame_reader_diagnostics');
  assert.equal(final.length, 1);
  assert.equal(final[0].readerDiagnostics.genericSubscribeControlCount, 1);
  assert.equal(final[0].capturedPageErrors, 1);
  assert.equal(final[0].pageErrorProbeAvailable, true);
  assert.equal(final[0].accessKind, 'unknown');
  assert.equal(final[0].accessEvidence, 'no_explicit_gate');
});

test('three consecutive unknown reader failures remain errors while later reads and two recovery rounds continue', async () => {
  // Reuse the real parser and serial scheduler fixture, rather than inventing
  // a second download policy. Only its browser/OCR/storage boundaries are fake.
  const fixturePath = path.join(__dirname, 'test-qidian-v26-subscription.cjs');
  const existing = fs.readFileSync(fixturePath, 'utf8');
  const cut = existing.indexOf('const tests=[];');
  assert(cut > 0, 'subscription fixture boundary');
  const suite = { require, __dirname, console, AbortController, Blob, URL };
  vm.runInNewContext(existing.slice(0, cut) + '\nthis.readerFixture=fixture;this.readerStatuses=statuses;', suite);
  const f = suite.readerFixture([{ id: 1, blank: true }, { id: 2, blank: true }, { id: 3, blank: true }, { id: 4 }]);
  await f.run();
  assert.deepEqual(normalize(f.state.requests.map(row => row.id)), [1, 2, 3, 4, 1, 2, 3, 1, 2, 3]);
  assert.equal(f.window.stopFlag.aborted, false);
  assert(f.chapters.slice(0, 3).every(chapter => chapter.qidianFailureKind === 'page' && chapter.qidianSkipReason !== 'unsubscribed' && chapter.status === suite.readerStatuses.failed && chapter.contentText === null));
  assert(f.chapters.slice(0, 3).every(chapter => chapter.qidianAttemptCount === 3));
  assert.equal(f.chapters[3].status, suite.readerStatuses.saved);
  assert.equal(f.summary().skippedCount, 0);
  assert.equal(f.summary().failedCount, 3);
  assert.equal(f.summary().unprocessedCount, 0);
  assert.equal(f.summary().outcome, 'partial');
});

(async () => {
  let failed = 0;
  for (const { name, fn } of tests) {
    try { await fn(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, error); }
  }
  console.log(`${tests.length - failed}/${tests.length} v27 reader diagnostic checks passed`);
  if (failed) process.exitCode = 1;
})();
