// Real shipped readiness, pseudo-content extraction and parser integration.
// Only browser transport, clock and the physical OCR engine are deterministic.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const dir = __dirname;
const source = fs.readFileSync(path.join(dir, 'novel-downloader-qidian-range.user.js'), 'utf8');
const prior = fs.readFileSync(path.join(dir, 'test-qidian-v32-reader-recovery.cjs'), 'utf8');
const suite = vm.runInNewContext(prior.slice(0, prior.indexOf('const tests = [];')) + '\n({fixture,readerDocument,free})',
  {require,__dirname:dir,AbortController,URL,console,process});
const rendererStart = source.indexOf('function extractRenderedText(');
const rendererEnd = source.indexOf('function canvasToUint8Array(', rendererStart);
assert(rendererStart > 0 && rendererEnd > rendererStart);
const rendererSource = source.slice(rendererStart, rendererEnd);
const ocrStart = source.indexOf('async function ocrContent(');
const ocrEnd = source.indexOf('async function buildFontDecodeMap(',ocrStart);
assert(ocrStart>0 && ocrEnd>ocrStart);
const ocrSource = source.slice(ocrStart,ocrEnd);
const canonical = text => String(text ?? '').replace(/\s/g, '');
function fixture(main, {pseudo='', expected=7000}={}) {
  const doc = suite.readerDocument(main);
  doc.styleSheets = [];
  doc.defaultView.getComputedStyle = (node, part) => ({display:'block',visibility:'visible',opacity:'1',
    content:part==='::before' && node.tagName==='P' ? JSON.stringify(pseudo) : 'none'});
  const f = suite.fixture({docs:[doc],expected});
  f.clock = {now:1000};
  class ClockDate extends Date {static now(){return f.clock.now;}}
  Object.assign(f.ctx,{Node:{TEXT_NODE:3,ELEMENT_NODE:1},Date:ClockDate});
  vm.runInContext(rendererSource,f.ctx);
  f.doc = doc;
  f.render = root => f.ctx.extractRenderedText(root,doc.defaultView,f.ctx.collectPseudoContentRules(doc),{
    preserveBlocks:true,exclude:node=>f.ctx.qidianFreeBodyExcluded(node)||['IMG','SOURCE'].includes(node?.tagName)});
  f.capture = () => f.ctx.qidianCaptureRenderedBody(main,f.render);
  return f;
}
function stableFrameTransport(f) {
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.Q2 = async (_url,predicate) => {
    f.state.frameRequests++;
    let removed=false;
    const frame={contentWindow:{document:f.doc},remove(){if(!removed){removed=true;f.state.framesRemoved++;}}};
    try {
      f.state.readiness.push(predicate(frame));
      f.clock.now+=1000;
      const ready=predicate(frame);f.state.readiness.push(ready);assert.equal(ready,true);
      return frame;
    } catch(error){frame.remove();throw error;}
  };
}
function installRealOcr(f) {
  f.doc.defaultView.document=f.doc;
  f.state.engineInputs=[];
  f.ctx.buildFontDecodeMap=async(_doc,_win,_font,chars,texts)=>{
    f.state.ocrCalls++;f.state.engineInputs.push({chars:Array.from(chars),texts:Array.from(texts)});
    const map=new Map(chars.map(ch=>[ch,ch]));map.qidianLocalRecoveryFinished=true;return map;
  };
  vm.runInContext(ocrSource,f.ctx);
}
function paragraphFixture({kind='span',pseudoAt='P'}={}) {
  const main=new suite.free.ElementNode('main'),paragraphs=[],prefixes=new Map();
  for(let index=0;index<54;index++){
    const rawLength=38+(index===53?14:0),pseudoLength=37+(index===53?2:0);
    const p=main.appendChild(new suite.free.ElementNode('p','',kind==='p'?{class:'content-text'}:{}));
    const first=p.appendChild(new suite.free.ElementNode('span','甲'.repeat(7),kind==='span'?{class:'content-text'}:{}));
    p.appendChild(new suite.free.ElementNode('span',String.fromCodePoint(0x4E30+index).repeat(rawLength-7)));
    prefixes.set(pseudoAt==='P'?p:first,'乙'.repeat(pseudoLength));paragraphs.push(p);
  }
  const f=fixture(main);
  f.doc.defaultView.getComputedStyle=(node,part)=>({display:node.tagName==='SPAN'?'inline':'block',visibility:'visible',opacity:'1',
    fontFamily:node.className==='content-text'?'qidian-fragment-font':'generic',
    content:part==='::before'&&prefixes.has(node)?JSON.stringify(prefixes.get(node)):'none'});
  return {f,main,paragraphs,expected:paragraphs.map(p=>f.render(p)).map(text=>text.trim()).join('\n')};
}
const tests=[];
const test=(name,run)=>tests.push({name,run});

test('a VIP chapter with raw2066 and CSS-rendered4066 enters OCR and passes the authorized50% final length check',async()=>{
  const f=fixture(suite.free.bodyWith(['甲'.repeat(2066)]).main,{pseudo:'乙'.repeat(2000)});
  const rendered=f.capture();assert.equal(rendered.rawBodyChars,2066);assert.equal(canonical(rendered.text).length,4066);
  f.ctx.ocrContent=async main=>{f.state.ocrCalls++;const text=f.render(main);return {contentText:text,contentHTML:new suite.free.ElementNode('div',text)};};
  const result=await new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',true,true,'UTF-8',f.options,0);
  assert.equal(canonical(result.contentText),'乙'.repeat(2000)+'甲'.repeat(2066));
  assert.equal(f.options.qidianValidation.complete,true);assert.equal(f.options.qidianValidation.minimumChars,3500);
  assert.equal(f.state.frameRequests,1);assert.equal(f.state.ocrCalls,1);assert.equal(f.state.framesRemoved,1);
  const row=f.events().find(row=>row.event==='frame_wait_state');
  assert.equal(row.expectedChars,7000);assert.equal(row.bodyReadiness.rawBodyChars,2066);
  assert.equal(row.bodyReadiness.bodyChars,4066);assert.equal(row.bodyReadiness.renderedTextUsed,true);
  assert(!JSON.stringify(row).includes('甲甲甲'));
});

for(const shape of [{kind:'span',pseudoAt:'P'},{kind:'span',pseudoAt:'SPAN'},{kind:'p',pseudoAt:'P'}])
test(`54 paragraph-scoped ${shape.kind} roots include ${shape.pseudoAt} pseudo text and complete real VIP parsing`,async()=>{
  const {f,main,expected}=paragraphFixture(shape);
  const raw=f.ctx.qidianCaptureFreeBody(main),rendered=f.capture();
  assert.equal(raw.rootSelection.contentRootCount,54);assert.equal(raw.rootSelection.eligibleRootCount,54);
  assert.equal(raw.rootSelection.reason,'paragraph_content_roots');assert.equal(raw.paragraphCount,54);
  assert.equal(canonical(raw.text).length,2066);assert.equal(rendered.rawBodyChars,2066);
  assert.equal(canonical(rendered.text).length,4066);assert.equal(canonical(rendered.text),canonical(expected));
  installRealOcr(f);
  const result=await new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',true,true,'UTF-8',f.options,0);
  assert.equal(result.contentText,expected);assert.equal(f.options.qidianValidation.complete,true);
  assert.equal(f.options.qidianValidation.actualChars,4066);assert.equal(f.options.qidianValidation.minimumChars,3500);
  assert.equal(f.state.frameRequests,1);assert.equal(f.state.ocrCalls,1);assert.equal(f.state.framesRemoved,1);
  assert.equal(f.state.engineInputs[0].texts.length,54);
});

test('free static and rendered capture accept paragraph fragments while unrelated paragraphs cannot pad or reorder them',async()=>{
  const {f,main,paragraphs,expected}=paragraphFixture();
  for(const [tag,attrs] of [['nav',{}],['section',{id:'r-authorSay'}],['div',{hidden:''}]]){
    const wrapper=main.appendChild(new suite.free.ElementNode(tag,'',attrs));
    const p=wrapper.appendChild(new suite.free.ElementNode('p'));
    p.appendChild(new suite.free.ElementNode('span','丁'.repeat(5000),{class:'content-text'}));
  }
  main.appendChild(new suite.free.ElementNode('p','戊'.repeat(5000)));
  paragraphs[0].appendChild(new suite.free.ElementNode('span','丙',{class:'content-text'}));
  // Re-adopt nodes appended after the fixture document was created.
  const adopt=node=>{node.ownerDocument=f.doc;for(const child of node.childNodes??[])adopt(child);};adopt(main);
  const raw=f.ctx.qidianCaptureFreeBody(main),scope=f.ctx.qidianResolveBodyRoots(main);
  assert.equal(raw.paragraphCount,54);assert.equal(scope.paragraphs.length,54);assert.equal(raw.rootSelection.eligibleRootCount,55);
  assert.equal(canonical(raw.text).length,2067);assert(!raw.text.includes('丁'));assert(!raw.text.includes('戊'));
  assert.equal(scope.fontRoot,paragraphs[0].querySelector('.content-text'));
  const result=await f.parseAttempt(1);
  assert.equal(canonical(f.ctx.qidianChapterBodyText({contentText:result.contentText,options:f.options})),canonical(expected).replace(/^(乙+甲+.{31})/u,'$1丙'));
  assert.equal(f.options.qidianValidation.complete,true);assert.equal(f.state.ocrCalls,0);assert.equal(f.state.attachmentRequests,0);
});

test('a single inline root includes its complete paragraph and multiple inline roots in that paragraph are captured once',()=>{
  const main=new suite.free.ElementNode('main'),p=main.appendChild(new suite.free.ElementNode('p','甲'));
  p.appendChild(new suite.free.ElementNode('span','乙',{class:'content-text'}));
  const f=fixture(main,{expected:3});assert.equal(f.ctx.qidianCaptureFreeBody(main).canonical,'甲乙');
  p.appendChild(new suite.free.ElementNode('span','丙',{class:'content-text'}));
  const raw=f.ctx.qidianCaptureFreeBody(main);assert.equal(raw.canonical,'甲乙丙');assert.equal(raw.paragraphCount,1);
  assert.equal(raw.rootSelection.eligibleRootCount,2);assert.equal(raw.rootSelection.reason,'paragraph_content_roots');
});

test('the static free parser saves all54 paragraph fragments in catalogue order without a frame or OCR',async()=>{
  const main=new suite.free.ElementNode('main'),texts=[];
  for(let index=0;index<54;index++){
    const text=String.fromCodePoint(0x4E30+index).repeat(74+(index===53?4:0));texts.push(text);
    const p=main.appendChild(new suite.free.ElementNode('p'));
    p.appendChild(new suite.free.ElementNode('span',text.slice(0,7),{class:'content-text'}));
    p.appendChild(new suite.free.ElementNode('span',text.slice(7)));
  }
  const f=fixture(main,{expected:4000});
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.pG=async()=>{f.state.htmlRequests++;return f.doc;};
  const result=await f.parseAttempt(0);
  assert.equal(canonical(result.contentText),texts.join(''));assert.equal(f.options.qidianValidation.actualChars,4000);
  assert.equal(f.options.qidianValidation.complete,true);assert.equal(f.state.htmlRequests,1);
  assert.equal(f.state.frameRequests,0);assert.equal(f.state.ocrCalls,0);assert.equal(f.state.attachmentRequests,0);
});

test('free rendered recovery preserves CSS text and excludes author notes, navigation and image metadata',async()=>{
  const body=suite.free.bodyWith(['甲'.repeat(2066)]);
  body.content.appendChild(new suite.free.ElementNode('nav','NAV_SHOULD_NOT_APPEAR'.repeat(300)));
  body.content.appendChild(new suite.free.ElementNode('section','AUTHOR_SHOULD_NOT_APPEAR'.repeat(300),{id:'r-authorSay'}));
  body.content.appendChild(new suite.free.ElementNode('img','',{src:'https://images.example.invalid/x.png',alt:'ALT_SHOULD_NOT_APPEAR'.repeat(300)}));
  const f=fixture(body.main,{pseudo:'乙'.repeat(2000)});
  const result=await f.parseAttempt(1);
  assert.equal(canonical(f.ctx.qidianChapterBodyText({contentText:result.contentText,options:f.options})),'乙'.repeat(2000)+'甲'.repeat(2066));
  assert(!result.contentText.includes('NAV_SHOULD_NOT_APPEAR'));assert(!result.contentText.includes('AUTHOR_SHOULD_NOT_APPEAR'));
  assert(!result.contentText.includes('ALT_SHOULD_NOT_APPEAR'));assert(result.contentText.includes('[正文图片链接]'));
  assert.equal(f.options.qidianValidation.minimumChars,3500);assert.equal(f.options.qidianValidation.complete,true);
  assert.equal(f.state.htmlRequests,0);assert.equal(f.state.frameRequests,1);assert.equal(f.state.ocrCalls,0);
  assert.equal(f.state.attachmentRequests,0);
});

test('free rendered recovery retains visible BR line breaks without changing legacy OCR extraction',async()=>{
  const body=suite.free.bodyWith(['甲'.repeat(100)]),p=body.content.querySelector('p');
  p.appendChild(new suite.free.ElementNode('br'));
  p.appendChild(new suite.free.ElementNode('span','乙'.repeat(100)));
  const f=fixture(body.main,{expected:200});
  const result=await f.parseAttempt(1);
  assert.equal(result.contentText,'甲'.repeat(100)+'\n'+'乙'.repeat(100));
  assert.equal(f.ctx.extractRenderedText(p,f.doc.defaultView,[]),'甲'.repeat(100)+'乙'.repeat(100));
});

for(const vip of [false,true]) test(`a stable body below50% retains only the scoped text with an explicit warning and still fails completeness (${vip?'VIP':'free'})`,async()=>{
  const f=fixture(suite.free.bodyWith(['甲'.repeat(2066)]).main);stableFrameTransport(f);
  if(vip)f.ctx.ocrContent=async()=>{f.state.ocrCalls++;return {contentText:'甲'.repeat(2066),contentHTML:new suite.free.ElementNode('div','甲'.repeat(2066))};};
  const result=await new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',vip,true,'UTF-8',f.options,1);
  assert.equal(result.contentText,'甲'.repeat(2066));
  assert.equal(f.options.qidianLengthWarning.actualChars,2066);
  assert.equal(f.options.qidianValidation.exportable,true);
  assert.equal(f.ctx.qidianContentIsComplete(result.contentText,7000,vip),false);
  assert.deepEqual(Array.from(f.state.readiness),[false,true]);assert.equal(f.options.qidianValidation.complete,false);
  assert.equal(f.options.qidianValidation.reason,'below_expected_length');assert.equal(f.options.qidianValidation.minimumChars,3500);
  assert.equal(f.state.frameRequests,1);assert.equal(f.state.framesRemoved,1);assert.equal(f.window.stopFlag.aborted,false);
});

test('the real VIP parser retains a warned short body without padding it with author, navigation, hidden or outside-root paragraphs',async()=>{
  const body=suite.free.bodyWith(['甲'.repeat(2066)]);
  for(const [tag,attributes,ch] of [['section',{id:'r-authorSay'},'乙'],['nav',{},'丙'],['div',{hidden:''},'丁']]){
    const wrapper=body.content.appendChild(new suite.free.ElementNode(tag,'',attributes));
    wrapper.appendChild(new suite.free.ElementNode('p',ch.repeat(3000)));
  }
  body.main.appendChild(new suite.free.ElementNode('p','戊'.repeat(3000)));
  const f=fixture(body.main);stableFrameTransport(f);installRealOcr(f);
  const result=await new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',true,true,'UTF-8',f.options,0);
  assert.equal(result.contentText,'甲'.repeat(2066));
  assert.equal(f.options.qidianLengthWarning.actualChars,2066);
  assert.equal(f.options.qidianValidation.exportable,true);
  assert.equal(f.options.qidianValidation.actualChars,2066);assert.equal(f.options.qidianValidation.minimumChars,3500);
  assert.equal(f.options.qidianValidation.complete,false);assert.equal(f.state.ocrCalls,1);
  assert.deepEqual(f.state.engineInputs,[{chars:['甲'],texts:['甲'.repeat(2066)]}]);
  assert.equal(f.state.persistCalls,1);assert.equal(f.state.framesRemoved,1);assert.equal(f.window.stopFlag.aborted,false);
});

test('the real VIP parser saves a full body without tolerance or content leaked from excluded paragraphs',async()=>{
  const body=suite.free.bodyWith(['甲'.repeat(4066)]);
  const nav=body.content.appendChild(new suite.free.ElementNode('nav'));
  nav.appendChild(new suite.free.ElementNode('p','\uE123'.repeat(30)));
  const hidden=body.content.appendChild(new suite.free.ElementNode('div','',{hidden:''}));
  hidden.appendChild(new suite.free.ElementNode('p','\uE124'.repeat(30)));
  body.main.appendChild(new suite.free.ElementNode('p','\uE125'.repeat(30)));
  const f=fixture(body.main);installRealOcr(f);
  const result=await new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',true,true,'UTF-8',f.options,0);
  assert.equal(result.contentText,'甲'.repeat(4066));assert.equal(f.options.qidianGlyphTolerance,null);
  assert.equal(f.options.qidianValidation.complete,true);assert.equal(f.state.ocrCalls,1);
  assert.deepEqual(f.state.engineInputs,[{chars:['甲'],texts:['甲'.repeat(4066)]}]);
  assert.equal(f.state.persistCalls,1);assert.equal(f.state.framesRemoved,1);
});

test('document replacement and changing content reset the stable-body observation even when raw counts match',()=>{
  const a=fixture(suite.free.bodyWith(['甲'.repeat(2066)]).main),b=fixture(suite.free.bodyWith(['甲'.repeat(2066)]).main);
  const observation={},diagnostics={};
  assert.equal(a.ctx.qidianReaderBodyIsReady(a.doc,7000,true,observation,a.capture(),diagnostics),false);
  a.clock.now+=1000;assert.equal(a.ctx.qidianReaderBodyIsReady(a.doc,7000,true,observation,a.capture(),diagnostics),true);
  assert.equal(a.ctx.qidianReaderBodyIsReady(b.doc,7000,true,observation,b.capture(),diagnostics),false);
  a.clock.now+=1000;assert.equal(a.ctx.qidianReaderBodyIsReady(b.doc,7000,true,observation,b.capture(),diagnostics),true);
  b.doc.querySelector('.content-text').textContent='乙'.repeat(2066);
  assert.equal(a.ctx.qidianReaderBodyIsReady(b.doc,7000,true,observation,b.capture(),diagnostics),false);
});

test('a valid100-character VIP body without catalogue length can finish after structural stability',async()=>{
  const f=fixture(suite.free.bodyWith(['甲'.repeat(100)]).main,{expected:0});stableFrameTransport(f);
  f.ctx.ocrContent=async()=>{f.state.ocrCalls++;return {contentText:'甲'.repeat(100),contentHTML:new suite.free.ElementNode('div','甲'.repeat(100))};};
  const result=await new f.ctx.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章 测试',true,true,'UTF-8',f.options,0);
  assert.equal(result.contentText,'甲'.repeat(100));assert.equal(f.options.qidianValidation.complete,true);
  assert.equal(f.options.qidianValidation.minimumChars,100);assert.deepEqual(Array.from(f.state.readiness),[false,true]);
});

test('loading controls, empty roots, explicit access and purchase pages never become structural bodies',()=>{
  const empty=fixture(suite.free.bodyWith(['']).main);
  empty.doc.querySelector('main').appendChild(new suite.free.ElementNode('nav','甲'.repeat(8000)));
  assert.equal(empty.ctx.qidianReaderBodyIsReady(empty.doc,4013,true,{},empty.capture()),false);
  const loading=fixture(suite.free.bodyWith(['甲'.repeat(4066)]).main);
  const label=new suite.free.ElementNode('div','正在加载正文');
  const all=loading.doc.querySelectorAll.bind(loading.doc);
  loading.doc.querySelectorAll=selector=>selector.startsWith('main button')?[label]:all(selector);
  assert.equal(loading.ctx.qidianReaderBodyIsReady(loading.doc,4013,true,{},loading.capture()),false);
  const access=fixture(suite.free.bodyWith(['']).main);access.doc.title='安全验证';
  assert.equal(access.ctx.qidianReaderBodyIsReady(access.doc,4013,true),false);
  const purchase=fixture(suite.free.bodyWith(['']).main);
  purchase.doc.querySelector('main').appendChild(new suite.free.ElementNode('div','订阅本章后阅读',{class:'vip-limit-wrap'}));
  assert.equal(purchase.ctx.qidianReaderBodyIsReady(purchase.doc,4013,true),false);
});

test('two visible content roots cannot be joined by the rendered extractor to manufacture a complete body',()=>{
  const a=suite.free.bodyWith(['甲'.repeat(2066)]),b=suite.free.bodyWith(['乙'.repeat(2066)]);a.main.appendChild(b.content);
  const f=fixture(a.main,{pseudo:'丙'.repeat(2000)});
  assert.equal(f.capture(),null);assert.equal(f.ctx.qidianReaderBodyIsReady(f.doc,4013,true,{},f.capture()),false);
});

(async()=>{let failed=0;for(const {name,run} of tests){try{await run();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,'\n',error.stack);}}console.log(`${tests.length-failed}/${tests.length} rendered readiness checks passed`);if(failed)process.exitCode=1;})().catch(error=>{console.error(error);process.exitCode=1;});
