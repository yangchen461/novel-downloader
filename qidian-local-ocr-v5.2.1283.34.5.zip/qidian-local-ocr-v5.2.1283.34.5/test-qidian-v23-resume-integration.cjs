// Exercise the shipped checkpoint, restore, scheduler, parser, saver and TXT code.
// Only browser/HTTP/OCR and Tampermonkey storage boundaries are replaced.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b, from = 0) {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing shipped implementation boundary: ${a}`);
  return src.slice(start, end);
}
const status = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode = take('class ChapterAbortError', '\n\n/***/ },');
const scheduler = take('  async initChapters(book,', '\n  postHook()');
const parse = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const saveCode = take('  async addChapter(chapter) {', '\n  async save()', src.indexOf('class SaveBook'));
const validation = take('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {',
  '      // Export lifecycle begins after per-chapter filtering.', src.indexOf('await self.initChapters(self.book'));
const prewarmGuard = take('      if (/^(?:www|book)\\.qidian\\.com$/.test(document.location.hostname) &&',
  '      if (self.book.chapters.length === 0)', src.indexOf('await qidianRestoreSelectedChapters(self.book'));
const txtCode = take('class TXT extends Options', ';// ./src/save/raw.ts');
const progressCode = take('function formatETA(', 'app.config.compilerOptions');
const progressOptions = vm.runInNewContext(progressCode + '\napp', {
  external_Vue_: { createApp:options=>options }, ui_progress:''
});
function body(id) { return `BODY_${id}_完整正文\n` + '正文内容完整。'.repeat(360); }
function node(tag='div') {
  return { tag, children:[], appendChild(child) { this.children.push(child); return child; } };
}
function fixture(configs, storage = new Map(), options = {}) {
  const state = { now:1000, starts:[], waits:[], clean:[], ocr:[], saves:[], writes:[],
    logs:[], notices:[], outputs:[], attempts:new Map(), timers:new Map(), timer:0,
    failWrites:false, beforeSave:null, prewarms:0, hangCheckpointReads:false,
    hangCheckpointWrites:false, pendingStorageHung:false, storageTimeouts:[] };
  const window = { stopController:new AbortController(), failedCount:0,
    qidianTxtOnly:!options.epub, qidianCheckpointSession:null };
  window.stopFlag = window.stopController.signal;
  const bookId = options.bookId ?? '1';
  const bookUrl = options.bookUrl ?? `https://www.qidian.com/book/${bookId}/`;
  const byId = new Map(configs.map(cfg=>[String(cfg.id), cfg]));
  const progress = progressOptions.data(); Object.assign(progress, progressOptions.methods);
  const log = Object.fromEntries(['info','warn','error','trace','debug'].map(level=>
    [level, value=>state.logs.push(typeof value === 'string' ? value : JSON.stringify(value))]));
  window.qidianDebugLogger=log;
  window.qidianDebugRun={id:'integration-fixture',startedAt:state.now};
  const sleep = async ms => { state.waits.push(ms); state.now += ms; };
  const isChapterKey=key=>String(key).startsWith('qidian-local-txt-checkpoint-v1:') &&
    !String(key).endsWith(':generation');
  const read = (key, fallback) => {
    state.pendingStorageHung=state.hangCheckpointReads&&isChapterKey(key);
    if (state.pendingStorageHung) return new Promise(()=>{});
    return storage.has(key) ? structuredClone(storage.get(key)) : fallback;
  };
  const write = (key, value) => {
    if (state.failWrites) throw new Error('synthetic storage quota exceeded');
    state.pendingStorageHung=state.hangCheckpointWrites&&isChapterKey(key);
    if (state.pendingStorageHung) return new Promise(()=>{});
    storage.set(key, structuredClone(value)); state.writes.push(key);
  };
  const request = async (route, url, predicate) => {
    const id = String(url.split('/').filter(Boolean).at(-1));
    const cfg = byId.get(id); assert(cfg, `Unexpected live request: ${url}`);
    const attempt = (state.attempts.get(id) || 0) + 1; state.attempts.set(id,attempt);
    state.starts.push({ id, route, at:state.now, attempt }); state.now += 700;
    if (cfg.requestError) {
      const error = new Error(`HTTP ${cfg.requestError}`); error.status = cfg.requestError;
      throw error;
    }
    const text = cfg.short ? '短文' : body(id);
    const main = { id, cfg, textContent:text, querySelectorAll:()=>Array(5) };
    const title = cfg.parsedTitle ?? cfg.title ?? `第${id}章`;
    const doc = { title, body:{textContent:text}, querySelector(selector) {
      if (selector === 'main' || selector === '.content-text, .vip-limit-wrap') return main;
      if (selector === 'h1.title') return { innerText:title };
      return null;
    }};
    if (route === 'html') return doc;
    const frame = { contentWindow:{document:doc}, remove(){} };
    assert.equal(predicate(frame),true); return frame;
  };
  class Options {
    genMetaDateTxt(book) {
      return `题名：${book.bookname}\n作者：${book.author}\n原始网址：${book.bookUrl}\n`+
        '本文件由小说下载器生成，软件地址：https://github.com/404-novel-project/novel-downloader\n';
    }
    getchapterName(chapter) { return chapter.chapterName; }
    genSectionText(section) { return `分卷：${section}`; }
    genChapterText(name, text) { return `## ${name}\n\n${text}\n\n`; }
    chapterSort(a,b) { return a.chapterNumber-b.chapterNumber; }
  }
  class ClockDate extends Date { static now() { return state.now; } }
  const ctx = vm.createContext({
    window, unsafeWindow:window, URL, Blob, TextEncoder, TextDecoder, Date:ClockDate,
    document:{ location:{ hostname:new URL(bookUrl).hostname, href:bookUrl }, createElement:node },
    Math:Object.assign(Object.create(Math), { random:()=>0 }), AbortController,
    setTimeout:(fn,ms)=>{
      const id=++state.timer; state.timers.set(id,{fn,ms});
      if(ms===5000&&state.pendingStorageHung)queueMicrotask(()=>{
        if(state.timers.has(id)){state.now+=ms;state.storageTimeouts.push(ms);fn();}
      });
      return id;
    },
    clearTimeout:id=>state.timers.delete(id), console:log, alert:message=>state.notices.push(message),
    GM_getValue:read, GM_setValue:write, GM_deleteValue:key=>storage.delete(key),
    GM_listValues:()=>[...storage.keys()], GM_info:{script:{version:'5.2.1283.25'}},
    GM:{getValue:async(...args)=>read(...args),setValue:async(...args)=>write(...args),
      deleteValue:async key=>storage.delete(key),listValues:async()=>[...storage.keys()]},
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:status}, main:{nW:status,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log,
    _log__WEBPACK_IMPORTED_MODULE_6___default:()=>log, loglevel_default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:sleep}, misc:{yy:sleep},
    setting:{Jv:{value:true},Zz:{value:options.epub ?? false},Nw:{value:false}},
    progress:{vm:progress}, log:{M6(){}}, Options,
    FileSaver_min:{saveAs:(blob,name)=>state.outputs.push({blob,name})},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async url=>request('html',url),
      Q2:async(url,predicate)=>request('frame',url,predicate)},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(){},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{async an(main) {
      assert.equal(main.cfg.vip,false,'VIP chapters must never use public HTML fallback');
      state.clean.push(main.id); return {dom:node(),text:main.textContent,images:[]};
    },is(){}},
    async ocrContent(main) {
      assert.equal(main.cfg.vip,true,'Free chapters must never use OCR');
      state.ocr.push(main.id); state.now += 300;
      return {contentText:main.textContent,contentHTML:node()};
    },
    qidianGlyphCache:new Map(), async qidianPersistGlyphCache(){}
  });
  vm.runInContext(globals + chapterCode + '\nclass Rule {'+scheduler+'}\nclass Qidian {'+parse+'}\nclass Save {'+saveCode+'}\n'+txtCode+
    '\nthis.Chapter=Chapter; this.Rule=Rule; this.Qidian=Qidian; this.Save=Save; this.TXT=TXT;'+
    '\nthis.restore=qidianRestoreSelectedChapters; this.open=qidianCheckpointOpen;'+
    '\nthis.importTxt=qidianCheckpointImportTxt; this.clear=qidianCheckpointClear;'+
    '\nthis.prewarmFromRun=self=>{'+prewarmGuard+'};'+
    '\nthis.validate=self=>{let qidianCompletionMessage;'+validation+'return self.book;};',ctx);
  const parser = new ctx.Qidian();
  const chapters = configs.map((cfg,index)=>new ctx.Chapter({
    bookUrl,bookname:'断点集成测试书',chapterUrl:`https://www.qidian.com/chapter/${bookId}/${cfg.id}/`,
    chapterNumber:cfg.catalogNumber ?? index+1,chapterName:cfg.title ?? `第${cfg.id}章`,
    sectionName:cfg.section ?? '正文卷',sectionNumber:1,sectionChapterNumber:index+1,
    isVIP:cfg.vip,isPaid:cfg.vip,charset:'UTF-8',
    options:{bookId,expectedChars:cfg.expectedChars ?? 2000,_csrfToken:'MUST_NOT_BE_STORED'},
    chapterParse:parser.chapterParse.bind(parser)
  }));
  const rule=new ctx.Rule(); Object.assign(rule,{concurrencyLimit:1,sleepTime:8000,maxSleepTime:20000});
  const saver=new ctx.Save(); saver.saveType={txt:true,epub:true};
  saver.epub={addChapter(){throw Error('EPUB must stay disabled');}};
  const originalAdd=saver.addChapter.bind(saver);
  saver.addChapter=async chapter=>{
    state.saves.push(chapter.chapterUrl);
    if (state.beforeSave) state.beforeSave(chapter);
    if(byId.get(String(chapter.chapterUrl.split('/').filter(Boolean).at(-1))).saveThrows)
      throw Error('synthetic addChapter failure');
    return originalAdd(chapter);
  };
  const book={bookUrl,bookname:'断点集成测试书',author:'测试作者',chapters};
  return {state,window,ctx,progress,storage,book,chapters,
    async restore(){ return ctx.restore(book,status); },
    async run(){
      await ctx.restore(book,status);
      ctx.prewarmFromRun({book,prewarmVipOCR(){state.prewarms++;}});
      await rule.initChapters(book,saver); return book;
    },
    validate(){return ctx.validate({book,postHook(){}});},
    async export(){this.validate();new ctx.TXT(book).saveTxt();return state.outputs.at(-1).blob.text();}
  };
}
const tests=[]; const test=(name,run)=>tests.push({name,run});
const requestIds=f=>f.state.starts.map(item=>item.id);
const savedIds=f=>f.chapters.filter(chapter=>chapter.status===status.saved)
  .map(chapter=>chapter.chapterUrl.split('/').filter(Boolean).at(-1));

test('page refresh restores successes and requests only missing chapters; merged TXT is complete',async()=>{
  const storage=new Map();
  const first=fixture([{id:1,vip:false},{id:2,vip:true,requestError:500},{id:3,vip:true}],storage);
  await first.run(); assert.deepEqual(requestIds(first),['1','2','3','2','2']);
  assert.deepEqual(savedIds(first),['1','3']);
  assert(first.chapters.filter(c=>c.status===status.saved).every(c=>c.contentHTML===null),
    'fixture must exercise debug disabled and SaveBook HTML cleanup');
  const second=fixture([{id:1,vip:false},{id:2,vip:true},{id:3,vip:true}],storage);
  await second.run(); assert.deepEqual(requestIds(second),['2']);
  assert.deepEqual(second.state.clean,[]); assert.deepEqual(second.state.ocr,['2']);
  assert.deepEqual(savedIds(second),['1','2','3']);
  assert.equal(second.book.qidianResumedCount,2); assert.equal(second.progress.finishedChapterNumber,3);
  const text=await second.export(); assert.match(text,/已写入 3 \/ 已选 3 章/);
  for(const id of [1,2,3])assert.equal(text.split(`BODY_${id}_`).length-1,1);
  assert(text.indexOf('BODY_1_')<text.indexOf('BODY_2_'));
  assert(text.indexOf('BODY_2_')<text.indexOf('BODY_3_'));
  assert.doesNotMatch(JSON.stringify([...storage.values()]),/MUST_NOT_BE_STORED|_csrfToken/);
});

test('fully restored VIP range skips network, parser, OCR and delay; still exports every chapter',async()=>{
  const storage=new Map(); const configs=[{id:101,vip:true},{id:102,vip:true}];
  const first=fixture(configs,storage); await first.run();
  const second=fixture(configs,storage); await second.run();
  assert.deepEqual(requestIds(second),[]); assert.deepEqual(second.state.ocr,[]);
  assert.deepEqual(second.state.saves,[]); assert.deepEqual(second.state.waits,[]);
  assert.equal(second.state.prewarms,0,'actual run guard must skip VIP model prewarming');
  assert.equal(second.book.qidianResumedCount,2); assert.equal(second.progress.finishedChapterNumber,2);
  assert.equal(second.progress.totalRequestTime,0); assert.equal(second.progress.qidianChapterTimes.length,0);
  const text=await second.export(); assert.match(text,/BODY_101_/); assert.match(text,/BODY_102_/);
});

test('same chapter title and number with distinct URLs persist and restore independently',async()=>{
  const storage=new Map(); const title='第182章 同名章节';
  const first=fixture([{id:301,vip:true,title},{id:302,vip:true,title,requestError:500}],storage);
  await first.run(); assert.deepEqual(savedIds(first),['301']);
  const second=fixture([{id:301,vip:true,title},{id:302,vip:true,title}],storage);
  await second.run(); assert.deepEqual(requestIds(second),['302']);
  const text=await second.export(); assert.equal(text.split(`## ${title}`).length-1,2);
  assert.equal(text.split('BODY_301_').length-1,1); assert.equal(text.split('BODY_302_').length-1,1);
});

test('new catalogue order and section metadata survive restore; only selected range is exported',async()=>{
  const storage=new Map(); const first=fixture([{id:1,vip:false},{id:2,vip:false},{id:3,vip:false}],storage);
  await first.run();
  const second=fixture([{id:3,vip:false,catalogNumber:1,section:'新分卷'},
    {id:1,vip:false,catalogNumber:2,section:'新分卷'}],storage);
  await second.run(); assert.deepEqual(requestIds(second),[]);
  assert.deepEqual(second.chapters.map(c=>c.chapterNumber),[1,2]);
  assert(second.chapters.every(c=>c.sectionName==='新分卷'));
  const text=await second.export(); assert.match(text,/分卷：新分卷/); assert.doesNotMatch(text,/BODY_2_/);
  assert(text.indexOf('BODY_3_')<text.indexOf('BODY_1_'));
});

test('chapter storage quota failure does not interrupt later chapters or TXT export',async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:true},{id:3,vip:true}]); f.state.failWrites=true;
  await f.run(); assert.deepEqual(requestIds(f),['1','2','3']);
  assert.deepEqual(savedIds(f),['1','2','3']); assert.equal(f.window.stopFlag.aborted,false);
  const text=await f.export(); assert.match(text,/已写入 3 \/ 已选 3 章/);
  assert(f.state.logs.some(line=>/quota|存储|checkpoint.*(?:error|fail)/i.test(line)),
    'debug must report unsuccessful persistence');
});

test('failed addChapter never becomes a successful resume checkpoint',async()=>{
  const storage=new Map(); const first=fixture([{id:1,vip:false,saveThrows:true},{id:2,vip:true}],storage);
  await first.run(); assert.deepEqual(savedIds(first),['2']);
  const second=fixture([{id:1,vip:false},{id:2,vip:true}],storage); await second.run();
  assert.deepEqual(requestIds(second),['1']); assert.equal(second.book.qidianResumedCount,1);
  const text=await second.export(); assert.match(text,/BODY_1_/); assert.match(text,/BODY_2_/);
});

test('changed catalogue title rejects just that checkpoint and leaves other successes reusable',async()=>{
  const storage=new Map(); const first=fixture([{id:1,vip:false},{id:2,vip:true}],storage); await first.run();
  const second=fixture([{id:1,vip:false,title:'第1章 修订标题'},{id:2,vip:true}],storage);
  await second.run(); assert.deepEqual(requestIds(second),['1']); assert.equal(second.book.qidianResumedCount,1);
  const text=await second.export(); assert.match(text,/第1章 修订标题/); assert.match(text,/BODY_2_/);
});

test('another book with the same chapter IDs never restores the first book text',async()=>{
  const storage=new Map(); const first=fixture([{id:1,vip:false},{id:2,vip:true}],storage); await first.run();
  const second=fixture([{id:1,vip:false},{id:2,vip:true}],storage,{bookId:'2'}); await second.run();
  assert.deepEqual(requestIds(second),['1','2']); assert.equal(second.book.qidianResumedCount,0);
});

test('importing existing partial TXT restores its good chapters and downloads only omissions',async()=>{
  const configs=[{id:1,vip:false},{id:2,vip:true},{id:3,vip:true}];
  const old=fixture(configs.map(cfg=>({...cfg,...(cfg.id===2?{requestError:500}:{})})));
  await old.run(); const partial=await old.export();
  assert.match(partial,/已写入 2 \/ 已选 3 章/); assert.match(partial,/第2章：/);
  const fresh=fixture(configs); const session=await fresh.ctx.open(fresh.book,()=>{});
  const result=await fresh.ctx.importTxt(session,fresh.book,partial);
  assert.equal(result.imported,2); assert.equal(result.incomplete,0); assert.equal(result.storageFailed,0);
  await fresh.run(); assert.deepEqual(requestIds(fresh),['2']); assert.equal(fresh.book.qidianResumedCount,2);
  assert.equal(fresh.chapters[0].contentText,body('1'));
  assert.equal(fresh.chapters[2].contentText,body('3'));
  const text=await fresh.export(); for(const id of [1,2,3])assert.equal(text.split(`BODY_${id}_`).length-1,1);
  assert.doesNotMatch(text,/HTTP 500|章节页面.*异常|部分完成/);
});

test('one corrupted checkpoint is retried without discarding other cached chapters',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false},{id:2,vip:true}];
  const first=fixture(configs,storage); await first.run();
  const entry=[...storage.entries()].find(([,value])=>value && typeof value==='object' && value.chapterId==='1');
  assert(entry,'successful chapter must have an independent persistent record');
  storage.set(entry[0],{...entry[1],text:entry[1].text+'篡改正文'});
  const second=fixture(configs,storage); await second.run();
  assert.deepEqual(requestIds(second),['1']); assert.equal(second.book.qidianResumedCount,1);
  const text=await second.export(); assert.doesNotMatch(text,/篡改正文/);
  assert(second.state.logs.some(line=>/body_digest_mismatch/.test(line)));
});

test('parsed page title differences do not invalidate an unchanged catalogue checkpoint',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false,parsedTitle:'第1章 正文页面标题'},
    {id:2,vip:true,parsedTitle:'第2章 正文页面标题'}];
  const first=fixture(configs,storage); await first.run();
  const second=fixture(configs,storage); await second.run();
  assert.deepEqual(requestIds(second),[]); assert.equal(second.book.qidianResumedCount,2);
  assert.deepEqual(second.chapters.map(c=>c.chapterName),configs.map(c=>c.parsedTitle));
  const text=await second.export(); assert.match(text,/第1章 正文页面标题/);
});

test('clearing current book checkpoints forces redownload and preserves another book records',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false},{id:2,vip:true}];
  const first=fixture(configs,storage); await first.run();
  const other=fixture(configs,storage,{bookId:'2'}); await other.run();
  assert.equal(await first.ctx.clear(first.book,()=>{}),true);
  const second=fixture(configs,storage); await second.run();
  assert.deepEqual(requestIds(second),['1','2']); assert.equal(second.book.qidianResumedCount,0);
  const otherRefresh=fixture(configs,storage,{bookId:'2'}); await otherRefresh.run();
  assert.deepEqual(requestIds(otherRefresh),[]); assert.equal(otherRefresh.book.qidianResumedCount,2);
});

test('EPUB mode does not hydrate TXT-only checkpoints as saved chapters',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false},{id:2,vip:true}];
  const first=fixture(configs,storage); await first.run();
  const epub=fixture(configs,storage,{epub:true}); await epub.restore();
  assert.equal(epub.book.qidianResumedCount,0); assert.equal(epub.window.qidianCheckpointSession,null);
  assert(epub.chapters.every(chapter=>chapter.status===status.pending&&chapter.contentText===undefined));
});

test('disabling resume ignores existing cached chapters and follows live download path',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false},{id:2,vip:true}];
  const first=fixture(configs,storage); await first.run(); storage.set('qidianResumeEnabledV1',false);
  const second=fixture(configs,storage); await second.run();
  assert.deepEqual(requestIds(second),['1','2']); assert.equal(second.book.qidianResumedCount,0);
  assert.equal(second.window.qidianCheckpointSession,null);
});

test('one hung checkpoint read disables restoration for this run and does not wait per chapter',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false},{id:2,vip:true},{id:3,vip:true}];
  const first=fixture(configs,storage); await first.run();
  const second=fixture(configs,storage); second.state.hangCheckpointReads=true; await second.run();
  assert.deepEqual(second.state.storageTimeouts,[5000]);
  assert.deepEqual(requestIds(second),['1','2','3']); assert.deepEqual(savedIds(second),['1','2','3']);
  assert.equal(second.window.stopFlag.aborted,false); assert.equal(second.book.qidianResumedCount,0);
  const text=await second.export(); assert.match(text,/已写入 3 \/ 已选 3 章/);
});

test('one hung checkpoint write disables later writes while later chapters still download and export',async()=>{
  const configs=[{id:1,vip:false},{id:2,vip:true},{id:3,vip:true}];
  const f=fixture(configs); f.state.hangCheckpointWrites=true; await f.run();
  assert.deepEqual(f.state.storageTimeouts,[5000]);
  assert.deepEqual(requestIds(f),['1','2','3']); assert.deepEqual(savedIds(f),['1','2','3']);
  assert.equal(f.window.stopFlag.aborted,false); const text=await f.export();
  assert.match(text,/已写入 3 \/ 已选 3 章/);
});

test('supported book.qidian.com/info route resumes canonical www book checkpoints',async()=>{
  const storage=new Map(); const configs=[{id:1,vip:false},{id:2,vip:true}];
  const first=fixture(configs,storage); await first.run();
  const legacy=fixture(configs,storage,{bookUrl:'https://book.qidian.com/info/1/'}); await legacy.run();
  assert.deepEqual(requestIds(legacy),[]); assert.equal(legacy.book.qidianResumedCount,2);
  const text=await legacy.export(); assert.match(text,/已写入 2 \/ 已选 2 章/);
  assert.match(text,/BODY_1_/); assert.match(text,/BODY_2_/);
});

(async()=>{for(const {name,run} of tests){await run();console.log(`PASS: ${name}`);}
  console.log(`PASS: ${tests.length} checkpoint/scheduler/TXT integration checks`);
})().catch(error=>{console.error(error);process.exitCode=1;});
