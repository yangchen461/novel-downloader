"""Retain v31 evidence without accepting body text or changing chapter outcomes."""
import importlib.util
import json
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("analyzer", Path(__file__).with_name("analyze-qidian-debug.py"))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def event(**fields):
    return dict(schema=2, version="5.2.1283.31", runId="synthetic-v31", event="content_check", chapterId="29", **fields)


def analyze(*rows):
    return A.analyze("\n".join("[QidianDebug] " + json.dumps(row) for row in rows))["runs"][0]


class V31AnalyzerTests(unittest.TestCase):
    def test_short_body_evidence_stays_a_failure(self):
        row = event(mode="free-html", sourceMatched=None, rawMainChars=1864, rawMainCjk=1600,
                    removedDuringCleanup=0, sourceSnapshot=True,
                    rootSelection={"contentRootCount": 1, "eligibleRootCount": 1, "reason": "single_content_root"},
                    sourceFingerprint={"kind": "dual32_utf16_nonspace", "digest": "1864:ab:cd"},
                    quality={"actualChars": 1864, "minimumChars": 1974, "complete": False, "reason": "below_expected_length"})
        result = analyze(row)
        saved = result["failedChecks"][0]
        self.assertEqual(saved["rawMainChars"], 1864)
        self.assertEqual(saved["removedDuringCleanup"], 0)
        self.assertIsNone(saved["sourceMatched"])
        self.assertEqual(saved["sourceFingerprint"]["digest"], "1864:ab:cd")
        self.assertEqual(saved["rootSelection"]["eligibleRootCount"], 1)
        self.assertEqual(len(result["failures"]), 1)

    def test_tristate_match_does_not_turn_unknown_into_false(self):
        for value in [None, False, True]:
            self.assertIs(A.sanitize(event(sourceMatched=value))["sourceMatched"], value)
        for value in [0, 1, "false", [], {}]:
            self.assertNotIn("sourceMatched", A.sanitize(event(sourceMatched=value)))

    def test_invalid_fingerprints_cannot_smuggle_text(self):
        for digest in ["BODY_SECRET", "12:ab:cd BODY_SECRET", "12:ab:cd\n", "9"*13+":a:b", None, [], {}]:
            result = A.sanitize(event(sourceFingerprint={"kind": "dual32_utf16_nonspace", "digest": digest}))
            self.assertNotIn("sourceFingerprint", result)
        result = A.sanitize(event(sourceFingerprint={"kind": "BODY_SECRET", "digest": "12:ab:cd"}))
        self.assertNotIn("sourceFingerprint", result)

    def test_whitelisted_nested_values_drop_raw_text(self):
        raw = event(sourceFingerprint={"kind": "dual32_utf16_nonspace", "digest": "12:ab:cd", "text": "BODY_SECRET"},
                    rootSelection={"contentRootCount": 2, "eligibleRootCount": 2, "reason": "ambiguous_content_roots", "contentText": "BODY_SECRET"},
                    probeInstallState={"readyState": "complete", "url": "URL_SECRET", "cookie": "COOKIE_SECRET"})
        result = A.sanitize(raw)
        self.assertNotIn("SECRET", json.dumps(result))
        self.assertEqual(result["probeInstallState"], {"readyState": "complete"})
        self.assertEqual(result["rootSelection"]["reason"], "ambiguous_content_roots")

    def test_probe_and_reader_fields_survive_nested_error_state(self):
        state = dict(documentGeneration=2, probeInstallState={"readyState": "interactive"},
                     readerDiagnostics={"contentRootCount": 2, "visibleContentRootCount": 1, "mainNonWhitespaceChars": 2000})
        result = A.sanitize(event(frameState=state))["frameState"]
        self.assertEqual(result, state)

    def test_invalid_root_and_probe_categories_are_omitted(self):
        for bad in ["BODY_SECRET", [], {}]:
            result = A.sanitize(event(rootSelection={"contentRootCount": True, "eligibleRootCount": -1, "reason": bad},
                                      probeInstallState={"readyState": bad}))
            self.assertEqual(result["rootSelection"], {})
            self.assertNotIn("probeInstallState", result)

    def test_old_logs_do_not_gain_invented_evidence(self):
        result = A.sanitize(event(quality={"complete": False}))
        for key in ["sourceMatched", "sourceFingerprint", "rootSelection", "probeInstallState", "documentGeneration"]:
            self.assertNotIn(key, result)


if __name__ == "__main__":
    unittest.main()
