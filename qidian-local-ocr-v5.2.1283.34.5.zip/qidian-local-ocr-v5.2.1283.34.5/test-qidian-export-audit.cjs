const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const s = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const helpers = s.slice(s.indexOf('function qidianContentIsComplete'), s.indexOf('/******/ \tvar __webpack_modules__'));
const ctx = vm.createContext({window: {}});
vm.runInContext(helpers, ctx);
assert.equal(ctx.qidianContentIsComplete('文'.repeat(400), 2000, true), false);
assert.equal(ctx.qidianContentIsComplete('文'.repeat(600), 10000, true), false);
assert.equal(ctx.qidianContentIsComplete('文'.repeat(2000), 2000, true), true);
assert.equal(ctx.qidianContentIsComplete('文', 0, false), false);

const migrationStart = s.indexOf('    // Older installations saved EpubDownload=true.');
const migrationEnd = s.indexOf('    setting.enableDebug = GM_getValue(', migrationStart);
const stored = {TxtDownload:false, EpubDownload:true};
const settingsContext = { setting: {},
  document:{location:{hostname:'www.qidian.com'}},
  GM_getValue:(key,fallback)=>key in stored ? stored[key] : fallback,
  GM_setValue:(key,value)=>{stored[key]=value;}
};
vm.runInNewContext(s.slice(migrationStart,migrationEnd),settingsContext);
assert.equal(stored.TxtDownload,true); assert.equal(stored.EpubDownload,false);
assert.match(s,/const EpubDownload = \{\s*value: false/);

const rangeStart = s.indexOf('function parseQidianChapterNumber(');
const rangeEnd = s.indexOf('const filterOptionDict =', rangeStart);
vm.runInContext(s.slice(rangeStart, rangeEnd), ctx);
const chapter = (title, num=1) => ({chapterName: title, chapterNumber: num, bookUrl: 'https://www.qidian.com/book/1/'});
const range = ctx.createChapterNumberFilter('1-100');
assert.equal(range(chapter('第一章')), true);
assert.equal(range(chapter('第一百章')), true);
assert.equal(range(chapter('第一百零一章')), false);
assert.equal(ctx.parseQidianChapterNumber('第１２３章'), 123);
assert.equal(ctx.createChapterNumberFilter('101-200')(chapter('第一百零一章')), true);
assert.equal(ctx.createChapterNumberFilter('1-2,5-6')(chapter('第五章')), true);
for (const bad of ['0-1','10-2','x','1--2']) assert.equal(ctx.createChapterNumberFilter(bad), undefined);

ctx.GM_getValue = () => ({filterType:'range'});
ctx.document = {location:{hostname:'www.qidian.com'}};
ctx.unsafeWindow = {chapterFilter: range};
ctx.main = {nW:{aborted:4,pending:0}};
const prepStart = s.indexOf('  async prepareChapters(book) {');
const prepEnd = s.indexOf('\n  selectChapters(',prepStart);
vm.runInContext('this.prepare = ({'+s.slice(prepStart,prepEnd)+'}).prepareChapters',ctx);

(async()=>{
  const selected = {...chapter('第五十章'), isVIP:true, status:4, chapterUrl:'https://www.qidian.com/chapter/1/50'};
  const outside = {...chapter('第一百零一章'), isVIP:true, status:4, chapterUrl:'https://www.qidian.com/chapter/1/101'};
  await ctx.prepare({chapters:[selected,outside]});
  assert.equal(selected.status,0); assert.equal(outside.status,0);
  assert.equal(range(outside),false,'selection, not catalogue access flags, excludes out-of-range candidates');

  let output;
  const start = s.indexOf('class TXT extends Options');
  const end = s.indexOf(';// ./src/save/raw.ts', start);
  class Options {
    genMetaDateTxt(){return '测试书';}
    getchapterName(c){return c.chapterName;}
    genSectionText(n){return n;}
    genChapterText(n,t){return n+'\n'+t;}
    chapterSort(a,b){return a.chapterNumber-b.chapterNumber;}
  }
  const txtContext = vm.createContext({Options, Blob, setting:{Nw:{value:false}},
    loglevel_default:()=>({debug(){},info(){}}), FileSaver_min:{saveAs:(blob,name)=>{output={blob,name};}}});
  vm.runInContext(s.slice(start,end)+'\nthis.TXT=TXT;',txtContext);
  const book = {author:'作者',bookname:'测试',downloadSuffix:' [1-100]',
    chapters:Array.from({length:40},(_,i)=>({chapterNumber:i+1,chapterName:`第${i+1}章`,contentText:'正文'})),
    downloadReport:{selectedCount:100,savedCount:40,missing:[{title:'第四十一章',reason:'访问拦截'},{title:'第四十二章',reason:'尚未处理（任务已停止）'}]}};
  new txtContext.TXT(book).saveTxt();
  assert.match(output.name,/部分下载_40章/);
  const text = await output.blob.text();
  assert.match(text,/已写入 40 \/ 已选 100 章/);
  assert.match(text,/第四十一章：访问拦截/);
  assert.match(text,/第四十二章：尚未处理/);
  assert.match(text,/第40章/);
  console.log('PASS: 截断拒收、范围边界、VIP锁标志与部分TXT标记/缺章清单');
})().catch(e=>{console.error(e);process.exitCode=1;});
