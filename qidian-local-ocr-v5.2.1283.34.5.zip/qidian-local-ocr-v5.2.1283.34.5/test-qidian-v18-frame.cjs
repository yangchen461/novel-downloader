// Exercise the shipped frame helper, Qidian parser and Chapter retry policy.
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b, from = 0) {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, a);
  return src.slice(start, end);
}
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const helper = take('async function getFrameContentConditionWithWindow(', '\n\n\n/***/');
const chapter = take('class ChapterAbortError', '\n\n/***/ },');
const parser = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const status = {pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5};
const url = 'https://www.qidian.com/chapter/1/119/';

function fixture(config = {}) {
  const state = {now:0, next:0, timers:new Map(), waits:[], frames:[], logs:[], removed:0};
  const window = {stopController:new AbortController(), failedCount:0};
  window.stopFlag = window.stopController.signal;
  const timer = (fn, ms, interval = false) => {
    const id = ++state.next;
    state.timers.set(id, {fn, at:state.now + ms, interval:interval ? ms : 0});
    return id;
  };
  const setTimeout = (fn, ms) => timer(fn, ms);
  const clearTimeout = id => state.timers.delete(id);
  Object.assign(window, {setTimeout, clearTimeout, setInterval:(fn, ms)=>timer(fn, ms, true), clearInterval:clearTimeout});
  const log = {debug(){}, error(){}, trace(){}, info:x=>state.logs.push(String(x)), warn:x=>state.logs.push(String(x))};
  const document = {
    location:{hostname:'www.qidian.com'},
    body:{appendChild(frame) {
      if(config.loadEvent !== false) frame.listeners.load();
      if(config.errorEvent) frame.listeners.error(new Error('frame error'));
    }},
    createElement(tag) {
      assert.equal(tag, 'iframe', 'empty pages must not enter OCR or construct output');
      const doc = {
        URL:config.address === undefined ? url + '?token=must-not-be-logged' : config.address,
        readyState:config.readyState || 'complete', title:config.waf ? 'WAF拦截页面' : '',
        body:{innerText:config.unknownText ? undefined : config.waf ? '403 您的请求已中断' : config.text || '', childElementCount:config.elements || 0},
        querySelector(selector) {
          if(selector === 'main' && config.paragraphs) return {querySelectorAll:()=>Array(config.paragraphs)};
          if(selector === '.content-text, .vip-limit-wrap' && config.content) return {};
          return null;
        },
        querySelectorAll:()=>Array(config.scripts || 0)
      };
      const frame = {listeners:{}, sandbox:{add(){}}, contentWindow:{document:doc},
        addEventListener(type, fn) {this.listeners[type]=fn;},
        remove() {if(!this.removed){this.removed=true;state.removed++;}}
      };
      state.frames.push(frame);
      return frame;
    }
  };
  const ctx = vm.createContext({
    window, document, URL, AbortController, Date:{now:()=>state.now}, setTimeout, clearTimeout,
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:status},
    _log__WEBPACK_IMPORTED_MODULE_0___default:()=>log,
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log,
    _log__WEBPACK_IMPORTED_MODULE_6___default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:async ms=>{state.waits.push(ms);state.now+=ms;}}
  });
  vm.runInContext(globals + helper + chapter + '\nclass Qidian {' + parser + '}\nthis.Chapter=Chapter;this.Qidian=Qidian;', ctx);
  ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__ = {Q2:ctx.getFrameContentConditionWithWindow};
  const qidian = new ctx.Qidian();
  const makeChapter = id => new ctx.Chapter({chapterName:`第${id}章`, chapterUrl:url, isVIP:true, isPaid:true,
    options:{expectedChars:2000}, chapterParse:(...args)=>qidian.chapterParse(...args)});
  async function drain(promise) {
    let done=false, result, error;
    promise.then(value=>{done=true;result=value;},err=>{done=true;error=err;});
    for(let i=0;!done && i<1000;i++) {
      for(let j=0;j<20;j++) await Promise.resolve();
      if(done) break;
      const next=[...state.timers].sort((a,b)=>a[1].at-b[1].at)[0];
      if(!next) continue; // The mocked cooldown advances through promise turns.
      const [id,t]=next; state.now=Math.max(state.now,t.at);
      if(t.interval) t.at=state.now+t.interval; else state.timers.delete(id);
      t.fn();
    }
    assert(done, 'virtual timer budget exceeded');
    if(error) throw error;
    return result;
  }
  return {state, window, ctx, makeChapter, drain};
}
const tests=[];
const test=(name, fn)=>tests.push({name,fn});

test('frame diagnostics distinguish a requested page and omit query/body content', async()=>{
  const f=fixture({elements:2,scripts:1,errorEvent:true,text:'private body text'});
  const task=f.ctx.getFrameContentConditionWithWindow(url,()=>false,undefined,20000);
  await assert.rejects(f.drain(task), error=>{
    const s=error.frameState;
    assert.equal(s.addressKind,'requested'); assert.equal(s.bodyTextLength,17);
    assert.equal(s.bodyElements,2); assert.equal(s.scriptCount,1);
    assert.equal(s.loadEvents,1); assert.equal(s.errorEvents,1);
    assert(!JSON.stringify(s).includes('must-not-be-logged')); assert(!JSON.stringify(s).includes('private'));
    return true;
  });
  assert.equal(f.state.now,20000); assert.equal(f.state.removed,1); assert.equal(f.state.timers.size,0);
});

test('confirmed empty requested page fails only this chapter after one timeout without reload',async()=>{
  const f=fixture(), c=f.makeChapter(119);
  await f.drain(c.init());
  assert.equal(f.state.frames.length,1); assert.equal(f.state.now,20000); assert.deepEqual(f.state.waits,[]);
  assert.equal(c.status,status.failed); assert.equal(c.retryTime,1); assert.equal(c.contentText,null);
  assert.equal(f.window.stopFlag.aborted,false); assert.equal(c.qidianFailureKind,'page'); assert.match(c.errorMessage,/已记录缺章/);
  assert.equal(f.state.removed,1); assert.equal(f.state.timers.size,0);
  await f.drain(f.makeChapter(120).init()); assert.equal(f.state.frames.length,2);
});

for(const config of [
  {readyState:'loading'}, {address:'about:blank'}, {address:''}, {unknownText:true},
  {address:'https://other.example/redirect'}, {text:'加载中'}, {paragraphs:1}
]) test(`unconfirmed blank state keeps ordinary cooldown/retry: ${JSON.stringify(config)}`,async()=>{
  const f=fixture(config), c=f.makeChapter(119);
  await f.drain(c.init());
  assert.equal(f.state.frames.length,2);
  const waitedMs=f.state.waits.reduce((a,b)=>a+b,0);
  assert(waitedMs>=85000 && waitedMs<=95000,'the sampled 90s cooldown stays within +/-5s');
  assert.equal(f.state.now,65000+waitedMs,'the two page timeouts plus sampled cooldown account for all elapsed time');
  const retry=f.state.logs.filter(line=>line.startsWith('[QidianDebug] ')).map(line=>JSON.parse(line.slice(14))).find(row=>row.event==='retry_scheduled');
  assert.equal(retry.baseWaitMs,90000); assert.equal(retry.waitMs,waitedMs);
  assert(f.state.waits.every(ms=>ms>0 && ms<=1000),'the full randomized cooldown remains cancellable');
  assert.equal(c.status,status.failed); assert.equal(f.window.stopFlag.aborted,false);
  assert.match(c.errorMessage,/连续两次超时/); assert.equal(c.qidianFailureKind,'page'); assert.equal(f.state.removed,2); assert.equal(f.state.timers.size,0);
});

test('WAF response pauses and cleans frame before timeout or any retry',async()=>{
  const f=fixture({waf:true}), c=f.makeChapter(119);
  await f.drain(c.init());
  assert.equal(f.state.now,0); assert.equal(f.state.frames.length,1); assert.equal(f.state.removed,1);
  assert.equal(f.state.timers.size,0); assert.deepEqual(f.state.waits,[]); assert.match(f.window.qidianPauseReason,/拦截/);
  assert.equal(c.qidianFailureKind,'access','synchronous frame cancellation retains access classification');
  assert.equal(c.options.qidianErrorInfo.errorCode,'access_restricted');
});

(async()=>{let failed=0;for(const {name,fn} of tests){try{await fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error);}}
console.log(`${tests.length-failed}/${tests.length} v18 frame checks passed`);if(failed)process.exitCode=1;})();
