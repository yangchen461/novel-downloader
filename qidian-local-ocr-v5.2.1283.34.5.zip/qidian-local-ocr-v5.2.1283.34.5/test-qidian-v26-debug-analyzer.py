#!/usr/bin/env python3
"""Synthetic v26 skip/access/export diagnostics; no page bodies or network."""
import importlib.util
import json
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("analyzer", Path(__file__).with_name("analyze-qidian-debug.py"))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def event(name, **fields):
    return {"schema": 2, "version": "5.2.1283.26", "runId": "synthetic-v26", "event": name, **fields}


def analyze(*rows):
    return A.analyze("\n".join("[QidianDebug] " + json.dumps(row) for row in rows))["runs"][0]


class V26AnalyzerTests(unittest.TestCase):
    def test_raw_aborted_status_with_skip_label_is_distinct(self):
        run = analyze(event("chapter_skipped", chapterId="2", status=4, statusName="skipped", skipReason="unsubscribed", accessEvidence="purchase_prompt", errorCode="chapter_unsubscribed"),
                      event("chapter_result", chapterId="2", status=4, statusName="skipped", skipReason="unsubscribed"),
                      event("chapter_result", chapterId="3", status=5),
                      event("chapter_result", chapterId="4", status=4))
        skipped, success, aborted = run["chapters"]
        self.assertEqual(skipped["finalOutcome"], "skipped")
        self.assertEqual(success["finalOutcome"], "success")
        self.assertEqual(aborted["finalOutcome"], "aborted")
        self.assertEqual(run["summary"]["skippedCount"], 1)
        self.assertEqual(run["summary"]["aborted"], 1)
        self.assertEqual(run["summary"]["failed"], 0)
        self.assertEqual(run["summary"]["skipped"][0]["skipReason"], "unsubscribed")

    def test_unsubscribed_error_stage_does_not_become_failure_or_recovery(self):
        run = analyze(event("chapter_stage_end", chapterId="2", stage="page_load", outcome="error", durationMs=2, errorCode="chapter_unsubscribed"),
                      event("attempt_error", chapterId="2", errorCode="chapter_unsubscribed", skipReason="unsubscribed"),
                      event("chapter_skipped", chapterId="2", status=4, statusName="skipped", skipReason="unsubscribed"),
                      event("chapter_result", chapterId="3", status=5))
        self.assertEqual(run["failures"], [])
        self.assertEqual(run["chapters"][0]["failures"], [])
        self.assertIsNone(run["chapters"][0]["lastFailure"])
        self.assertFalse(run["chapters"][0]["recovered"])
        self.assertEqual(run["retryStats"]["attemptErrors"], 0)
        self.assertEqual(run["stageDurations"]["page_load"]["medianMs"], 2)

    def test_prior_real_failure_then_skip_is_not_recovered(self):
        run = analyze(event("attempt_error", chapterId="2", errorCode="page_timeout", attempt=1),
                      event("chapter_skipped", chapterId="2", statusName="skipped", skipReason="unsubscribed", attempt=2))
        chapter = run["chapters"][0]
        self.assertEqual(chapter["finalOutcome"], "skipped")
        self.assertFalse(chapter["recovered"])
        self.assertEqual(chapter["lastFailure"]["errorCode"], "page_timeout")
        self.assertEqual(run["retryStats"]["attemptErrors"], 1)

    def test_access_denial_does_not_infer_unsubscribed(self):
        run = analyze(event("access_check", chapterId="2", kind="restricted", evidence="http_status"),
                      event("attempt_error", chapterId="2", errorCode="http_access_restricted", httpStatus=403),
                      event("chapter_result", chapterId="2", status=4))
        self.assertEqual(run["chapters"][0]["finalOutcome"], "aborted")
        self.assertEqual(run["summary"]["skippedCount"], 0)
        self.assertEqual(len(run["failures"]), 1)
        self.assertEqual(run["accessChecks"][0]["kind"], "restricted")

    def test_completed_with_skips_summary_counts_include_skips(self):
        row = event("run_summary", outcome="completed_with_skips", selectedCount=3, savedCount=2, exportedCount=2,
                    skippedCount=1, failedCount=0, abortedCount=0, unprocessedCount=0, inProgressCount=0, resumedCount=0,
                    missingCount=0, missing=[], skipped=[{"chapterId": "2", "status": 4, "statusName": "skipped", "skipReason": "unsubscribed"}])
        summary = analyze(row)["summary"]
        self.assertEqual(summary["outcome"], "completed_with_skips")
        self.assertTrue(summary["countsComplete"])
        self.assertFalse(summary["countMismatch"])
        self.assertEqual(summary["missing"], [])
        self.assertEqual(summary["skippedCount"], 1)
        self.assertEqual(summary["skipped"][0]["statusName"], "skipped")

    def test_all_skipped_complete_zero_export(self):
        summary = analyze(event("run_summary", outcome="completed_with_skips", selectedCount=2, savedCount=0, exportedCount=0,
                                skippedCount=2, failedCount=0, abortedCount=0, unprocessedCount=0, resumedCount=0,
                                skipped=[{"chapterId": "1", "statusName": "skipped"}, {"chapterId": "2", "statusName": "skipped"}]))["summary"]
        self.assertTrue(summary["countsComplete"])
        self.assertEqual(summary["success"], 0)
        self.assertEqual(summary["exportedCount"], 0)
        self.assertEqual(summary["outcome"], "completed_with_skips")

    def test_double_counting_skips_as_aborted_is_reported(self):
        summary = analyze(event("run_summary", selectedCount=2, savedCount=1, failedCount=0, abortedCount=1,
                                skippedCount=1, unprocessedCount=0, resumedCount=0))["summary"]
        self.assertTrue(summary["countMismatch"])
        self.assertFalse(summary["countsComplete"])

    def test_txt_skip_list_retained_without_sensitive_payload(self):
        run = analyze(event("txt_export", outcome="save_requested", exportedCount=2, skippedCount=1,
                            skipped=[{"chapterId": "2", "statusName": "skipped", "skipReason": "unsubscribed", "accessEvidence": "purchase_prompt", "body": "BODY_SECRET", "cookies": "COOKIE_SECRET"}]))
        self.assertEqual(run["export"]["skippedCount"], 1)
        self.assertEqual(run["export"]["skipped"][0]["accessEvidence"], "purchase_prompt")
        self.assertNotIn("SECRET", json.dumps(run))

    def test_frame_state_and_progress_snapshot_whitelisted(self):
        run = analyze(event("frame_wait_state", chapterId="2", readyState="complete", elapsedWaitMs=5000, hasContent=False,
                            snapshot={"frameAccessible": True, "hasPurchasePrompt": True, "frameCount": 1, "body": "BODY_SECRET"}),
                      event("completion_notice", outcome="completed_with_skips", progress={"processedCount": 3, "remainingCount": 0, "progressPercent": 100, "etaMs": 0, "token": "TOKEN_SECRET"}))
        self.assertEqual(run["frameWaitStates"][0]["snapshot"]["frameCount"], 1)
        self.assertTrue(run["frameWaitStates"][0]["snapshot"]["hasPurchasePrompt"])
        self.assertEqual(run["progress"][0]["progress"]["etaMs"], 0)
        self.assertNotIn("SECRET", json.dumps(run))

    def test_export_lifecycle_duration_and_notice_are_separate(self):
        run = analyze(event("export_begin", elapsedMs=10, selectedCount=3),
                      event("txt_export", elapsedMs=11, outcome="download_requested", exportedCount=2, skippedCount=1),
                      event("export_end", elapsedMs=16, outcome="completed", exportedCount=2),
                      event("completion_notice", elapsedMs=17, outcome="completed_with_skips"))
        self.assertEqual(run["exportDurations"]["medianMs"], 6)
        self.assertEqual(len(run["exportLifecycle"]), 3)
        self.assertEqual(run["export"]["exportedCount"], 2)
        self.assertEqual(run["chapters"], [])
        self.assertIn("does not prove", run["exportNote"])

    def test_unmatched_export_end_does_not_invent_duration(self):
        run = analyze(event("export_end", elapsedMs=100))
        self.assertEqual(run["exportDurations"]["count"], 0)
        self.assertEqual(run["exportDiagnostics"]["pairingIssues"]["unmatchedEnds"], 1)

    def test_failed_export_end_remains_run_failure(self):
        run = analyze(event("export_begin", elapsedMs=1),
                      event("export_end", outcome="error", durationMs=4, errorCode="txt_save_failed"))
        self.assertEqual(len(run["failures"]), 1)
        self.assertEqual(run["failures"][0]["errorCode"], "txt_save_failed")
        self.assertEqual(run["exportDurations"]["medianMs"], 4)

    def test_actual_frame_scanner_and_timeout_snapshot_fields(self):
        state = dict(readyState="complete", bodyPresent=True, bodyTextLength=120, mainPresent=False,
                     mainParagraphs=0, contentPresent=False, accessKind="unknown", accessEvidence="none",
                     addressKind="chapter", loadEvents=1, errorEvents=0, bodyElements=3, scriptCount=2,
                     body="BODY_SECRET", url="https://example.test/?token=SECRET")
        run = analyze(event("frame_wait_state", chapterId="2", durationMs=20000, **state),
                      event("attempt_error", chapterId="2", errorCode="page_timeout", frameState=state),
                      event("access_check", chapterId="3", stage="access_check", accessKind="unsubscribed", accessEvidence="purchase_prompt"),
                      event("completion_notice", noticeShown=True, selectedCount=3, savedCount=1, skippedCount=1,
                            failedCount=1, missingCount=1, unprocessedCount=0, exportedCount=1))
        frame = run["frameWaitStates"][0]
        self.assertEqual(frame["bodyTextLength"], 120)
        self.assertTrue(frame["bodyPresent"])
        self.assertFalse(frame["contentPresent"])
        timeout_state = run["failures"][0]["frameState"]
        self.assertEqual(timeout_state["addressKind"], "chapter")
        self.assertEqual(timeout_state["scriptCount"], 2)
        self.assertEqual(run["accessChecks"][0]["accessKind"], "unsubscribed")
        self.assertTrue(run["exportLifecycle"][0]["noticeShown"])
        self.assertEqual(run["exportLifecycle"][0]["skippedCount"], 1)
        self.assertNotIn("SECRET", json.dumps(run))

    def test_wrapper_unsubscribed_diagnostic_does_not_count_run_failure(self):
        run = analyze(event("run_error", errorCode="chapter_unsubscribed", skipReason="unsubscribed"),
                      event("chapter_skipped", chapterId="2", statusName="skipped", skipReason="unsubscribed"))
        self.assertEqual(run["failures"], [])
        self.assertEqual(run["summary"]["skippedCount"], 1)

    def test_schema1_aborted_and_errors_remain_legacy(self):
        run = analyze(event("chapter_result", schema=1, chapterId="2", status=4),
                      event("attempt_error", schema=1, chapterId="2", reason="old error"))
        self.assertEqual(run["chapters"][0]["finalOutcome"], "aborted")
        self.assertEqual(run["summary"]["skippedCount"], 0)
        self.assertEqual(len(run["failures"]), 1)


if __name__ == "__main__":
    unittest.main()
