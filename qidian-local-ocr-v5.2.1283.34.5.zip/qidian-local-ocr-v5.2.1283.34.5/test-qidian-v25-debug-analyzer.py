#!/usr/bin/env python3
"""Synthetic analyzer tests: no novel text, live credentials or network."""
import importlib.util
import json
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("analyzer", Path(__file__).with_name("analyze-qidian-debug.py"))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def event(name, **fields):
    return {"schema": 2, "version": "5.2.1283.25", "runId": "synthetic-run", "event": name, **fields}


def analyze(*rows):
    return A.analyze("\n".join("[info] [QidianDebug] " + json.dumps(row) for row in rows))


class AnalyzerTests(unittest.TestCase):
    def test_legacy_schema1(self):
        rows = [event("selection_result", selectedCount=2, savedCount=1, resumedCount=1, missing=[{"chapterId": "2", "status": 2}]),
                event("checkpoint_commit", durationMs=12), event("txt_export", outcome="save_requested", exportedCount=1)]
        for row in rows:
            row["schema"] = 1
        result = analyze(*rows)
        run = result["runs"][0]
        self.assertEqual(result["structuredEvents"], 3)
        self.assertEqual(run["schemas"], [1])
        self.assertEqual(run["medianCheckpointMs"], 12)
        self.assertEqual(run["summary"]["failed"], 1)
        self.assertEqual(run["export"]["outcome"], "save_requested")
        self.assertFalse(run["summary"]["countsComplete"])

    def test_truncated_invalid_json(self):
        text = '[QidianDebug] {bad\n[QidianDebug] {"schema": 2, "event": "attempt_error"\n[QidianDebug] ' + json.dumps(event("run_start"))
        result = A.analyze(text)
        self.assertEqual(result["invalidJsonEvents"], 2)
        self.assertEqual(result["structuredEvents"], 1)

    def test_malformed_types(self):
        result = analyze(event("content_check", durationMs={}, elapsedMs="slow", quality=[False], checkpointStats=True),
                         event("attempt_error", chapterId=[], attempts=True, seq=-2, httpStatus=float("nan")),
                         {"schema": 2, "event": []}, {"schema": True, "event": "run_start"}, [])
        self.assertEqual(result["structuredEvents"], 2)
        self.assertGreaterEqual(result["malformedFields"], 6)
        self.assertEqual(result["unsupportedSchemaEvents"], 1)
        json.dumps(result, allow_nan=False)

    def test_multiple_runs_and_pre_run(self):
        result = analyze(event("checkpoint_import", runId=None), event("run_start", runId="one"),
                         event("run_start", runId="two"), event("attempt_error", runId="one", chapterId="9"))
        self.assertEqual([run["runId"] for run in result["runs"]], ["one", "two"])
        self.assertEqual(len(result["unassignedEvents"]), 1)
        self.assertEqual(result["preRun"]["eventCounts"], {"checkpoint_import": 1})

    def test_duplicate_gapped_sequences_keep_file_order(self):
        run = analyze(event("attempt_start", chapterId="1", seq=3), event("attempt_error", chapterId="1", seq=3),
                      event("retry_scheduled", chapterId="1", seq=8), event("chapter_result", chapterId="1", seq=2, status=5),
                      event("run_summary", outcome="completed"))["runs"][0]
        self.assertEqual([row.get("seq") for row in run["chapters"][0]["timeline"]], [3, 3, 8, 2])
        seq = run["sequenceDiagnostics"]
        self.assertEqual(seq["duplicateSequences"], [3])
        self.assertEqual(seq["gaps"], [{"after": 3, "before": 8, "missingCount": 4}])
        self.assertEqual(seq["outOfOrderTransitions"], 1)
        self.assertEqual(seq["missingSequenceFields"], 1)

    def test_failed_stage_then_recovered(self):
        run = analyze(event("chapter_stage_start", chapterId="7", attempt=1, stage="body_check", elapsedMs=1),
                      event("chapter_stage_end", chapterId="7", attempt=1, stage="body_check", elapsedMs=5, outcome="failed", errorCode="BODY_SHORT"),
                      event("attempt_error", chapterId="7", attempt=1, stage="body_check", errorCode="BODY_SHORT"),
                      event("retry_scheduled", chapterId="7", waitMs=10000),
                      event("chapter_stage_start", chapterId="7", attempt=2, stage="body_check", elapsedMs=20),
                      event("chapter_stage_end", chapterId="7", attempt=2, stage="body_check", durationMs=2, outcome="success"),
                      event("chapter_result", chapterId="7", attempts=2, statusName="saved"))["runs"][0]
        chapter = run["chapters"][0]
        self.assertTrue(chapter["recovered"])
        self.assertEqual(chapter["finalOutcome"], "success")
        self.assertEqual(chapter["lastFailure"]["stage"], "body_check")
        self.assertEqual(run["retryStats"]["scheduledRetries"], 1)
        self.assertEqual(run["retryStats"]["totalScheduledWaitMs"], 10000)
        self.assertEqual(run["stageDurations"]["body_check"]["medianMs"], 3)

    def test_unknown_root_cause_remains_unknown(self):
        run = analyze(event("attempt_error", chapterId="1", errorName="Error", reason="unknown"))["runs"][0]
        self.assertEqual(run["failures"][0]["stage"], "unknown")
        self.assertNotIn("rootCause", run["failures"][0])

    def test_unrequested_catalog_chapters_not_counted(self):
        row = event("chapter_result", chapterId="500", catalogNumber=9000, status=5)
        run = analyze(row, event("run_summary", queued=2, success=1, failed=1, aborted=0, unprocessed=0, restored=0, durationMs=12, outcome="partial", failures=[{"chapterId": "501", "stage": "ocr"}]))["runs"][0]
        self.assertEqual(run["summary"]["queued"], 2)
        self.assertEqual(run["summary"]["unprocessed"], 0)
        self.assertTrue(run["summary"]["countsComplete"])
        observed = analyze(row)["runs"][0]["summary"]
        self.assertIsNone(observed["queued"])
        self.assertIsNone(observed["unprocessed"])

    def test_percentiles_nested_stages_not_summed(self):
        rows = [event("chapter_stage_end", stage="ocr", durationMs=n) for n in range(1, 21)]
        run = analyze(*rows, event("chapter_stage_end", stage="font_ready", durationMs=9))["runs"][0]
        self.assertEqual(run["stageDurations"]["ocr"]["medianMs"], 10.5)
        self.assertEqual(run["stageDurations"]["ocr"]["p95Ms"], 19)
        self.assertNotIn("totalStageMs", run)
        self.assertIn("overlap", run["stageDiagnostics"]["note"])

    def test_ambiguous_starts_not_paired(self):
        run = analyze(event("chapter_stage_start", stage="ocr", elapsedMs=1),
                      event("chapter_stage_start", stage="ocr", elapsedMs=2), event("chapter_stage_end", stage="ocr", elapsedMs=3))["runs"][0]
        self.assertNotIn("ocr", run["stageDurations"])
        self.assertEqual(run["stageDiagnostics"]["pairingIssues"]["ambiguousStarts"], 1)

    def test_pacing_and_ocr_cache_metrics(self):
        run = analyze(event("request_pacing", waitMs=10000, minimumGapMs=10000, requestGapMs=None),
                      event("request_pacing", waitMs=0, minimumGapMs=10000, requestGapMs=11000),
                      event("ocr_metrics", cachedGlyphs=90, uniqueGlyphs=100, unresolvedGlyphs=1, ocrCalls=10, fingerprintMs=20, ocrMs=70, cacheHitRatio=.9),
                      event("ocr_metrics", cachedGlyphs=50, uniqueGlyphs=50, unresolvedGlyphs=0, ocrCalls=0, cacheHitRatio=1))["runs"][0]
        self.assertEqual(run["pacing"]["requestGapMs"]["count"], 1)
        self.assertEqual(run["ocrMetrics"]["weightedCacheHitRatio"], 140 / 150)
        self.assertEqual(run["ocrMetrics"]["medianReportedCacheHitRatio"], .95)
        self.assertEqual(run["ocrMetrics"]["unresolvedGlyphs"], 1)

    def test_privacy_whitelisting_and_redaction(self):
        row = event("attempt_error", chapterId="1", reason="HTTP https://example.test/read?token=SECRET token=SECRET",
                    stack="Error\n at https://example.test/private?cookie=SECRET\nCookie: SECRET",
                    body="BODY_SECRET", options={"body": "BODY_SECRET"}, cookies="COOKIE_SECRET",
                    quality={"complete": False, "reason": "below_expected_length", "body": "BODY_SECRET"},
                    checkpointStats={"written": 1, "cookie": "COOKIE_SECRET"},
                    missing=[{"title": "Synthetic chapter", "chapterUrl": "https://example.test/?token=SECRET", "body": "BODY_SECRET"}])
        encoded = json.dumps(analyze(row))
        self.assertNotIn("SECRET", encoded)
        self.assertNotIn("chapterUrl", encoded)
        self.assertIn("[REDACTED]", encoded)
        self.assertIn("below_expected_length", encoded)

    def test_log_export_means_requested_not_written(self):
        run = analyze(event("log_export", outcome="download_requested", eventCount=10, logBytes=256))["runs"][0]
        self.assertEqual(run["logExports"][0]["outcome"], "download_requested")
        self.assertEqual(run["summary"]["outcome"], "unknown")
        self.assertIn("does not prove", run["exportNote"])

    def test_empty_log_fallback(self):
        result = A.analyze("old unstructured line")
        self.assertEqual(result["structuredEvents"], 0)
        self.assertIn("manual review", result["note"])

    def test_huge_nonfinite_metrics_rejected(self):
        result = analyze(event("ocr_metrics", ocrMs=1e308, cachedGlyphs=10 ** 200))
        self.assertEqual(result["malformedFields"], 2)
        json.dumps(result, allow_nan=False)

    def test_summary_count_mismatch_reported(self):
        run = analyze(event("run_summary", queued=2, success=2, failed=1, aborted=0, unprocessed=0, restored=0, outcome="partial"))["runs"][0]
        self.assertTrue(run["summary"]["countMismatch"])
        self.assertFalse(run["summary"]["countsComplete"])

    def test_optional_storage_failure_not_reported_as_extraction_recovery(self):
        run = analyze(event("checkpoint_storage_error", chapterId="7", errorName="QuotaExceededError"),
                      event("chapter_result", chapterId="7", status=5))["runs"][0]
        self.assertFalse(run["chapters"][0]["recovered"])
        self.assertEqual(len(run["storageErrors"]), 1)

    def test_restored_status_in_observed_results(self):
        run = analyze(event("chapter_restored", chapterId="7", status=5, source="checkpoint"))["runs"][0]
        self.assertEqual(run["summary"]["success"], 1)
        self.assertEqual(run["summary"]["restored"], 1)

    def test_real_v25_summary_aliases_and_formatter_failures(self):
        run = analyze(event("run_summary", selectedCount=4, savedCount=3, exportedCount=2, failedCount=1, abortedCount=0,
                            unprocessedCount=0, inProgressCount=0, resumedCount=1, formatFailureCount=1, missingCount=2, outcome="partial", durationMs=77,
                            missing=[{"chapterId": "9", "statusName": "failed", "stage": "ocr"}]))["runs"][0]
        self.assertEqual(run["summary"]["queued"], 4)
        self.assertEqual(run["summary"]["success"], 3)
        self.assertEqual(run["summary"]["exportedCount"], 2)
        self.assertEqual(run["summary"]["formatFailureCount"], 1)
        self.assertTrue(run["summary"]["countsComplete"])
        self.assertEqual(run["summary"]["failures"][0]["stage"], "ocr")

    def test_nested_error_aliases_and_build_failure_redaction(self):
        result = analyze(event("log_export_error", error={"name": "Error", "message": "token=SECRET", "body": "BODY_SECRET"}),
                         event("ocr_metrics", buildError={"errorName": "Error", "reason": "https://example.test/?token=SECRET", "options": {"body": "BODY_SECRET"}}))
        run = result["runs"][0]
        self.assertEqual(run["failures"][0]["error"]["errorName"], "Error")
        self.assertNotIn("SECRET", json.dumps(result))

    def test_stage_return_does_not_certify_body_quality(self):
        run = analyze(event("chapter_stage_end", chapterId="8", stage="body_check", outcome="success", durationMs=2),
                      event("content_check", chapterId="8", quality={"complete": False, "reason": "below_expected_length"}),
                      event("chapter_result", chapterId="8", statusName="failed", stage="body_check"))["runs"][0]
        self.assertEqual(run["chapters"][0]["finalOutcome"], "failed")
        self.assertEqual(len(run["failedChecks"]), 1)
        self.assertEqual(run["stageDurations"]["body_check"]["count"], 1)

    def test_deep_malformed_metadata_is_bounded(self):
        nested = {"complete": False}
        for _ in range(80):
            nested = {"quality": nested}
        result = analyze(event("content_check", quality=nested))
        self.assertEqual(result["structuredEvents"], 1)
        self.assertEqual(result["runs"][0]["failedChecks"], [])


if __name__ == "__main__":
    unittest.main()
