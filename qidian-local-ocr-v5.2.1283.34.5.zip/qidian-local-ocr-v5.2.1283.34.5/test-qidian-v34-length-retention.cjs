// Exercise the shipped scheduler, validator, checkpoint and TXT code. No network.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const source = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const fixtureSource = fs.readFileSync(path.join(__dirname, 'test-qidian-v19-resilience.cjs'), 'utf8');
const fixtureContext = { require, __dirname, console, AbortController };
vm.runInNewContext(fixtureSource.slice(0, fixtureSource.indexOf('\nconst tests=[];')) +
  '\nthis.fixture = fixture;', fixtureContext);
const status = { pending: 0, downloading: 1, failed: 2, finished: 3, aborted: 4, saved: 5 };
const tests = [];
const test = (name, run) => tests.push({ name, run });
const same = (left, right) => assert.deepEqual(JSON.parse(JSON.stringify(left)), JSON.parse(JSON.stringify(right)));
const warning = (f, chapter) => f.ctx.qidianChapterLengthWarning(chapter);
const textOfLength = (count, character = '文') => character.repeat(count);

function setup(plans, { vip = true, expectedChars = 2000 } = {}) {
  const f = fixtureContext.fixture(plans.map((_, id) => ({ id, vip, paid: true })));
  f.window.qidianTxtOnly = true;
  const order = [], commits = [], latest = new Map(), calls = plans.map(() => 0);
  const realCheckpointSave = f.ctx.qidianCheckpointSave;
  f.window.qidianCheckpointSession = {};
  f.ctx.qidianCheckpointSave = async (_session, chapter) => {
    const record = {
      text: chapter.contentText,
      lengthWarning: structuredClone(warning(f, chapter)),
      glyphTolerance: structuredClone(f.ctx.qidianChapterGlyphTolerance(chapter))
    };
    latest.set(chapter.chapterUrl, record);
    commits.push(chapter.chapterUrl);
    return true;
  };
  function result(chapter, options, instruction) {
    const unknown = instruction.unknown || 0;
    const base = instruction.text ?? textOfLength(instruction.chars, instruction.character || '文');
    const body = base + '□'.repeat(unknown);
    const glyphTolerance = unknown ? {
      schema: 1, placeholder: '□', mode: 'distinct', limit: 10, distinctCount: 1,
      occurrenceCount: unknown, bodyDigest: f.ctx.qidianCheckpointDigest(body),
      glyphs: [{ sourceCodepoint: 'U+4E00', occurrences: unknown,
        positions: Array.from({ length: unknown }, (_, index) => base.length + index) }]
    } : null;
    options.qidianBodyText = body;
    options.qidianBodyLength = body.length;
    options.qidianGlyphTolerance = glyphTolerance;
    options.qidianValidation = f.ctx.qidianContentCheck(body, options.expectedChars, chapter.isVIP, glyphTolerance);
    options.qidianLengthWarning = f.ctx.qidianCreateLengthWarning(body, options.expectedChars, chapter.isVIP, glyphTolerance);
    return { chapterName: chapter.chapterName, contentText: body, contentHTML: {}, contentImages: [] };
  }
  f.chapters.forEach((chapter, id) => {
    chapter.options.expectedChars = expectedChars;
    chapter.chapterParse = async (_url, _name, _vip, _paid, _charset, options) => {
      const attempt = calls[id]++;
      order.push(id);
      const instruction = plans[id][Math.min(attempt, plans[id].length - 1)];
      if (instruction === 'fail') {
        const error = new Error('synthetic local failure');
        error.name = 'QidianGlyphError';
        throw error;
      }
      if (instruction === 'unsubscribed') {
        const error = new Error('subscription gate');
        error.name = 'QidianUnsubscribedError';
        throw error;
      }
      if (instruction === 'stop') {
        f.window.stopController.abort();
        return result(chapter, options, { chars: 2200 });
      }
      return result(chapter, options, typeof instruction === 'number' ? { chars: instruction } : instruction);
    };
  });
  return Object.assign(f, { order, commits, latest, calls, realCheckpointSave });
}

function candidate(f, text, glyphTolerance = null, extra = {}) {
  const c = {
    contentText: text, contentHTML: {}, isVIP: true,
    options: { expectedChars: 2000, qidianBodyLength: text.length, qidianGlyphTolerance: glyphTolerance }
  };
  c.options.qidianLengthWarning = f.ctx.qidianCreateLengthWarning(text, 2000, true, glyphTolerance);
  Object.assign(c, extra);
  return c;
}

test('retained short text remains incomplete and needs digest-bound warning to become exportable', () => {
  const f = setup([[800]]), body = textOfLength(800), chapter = candidate(f, body);
  const strict = f.ctx.qidianContentCheck(body, 2000, true);
  assert.equal(strict.complete, false);
  assert.equal(strict.reason, 'below_expected_length');
  assert.equal(chapter.options.qidianLengthWarning.schema, 1);
  assert.equal(chapter.options.qidianLengthWarning.bodyDigest, f.ctx.qidianCheckpointDigest(body));
  const retained = f.ctx.qidianChapterContentCheck(chapter);
  assert.equal(retained.complete, false);
  assert.equal(retained.exportable, true);
  assert.equal(retained.lengthUncertain, true);
  chapter.options.qidianLengthWarning = null;
  assert.equal(f.ctx.qidianChapterContentCheck(chapter).exportable, false);
});

test('50 percent boundary is inclusive and odd catalogue counts round up rather than accepting less than half', () => {
  const f = setup([[800]]);
  for (const [expected, below, boundary] of [[2000, 999, 1000], [2001, 1000, 1001], [4013, 2006, 2007]]) {
    assert(below / expected < 0.5);
    assert(boundary / expected >= 0.5);
    const rejected = f.ctx.qidianContentCheck(textOfLength(below), expected, true);
    assert.equal(rejected.minimumChars, Math.ceil(expected * 0.5));
    assert.equal(rejected.complete, false);
    assert.equal(rejected.reason, 'below_expected_length');
    assert(f.ctx.qidianCreateLengthWarning(textOfLength(below), expected, true));
    const accepted = f.ctx.qidianContentCheck(textOfLength(boundary), expected, true);
    assert.equal(accepted.minimumChars, Math.ceil(expected * 0.5));
    assert.equal(accepted.complete, true);
    assert.equal(f.ctx.qidianCreateLengthWarning(textOfLength(boundary), expected, true), null);
  }
});

test('the nine observed actual versus catalogue counts all complete at 50 percent without length warnings or repair', async () => {
  // Counts from the latest log audit; synthetic CJK bodies avoid copying novel content.
  const observations = [
    { catalogue: 74, actual: 2064, expected: 4013 },
    { catalogue: 240, actual: 1678, expected: 2085 },
    { catalogue: 565, actual: 2458, expected: 3049 },
    { catalogue: 637, actual: 3412, expected: 4037 },
    { catalogue: 642, actual: 3431, expected: 4044 },
    { catalogue: 643, actual: 2070, expected: 3033 },
    { catalogue: 644, actual: 3218, expected: 3804 },
    { catalogue: 710, actual: 3443, expected: 4084 },
    { catalogue: 736, actual: 3311, expected: 4080 }
  ];
  const f = setup(observations.map(row => [row.actual]));
  observations.forEach((row, index) => { f.chapters[index].options.expectedChars = row.expected; });
  await f.run();
  assert.deepEqual(f.order, observations.map((_, index) => index));
  assert.equal(f.commits.length, observations.length);
  assert.equal(f.progress.finishedChapterNumber, observations.length);
  observations.forEach((row, index) => {
    const chapter = f.chapters[index], quality = f.ctx.qidianChapterContentCheck(chapter);
    assert.equal(chapter.status, status.saved, 'catalogue ' + row.catalogue);
    assert.equal(quality.actualChars, row.actual);
    assert.equal(quality.minimumChars, Math.ceil(row.expected * 0.5));
    assert.equal(quality.complete, true, 'catalogue ' + row.catalogue);
    assert.equal(quality.exportable, true);
    assert.equal(quality.lengthUncertain, false);
    assert.equal(warning(f, chapter), null);
  });
});

test('warning rejects garbled, unverified, empty and non-body text rather than bypassing those checks', () => {
  const f = setup([[800]]);
  for (const body of ['', ' '.repeat(800), textOfLength(99), 'a'.repeat(800),
    textOfLength(800) + '\uE001', textOfLength(800) + '\uFFFD', textOfLength(800) + '□']) {
    assert.equal(f.ctx.qidianCreateLengthWarning(body, 2000, true), null);
  }
  assert.equal(f.ctx.qidianCreateLengthWarning(textOfLength(19), 2000, false), null);
  assert.equal(f.ctx.qidianCreateLengthWarning(textOfLength(2200), 2000, true), null);
  assert.equal(f.ctx.qidianCreateLengthWarning(textOfLength(800), 0, true), null);
  assert.equal(f.ctx.qidianCreateLengthWarning(null, 2000, true), null);
});

test('tampered warning and changed body or catalogue expectations fail closed; options null overrides fallback', () => {
  const f = setup([[800]]), chapter = candidate(f, textOfLength(800));
  const original = structuredClone(chapter.options.qidianLengthWarning);
  chapter.qidianLengthWarning = original;
  chapter.options.qidianLengthWarning = null;
  assert.equal(warning(f, chapter), null);
  chapter.options.qidianLengthWarning = { ...original, bodyDigest: 'wrong' };
  assert.equal(f.ctx.qidianChapterContentCheck(chapter).exportable, false);
  chapter.options.qidianLengthWarning = original;
  chapter.contentText = textOfLength(800, '甲');
  assert.equal(warning(f, chapter), null);
  chapter.contentText = textOfLength(800);
  chapter.options.expectedChars = 3000;
  assert.equal(warning(f, chapter), null);
  chapter.options.expectedChars = 2000;
  same(warning(f, chapter), original);
});

test('author notes cannot turn an invalid body prefix into eligible short text', () => {
  const f = setup([[800]]);
  const body = textOfLength(40), full = body + '\n\n----------\n\n' + textOfLength(5000);
  const chapter = { contentText: full, isVIP: true,
    options: { expectedChars: 2000, qidianBodyLength: body.length, qidianGlyphTolerance: null } };
  assert.equal(f.ctx.qidianCreateLengthWarning(f.ctx.qidianChapterBodyText(chapter), 2000, true), null);
  assert.equal(f.ctx.qidianChapterContentCheck(chapter).exportable, false);
});

test('all chapters are traversed before length repair; replacement preserves identity, order and save count', async () => {
  const f = setup([[800, 2200], [2200], [600, 700, 500]]), originals = [...f.chapters];
  await f.run();
  assert.deepEqual(f.order, [0, 1, 2, 0, 2, 2]);
  assert.deepEqual(f.chapters.map(chapter => chapter.contentText.length), [2200, 2200, 700]);
  originals.forEach((chapter, index) => assert.equal(f.book.chapters[index], chapter));
  assert.equal(f.book.chapters.length, 3);
  assert.equal(f.progress.finishedChapterNumber, 3);
  assert.equal(f.commits.length, 5);
  assert.equal(warning(f, f.chapters[0]), null);
  assert(warning(f, f.chapters[2]));
  assert(f.chapters.every(chapter => chapter.status === status.saved));
  assert.equal(f.latest.get(f.chapters[2].chapterUrl).text, f.chapters[2].contentText);
});

test('missing chapters retain priority over saved short-body repair', async () => {
  const f = setup([[800, 2200], ['fail', 2200], [2200]]);
  await f.run();
  assert.deepEqual(f.order, [0, 1, 2, 1, 0]);
  assert.equal(f.progress.finishedChapterNumber, 3);
  assert.equal(f.commits.length, 4);
  assert(f.chapters.every(chapter => chapter.status === status.saved));
});

test('failed or shorter repair candidates never destroy a saved short body and its checkpoint', async () => {
  const f = setup([[800, 'fail', 500], [2200]]);
  await f.run();
  assert.deepEqual(f.order, [0, 1, 0, 0]);
  assert.equal(f.chapters[0].status, status.saved);
  assert.equal(f.chapters[0].contentText.length, 800);
  assert.equal(f.commits.length, 2);
  assert.equal(f.progress.finishedChapterNumber, 2);
  assert.equal(f.latest.get(f.chapters[0].chapterUrl).text, f.chapters[0].contentText);
  same(f.latest.get(f.chapters[0].chapterUrl).lengthWarning, warning(f, f.chapters[0]));
});

test('equal-length alternate text is not an improvement and a shorter clean body cannot replace a longer body', async () => {
  const f = setup([[{ chars: 800, character: '甲' }, { chars: 800, character: '乙' }, 700]]);
  await f.run();
  assert.equal(f.chapters[0].contentText, textOfLength(800, '甲'));
  assert.equal(f.commits.length, 1);
  assert.equal(f.progress.finishedChapterNumber, 1);
});

test('strictly complete body outranks short-body retention even when it has marked glyph uncertainty', async () => {
  const f = setup([[800, { chars: 1800, unknown: 2 }, { chars: 1800, unknown: 2 }]]);
  await f.run();
  const chapter = f.chapters[0];
  assert.equal(warning(f, chapter), null);
  assert.equal(f.ctx.qidianChapterContentCheck(chapter).complete, true);
  assert.equal(f.ctx.qidianChapterGlyphTolerance(chapter).occurrenceCount, 2);
  assert.equal(f.commits.length, 2);
  assert(f.ctx.qidianChapterQualityRank(chapter) < f.ctx.qidianChapterQualityRank(candidate(f, textOfLength(800))));
});

test('a clean half-length candidate that passes 50 percent never replaces a longer accepted body with one placeholder', async () => {
  const f = setup([[{ chars: 3999, unknown: 1 }, 2000, 2000]], { expectedChars: 4000 });
  await f.run();
  const chapter = f.chapters[0], retainedText = textOfLength(3999) + '□';
  const half = { contentText: textOfLength(2000), isVIP: true,
    options: { expectedChars: 4000, qidianBodyLength: 2000, qidianGlyphTolerance: null, qidianLengthWarning: null } };
  assert.equal(f.ctx.qidianChapterContentCheck(half).complete, true, 'the rejected candidate itself meets the new length gate');
  assert(f.ctx.qidianChapterQualityRank(half) < f.ctx.qidianChapterQualityRank(chapter), 'lower glyph rank alone must not discard half the story');
  assert.equal(f.ctx.qidianChapterCandidateImproves(half, chapter), false);
  assert.deepEqual(f.order, [0, 0, 0]);
  assert.equal(chapter.contentText, retainedText);
  assert.equal(chapter.status, status.saved);
  assert.equal(warning(f, chapter), null);
  assert.equal(f.ctx.qidianChapterGlyphTolerance(chapter).occurrenceCount, 1);
  assert.equal(f.latest.get(chapter.chapterUrl).text, retainedText);
  same(f.latest.get(chapter.chapterUrl).glyphTolerance, f.ctx.qidianChapterGlyphTolerance(chapter));
  assert.equal(f.commits.length, 1);
  assert.equal(f.progress.finishedChapterNumber, 1);
});

test('equal-length and longer candidates with fewer remaining placeholders still replace the retained body', async () => {
  for (const finalLength of [4000, 4200]) {
    const improved = { chars: finalLength - 1, unknown: 1 };
    const f = setup([[{ chars: 3998, unknown: 2 }, improved, improved]], { expectedChars: 4000 });
    await f.run();
    const chapter = f.chapters[0];
    assert.deepEqual(f.order, [0, 0, 0]);
    assert.equal(chapter.contentText.length, finalLength);
    assert.equal(f.ctx.qidianChapterGlyphTolerance(chapter).occurrenceCount, 1);
    assert.equal(chapter.status, status.saved);
    assert.equal(f.commits.length, 2, 'the equivalent second repair must not save another copy');
    assert.equal(f.latest.get(chapter.chapterUrl).text, chapter.contentText);
    assert.equal(f.progress.finishedChapterNumber, 1);
    assert.equal(f.book.chapters.length, 1);
  }
});

test('equal-length and longer fully decoded candidates clear glyph uncertainty without losing body text', async () => {
  for (const finalLength of [4000, 4200]) {
    const f = setup([[{ chars: 3999, unknown: 1 }, finalLength]], { expectedChars: 4000 });
    await f.run();
    const chapter = f.chapters[0];
    assert.deepEqual(f.order, [0, 0]);
    assert.equal(chapter.contentText.length, finalLength);
    assert.equal(f.ctx.qidianChapterGlyphTolerance(chapter), null);
    assert.equal(f.commits.length, 2);
    assert.equal(f.latest.get(chapter.chapterUrl).text, chapter.contentText);
    assert.equal(f.progress.finishedChapterNumber, 1);
  }
});

test('unchanged glyph rank accepts more body text but rejects an equal-length alternate reading', async () => {
  const f = setup([[{ chars: 3999, unknown: 1, character: '甲' },
    { chars: 4199, unknown: 1, character: '乙' },
    { chars: 4199, unknown: 1, character: '丙' }]], { expectedChars: 4000 });
  await f.run();
  const chapter = f.chapters[0], improvedText = textOfLength(4199, '乙') + '□';
  assert.deepEqual(f.order, [0, 0, 0]);
  assert.equal(chapter.contentText, improvedText);
  assert.equal(f.ctx.qidianChapterGlyphTolerance(chapter).occurrenceCount, 1);
  assert.equal(f.commits.length, 2);
  assert.equal(f.latest.get(chapter.chapterUrl).text, improvedText);
  assert.equal(f.progress.finishedChapterNumber, 1);
});

test('stop during repair parse preserves the saved short body and durable warning', async () => {
  const f = setup([[800, 'stop'], [2200]]);
  await f.run();
  assert(f.window.stopFlag.aborted);
  assert.equal(f.chapters[0].status, status.saved);
  assert.equal(f.chapters[0].contentText.length, 800);
  assert.equal(f.commits.length, 2);
  assert.equal(f.progress.finishedChapterNumber, 2);
  same(f.latest.get(f.chapters[0].chapterUrl).lengthWarning, warning(f, f.chapters[0]));
});

test('stop during deferred cooldown does not request repair or discard earlier accepted bodies', async () => {
  const f = setup([[800, 2200], [2200]]);
  f.state.onSleep = () => { if (f.order.length === 2) f.window.stopController.abort(); };
  await f.run();
  assert.deepEqual(f.order, [0, 1]);
  assert.equal(f.chapters[0].contentText.length, 800);
  assert.equal(f.chapters[0].status, status.saved);
  assert.equal(f.commits.length, 2);
});

test('stop during replacement save retains the original body; stop after durable write retains the committed improvement', async () => {
  const stoppedSave = setup([[800, 2200], [2200]]);
  let saves = 0;
  stoppedSave.state.onSave = () => { if (++saves === 3) stoppedSave.window.stopController.abort(); };
  await stoppedSave.run();
  assert.equal(stoppedSave.chapters[0].contentText.length, 800);
  assert.equal(stoppedSave.commits.length, 2);
  assert.equal(stoppedSave.latest.get(stoppedSave.chapters[0].chapterUrl).text, stoppedSave.chapters[0].contentText);
  const stoppedCheckpoint = setup([[800, 2200], [2200]]), save = stoppedCheckpoint.ctx.qidianCheckpointSave;
  stoppedCheckpoint.ctx.qidianCheckpointSave = async (...args) => {
    const result = await save(...args);
    if (stoppedCheckpoint.commits.length === 3) stoppedCheckpoint.window.stopController.abort();
    return result;
  };
  await stoppedCheckpoint.run();
  assert.equal(stoppedCheckpoint.chapters[0].contentText.length, 2200);
  assert.equal(warning(stoppedCheckpoint, stoppedCheckpoint.chapters[0]), null);
  assert.equal(stoppedCheckpoint.latest.get(stoppedCheckpoint.chapters[0].chapterUrl).text, stoppedCheckpoint.chapters[0].contentText);
  assert.equal(stoppedCheckpoint.progress.finishedChapterNumber, 2);
});

test('subscription gate encountered during repair preserves accepted text and never inflates skipped count', async () => {
  const f = setup([[800, 'unsubscribed'], [2200]]);
  await f.run();
  assert.equal(f.chapters[0].status, status.saved);
  assert.equal(f.chapters[0].contentText.length, 800);
  assert.equal(f.progress.qidianSkippedChapterNumber, 0);
  assert.equal(f.calls[0], 2);
  assert.equal(f.commits.length, 2);
});

test('real parser access gates cannot be converted to retained short text', async () => {
  const unsubscribed = fixtureContext.fixture([{ id: 0, vip: true, paid: true, locked: true }, { id: 1, vip: true, paid: true }]);
  unsubscribed.window.qidianTxtOnly = true;
  await unsubscribed.run();
  assert.equal(unsubscribed.chapters[0].qidianSkipReason, 'unsubscribed');
  assert.equal(unsubscribed.chapters[0].status, status.aborted);
  assert.equal(unsubscribed.ctx.qidianChapterLengthWarning(unsubscribed.chapters[0]), null);
  assert.equal(unsubscribed.chapters[1].status, status.saved);
  const login = fixtureContext.fixture([{ id: 0, vip: true, paid: true, password: true }]);
  login.window.qidianTxtOnly = true;
  await login.run();
  assert.notEqual(login.chapters[0].status, status.saved);
  assert.equal(login.ctx.qidianChapterLengthWarning(login.chapters[0]), null);
});

test('raw PUA cannot reach saver through the short-body queue and later chapters still succeed', async () => {
  const f = setup([[{ text: textOfLength(800) + '\uE001' }], [2200]]);
  await f.run();
  assert.equal(f.chapters[0].status, status.failed);
  assert.equal(warning(f, f.chapters[0]), null);
  assert.equal(f.chapters[1].status, status.saved);
  assert.equal(f.commits.length, 1);
  assert.equal(f.progress.finishedChapterNumber, 1);
});

test('same titles keep separate URL identities while short-body replacements remain one catalogue entry each', async () => {
  const f = setup([[800, 2200], [900, 2200]]);
  f.chapters.forEach(chapter => { chapter.chapterName = '同名章节'; });
  await f.run();
  assert.equal(f.latest.size, 2);
  assert.equal(f.book.chapters.length, 2);
  assert.equal(f.progress.finishedChapterNumber, 2);
  assert.equal(f.commits.length, 4);
  assert(f.chapters.every(chapter => warning(f, chapter) === null));
});

async function useRealStorage(f) {
  const storage = new Map();
  f.ctx.URL = URL;
  f.ctx.Date = class extends Date { static now() { return f.state.now; } };
  f.ctx.GM_getValue = (key, fallback) => structuredClone(storage.get(key) ?? fallback);
  f.ctx.GM_setValue = (key, value) => storage.set(key, structuredClone(value));
  f.ctx.GM_deleteValue = key => storage.delete(key);
  f.ctx.qidianCheckpointSave = f.realCheckpointSave;
  Object.assign(f.book, { bookUrl: 'https://www.qidian.com/book/1/', bookname: '长度核验测试书', author: '测试作者' });
  f.window.qidianCheckpointSession = await f.ctx.qidianCheckpointOpen(f.book, () => {});
  return storage;
}
class TXTOptions {
  genMetaDateTxt(book) {
    return '题名：' + book.bookname + '\n作者：' + book.author + '\n原始网址：' + book.bookUrl +
      '\n本文件由小说下载器生成，软件地址：https://github.com/404-novel-project/novel-downloader\n';
  }
  getchapterName(chapter) { return chapter.chapterName; }
  genSectionText() { return ''; }
  genChapterText(name, text) { return '…'.repeat(30) + '\n' + name + '\n\n' + text + '\n'; }
  chapterSort(a, b) { return a.chapterNumber - b.chapterNumber; }
}
async function exportTxt(f) {
  const outputs = [];
  f.ctx.Options = TXTOptions;
  f.ctx.Blob = Blob;
  f.ctx.FileSaver_min = { saveAs: (blob, name) => outputs.push({ blob, name }) };
  const start = source.indexOf('class TXT extends Options'), end = source.indexOf(';// ./src/save/raw.ts', start);
  assert(start >= 0 && end > start);
  vm.runInContext(source.slice(start, end) + '\nthis.TXT=TXT;', f.ctx);
  f.validate();
  new f.ctx.TXT(f.book).saveTxt();
  assert.equal(outputs.length, 1);
  return { name: outputs[0].name, text: await outputs[0].blob.text() };
}

test('production checkpoint binds retained short metadata and rejects corrupt digest or raw private glyphs', async () => {
  const f = setup([[800], [2200]]), storage = await useRealStorage(f);
  await f.run();
  const session = f.window.qidianCheckpointSession, chapter = f.chapters[0];
  const record = await f.ctx.qidianCheckpointRestore(session, chapter);
  assert(record);
  assert.equal(record.text, chapter.contentText);
  same(record.qidianLengthWarning, warning(f, chapter));
  const key = f.ctx.qidianCheckpointRecordKey(session, '0'), original = structuredClone(storage.get(key));
  assert(original.qidianLengthWarning);
  storage.set(key, { ...original, qidianLengthWarning: { ...original.qidianLengthWarning, bodyDigest: 'wrong' } });
  assert.equal(await f.ctx.qidianCheckpointRestore(session, chapter), null);
  storage.set(key, original);
  const invalid = { ...chapter, contentText: textOfLength(800) + '\uE001',
    options: { expectedChars: 2000, qidianBodyLength: 801, qidianLengthWarning: original.qidianLengthWarning } };
  assert.equal(await f.ctx.qidianCheckpointSave(session, invalid), false);
  assert.equal(storage.get(key).text, original.text);
});

test('short body with validated OCR placeholders survives TXT and checkpoint import with both warnings bound to body', async () => {
  const f = setup([[{ chars: 800, unknown: 2 }], [2200]]);
  await useRealStorage(f);
  await f.run();
  const body = f.chapters[0].contentText, lengthMetadata = warning(f, f.chapters[0]);
  const glyphMetadata = f.ctx.qidianChapterGlyphTolerance(f.chapters[0]);
  const output = await exportTxt(f);
  assert(output.text.includes(body));
  assert(output.text.includes(f.chapters[1].contentText));
  assert.equal(output.text.split('\n').filter(line => line.trim() === f.chapters[0].chapterName).length, 1);
  assert(output.text.includes(f.ctx.qidianLengthWarningText(lengthMetadata)));
  const restored = setup([[2200], [2200]]);
  await useRealStorage(restored);
  const imported = await restored.ctx.qidianCheckpointImportTxt(restored.window.qidianCheckpointSession, restored.book, output.text);
  assert.equal(imported.imported, 2);
  const record = await restored.ctx.qidianCheckpointRestore(restored.window.qidianCheckpointSession, restored.chapters[0]);
  assert(record);
  assert.equal(record.text, body);
  same(record.qidianLengthWarning, lengthMetadata);
  same(record.qidianGlyphTolerance, glyphMetadata);
});

(async () => {
  let passed = 0;
  for (const { name, run } of tests) {
    try { await run(); passed++; console.log('PASS ' + name); }
    catch (error) { console.error('FAIL ' + name, error); process.exitCode = 1; }
  }
  console.log(passed + '/' + tests.length + ' length retention checks passed');
})();
