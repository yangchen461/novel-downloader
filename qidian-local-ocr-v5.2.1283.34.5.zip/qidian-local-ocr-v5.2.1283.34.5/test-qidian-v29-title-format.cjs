/* Exercise the actual chapter_name settings preset and TXT checkpoint importer. */
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const main = fs.readFileSync(process.env.QIDIAN_SCRIPT_PATH || path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function between(start, end) {
  const begin = main.indexOf(start);
  const finish = main.indexOf(end, begin + start.length);
  assert(begin >= 0 && finish > begin, `source markers exist: ${start}`);
  return main.slice(begin, finish);
}
const formatter = between('function qidianFormatChapterName(', 'function qidianChapterDiagnostic(');
const presets = between('const saveOptions = [', '// Older installations saved EpubDownload=true.');
const checkpoints = between('// Local TXT checkpoints.', '// End local TXT checkpoint helpers.');
const validation = between('function qidianContentIsComplete(', 'function qidianContentFailure(');
function harness(hostname = 'www.qidian.com') {
  const storage = new Map();
  const context = vm.createContext({ URL, Map, Math, Date, Promise, setTimeout, clearTimeout,
    document: { location: { hostname } },
    GM_getValue: (key, fallback) => structuredClone(storage.get(key) ?? fallback),
    GM_setValue: (key, value) => storage.set(key, structuredClone(value)),
    GM_deleteValue: key => storage.delete(key) });
  vm.runInContext(formatter + presets + '\nglobalThis.realPreset = saveOptions.find(x => x.key === "chapter_name").options.getchapterName;', context);
  vm.runInContext(validation + checkpoints, context);
  return { context, storage, format: chapter => context.realPreset(chapter) };
}
const title = '第170章 重开击杀伊拉克司令！（求月票～）';
const body = '这是完整章节正文。包含足够汉字并保留全部段落。\n'.repeat(100);
function chapter(name = title) { return { chapterName: name, qidianCatalogTitle: name, chapterNumber: 173,
  chapterUrl: 'https://www.qidian.com/chapter/1048193111/903254700/', isVIP: true,
  options: { expectedChars: 2000 } }; }
function book() { return { bookname: '测试书', author: '测试作者',
  bookUrl: 'https://www.qidian.com/book/1048193111/', chapters: [chapter()] }; }
function txt(b, header) { return `题名：${b.bookname}\n作者：${b.author}\n原始网址：${b.bookUrl}\n本文件由小说下载器生成，软件地址：https://github.com/404-novel-project/novel-downloader\n\n${'…'.repeat(30)}\n${header}\n\n${body}\n`; }
let passed = 0;
async function test(name, fn) { await fn(); passed++; }
(async () => {
  await test('actual preset preserves the original numbered Qidian title', () => {
    const h = harness();
    assert.equal(h.format(chapter()), title);
    assert(!h.format(chapter()).startsWith('第173章'));
  });
  await test('actual preset preserves final chapter 340 rather than rendering catalog 349', () => {
    const h = harness(); const original = '第340章 大胜险地！制空权才是现代战争！（求月票！）';
    assert.equal(h.format({ ...chapter(original), chapterNumber: 349 }), original);
  });
  await test('Chinese, fullwidth and spaced original numbers retain the exact original string', () => {
    const h = harness();
    for (const original of ['第一百七十章 测试', '第壹佰柒拾章 测试', '第１７０章 测试', '  第 170 章 测试  ']) {
      assert.equal(h.format(chapter(original)), original);
    }
  });
  await test('legacy Qidian catalog hostname uses the same original-title behavior', () => {
    assert.equal(harness('book.qidian.com').format(chapter()), title);
  });
  await test('Qidian names without chapter numbers retain the existing catalog fallback', () => {
    const h = harness();
    assert.equal(h.format(chapter('番外：测试')), '第173章 番外：测试');
    assert.equal(h.format(chapter('')), '第173章');
    assert.equal(h.format({ ...chapter(), chapterName: undefined }), '第173章');
    assert.equal(h.format(chapter('第170章后面的标题')), '第170章后面的标题');
  });
  await test('non-Qidian presets retain their prior numbering behavior', () => {
    for (const host of ['www.example.com', 'www.qidian.com.example.com', 'notqidian.com']) {
      assert.equal(harness(host).format(chapter()), `第173章 ${title}`);
    }
  });
  await test('real checkpoint import accepts the new preset title and restores complete content', async () => {
    const h = harness(); const b = book(); const session = await h.context.qidianCheckpointOpen(b);
    const result = await h.context.qidianCheckpointImportTxt(session, b, txt(b, h.format(b.chapters[0])));
    assert.equal(result.parsed, 1); assert.equal(result.imported, 1); assert.equal(result.incomplete, 0);
    const restored = await h.context.qidianCheckpointRestore(session, b.chapters[0]);
    assert(restored); assert.equal(restored.text, body.trim());
  });
  await test('real checkpoint import remains compatible with old duplicate catalog prefixes', async () => {
    const h = harness(); const b = book(); const session = await h.context.qidianCheckpointOpen(b);
    const oldHeader = `第173章 ${title}`;
    const result = await h.context.qidianCheckpointImportTxt(session, b, txt(b, oldHeader));
    assert.equal(result.parsed, 1); assert.equal(result.imported, 1); assert.equal(result.ambiguous, 0);
    const restored = await h.context.qidianCheckpointRestore(session, b.chapters[0]);
    assert(restored); assert.equal(restored.text, body.trim());
  });
  await test('import helper strips an old catalog prefix only for an exact known title', () => {
    const h = harness(); const normalized = h.context.qidianCheckpointNormalize(title);
    const titles = new Set([normalized]);
    assert.equal(h.context.qidianCheckpointImportTitle(title, titles), normalized);
    assert.equal(h.context.qidianCheckpointImportTitle(`第173章 ${title}`, titles), normalized);
    assert.equal(h.context.qidianCheckpointImportTitle('第173章 第171章 另一个标题', titles), null);
    assert.equal(h.context.qidianCheckpointImportTitle(`第173章 第174章 ${title}`, titles), null);
  });
  console.log(`Qidian v29 title preset and TXT import: ${passed}/${passed} passed`);
})().catch(error => { console.error(error); process.exitCode = 1; });
