// Run the shipped full-catalog parsers, skip helper, restore, Chapter.parse and serial scheduler.
// Only browser/network/OCR/storage delivery are fixtures; no site is contacted.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a,b,from=0) {
  const start=src.indexOf(a,from),end=src.indexOf(b,start);
  assert(start>=0&&end>start,`Missing shipped source boundary: ${a}`);
  return src.slice(start,end);
}

const globals=take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode=take('class ChapterAbortError','\n\n/***/ },');
const catalogMethods=take('  async bookParse_www()', '  async chapterParse(',src.indexOf('class Qidian extends'));
const parser=take('  async chapterParse(', '\n}\n\n\n/***/',src.indexOf('class Qidian extends'));
const scheduler=take('  async initChapters(book,','\n  postHook()');
const prewarmGuard=take('      if (/^(?:www|book)\\.qidian\\.com$/.test(document.location.hostname) &&',
  '      if (self.book.chapters.length === 0)',src.indexOf('await qidianRestoreSelectedChapters(self.book'));
const saveCode=take('  async addChapter(chapter) {','\n  async save()',src.indexOf('class SaveBook'));
const validation=take('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {',
  '      // Export lifecycle begins after per-chapter filtering.',src.indexOf('await self.initChapters(self.book'));
const txtCode=take('class TXT extends Options',';// ./src/save/raw.ts');
const progressCode=take('function formatETA(','app.config.compilerOptions');
const progressOptions=vm.runInNewContext(progressCode+'\napp',{external_Vue_:{createApp:o=>o},ui_progress:''});
const statuses={pending:0,downloading:1,failed:2,finished:3,aborted:4,saved:5};
const body='真实正文内容完整，页面正常显示。'.repeat(200);
const normalize=value=>JSON.parse(JSON.stringify(value));
function node(tag='div') {
  return {tagName:tag.toUpperCase(),children:[],appendChild(child){this.children.push(child);return child;}};
}
function makeDoc(cfg) {
  const text=cfg.rawText??(cfg.short?'短正文':body);
  const visibleText=cfg.gate&&!cfg.fullWithGate?cfg.prompt??'本章为VIP章节，请订阅后阅读':text;
  const limit=cfg.gate?{textContent:cfg.prompt??'本章为VIP章节，请订阅后阅读',innerText:cfg.prompt??'本章为VIP章节，请订阅后阅读',
    hidden:cfg.hiddenGate??false,style:cfg.hiddenGateStyle?{display:'none'}:{},
    getAttribute(name){return name==='aria-hidden'&&cfg.ariaHiddenGate?'true':null;},querySelector(){return null;},querySelectorAll(){return [];}}:null;
  const control=cfg.control?{innerText:cfg.control,textContent:cfg.control,getAttribute(){return null;},
    closest(selector){
      if(cfg.navControl&&/nav|header|footer|aside/.test(selector))return {};
      if(cfg.bodyControl&&selector==='.content-text')return main;
      return null;
    }}:null;
  const main=cfg.noMain?null:{cfg,textContent:visibleText,innerText:visibleText,
    querySelectorAll:selector=>selector==='p'?Array(5).fill({}):[],
    querySelector(selector){
      if(selector==='.content-text')return cfg.gate&&!cfg.fullWithGate?null:main;
      if(selector.split(',').some(s=>s.trim()==='.vip-limit-wrap'))return limit;
      return null;
    }};
  const doc={title:cfg.block?'WAF拦截页面':cfg.login?'用户登录':cfg.verify?'安全验证':`第${cfg.id}章`,
    body:{textContent:cfg.block?'403 您的请求已中断':cfg.login?'请先登录，订阅后阅读':cfg.verify?'请完成安全验证':visibleText,
      innerText:cfg.block?'403 您的请求已中断':cfg.login?'请先登录，订阅后阅读':cfg.verify?'请完成安全验证':visibleText},
    querySelector(selector){
      for(const s of selector.split(',').map(v=>v.trim())) {
        if(s==='main'&&main)return main;
        if(s==='h1.title')return {innerText:`第${cfg.id}章`};
        if(s==='.vip-limit-wrap'&&limit)return limit;
        if(s==='.content-text'&&main&&(!cfg.gate||cfg.fullWithGate))return main;
      }
      return null;
    },querySelectorAll(selector){return control&&selector.startsWith('main button')?[control]:[];}};
  main&&(main.ownerDocument=doc);
  return doc;
}
function fixture(configs, options={}) {
  const storage=options.storage??new Map();
  const state={now:1000,requests:[],waits:[],ocr:[],clean:[],persist:0,saved:[],logs:[],timers:new Map(),timer:0,removed:[],postHooks:0,prewarms:0};
  const log=Object.fromEntries(['info','warn','error','trace','debug'].map(level=>[level,(...args)=>state.logs.push({level,text:args.map(value=>String(value?.message??value)).join(' ')})]));
  const window={stopController:new AbortController(),qidianTxtOnly:true,failedCount:0,qidianDebugLogger:log};
  window.stopFlag=window.stopController.signal;
  const progress=progressOptions.data();Object.assign(progress,progressOptions.methods);
  for(const [key,computed]of Object.entries(progressOptions.computed))Object.defineProperty(progress,key,{get:()=>computed.call(progress)});
  const configsById=new Map(configs.map(cfg=>[cfg.id,cfg]));
  async function request(route,url,predicate) {
    const id=Number(String(url).split('/').filter(Boolean).at(-1));
    const cfg=configsById.get(id);assert(cfg,`Unexpected chapter ${id}`);
    state.requests.push({id,route,at:state.now,otherTypePending:progress.qidianOtherTypePending,
      finishedCount:progress.finishedChapterNumber,skippedCount:progress.qidianSkippedChapterNumber,
      processedIndex:progress.processedChapterIndex});state.now+=cfg.pageMs??700;
    if(cfg.httpStatus){const e=new Error(`HTTP ${cfg.httpStatus}`);e.status=cfg.httpStatus;throw e;}
    if(cfg.blank){const e=new Error('Frame Timeout!');e.frameState={addressKind:'requested',readyState:'complete',bodyPresent:true,
      bodyTextLength:0,contentPresent:false,mainParagraphs:0};throw e;}
    if(cfg.network){throw Error('ordinary network failure');}
    const doc=makeDoc(cfg);
    if(route==='html')return doc;
    let removed=false;
    const frame={contentWindow:{document:doc},remove(){if(!removed){removed=true;state.removed.push(id);}}};
    try{assert.equal(predicate(frame),true);}catch(e){frame.remove();throw e;}
    return frame;
  }
  class ClockDate extends Date {static now(){return state.now;}}
  const sleep=async ms=>{state.waits.push(ms);state.now+=ms;};
  const ctx=vm.createContext({window,unsafeWindow:window,Date:ClockDate,URL,Map,Set,Promise,AbortController,console:log,
    Math:Object.assign(Object.create(Math),{random:()=>0}),alert(){},
    document:{location:{hostname:options.host??'www.qidian.com',href:`https://${options.host??'www.qidian.com'}/book/1/`},createElement:node},
    TextEncoder,TextDecoder,
    GM_info:{script:{version:'5.2.1283.34.3'}},
    GM:{getValue:async(key,fallback)=>storage.has(key)?structuredClone(storage.get(key)):fallback,
      setValue:async(key,value)=>storage.set(key,structuredClone(value)),deleteValue:async key=>storage.delete(key),listValues:async()=>[...storage.keys()]},
    _main_Chapter__WEBPACK_IMPORTED_MODULE_8__:{I:null},
    _main_main__WEBPACK_IMPORTED_MODULE_7__:{nW:statuses},
    _main_Book__WEBPACK_IMPORTED_MODULE_9__:{E:class Book{constructor(data){Object.assign(this,data);}}},
    _lib_rule__WEBPACK_IMPORTED_MODULE_5__:{HV:async()=>['fixture intro',node()]},
    _lib_attachments__WEBPACK_IMPORTED_MODULE_0__:{if:async()=>({})},
    _lib_misc__WEBPACK_IMPORTED_MODULE_3__:{yy:sleep},
    setTimeout:(fn,ms)=>{const id=++state.timer;state.timers.set(id,{fn,ms});return id;},clearTimeout:id=>state.timers.delete(id),
    GM_getValue:(key,fallback)=>key==='qidianSkipCatalogLockedV2'&&options.skipEnabled!==undefined?options.skipEnabled===true:storage.has(key)?structuredClone(storage.get(key)):fallback,
    GM_setValue:(key,value)=>storage.set(key,structuredClone(value)),GM_deleteValue:key=>storage.delete(key),GM_listValues:()=>[...storage.keys()],
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:statuses},main:{nW:statuses,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log,_log__WEBPACK_IMPORTED_MODULE_6___default:()=>log,loglevel_default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:sleep},misc:{yy:sleep},setting:{Zz:{value:false},Nw:{value:false}},progress:{vm:progress},log:{M6(){}},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async url=>request('html',url),Q2:async(url,predicate)=>request('frame',url,predicate)},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(){},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{async an(main){state.clean.push(main.cfg.id);return {dom:node(),text:main.textContent,images:[]};},is(){}},
    async ocrContent(main){state.ocr.push(main.cfg.id);state.now+=400;return {contentText:main.cfg.ocrText??main.textContent,contentHTML:node()};},
    qidianGlyphCache:new Map(),async qidianPersistGlyphCache(){state.persist++;}
  });
  vm.runInContext(globals+chapterCode+'\nclass Qidian {'+catalogMethods+parser+'}\nclass Rule {'+scheduler+'}\nclass Save {'+saveCode+'}\nthis.Chapter=Chapter;this.Qidian=Qidian;this.Rule=Rule;this.Save=Save;'+
    '\nthis.validate=self=>{let qidianCompletionMessage;'+validation+'return self.book;};'+
    '\nthis.prewarm=self=>{'+prewarmGuard+'};',ctx);
  ctx._main_Chapter__WEBPACK_IMPORTED_MODULE_8__.I=ctx.Chapter;
  const qidian=new ctx.Qidian();
  const chapters=configs.map(cfg=>new ctx.Chapter({bookUrl:'https://www.qidian.com/book/1/',chapterUrl:`https://www.qidian.com/chapter/1/${cfg.id}/`,
    chapterNumber:cfg.id,chapterName:`第${cfg.id}章`,isVIP:cfg.vip??true,isPaid:cfg.paid??true,charset:'UTF-8',options:{bookId:'1',expectedChars:cfg.expectedChars??2000,qidianCatalogLocked:cfg.locked===true,limitFree:cfg.limitFree===true},chapterParse:qidian.chapterParse.bind(qidian)}));
  const book={bookUrl:'https://www.qidian.com/book/1/',bookname:'catalog test',author:'fixture',chapters,qidianCatalogHasPaidVIP:options.trusted!==false};
  window.qidianDebugRun={id:'subscription-fixture',startedAt:state.now,book,selectedChapters:chapters,selectedCount:chapters.length};
  const rule=new ctx.Rule();Object.assign(rule,{concurrencyLimit:1,sleepTime:8000,maxSleepTime:20000});
  const saver=new ctx.Save();saver.saveType={txt:true,epub:false};
  const originalAdd=saver.addChapter.bind(saver);
  saver.addChapter=async chapter=>{state.saved.push(chapter.chapterNumber);return originalAdd(chapter);};
  const events=()=>state.logs.filter(entry=>entry.text.startsWith('[QidianDebug] ')).map(entry=>JSON.parse(entry.text.slice('[QidianDebug] '.length)));
  return {ctx,state,window,progress,chapters,book,events,storage,qidian,
    async prepare(){await ctx.qidianRestoreSelectedChapters(book,statuses);return ctx.qidianApplyCatalogSkips(book,statuses,log);},
    async run({prepared=false}={}){if(!prepared)await this.prepare();ctx.prewarm({book,prewarmVipOCR(){state.prewarms++;}});try{await rule.initChapters(book,saver);}catch(e){if(!window.stopFlag.aborted)throw e;}window.qidianDebugRun.finished=true;window.qidianDebugRun.endedAt=state.now;return book;},
    validate:()=>ctx.validate({book,postHook(){state.postHooks++;}}),summary:()=>normalize(ctx.qidianRunSummary(book))};
}

const tests=[];const test=(name,fn)=>tests.push({name,fn});
const ids=f=>f.state.requests.map(row=>row.id);
function assertCatalogSkipped(f,index) {
  const chapter=f.chapters[index],row=normalize(f.ctx.qidianChapterDiagnostic(chapter));
  assert.equal(chapter.status,statuses.aborted);
  assert.equal(chapter.qidianSkipReason,'unsubscribed');
  assert.equal(chapter.qidianFailureKind,null);
  assert.equal(chapter.qidianAttemptCount,0,'a catalog skip must not enter chapter parsing');
  assert.equal(chapter.qidianAccessEvidence,'catalog_lock');
  assert.equal(row.statusName,'skipped');assert.equal(row.stage,'access_check');
  assert.equal(row.errorCode,'chapter_unsubscribed');assert.equal(row.quality,null);
  assert(chapter.contentText==null);assert(chapter.contentHTML==null);
}
function installCatalog(f,configs,{host='www.qidian.com',limitFree=false}={}) {
  const www=host==='www.qidian.com';
  const sections=configs.map(cfg=>{
    const lock=cfg.locked?{hidden:!!cfg.hiddenLock,style:{},parentElement:null,
      getAttribute(name){return name==='aria-hidden'&&cfg.ariaHiddenLock?'true':null;},closest(){return null;}}:null;
    const a={innerText:`第${cfg.id}章`,href:`https://www.qidian.com/chapter/1/${cfg.id}/`,
      getAttribute:name=>name==='title'?'章节字数：2000':null};
    const li={querySelector(selector){
      if(selector==='a')return a;
      if(selector==='.chapter-locked'||selector==='em.iconfont')return lock;
      return null;
    }};
    return {querySelector(selector){
      if(selector==='.volume-name')return {innerText:'正文卷'};
      if(selector==='.volume-header'||selector==='h3')return {innerText:cfg.vip===false?'正文卷':'正文卷 VIP'};
      return null;
    },querySelectorAll(selector){return selector==='ul.volume-chapters > li'||selector==='ul.cf > li'?[li]:[];}};
  });
  const doc={cookie:'_csrfToken=LOCAL_ONLY_CREDENTIAL',
    location:{hostname:host,href:`https://${host}/book/1/`},defaultView:{getComputedStyle:el=>el.style??{}},
    getElementById(id){return id==='bookImg'?{getAttribute:()=> '1'}:id==='authorId'?{getAttribute:()=> '7'}:null;},
    querySelector(selector){
      if(selector==='.author')return {innerText:'fixture'};
      if(selector==='#bookName'||selector==='.book-info > h1 > em')return {innerText:'catalog test'};
      if(selector==='.book-info .writer, .book-info > h1:nth-child(1) > span:nth-child(2)')return {innerText:'作者:fixture 著'};
      if(selector==='#bookImg > img')return {src:''};
      if(selector==='#J-catalogCount')return {innerText:String(configs.length)};
      if(selector==='#bookImg > div.limit-flag'||selector==='.book-information .flag')return limitFree?{}:null;
      return null;
    },querySelectorAll(selector){
      if(selector==='.catalog-volume'||selector==='#j-catalogWrap > .volume-wrap > .volume')return sections;
      if(selector==='#j-catalogWrap li')return configs;
      return [];
    }};
  f.ctx.document=doc;return www?f.qidian.bookParse_www():f.qidian.bookParse_book();
}

for(const count of [3,10])test(`${count} consecutive catalog locks make zero requests and the following paid chapter saves`,async()=>{
  const f=fixture([...Array.from({length:count},(_,i)=>({id:i+1,locked:true,paid:false,blank:true})),{id:count+1}],{skipEnabled:true});
  await f.run();for(let i=0;i<count;i++)assertCatalogSkipped(f,i);
  assert.deepEqual(ids(f),[count+1]);assert.deepEqual(f.state.ocr,[count+1]);
  assert.deepEqual(f.state.saved,[count+1]);assert.equal(f.chapters[count].status,statuses.saved);
  assert.equal(f.window.stopFlag.aborted,false);assert.equal(f.window.failedCount,0);
  assert.equal(f.progress.processedChapterIndex,count+1);assert.equal(f.progress.finishedChapterNumber,1);
  assert.equal(f.progress.totalChapterNumber,count+1);
  const events=f.events();assert.equal(events.filter(e=>e.event==='chapter_skipped').length,count);
  assert.equal(events.filter(e=>e.event==='chapter_result').length,count+1);
  assert(events.filter(e=>e.event==='chapter_skipped').every(e=>e.attempt===0&&e.accessEvidence==='catalog_lock'));
  assert.equal(events.filter(e=>e.event==='request_pacing').length,1,'no pacing events for unrequested catalog locks');
  assert(!events.some(e=>Number(e.chapterId)<=count&&['attempt_start','attempt_error','retry_scheduled','chapter_stage_start'].includes(e.event)));
  assert.equal(f.summary().skippedCount,count);assert.equal(f.summary().savedCount,1);
  assert.equal(f.summary().failedCount,0);assert.equal(f.summary().outcome,'completed_with_skips');
});

test('an all-locked selected range remains skippable when paid evidence comes from the full catalog',async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2,locked:true,paid:false}],{skipEnabled:true});
  const parsed=await installCatalog(f,[{id:1,locked:true},{id:2,locked:true},{id:99}]);
  assert.equal(parsed.qidianCatalogHasPaidVIP,true);
  f.book.qidianCatalogHasPaidVIP=parsed.qidianCatalogHasPaidVIP;
  f.ctx.document.location.hostname='www.qidian.com';await f.run();
  assert.deepEqual(ids(f),[]);f.chapters.forEach((_,i)=>assertCatalogSkipped(f,i));
  assert.equal(f.progress.processedChapterIndex,2);assert.equal(f.summary().outcome,'completed_with_skips');
  assert.equal(f.state.prewarms,0,'all catalog skips must not prewarm the OCR model');
  assert.deepEqual(f.state.waits,[]);f.validate();
  assert.equal(f.book.downloadReport.skippedCount,2);assert.equal(f.book.downloadReport.missing.length,0);
});

for(const host of ['www.qidian.com','book.qidian.com'])test(`${host}: actual catalog parser records mixed ownership and only VIP locks`,async()=>{
  const f=fixture([]),parsed=await installCatalog(f,[{id:1,locked:true},{id:2},{id:3,vip:false,locked:true}],{host});
  assert.equal(parsed.qidianCatalogHasPaidVIP,true);
  assert.equal(parsed.chapters[0].options.qidianCatalogLocked,true);
  assert.notEqual(parsed.chapters[1].options.qidianCatalogLocked,true);
  assert.notEqual(parsed.chapters[2].options.qidianCatalogLocked,true,'public chapter decorations are not subscription evidence');
  assert.equal(parsed.chapters[0].isPaid,false);assert.equal(parsed.chapters[1].isPaid,true);
});

for(const host of ['www.qidian.com','book.qidian.com'])test(`${host}: a full catalog without positive paid VIP evidence stays untrusted`,async()=>{
  const f=fixture([]),parsed=await installCatalog(f,[{id:1,locked:true},{id:2,locked:true},{id:3,vip:false}],{host});
  assert.equal(parsed.qidianCatalogHasPaidVIP,false,'a free chapter cannot prove authenticated VIP ownership');
});

for(const host of ['www.qidian.com','book.qidian.com'])test(`${host}: hidden lock is not positive catalog-lock evidence`,async()=>{
  const f=fixture([]),parsed=await installCatalog(f,[{id:1,locked:true,hiddenLock:true},{id:2}],{host});
  assert.notEqual(parsed.chapters[0].options.qidianCatalogLocked,true);
});

test('disabled catalog skip flag probes a readable stale lock and still downloads it',async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2}],{skipEnabled:false});await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.saved,[1,2]);assert.equal(f.summary().skippedCount,0);
});

for(const legacyEnabled of [false,true])test(`V32 defaults to reader verification even when the legacy V1 catalogue preference is ${legacyEnabled}`,async()=>{
  const storage=new Map([['qidianSkipCatalogLockedV1',legacyEnabled]]);
  const f=fixture([{id:1,locked:true,paid:false},{id:2,locked:true,paid:false},{id:3,vip:false}],{storage});
  await f.run();
  assert.deepEqual(ids(f),[1,2,3],'the default must inspect every selected reader rather than trust catalogue lock icons');
  assert.deepEqual(f.state.ocr,[1,2]);assert.deepEqual(f.state.clean,[3]);
  assert.deepEqual(f.state.saved,[1,2,3]);assert.equal(f.summary().skippedCount,0);
  assert.equal(f.summary().outcome,'completed');assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(storage.has('qidianSkipCatalogLockedV2'),false,'the fixture must exercise the shipped default');
});

test('untrusted all-locked catalog probes chapters instead of silently discarding a readable body',async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2,locked:true,paid:false}],{trusted:false,skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.saved,[1,2]);assert.equal(f.summary().skippedCount,0);
});

test('untrusted catalog can still skip three positively detected reader gates and continue',async()=>{
  const f=fixture([{id:1,locked:true,gate:true},{id:2,locked:true,gate:true},{id:3,locked:true,gate:true},{id:4}],{trusted:false,skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[1,2,3,4]);assert.deepEqual(f.state.saved,[4]);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.window.failedCount,0);assert.equal(f.summary().skippedCount,3);
  assert(f.chapters.slice(0,3).every(c=>c.qidianAttemptCount===1&&c.qidianAccessEvidence!=='catalog_lock'));
});

test('limit-free VIP lock remains downloadable',async()=>{
  const f=fixture([{id:1,locked:true,paid:false,limitFree:true},{id:2}],{skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.saved,[1,2]);assert.equal(f.summary().skippedCount,0);
});

test('a free chapter with a lock flag cannot be catalog-skipped',async()=>{
  const f=fixture([{id:1,vip:false,locked:true,paid:false},{id:2}],{skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[1,2]);assert.deepEqual(f.state.clean,[1]);assert.deepEqual(f.state.ocr,[2]);
  assert.equal(f.summary().skippedCount,0);
});

test('an explicitly paid catalog chapter takes priority over a conflicting stale lock flag',async()=>{
  const f=fixture([{id:1,locked:true,paid:true},{id:2}],{skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[1,2]);assert(f.chapters.every(c=>c.status===statuses.saved));
  assert.equal(f.summary().skippedCount,0);
});

test('turning off only catalog skips still honors confirmed reader subscription gates',async()=>{
  const f=fixture([{id:1,locked:true,paid:false,gate:true},{id:2,locked:true,paid:false,gate:true},
    {id:3,locked:true,paid:false,gate:true},{id:4}],{skipEnabled:false});await f.run();
  assert.deepEqual(ids(f),[1,2,3,4]);assert.deepEqual(f.state.saved,[4]);
  assert.equal(f.summary().skippedCount,3);assert.equal(f.window.failedCount,0);assert.equal(f.window.stopFlag.aborted,false);
  assert(f.chapters.slice(0,3).every(c=>c.qidianAccessEvidence==='vip_limit_wrap'));
});

test('catalog skip clears the previous failure classification and records fresh access evidence',async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2}],{skipEnabled:true}),chapter=f.chapters[0];
  chapter.status=statuses.failed;chapter.qidianFailureKind='page';chapter.qidianAttemptCount=2;
  chapter.options.qidianFailureStage='page_load';chapter.options.qidianErrorInfo={errorCode:'page_timeout',reason:'old timeout'};
  await f.run();assertCatalogSkipped(f,0);assert.equal(f.window.failedCount,0);
  assert.equal(normalize(f.ctx.qidianChapterDiagnostic(chapter)).httpStatus,null);
  assert(!f.events().some(e=>e.chapterId==='1'&&e.errorCode==='page_timeout'));
});

test('actual full catalog parser and serial scheduler skip ten locks before the paid VIP',async()=>{
  const configs=[...Array.from({length:10},(_,i)=>({id:i+1,locked:true,paid:false,blank:true})),{id:11}];
  const f=fixture(configs,{skipEnabled:true}),parsed=await installCatalog(f,configs);
  f.chapters.splice(0,f.chapters.length,...parsed.chapters);Object.assign(f.book,parsed,{chapters:f.chapters});
  f.ctx.document.createElement=node;await f.run();
  assert.deepEqual(ids(f),[11]);assert.deepEqual(f.state.saved,[11]);
  for(let i=0;i<10;i++)assertCatalogSkipped(f,i);
  assert.equal(f.window.stopFlag.aborted,false);assert.equal(f.summary().skippedCount,10);
});

test('catalog helper is inert outside Qidian',async()=>{
  const f=fixture([{id:1,locked:true,paid:false}],{host:'example.com',skipEnabled:true});
  f.ctx.qidianApplyCatalogSkips(f.book,statuses);
  assert.equal(f.chapters[0].status,statuses.pending);assert.notEqual(f.chapters[0].qidianSkipReason,'unsubscribed');
});

test('restored valid body takes priority over a newly observed stale catalog lock',async()=>{
  const storage=new Map(),first=fixture([{id:1},{id:2}],{storage});await first.run();
  const second=fixture([{id:1,locked:true,paid:false},{id:2}],{storage,skipEnabled:true});await second.run();
  assert.deepEqual(ids(second),[]);assert(second.chapters.every(c=>c.status===statuses.saved));
  assert.equal(second.book.qidianResumedCount,2);assert.equal(second.summary().skippedCount,0);
  assert.equal(second.progress.finishedChapterNumber,2);assert.equal(second.progress.processedChapterIndex,2);
});

test('a skipped chapter is not negatively persisted and can download after subscription changes',async()=>{
  const storage=new Map(),first=fixture([{id:1,locked:true,paid:false},{id:2}],{storage,skipEnabled:true});await first.run();
  const second=fixture([{id:1,paid:true},{id:2}],{storage});await second.run();
  assert.deepEqual(ids(first),[2]);assert.deepEqual(ids(second),[1]);
  assert(second.chapters.every(c=>c.status===statuses.saved));assert.equal(second.summary().skippedCount,0);
  assert(!JSON.stringify([...storage.values()]).includes('chapter_unsubscribed'),'catalog skips are session-only');
});

test('corrupted stale checkpoint cannot force a locked chapter into saved status',async()=>{
  const storage=new Map(),first=fixture([{id:1},{id:2}],{storage});await first.run();
  let corruptions=0;
  for(const [key,value]of storage)if(value?.chapterId==='1'){storage.set(key,{...value,text:'短正文'});corruptions++;}
  assert.equal(corruptions,1,'the actual saved chapter record must be corrupted by this fixture');
  const second=fixture([{id:1,locked:true,paid:false},{id:2}],{storage,skipEnabled:true});await second.run();
  assertCatalogSkipped(second,0);assert.equal(second.chapters[1].status,statuses.saved);
  assert.deepEqual(ids(second),[]);assert.equal(second.book.qidianResumedCount,1);
});

test('opted-in catalog skips and adjacent failed recovery chapters preserve full traversal and pacing',async()=>{
  const f=fixture([{id:1,blank:true},{id:2,blank:true},{id:3,locked:true,paid:false},{id:4,blank:true},{id:5}],{skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[1,2,4,5,1,2,4,1,2,4]);assert.equal(f.window.stopFlag.aborted,false);
  assertCatalogSkipped(f,2);assert.equal(f.chapters[4].status,statuses.saved);
  assert.equal(f.window.failedCount,9);assert.equal(f.summary().failedCount,3);assert.equal(f.summary().skippedCount,1);
  assert.equal(f.events().filter(e=>e.event==='recovery_round_start').length,2);
  for(let i=1;i<f.state.requests.length;i++)assert(f.state.requests[i].at-f.state.requests[i-1].at>=10000);
});

for(const httpStatus of [401,403,429])test(`catalog skips do not suppress a real HTTP ${httpStatus} global pause`,async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2,httpStatus},{id:3}],{skipEnabled:true});await f.run();
  assertCatalogSkipped(f,0);assert.deepEqual(ids(f),[2]);assert.equal(f.window.stopFlag.aborted,true);
  assert.equal(f.chapters[2].status,statuses.pending);assert.equal(f.summary().outcome,'paused');
  assert.equal(f.summary().skippedCount,1);assert.notEqual(f.chapters[1].qidianSkipReason,'unsubscribed');
});

test('three consecutive unknown blank pages after opted-in catalog skips still save later chapters',async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2,blank:true},{id:3,blank:true},{id:4,blank:true},{id:5}],{skipEnabled:true});await f.run();
  assert.deepEqual(ids(f),[2,3,4,5,2,3,4,2,3,4]);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.chapters[4].status,statuses.saved);assert.equal(f.summary().skippedCount,1);
  assert.equal(f.summary().failedCount,3);assert.equal(f.summary().unprocessedCount,0);
  assert.equal(f.events().filter(e=>e.event==='recovery_round_start').length,2);
  for(const chapter of f.chapters.slice(1,4)) {
    assert.equal(chapter.qidianAttemptCount,3);assert.notEqual(chapter.qidianSkipReason,'unsubscribed');
    assert.equal(chapter.status,statuses.failed);assert.equal(chapter.contentText,null);
  }
  for(let i=1;i<4;i++)assert.equal(f.state.requests[i].at-f.state.requests[i-1].at,10000,'a 5s sampled cooldown still preserves the ordinary 10s protected request interval');
});

test('the shipped run restores saved chapters before applying catalog skips',()=>{
  const run=take('  async run() {','  async preHook()',src.indexOf('class BaseRuleClass'));
  const restore=run.indexOf('await qidianRestoreSelectedChapters(self.book, main/* Status */.nW)');
  const apply=run.indexOf('qidianApplyCatalogSkips(self.book, main/* Status */.nW');
  assert(restore>=0&&apply>restore,'catalog skip policy must run after successful checkpoint restore');
  assert(apply<run.indexOf('await self.initChapters(self.book'));
});

function assertCompletedProgress(f,successful,skipped) {
  assert.equal(f.progress.finishedChapterNumber,successful,'finished count remains actual saved chapter count');
  assert.equal(f.progress.qidianSkippedChapterNumber,skipped);
  assert.equal(f.progress.chapterPercent,100,'successes plus subscription skips complete the selected range');
  assert.equal(f.progress.etaText,'','no remaining ETA after all successful and skipped chapters are processed');
  assert.match(f.progress.chapterProgressTitle,new RegExp(`成功\\s*${successful}`));
  assert.match(f.progress.chapterProgressTitle,new RegExp(`跳过\\s*${skipped}`));
}

test('10 catalog skips and 5 saved chapters produce 100 percent and an empty ETA in shipped VM computed',async()=>{
  const f=fixture([...Array.from({length:10},(_,i)=>({id:i+1,locked:true,paid:false})),
    ...Array.from({length:5},(_,i)=>({id:i+11}))],{skipEnabled:true});await f.run();
  assertCompletedProgress(f,5,10);assert.deepEqual(ids(f),[11,12,13,14,15]);
  assert.equal(f.state.requests[0].skippedCount,10,'pre-marked catalog skips are counted once before the first request');
  assert.equal(f.progress.processedChapterIndex,15);assert.equal(f.progress.qidianOtherTypePending,false);
});

test('an entirely skipped selected range reaches 100 percent without a request or OCR warmup',async()=>{
  const f=fixture(Array.from({length:10},(_,i)=>({id:i+1,locked:true,paid:false})),{skipEnabled:true});await f.run();
  assertCompletedProgress(f,0,10);assert.deepEqual(ids(f),[]);assert.equal(f.state.prewarms,0);
  assert.equal(f.progress.processedChapterIndex,10);assert.equal(f.progress.qidianOtherTypePending,false);
});

test('three reader-detected skips increment progress once each and the saved chapter completes the task',async()=>{
  const f=fixture([{id:1,gate:true},{id:2,gate:true},{id:3,gate:true},{id:4}]);await f.run();
  assertCompletedProgress(f,1,3);
  assert.deepEqual(f.state.requests.map(row=>row.skippedCount),[0,1,2,3]);
  assert.deepEqual(ids(f),[1,2,3,4]);assert.equal(f.window.stopFlag.aborted,false);
  assert.equal(f.progress.qidianOtherTypePending,false);
});

test('only catalog-skipped VIPs between two free chapters do not create a pending mixed-route queue',async()=>{
  const f=fixture([{id:1,vip:false},...Array.from({length:10},(_,i)=>({id:i+2,locked:true,paid:false})),{id:12,vip:false}],{skipEnabled:true});
  await f.run();assertCompletedProgress(f,2,10);
  assert.deepEqual(ids(f),[1,12]);assert(f.state.requests.every(row=>row.otherTypePending===false),
    'initial free/VIP queue counts must exclude catalog skips, and the skip branch must not decrement them twice');
  assert(f.state.requests[1].at-f.state.requests[0].at<10000,'unrequested VIP locks must not change the actual free route');
  assert.equal(f.progress.qidianOtherTypePending,false);
});

test('progress reset clears subscription skip count',async()=>{
  const f=fixture([{id:1,locked:true,paid:false},{id:2}],{skipEnabled:true});await f.run();
  assertCompletedProgress(f,1,1);f.progress.reset();
  assert.equal(f.progress.qidianSkippedChapterNumber,0);assert.equal(f.progress.finishedChapterNumber,0);
  assert.equal(f.progress.totalChapterNumber,0);assert.equal(f.progress.chapterPercent,0);assert.equal(f.progress.etaText,'');
});

test('non-Qidian VM progress retains the original successful count, title and ETA despite skip metadata',()=>{
  const progress={...progressOptions.data(),finishedChapterNumber:5,totalChapterNumber:10,
    totalRequestTime:5000,processedChapterIndex:5,concurrencyLimit:2,isQidianRun:false,qidianSkippedChapterNumber:5};
  for(const [key,computed]of Object.entries(progressOptions.computed))Object.defineProperty(progress,key,{get:()=>computed.call(progress)});
  assert.equal(progress.chapterPercent,50);assert.equal(progress.chapterProgressTitle,'章节：5/10');
  assert.equal(progress.etaText,'~3s');
});

(async()=>{let failed=0;for(const{name,fn}of tests){try{await fn();console.log('PASS',name);}catch(error){failed++;console.error('FAIL',name,error);}}
console.log(`${tests.length-failed}/${tests.length} v27 catalog skip checks passed`);if(failed)process.exitCode=1;})();
