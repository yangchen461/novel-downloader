#!/usr/bin/env python3
"""v27 reader/probe/catalog diagnostics: synthetic metadata, no network."""
import importlib.util
import json
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("analyzer", Path(__file__).with_name("analyze-qidian-debug.py"))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def event(name, **fields):
    return {"schema": 2, "version": "5.2.1283.27", "runId": "synthetic-v27", "event": name, **fields}


def analyze(*rows):
    return A.analyze("\n".join("[QidianDebug] " + json.dumps(row) for row in rows))["runs"][0]


def reader(**fields):
    return dict(mainTextLength=350, contentTextLength=0, contentRootPresent=False, contentRootVisible=False,
                vipLimitPresent=False, vipLimitVisible=False, purchaseControlCount=0,
                genericSubscribeControlCount=1, loginControlCount=0, verificationControlCount=0,
                loadingControlCount=0, controlCount=1, omittedControls=0,
                controls=[dict(tagName="button", classes=["subscribe-btn"], labelKind="generic_purchase",
                               visible=True, inContent=False, inNavigation=False)], **fields)


class V27AnalyzerTests(unittest.TestCase):
    def test_reader_counts_control_labels_and_probe_state_retained(self):
        run = analyze(event("frame_wait_state", chapterId="2", attempt=1, readyState="complete",
                            readerDiagnostics=reader(), pageErrorProbeAvailable=True,
                            capturedPageErrors=2, droppedPageErrors=1, observationMs=19000))
        state = run["frameWaitStates"][0]
        self.assertEqual(state["readerDiagnostics"]["mainTextLength"], 350)
        self.assertFalse(state["readerDiagnostics"]["contentRootPresent"])
        self.assertEqual(state["readerDiagnostics"]["genericSubscribeControlCount"], 1)
        self.assertEqual(state["readerDiagnostics"]["controls"][0]["labelKind"], "generic_purchase")
        self.assertEqual(state["capturedPageErrors"], 2)
        self.assertEqual(state["droppedPageErrors"], 1)
        self.assertEqual(state["observationMs"], 19000)
        self.assertTrue(state["pageErrorProbeAvailable"])

    def test_reader_diagnostics_in_failure_frame_and_summary_preserved(self):
        state = dict(readyState="complete", readerDiagnostics=reader(), capturedPageErrors=0,
                     pageErrorProbeAvailable=True, observationMs=20000)
        run = analyze(event("attempt_error", chapterId="2", errorCode="page_timeout", frameState=state),
                      event("run_summary", missing=[dict(chapterId="2", statusName="failed", frameState=state)]))
        self.assertEqual(run["failures"][0]["frameState"]["readerDiagnostics"]["controls"][0]["classes"], ["subscribe-btn"])
        nested = run["summary"]["missing"][0]["frameState"]
        self.assertEqual(nested["readerDiagnostics"]["mainTextLength"], 350)

    def test_final_reader_diagnostics_grouped_in_file_order(self):
        run = analyze(event("frame_reader_diagnostics", chapterId="2", attempt=1, seq=4, readerDiagnostics=reader()),
                      event("frame_reader_diagnostics", chapterId="2", attempt=2, seq=3, readerDiagnostics=reader()))
        self.assertEqual([row["attempt"] for row in run["frameReaderDiagnostics"]], [1, 2])
        self.assertEqual([row["seq"] for row in run["chapters"][0]["timeline"]], [4, 3])
        self.assertEqual(run["sequenceDiagnostics"]["outOfOrderTransitions"], 1)

    def test_nested_final_frame_reader_diagnostics_keeps_all_structure(self):
        state = dict(readyState="complete", contentPresent=False, accessKind="unknown", readerDiagnostics=reader(),
                     pageErrorProbeAvailable=True, capturedPageErrors=1, droppedPageErrors=2, observationMs=20000)
        run = analyze(event("frame_reader_diagnostics", chapterId="2", frameState=state))
        result = run["frameReaderDiagnostics"][0]["frameState"]
        self.assertEqual(result["readerDiagnostics"]["controls"][0]["labelKind"], "generic_purchase")
        self.assertEqual(result["capturedPageErrors"], 1)
        self.assertEqual(result["observationMs"], 20000)
        self.assertEqual(run["summary"]["skippedCount"], 0)

    def test_reader_privacy_omits_text_html_request_and_account_fields(self):
        diagnostic = reader(body="BODY_SECRET", text="TEXT_SECRET", innerHTML="HTML_SECRET", options={"token": "SECRET"},
                            url="https://example.test/?token=SECRET")
        diagnostic["controls"][0].update(text="TEXT_SECRET", innerText="TEXT_SECRET", href="https://example.test/?token=SECRET",
                                            account="ACCOUNT_SECRET", error={"message": "ERROR_SECRET"})
        encoded = json.dumps(analyze(event("frame_reader_diagnostics", readerDiagnostics=diagnostic)))
        self.assertNotIn("SECRET", encoded)
        self.assertNotIn("innerText", encoded)
        self.assertIn("generic_purchase", encoded)

    def test_control_classes_filter_credentials_urls_numeric_ids_and_unrelated(self):
        diagnostic = reader()
        diagnostic["controls"][0]["classes"] = ["subscribe-btn", "read-wrap", "login-token-SECRET", "chapter123456",
                                                   "https://example.test/?token=SECRET", "unrelated", "vip-password", "subscribe-btn2"]
        classes = analyze(event("frame_wait_state", readerDiagnostics=diagnostic))["frameWaitStates"][0]["readerDiagnostics"]["controls"][0]["classes"]
        self.assertEqual(classes, ["subscribe-btn", "read-wrap", "subscribe-btn2"])

    def test_control_and_class_lists_are_bounded_with_explicit_omission(self):
        diagnostic = reader()
        diagnostic["controls"] = [dict(tagName="button", classes=["btn" + str(i) for i in range(80)], labelKind="loading") for _ in range(43)]
        result = analyze(event("frame_wait_state", readerDiagnostics=diagnostic))["frameWaitStates"][0]["readerDiagnostics"]
        self.assertEqual(len(result["controls"]), 40)
        self.assertEqual(result["analyzerOmittedControls"], 3)
        self.assertTrue(all(len(control["classes"]) == 6 for control in result["controls"]))

    def test_malformed_reader_numbers_labels_and_booleans_are_ignored(self):
        diagnostic = dict(mainTextLength="350", contentTextLength=-1, controlCount=True, purchaseControlCount=float("nan"),
                          loginControlCount={}, contentRootPresent=1, vipLimitPresent="false", controls=[None,
                          dict(tagName={}, labelKind=[], visible="yes", classes=[None, {}])])
        result = analyze(event("frame_wait_state", readerDiagnostics=diagnostic))["frameWaitStates"][0]["readerDiagnostics"]
        self.assertEqual(result, {"controls": [{"classes": []}]})
        json.dumps(result, allow_nan=False)

    def test_unknown_control_labels_are_not_retained_as_free_text(self):
        diagnostic = reader()
        diagnostic["controls"][0]["labelKind"] = "BODY_SECRET"
        result = analyze(event("frame_wait_state", readerDiagnostics=diagnostic))
        self.assertNotIn("SECRET", json.dumps(result))
        self.assertNotIn("labelKind", result["frameWaitStates"][0]["readerDiagnostics"]["controls"][0])

    def test_unknown_state_with_purchase_diagnostics_does_not_infer_unsubscribed(self):
        diagnostic = reader()
        diagnostic["purchaseControlCount"] = 1
        run = analyze(event("frame_wait_state", chapterId="2", accessKind="unknown", accessEvidence="no_explicit_gate", readerDiagnostics=diagnostic),
                      event("frame_reader_diagnostics", chapterId="2", accessKind="unknown", readerDiagnostics=diagnostic))
        self.assertEqual(run["summary"]["skippedCount"], 0)
        self.assertEqual(run["chapters"][0]["finalOutcome"], "unknown")
        self.assertEqual(run["failures"], [])

    def test_resource_and_runtime_events_are_evidence_without_failures(self):
        run = analyze(event("frame_page_error", chapterId="2", reasonCode="resource_error", resourceKind="script", messageKind="module_load_failed", errorName="ChunkLoadError"),
                      event("frame_page_error", chapterId="2", reasonCode="runtime_error", resourceKind="none", messageKind="unclassified", errorName="TypeError"),
                      event("frame_page_error", chapterId="2", reasonCode="unhandled_rejection", resourceKind="none", messageKind="network_failed", errorName="NetworkError"))
        diagnostics = run["pageErrorDiagnostics"]
        self.assertEqual(diagnostics["observedEvents"], 3)
        self.assertEqual(diagnostics["reasonCodes"], {"resource_error": 1, "runtime_error": 1, "unhandled_rejection": 1})
        self.assertEqual(diagnostics["resourceKinds"], {"script": 1, "none": 2})
        self.assertEqual(run["retryStats"]["attemptErrors"], 0)
        self.assertEqual(run["failures"], [])
        self.assertEqual(run["chapters"][0]["failures"], [])
        self.assertFalse(run["chapters"][0]["recovered"])

    def test_page_errors_do_not_change_success_or_mark_recovery(self):
        run = analyze(event("frame_page_error", chapterId="2", reasonCode="runtime_error", errorName="TypeError"),
                      event("chapter_result", chapterId="2", statusName="saved"))
        self.assertEqual(run["chapters"][0]["finalOutcome"], "success")
        self.assertFalse(run["chapters"][0]["recovered"])
        self.assertEqual(run["summary"]["failed"], 0)

    def test_page_probe_error_raw_payload_is_dropped_even_nested(self):
        run = analyze(event("frame_page_error", chapterId="2", reasonCode="runtime_error", messageKind="unclassified", errorName="Error",
                            message="ERROR_SECRET", reason="BODY_SECRET", stack="STACK_SECRET", url="https://example.test/?token=SECRET",
                            error={"name": "ERROR_SECRET", "message": "BODY_SECRET"}, buildError={"message": "BUILD_SECRET"},
                            frameState={"message": "NESTED_SECRET"}, summary={"error": {"message": "SUMMARY_SECRET"}}))
        self.assertNotIn("SECRET", json.dumps(run))
        probe = run["framePageErrors"][0]
        self.assertEqual(probe["errorName"], "Error")
        for field in ("message", "reason", "stack", "error", "buildError", "frameState", "summary"):
            self.assertNotIn(field, probe)

    def test_invalid_page_categories_are_unknown_not_raw_causes(self):
        run = analyze(event("frame_page_error", reasonCode="RAW_SECRET", resourceKind=[], messageKind={}, errorName="BODY_SECRET"))
        self.assertEqual(run["pageErrorDiagnostics"]["reasonCodes"], {"unknown": 1})
        self.assertEqual(run["pageErrorDiagnostics"]["resourceKinds"], {"unknown": 1})
        self.assertEqual(run["pageErrorDiagnostics"]["messageKinds"], {"unknown": 1})
        self.assertNotIn("SECRET", json.dumps(run))

    def test_zero_probe_errors_do_not_claim_page_initialized(self):
        run = analyze(event("frame_reader_diagnostics", chapterId="2", pageErrorProbeAvailable=True, capturedPageErrors=0,
                            droppedPageErrors=0, observationMs=19000, readerDiagnostics=reader()))
        self.assertEqual(run["pageErrorDiagnostics"]["observedEvents"], 0)
        self.assertIn("may miss earlier errors", run["pageErrorDiagnostics"]["note"])
        self.assertNotIn("pageInitialized", run)

    def test_catalog_skip_summary_is_policy_evidence_not_chapter_count(self):
        run = analyze(event("catalog_skip_summary", enabled=True, trustedMixedCatalog=True, skippedCount=9, reasonCode="visible_catalog_locks", chapterId="unexpected"))
        self.assertEqual(run["catalogSkipSummaries"][0]["skippedCount"], 9)
        self.assertTrue(run["catalogSkipSummaries"][0]["trustedMixedCatalog"])
        self.assertEqual(run["catalogSkipSummaries"][0]["reasonCode"], "visible_catalog_locks")
        self.assertEqual(run["chapters"], [])
        self.assertEqual(run["summary"]["skippedCount"], 0)
        self.assertEqual(run["failures"], [])

    def test_explicit_catalog_skips_and_results_keep_separate_outcomes(self):
        run = analyze(event("catalog_skip_summary", enabled=True, trustedMixedCatalog=True, skippedCount=1, reasonCode="visible_catalog_locks"),
                      event("chapter_skipped", chapterId="2", statusName="skipped", skipReason="unsubscribed", accessEvidence="catalog_lock"),
                      event("chapter_result", chapterId="3", statusName="saved"))
        self.assertEqual(run["summary"]["skippedCount"], 1)
        self.assertEqual(run["summary"]["success"], 1)
        self.assertEqual(run["summary"]["failed"], 0)
        self.assertEqual(run["chapters"][0]["accessEvidence"], "catalog_lock")

    def test_catalog_locked_paid_flags_retained_without_inferring_skip(self):
        run = analyze(event("chapter_result", chapterId="2", statusName="failed", catalogLocked=True, catalogMarkedPaid=False,
                            errorCode="page_timeout"),
                      event("chapter_result", chapterId="3", statusName="saved", catalogLocked=False, catalogMarkedPaid=True))
        self.assertTrue(run["chapters"][0]["catalogLocked"])
        self.assertFalse(run["chapters"][0]["catalogMarkedPaid"])
        self.assertTrue(run["chapters"][1]["catalogMarkedPaid"])
        self.assertTrue(run["failures"][0]["catalogLocked"])
        self.assertEqual(run["summary"]["skippedCount"], 0)

    def test_catalog_disabled_untrusted_and_invalid_reasons_retained_safely(self):
        run = analyze(event("catalog_skip_summary", enabled=False, trustedMixedCatalog=True, skippedCount=0, reasonCode="user_disabled"),
                      event("catalog_skip_summary", enabled=True, trustedMixedCatalog=False, skippedCount=0, reasonCode="no_paid_catalog_reference"),
                      event("catalog_skip_summary", reasonCode="BODY_SECRET", cookie="COOKIE_SECRET", options={"body": "BODY_SECRET"}))
        rows = run["catalogSkipSummaries"]
        self.assertFalse(rows[0]["enabled"])
        self.assertFalse(rows[1]["trustedMixedCatalog"])
        self.assertNotIn("reasonCode", rows[2])
        self.assertNotIn("SECRET", json.dumps(run))

    def test_page_error_and_actual_timeout_remain_separate_evidence(self):
        run = analyze(event("frame_page_error", chapterId="2", reasonCode="resource_error", resourceKind="script", messageKind="network_failed", errorName="Error"),
                      event("attempt_error", chapterId="2", errorCode="page_timeout", stage="page_load", attempt=1),
                      event("chapter_result", chapterId="2", statusName="failed", errorCode="page_timeout"))
        self.assertEqual(len(run["framePageErrors"]), 1)
        self.assertEqual(len(run["failures"]), 2)
        self.assertEqual(run["retryStats"]["attemptErrors"], 1)
        self.assertEqual(run["summary"]["failed"], 1)
        self.assertTrue(all(row.get("event") != "frame_page_error" for row in run["failures"]))

    def test_catalog_skip_setting_is_typed_policy_metadata(self):
        self.assertTrue(A.sanitize(event("run_start", catalogSkipEnabled=True))["catalogSkipEnabled"])
        self.assertFalse(A.sanitize(event("run_start", catalogSkipEnabled=False))["catalogSkipEnabled"])
        self.assertNotIn("catalogSkipEnabled", A.sanitize(event("run_start", catalogSkipEnabled="true")))

    def test_firefox_extension_urls_are_redacted_in_legacy_errors(self):
        cleaned = A.safe_text("TypeError at moz-extension://abc/reader.js?token=RAW_SECRET#MORE_SECRET:12:3")
        self.assertEqual(cleaned, "TypeError at [URL]")

    def test_schema1_and_pre_run_probe_diagnostics_remain_compatible(self):
        result = A.analyze("\n".join("[QidianDebug] " + json.dumps(row) for row in [
            event("frame_page_error", schema=1, runId=None, reasonCode="resource_error", resourceKind="style", messageKind="unclassified"),
            event("frame_reader_diagnostics", schema=1, chapterId="2", readerDiagnostics=reader())]))
        self.assertEqual(result["preRun"]["pageErrorDiagnostics"]["observedEvents"], 1)
        self.assertEqual(result["runs"][0]["schemas"], [1])
        self.assertEqual(len(result["runs"][0]["frameReaderDiagnostics"]), 1)


if __name__ == "__main__":
    unittest.main()
