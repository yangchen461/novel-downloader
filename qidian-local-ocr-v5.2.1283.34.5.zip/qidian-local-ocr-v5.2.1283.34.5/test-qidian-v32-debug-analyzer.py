"""Reassemble bounded v32 final-summary details without inventing lost rows."""
import importlib.util
import json
import unittest
from pathlib import Path

SPEC = importlib.util.spec_from_file_location("analyzer", Path(__file__).with_name("analyze-qidian-debug.py"))
A = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(A)


def event(name, **fields):
    return dict(schema=2, version="5.2.1283.32", event=name, runId="synthetic-v32", **fields)


def fixture(count=1250):
    missing = [dict(chapterId=str(index + 1), catalogNumber=index + 1, statusName="failed" if index == 0 else "pending",
                    stage="page_load", token="TOKEN_SECRET", contentText="BODY_SECRET") for index in range(count)]
    main = event("run_summary", seq=10, outcome="paused", pauseReason="等待阅读页超时",
                 selectedCount=count+128, savedCount=128, exportedCount=128, failedCount=1, abortedCount=0,
                 unprocessedCount=count-1, inProgressCount=0, resumedCount=125, skippedCount=0,
                 missingCount=count, missing=missing[:12], missingTotal=count, missingOmitted=count-12,
                 detailsFollow=True, detailChunkCount=(count-12+39)//40)
    chunks = [event("run_details", seq=11+index, summarySeq=10, kind="missing", offset=offset,
                    total=count, chunkIndex=index, chunkCount=(count-12+39)//40, missing=missing[offset:offset+40])
              for index, offset in enumerate(range(12, count, 40))]
    return main, chunks


def analyze(*rows):
    result = A.analyze("\n".join("[QidianDebug] " + json.dumps(row) for row in rows))
    return result["runs"][0]


class V32AnalyzerTests(unittest.TestCase):
    def test_1250_final_rows_preserved_with_counts_and_privacy(self):
        main, chunks = fixture()
        result = analyze(main, *chunks)
        summary = result["summary"]
        self.assertEqual(len(summary["missing"]), 1250)
        self.assertEqual([item["catalogNumber"] for item in summary["missing"]], list(range(1, 1251)))
        self.assertEqual(summary["missingCount"], 1250)
        self.assertTrue(summary["countsComplete"])
        self.assertTrue(summary["detailDiagnostics"]["missing"]["complete"])
        self.assertEqual(len(summary["failures"]), 1)
        self.assertEqual(summary["pauseReason"], "等待阅读页超时")
        self.assertNotIn("SECRET", json.dumps(result))

    def test_missing_chunk_is_reported_without_inventing_chapter_rows(self):
        main, chunks = fixture(749)
        result = analyze(main, *chunks[:2], *chunks[3:])["summary"]
        self.assertEqual(result["missingCount"], 749)
        self.assertEqual(len(result["missing"]), 709)
        self.assertEqual(result["detailDiagnostics"]["missing"]["unavailableCount"], 40)
        self.assertFalse(result["detailDiagnostics"]["missing"]["complete"])

    def test_wrong_summary_sequence_kind_and_total_are_not_merged(self):
        main, chunks = fixture(100)
        for changes in [dict(summarySeq=9), dict(kind="skipped"), dict(total=99), dict(offset=0), dict(offset=1.5)]:
            invalid = [dict(chunk, **changes) for chunk in chunks]
            result = analyze(main, *invalid)["summary"]
            self.assertEqual(len(result["missing"]), 12)
            self.assertEqual(result["detailDiagnostics"]["missing"]["unavailableCount"], 88)

    def test_duplicate_chunks_do_not_duplicate_chapters(self):
        main, chunks = fixture(100)
        result = analyze(main, *chunks, chunks[0])["summary"]
        self.assertEqual(len(result["missing"]), 100)
        self.assertEqual(result["detailDiagnostics"]["missing"]["duplicateItems"], 40)

    def test_last_summary_does_not_borrow_a_prior_summarys_chunks(self):
        main, chunks = fixture(100)
        newer = dict(main, seq=20)
        result = analyze(main, *chunks, newer)["summary"]
        self.assertEqual(len(result["missing"]), 12)
        self.assertFalse(result["detailDiagnostics"]["missing"]["complete"])

    def test_legacy_small_summary_remains_unchanged(self):
        result = analyze(event("run_summary", missing=[dict(chapterId="1", statusName="failed")], missingCount=1))["summary"]
        self.assertEqual(len(result["missing"]), 1)
        self.assertNotIn("detailDiagnostics", result)


if __name__ == "__main__":
    unittest.main()
