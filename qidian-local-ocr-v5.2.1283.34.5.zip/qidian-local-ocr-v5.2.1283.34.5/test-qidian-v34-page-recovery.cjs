// Execute the shipped frame wait, access classifier and scheduler. No network.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
function suite(file, expression) {
  const source = fs.readFileSync(path.join(__dirname, file), 'utf8');
  return vm.runInNewContext(source.slice(0, source.lastIndexOf('const tests=[];')) + '\n(' + expression + ')',
    { require, __dirname, AbortController, URL, console });
}
const frameSuite = suite('test-qidian-v18-frame.cjs', '{fixture}');
const queueSuite = suite('test-qidian-v19-resilience.cjs', '{fixture,status}');
const fullRunSuite = suite('test-qidian-v34-access-qa.cjs', '{fixture,drain,until}');
const tests = [];
const test = (name, run) => tests.push({ name, run });
const securityError = () => Object.assign(new Error('Cross-origin document is not readable yet'), { name: 'SecurityError' });

test('a transient cross-origin navigation can become readable in the same bounded frame wait', async () => {
  const f = frameSuite.fixture();
  let checks = 0;
  const task = f.ctx.getFrameContentConditionWithWindow('https://www.qidian.com/chapter/1/119/', () => {
    if (++checks < 3) throw securityError();
    return true;
  }, undefined, 20000, { checkOnLoad: true, waitOnCrossOrigin: true });
  const result = await f.drain(task);
  assert.equal(result, f.state.frames[0]);
  assert.equal(checks, 3);
  assert.equal(f.state.now, 2000);
  assert.equal(f.state.frames.length, 1);
  assert.equal(f.state.timers.size, 0);
  result.remove();
});

test('persistent cross-origin unreadability expires and cleans its frame without a task-wide pause', async () => {
  const f = frameSuite.fixture();
  const task = f.ctx.getFrameContentConditionWithWindow('https://www.qidian.com/chapter/1/119/', () => {
    throw securityError();
  }, undefined, 20000, { checkOnLoad: true, waitOnCrossOrigin: true });
  await assert.rejects(f.drain(task), error => error.message === 'Frame Timeout!' && error.frameState.crossOriginReadErrors > 0);
  assert.equal(f.state.now, 20000);
  assert.equal(f.state.frames.length, 1);
  assert.equal(f.state.removed, 1);
  assert.equal(f.state.timers.size, 0);
  assert.equal(f.window.stopFlag.aborted, false);
  assert(!f.window.qidianPauseReason);
});

test('ordinary helper consumers still reject immediately and explicit HTTP access evidence is retained', async () => {
  for (const [options, status] of [[{ checkOnLoad: true }, null], [{ checkOnLoad: true, waitOnCrossOrigin: true }, 403]]) {
    const f = frameSuite.fixture();
    const task = f.ctx.getFrameContentConditionWithWindow('https://www.qidian.com/chapter/1/119/', () => {
      const error = securityError();
      if (status) error.status = status;
      throw error;
    }, undefined, 20000, options);
    await assert.rejects(f.drain(task), error => error.name === 'SecurityError');
    assert.equal(f.state.now, 0);
    assert.equal(f.state.removed, 1);
    assert.equal(f.state.timers.size, 0);
  }
});

test('user Stop interrupts a cross-origin wait and removes all owned timers', async () => {
  const f = frameSuite.fixture();
  const task = f.ctx.getFrameContentConditionWithWindow('https://www.qidian.com/chapter/1/119/', () => {
    throw securityError();
  }, undefined, 20000, { checkOnLoad: true, waitOnCrossOrigin: true, signal: f.window.stopFlag });
  f.window.stopController.abort();
  await assert.rejects(f.drain(task), error => error.name === 'AbortError');
  assert.equal(f.state.now, 0);
  assert.equal(f.state.removed, 1);
  assert.equal(f.state.timers.size, 0);
});

test('WAF phrases inside a readable chapter cannot classify the whole task as blocked', () => {
  const f = frameSuite.fixture();
  const story = '他望着屏幕上的访问已被拦截和Web应用防护字样，然后继续讲述自己的经历。'.repeat(30);
  const main = { textContent: story };
  const doc = { title: '第一百章 访问已被拦截 - 起点中文网', body: { innerText: story },
    querySelector: selector => selector === 'main' || selector === '.content-text' ? main : null,
    querySelectorAll: () => [] };
  assert.equal(f.ctx.qidianChapterAccessState(doc, true, story.length).kind, 'unknown');
});

test('a standalone short WAF page is still an explicit gate', () => {
  const f = frameSuite.fixture();
  const doc = { title: 'WAF拦截页面', body: { innerText: '403 您的请求已中断 请求UUID' },
    querySelector: () => null, querySelectorAll: () => [] };
  assert.equal(f.ctx.qidianChapterAccessState(doc, true).kind, 'verification_required');
});

test('successive empty pages cause bounded longer waits and still reach all later chapters', async () => {
  const configs = Array.from({ length: 7 }, (_, index) => ({ id: index + 1, vip: true, frameTimeout: 'blank', frameTimeoutFirst: true }));
  configs.push({ id: 8, vip: true });
  const f = queueSuite.fixture(configs);
  f.window.qidianAdaptivePacingEnabled = true;
  await f.run();
  const events = Array.from(f.state.logs).filter(line => line.startsWith('[QidianDebug] ')).map(line => JSON.parse(line.slice(14)));
  const waits = events.filter(row => row.event === 'page_failure_cooldown' && row.recoveryRound === 0);
  assert.deepEqual(waits.map(row => row.baseWaitMs), [10000, 20000, 40000, 60000, 60000, 60000, 60000]);
  assert.deepEqual(waits.map(row => row.waitMs), [5000, 15000, 35000, 55000, 55000, 55000, 55000],'RNG=0 samples each backoff base once at its lower bound');
  assert(waits.every(row => row.taskPaused === false));
  assert.deepEqual(Array.from(f.state.starts.slice(0, 8), row => row.id), configs.map(row => row.id));
  assert(f.chapters.every(chapter => chapter.status === queueSuite.status.saved));
  assert.equal(f.chapters[7].qidianAttemptCount, 1);
  assert.equal(f.window.stopFlag.aborted, false);
});

test('a second Start cannot replace the first task or its manual access gate', async () => {
  const configs = [{ id: 1, vip: true, accessTitle: '安全验证' }, { id: 2, vip: true }];
  const f = fullRunSuite.fixture(configs);
  const first = f.run();
  await fullRunSuite.until(() => f.window.qidianAccessRecoveryGate);
  await fullRunSuite.drain();
  const gate = f.window.qidianAccessRecoveryGate;
  const signal = f.window.stopFlag;
  const runToken = f.window.qidianAccessRecoveryRun;
  await f.run();
  assert.equal(f.window.qidianAccessRecoveryGate, gate);
  assert.equal(f.window.qidianAccessRecoveryRun, runToken);
  assert.equal(f.window.stopFlag, signal);
  assert.deepEqual(Array.from(f.state.starts, row => row.id), [1]);
  assert.equal(f.state.outputs.length, 0);
  configs[0].accessTitle = null;
  assert.equal(gate.continue(), true);
  await first;
  assert.deepEqual(Array.from(f.state.starts, row => row.id), [1, 1, 2]);
  assert.equal(f.state.outputs.length, 1);
  assert.equal(f.state.outputs[0].length, 2);
});

(async () => {
  let failed = 0;
  for (const { name, run } of tests) {
    try { await run(); console.log('PASS', name); }
    catch (error) { failed++; console.error('FAIL', name, error.stack); }
  }
  console.log(`${tests.length - failed}/${tests.length} page recovery checks passed`);
  if (failed) process.exitCode = 1;
})();
