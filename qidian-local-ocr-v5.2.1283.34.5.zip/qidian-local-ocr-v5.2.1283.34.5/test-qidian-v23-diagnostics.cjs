// Test shipped v23 diagnostics and free-text recovery, replacing only DOM/network boundaries.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b, from = 0) {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing shipped implementation boundary: ${a}`);
  return src.slice(start, end);
}
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const parse = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const getImg = take('    async function getImg(url) {', '\n    function img(elem2)', src.indexOf('async function cleanDOM('));
class FixtureTextNode {
  constructor(text = '') { this.nodeType = 3; this.nodeName = '#text'; this.nodeValue = String(text); this.parentNode = null; }
  get textContent() { return this.nodeValue; }
  set textContent(text) { this.nodeValue = String(text); }
  cloneNode() { return new FixtureTextNode(this.nodeValue); }
  remove() { if (this.parentNode) this.parentNode.removeChild(this); }
}
class FixtureNode {
  constructor(tag = 'div', text = '') {
    this.tag = tag.toLowerCase(); this.nodeType = 1; this.nodeName = this.tagName = this.tag.toUpperCase();
    this.childNodes = []; this.parentNode = null; this.attributes = {};
    if (text) this.appendChild(new FixtureTextNode(text));
  }
  get children() { return this.childNodes.filter(child => child.nodeType === 1); }
  get parentElement() { return this.parentNode?.nodeType === 1 ? this.parentNode : null; }
  get className() { return this.getAttribute('class') ?? ''; }
  set className(value) { this.setAttribute('class', value); }
  appendChild(node) { node.remove(); this.childNodes.push(node); node.parentNode = this; return node; }
  removeChild(node) { this.childNodes = this.childNodes.filter(child => child !== node); node.parentNode = null; return node; }
  setAttribute(key, value) { this.attributes[key] = String(value); }
  getAttribute(key) { return Object.hasOwn(this.attributes, key) ? this.attributes[key] : null; }
  getAttributeNames() { return Object.keys(this.attributes); }
  hasAttribute(key) { return Object.hasOwn(this.attributes, key); }
  removeAttribute(key) { delete this.attributes[key]; }
  get textContent() { return this.childNodes.map(child => child.textContent).join(''); }
  set textContent(text) {
    for (const child of this.childNodes) child.parentNode = null;
    this.childNodes = []; if (String(text)) this.appendChild(new FixtureTextNode(text));
  }
  get innerText() { return this.textContent; }
  set innerText(text) { this.textContent = text; }
  get outerHTML() { return `<${this.tag}>${this.textContent}</${this.tag}>`; }
  cloneNode(deep) { const out = new FixtureNode(this.tag); out.attributes = { ...this.attributes }; if (deep) for (const child of this.childNodes) out.appendChild(child.cloneNode(true)); return out; }
  remove() { if (this.parentNode) this.parentNode.removeChild(this); }
  querySelector(selector) { return this.querySelectorAll(selector)[0] ?? null; }
  matches(selector) {
    return selector.split(',').some(raw => {
      const part = raw.trim();
      if (part.startsWith('.')) return this.className.split(/\s+/).includes(part.slice(1));
      if (part.startsWith('#')) return this.getAttribute('id') === part.slice(1);
      const match = part.match(/^([a-zA-Z][\w-]*)(?:\.([\w-]+))?$/);
      return match && this.tag === match[1].toLowerCase() && (!match[2] || this.className.split(/\s+/).includes(match[2]));
    });
  }
  closest(selector) {
    for (let node = this; node; node = node.parentElement) if (node.matches(selector)) return node;
    return null;
  }
  querySelectorAll(selector) {
    const result = [];
    const walk = node => { for (const child of node.children) { if (child.matches(selector)) result.push(child); walk(child); } };
    walk(this); return result;
  }
}
function mainWith(texts) {
  const main = new FixtureNode('main');
  for (const text of texts) main.appendChild(new FixtureNode('p', text));
  return main;
}
function fixture(config = {}) {
  const state = { now:1000, logs:[], htmlRequests:0, frameRequests:0, cleanCalls:0, ocrCalls:0, removed:0, cleanOptions:[] };
  const main = config.main ?? mainWith([config.text ?? '正文'.repeat(1000)]);
  const authorSay = config.authorText ? new FixtureNode('section') : null;
  if (authorSay) authorSay.appendChild(new FixtureNode('div',config.authorText));
  const log = { info:line => state.logs.push(String(line)), warn:line => state.logs.push(String(line)), error() {}, debug() {} };
  const window = { qidianDebugRun:{ id:'run-fixture-23', startedAt:900 }, qidianDebugLogger:log, qidianTxtOnly:config.txtOnly ?? true, stopController:new AbortController() };
  window.stopFlag = window.stopController.signal;
  const doc = { title:'第39章 测试章节', body:{ textContent:main.textContent }, querySelector(selector) {
    if (selector === 'main' || selector === '.content-text, .vip-limit-wrap') return main;
    if (selector === 'h1.title') return { innerText:'第39章 测试章节' };
    if (selector === '.vip-limit-wrap') return config.locked ? {} : null;
    if (selector === '#r-authorSay') return authorSay;
    return null;
  } };
  const context = vm.createContext({ URL, window, document:{ location:{hostname:'www.qidian.com'}, createElement:tag => new FixtureNode(tag) }, Date:{ now:() => state.now }, console:log,
    _log__WEBPACK_IMPORTED_MODULE_6___default:() => log,
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{ pG:async () => { state.htmlRequests++; state.now += 700; return doc; }, Q2:async (_url, predicate) => { state.frameRequests++; state.now += 700; const frame = { contentWindow:{ document:doc }, remove() { state.removed++; } }; assert.equal(predicate(frame),true); return frame; } },
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{ rm(selector,_deep,node) { for (const item of node.querySelectorAll(selector)) item.remove(); }, Sf() {} },
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{ async an(_node,_mode,options) {
      state.cleanCalls++; state.cleanOptions.push(options); state.now += 200;
      const text = _node === main ? config.cleaned ?? main.textContent : _node.textContent;
      const dom = _node === main && config.cleaned !== undefined ? mainWith([config.cleaned]) : _node.cloneNode(true);
      return { dom, text, images:[] };
    }, is() {} },
    async ocrContent() { state.ocrCalls++; if (config.ocrThrows) { const error = new Error('unresolved glyph'); error.name = 'QidianGlyphError'; throw error; } return { contentText:config.ocrText ?? main.textContent, contentHTML:new FixtureNode('div') }; },
    qidianGlyphCache:new Map(), async qidianPersistGlyphCache() {}, AbortController
  });
  vm.runInContext(globals + '\nclass Qidian {' + parse + '}\nthis.Qidian=Qidian;',context);
  return { context, state, main, window, options:{ expectedChars:config.expected ?? 2000 }, parse(vip = false) { return new context.Qidian().chapterParse('https://www.qidian.com/chapter/1/39/','第39章',vip,true,'UTF-8',this.options); }, events() { return state.logs.filter(line => line.startsWith('[QidianDebug] ')).map(line => JSON.parse(line.slice('[QidianDebug] '.length))); } };
}
const tests = [];
const test = (name, fn) => tests.push({ name, fn });

test('length checks preserve 50 percent and strip whitespace instead of trusting displayed length',() => {
  const f = fixture();
  const check = f.context.qidianContentCheck;
  const boundary = check('中'.repeat(2000),4000,false);
  assert.equal(boundary.minimumChars,2000); assert.equal(boundary.minimumCjk,80); assert.equal(boundary.complete,true);
  const short = check('中'.repeat(1999) + ' \n\t'.repeat(1000),4000,false);
  assert.equal(short.actualChars,1999); assert.equal(short.complete,false); assert.equal(short.reason,'below_expected_length');
  assert.equal(f.context.qidianContentIsComplete('中'.repeat(1999),4000,false),false);
});
test('expected-length check has no upper cap that would admit a short long chapter',() => {
  const check = fixture().context.qidianContentCheck;
  assert.equal(check('中'.repeat(9999),20000,false).minimumChars,10000);
  assert.equal(check('中'.repeat(9999),20000,false).complete,false);
  assert.equal(check('中'.repeat(10000),20000,false).complete,true);
});
test('CJK check rejects long raw Latin or encoded output and preserves its lower bound',() => {
  const check = fixture().context.qidianContentCheck;
  const latin = check('x'.repeat(4000),4000,false);
  assert.equal(latin.reason,'insufficient_cjk'); assert.equal(latin.minimumCjk,80);
  assert.equal(check('中'.repeat(79) + 'x'.repeat(3321),4000,false).complete,false);
  assert.equal(check('中'.repeat(80) + 'x'.repeat(3320),4000,false).complete,true);
});
test('fallback thresholds preserve free and VIP minima without directory length',() => {
  const check = fixture().context.qidianContentCheck;
  assert.equal(check('中'.repeat(20),0,false).complete,true);
  assert.equal(check('中'.repeat(19),0,false).complete,false);
  assert.equal(check('中'.repeat(100),undefined,true).complete,true);
  assert.equal(check('中'.repeat(99),NaN,true).complete,false);
  assert.equal(check('中'.repeat(99),Infinity,true).expectedChars,0);
});
test('structured chapter diagnostics include attempt, source and quality but never body or URL secrets',() => {
  const f = fixture(); const secretBody = 'BODY_SECRET_' + '正文'.repeat(1000);
  const chapter = { chapterUrl:'https://www.qidian.com/chapter/1/39/?token=URL_SECRET',chapterNumber:40,chapterName:'第39章 测试章节',isVIP:false,status:5,contentText:secretBody,contentRaw:secretBody,
    qidianAttemptCount:2,qidianSource:'checkpoint',options:{ expectedChars:2000 } };
  f.context.qidianDebugEvent(null,'chapter_result',f.context.qidianChapterDiagnostic(chapter));
  const [event] = f.events(); assert.equal(event.schema,2); assert.equal(event.version,'5.2.1283.34.5'); assert.equal(event.runId,'run-fixture-23'); assert.equal(event.elapsedMs,100);
  assert.equal(event.chapterId,'39'); assert.equal(event.catalogNumber,40); assert.equal(event.attempts,2); assert.equal(event.source,'checkpoint'); assert.equal(event.mode,'free-html');
  assert.equal(event.quality.complete,true); assert.equal(event.quality.actualChars,secretBody.replace(/\s/g,'').length);
  assert(!JSON.stringify(event).includes('BODY_SECRET')); assert(!JSON.stringify(event).includes('URL_SECRET')); assert(!('contentText' in event)); assert(!('contentRaw' in event));
});
test('explicit parser quality is retained in diagnostics for failed chapter with discarded body',() => {
  const f = fixture(); const quality = f.context.qidianContentCheck('中'.repeat(1602),4000,false);
  const diagnostic = f.context.qidianChapterDiagnostic({ chapterUrl:'https://www.qidian.com/chapter/1/39/',chapterName:'第39章',isVIP:false,status:2,contentText:null,qidianAttemptCount:2,qidianFailureKind:'local',errorMessage:'short',options:{expectedChars:4000,qidianValidation:quality} });
  assert.equal(diagnostic.quality.actualChars,1602); assert.equal(diagnostic.quality.minimumChars,2000); assert.equal(diagnostic.quality.complete,false);
  assert.equal(diagnostic.reason,'short'); assert.equal(diagnostic.failureKind,'local');
});
test('logging errors never interrupt chapter processing',() => {
  const f = fixture(); assert.doesNotThrow(() => f.context.qidianDebugEvent({ info() { throw new Error('broken logger'); } },'test',{}));
  const circular = {}; circular.self = circular; assert.doesNotThrow(() => f.context.qidianDebugEvent(null,'test',circular));
});
test('free paragraph recovery clones complete text and strips non-body nodes without mutating source',() => {
  const main = mainWith(['甲'.repeat(1800),'乙'.repeat(1800)]);
  for (const tag of ['script','style','form','nav','button']) main.children[0].appendChild(new FixtureNode(tag,'UNWANTED_'+tag));
  const review = new FixtureNode('span','UNWANTED_review'); review.className = 'review'; main.children[0].appendChild(review);
  main.appendChild(new FixtureNode('div','OUTSIDE_PARAGRAPHS'));
  const before = main.textContent;
  const f = fixture({ main, expected:4000 }); const recovered = f.context.qidianRecoverFreeParagraphs(main,4000);
  assert(recovered); assert.equal(recovered.text,'甲'.repeat(1800)+'\n\n'+'乙'.repeat(1800)); assert.equal(recovered.dom.children.length,2);
  assert.equal(main.textContent,before); assert(!recovered.text.includes('UNWANTED')); assert(!recovered.text.includes('OUTSIDE_PARAGRAPHS'));
});
test('free recovery rejects short source even if its whitespace or outside paragraphs are long',() => {
  const main = mainWith(['中'.repeat(1602)+' \n'.repeat(2000)]); main.appendChild(new FixtureNode('div','中'.repeat(4000)));
  const f = fixture({main}); assert.equal(f.context.qidianRecoverFreeParagraphs(main,4000),null);
});
test('recovery rejects a short paragraph padded with scripts or review text despite long raw main',async () => {
  const main = mainWith(['中'.repeat(1602)]);
  main.children[0].appendChild(new FixtureNode('script','中'.repeat(1000)));
  const f = fixture({main,expected:4000,cleaned:'中'.repeat(1602)});
  assert.equal(f.context.qidianRecoverFreeParagraphs(main,4000),null);
  await assert.rejects(() => f.parse(),error => error.name === 'QidianContentError');
  const event = f.events().find(event => event.event === 'content_check');
  assert.equal(event.rawMainComplete,true); assert.equal(event.rawMainChars,2602);
  assert.equal(event.quality.actualChars,1602); assert.equal(event.quality.complete,false);
});
test('free recovery rejects PUA encoded text instead of outputting raw VIP glyph codes',() => {
  for (const point of [0xe123,0xf0123,0x100123]) {
    const main = mainWith(['中'.repeat(3500)+String.fromCodePoint(point)]); const f = fixture({main});
    assert.equal(f.context.qidianRecoverFreeParagraphs(main,4000),null);
  }
});
test('recovery excludes navigation and author-note paragraphs and prefers the actual content container', () => {
  const main = mainWith(['中'.repeat(1602)]);
  for (const tag of ['nav','form','aside']) {
    const parent = main.appendChild(new FixtureNode(tag));
    parent.appendChild(new FixtureNode('p','中'.repeat(1000)));
  }
  const author = main.appendChild(new FixtureNode('div')); author.className = 'authorSay';
  author.appendChild(new FixtureNode('p','中'.repeat(1000)));
  const f = fixture({main}); assert.equal(f.context.qidianRecoverFreeParagraphs(main,4000),null);
  const scoped = new FixtureNode('main'); scoped.appendChild(new FixtureNode('p','OUTSIDE_BODY'));
  const content = scoped.appendChild(new FixtureNode('div')); content.className = 'content-text';
  content.appendChild(new FixtureNode('p','中'.repeat(3500)));
  const recovered = f.context.qidianRecoverFreeParagraphs(scoped,4000);
  assert.equal(recovered.text,'中'.repeat(3500));
});
test('free recovery rejects absent paragraphs and uncloneable synthetic placeholders',() => {
  const f = fixture(); assert.equal(f.context.qidianRecoverFreeParagraphs(new FixtureNode('main','中'.repeat(4000)),4000),null);
  assert.equal(f.context.qidianRecoverFreeParagraphs({querySelectorAll:() => [{textContent:'中'.repeat(4000)}]},4000),null);
});
test('actual free parser repairs cleanup loss while keeping strict source threshold and expected-source diagnostics',async () => {
  const main = mainWith(['甲'.repeat(1800),'乙'.repeat(1800)]);
  main.children[0].appendChild(new FixtureNode('script','X'.repeat(100)));
  const f = fixture({main,expected:4000,cleaned:'甲'.repeat(1602)}); const parsed = await f.parse();
  assert.equal(parsed.contentText,'甲'.repeat(1800)+'\n\n'+'乙'.repeat(1800)); assert.equal(f.state.htmlRequests,1); assert.equal(f.state.ocrCalls,0);
  const cleanedQuality = f.context.qidianContentCheck('甲'.repeat(1602),4000,false);
  assert.equal(cleanedQuality.actualChars,1602); assert.equal(cleanedQuality.complete,false);
  const recovery = f.events().find(event => event.event === 'free_source_comparison'); assert(recovery);
  assert.equal(recovery.replaced,true); assert.equal(recovery.reason,'cleanup_text_mismatch'); assert.equal(recovery.sourceChars,3600);
  const event = f.events().find(event => event.event === 'content_check'); assert(event); assert.equal(event.mode,'free-html'); assert.equal(event.expectedSource,'catalog_title_attribute'); assert.equal(event.rawMainChars,3700); assert.equal(event.rawMainCjk,3600); assert.equal(event.rawMainComplete,true); assert.equal(event.removedDuringCleanup,100); assert.equal(event.paragraphCount,2); assert.equal(event.pageMs,700); assert.equal(event.cleanMs,200); assert.equal(event.sourceSnapshot,true);
  assert.equal(event.quality.expectedChars,4000); assert.equal(event.quality.minimumChars,2000); assert.equal(event.quality.actualChars,3600); assert.equal(event.runId,'run-fixture-23');
  assert(!JSON.stringify(f.events()).includes('甲'.repeat(100)));
});
test('actual free parser reports 1602 versus 4000 mismatch and refuses incomplete raw source',async () => {
  const main = mainWith(['中'.repeat(1602)+' \n'.repeat(1000)]);
  const f = fixture({main,expected:4000,cleaned:main.textContent});
  await assert.rejects(() => f.parse(),error => error.name === 'QidianContentError' && /1602.*4000.*2000/.test(error.message));
  assert(!f.events().some(event => event.event === 'free_cleanup_recovery'));
  const event = f.events().find(event => event.event === 'content_check'); assert(event); assert.equal(event.quality.actualChars,1602); assert.equal(event.rawMainChars,1602); assert.equal(event.rawMainComplete,false); assert.equal(event.removedDuringCleanup,0); assert.equal(event.quality.reason,'below_expected_length'); assert.equal(f.options.qidianValidation.complete,false);
});
test('actual free parser checks body before any author note can make a short chapter appear complete',async () => {
  const f = fixture({text:'短正文',expected:4000,authorText:'作者附言'.repeat(2000)});
  await assert.rejects(() => f.parse(),error => error.name === 'QidianContentError');
  assert.equal(f.events().find(event => event.event === 'content_check').quality.complete,false);
  assert.equal(f.state.cleanCalls,1,'author note must not be cleaned or used before the short body is rejected');
});
test('actual VIP parser never falls back to free paragraphs when OCR fails',async () => {
  const f = fixture({ocrThrows:true}); await assert.rejects(() => f.parse(true),error => error.name === 'QidianGlyphError');
  assert.equal(f.state.frameRequests,1); assert.equal(f.state.htmlRequests,0); assert.equal(f.state.cleanCalls,0); assert.equal(f.state.ocrCalls,1); assert(!f.events().some(event => event.event === 'free_cleanup_recovery'));
});
test('actual VIP parser rejects short OCR and reports its measured quality',async () => {
  const f = fixture({text:'中'.repeat(4000),ocrText:'短正文',expected:4000}); await assert.rejects(() => f.parse(true),error => error.name === 'QidianContentError');
  const event = f.events().find(event => event.event === 'content_check'); assert(event); assert.equal(event.mode,'vip-ocr'); assert.equal(event.quality.actualChars,3); assert.equal(event.quality.complete,false); assert.equal(f.state.cleanCalls,0);
});
test('actual free parser enables attachment skip only in TXT-only mode',async () => {
  const txt = fixture(); await txt.parse(); assert.equal(txt.state.cleanOptions[0]?.skipDownloadAttachments,true);
  const epub = fixture({txtOnly:false}); await epub.parse(); assert.notEqual(epub.state.cleanOptions[0]?.skipDownloadAttachments,true);
});
function imageFixture(options) {
  const state = {cache:0,random:0,fetch:0};
  const context = vm.createContext({options,imgMode:'TM',document:{createElement:tag => new FixtureNode(tag)},_attachments__WEBPACK_IMPORTED_MODULE_1__:{_s() {state.cache++;return null;},VJ() {state.random++;return 'fixture-image';},async if() {state.fetch++;return {name:'fixture-image'};} }});
  vm.runInContext(getImg+'\nthis.getImg=getImg;',context);return {state,get:context.getImg};
}
test('shipped getImg TXT attachment skip returns URL markdown without lookup, random name or network fetch',async () => {
  const f = imageFixture({skipDownloadAttachments:true}); const url = 'https://example.invalid/chapter-image.png'; const result = await f.get(url);
  assert.deepEqual(f.state,{cache:0,random:0,fetch:0}); assert.equal(result.text,`![${url}](${url})`); assert.equal(result.images.length,0);
});
test('shipped getImg retains ordinary EPUB image attachment path when option is not enabled',async () => {
  const f = imageFixture(undefined); const result = await f.get('https://example.invalid/chapter-image.png');
  assert.deepEqual(f.state,{cache:1,random:1,fetch:1}); assert.equal(result.images.length,1); assert.equal(result.images[0].name,'fixture-image');
});
(async () => {
  let failures = 0;
  for (const {name,fn} of tests) { try { await fn(); console.log(`PASS ${name}`); } catch (error) { failures++; console.error(`FAIL ${name}\n${error.stack}`); } }
  console.log(`${tests.length-failures}/${tests.length} v23 diagnostics and recovery checks passed`);
  if (failures) process.exitCode = 1;
})();
