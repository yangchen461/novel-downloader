// Executes the real frame helper, parser and Chapter error handler.
// The blank-state cases fail against .29 and pass after .30 metadata repair.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const sourceDirectory = path.resolve(process.argv[2] || __dirname);
const suiteSource = fs.readFileSync(path.join(sourceDirectory, 'test-qidian-v18-frame.cjs'), 'utf8');
const boundary = suiteSource.indexOf('const tests=[];');
assert(boundary >= 0, 'Existing real-function fixture boundary is missing');
const fixture = vm.runInNewContext(suiteSource.slice(0, boundary) + '\nfixture;', {
  require, __dirname: sourceDirectory, AbortController, URL, console, process
});
const freeSuite = fs.readFileSync(path.join(sourceDirectory, 'test-qidian-v24-parser-accuracy.cjs'), 'utf8');
const freeBoundary = freeSuite.indexOf('const tests=[];');
assert(freeBoundary >= 0, 'Existing free-parser fixture boundary is missing');
const freeFunctions = vm.runInNewContext(freeSuite.slice(0, freeBoundary) + '\n({fixture,bodyWith});', {
  require, __dirname: sourceDirectory, AbortController, URL, console, process
});
function events(f) {
  return f.state.logs.filter(line => line.startsWith('[QidianDebug] '))
    .map(line => JSON.parse(line.slice('[QidianDebug] '.length)));
}
function structural(state) {
  assert(state && typeof state === 'object', 'Converted page error must retain structural frame state');
  assert.equal(state.addressKind, 'requested');
  assert.equal(state.readyState, 'complete');
  assert.equal(state.bodyPresent, true);
  assert.equal(state.bodyTextLength, 0);
  assert.equal(state.bodyElements, 2);
  assert.equal(state.scriptCount, 3);
  assert.equal(state.loadEvents, 1);
  assert.equal(state.errorEvents, 0);
  assert.equal(state.contentPresent, false);
  assert.equal(state.mainParagraphs, 0);
  const serialized = JSON.stringify(state);
  assert(!serialized.includes('must-not-be-logged'));
  for (const forbidden of ['bodyText', 'innerText', 'contentText', 'URL', 'url', 'cookie', 'token']) {
    assert(!Object.hasOwn(state, forbidden), `Structural diagnostic cannot include ${forbidden}`);
  }
}
const tests=[];
const test=(name,run)=>tests.push({name,run});
test('blank requested timeout retains low-level state through parser conversion into attempt_error', async()=>{
  const f=fixture({elements:2,scripts:3}), chapter=f.makeChapter(338);
  await f.drain(chapter.init());
  assert.equal(chapter.qidianFailureKind,'page');
  assert.equal(chapter.retryTime,1);
  assert.equal(f.state.frames.length,1,'diagnostic repair must not introduce a page reload');
  assert.equal(f.state.waits.length,0);
  assert.equal(f.window.stopFlag.aborted,false);
  const error=events(f).find(event=>event.event==='attempt_error');
  assert.equal(error.errorName,'QidianChapterPageError');
  assert.equal(error.errorCode,'page_read_failed');
  structural(error.frameState);
});
test('final reader diagnostic retains the same timeout transport and document structure', async()=>{
  const f=fixture({elements:2,scripts:3});
  await f.drain(f.makeChapter(341).init());
  const diagnostic=events(f).find(event=>event.event==='frame_reader_diagnostics');
  structural(diagnostic);
  assert.equal(diagnostic.title,'第341章');
  assert.equal(diagnostic.accessKind,'unknown');
  assert.equal(diagnostic.accessEvidence,'no_explicit_gate','blank pages cannot be reclassified as unsubscribed');
  assert.equal(diagnostic.capturedPageErrors,0);
  assert.equal(f.state.timers.size,0);
  assert.equal(f.state.removed,1);
});
test('diagnostic repair does not change unknown timeout retries or disclose source body and address query', async()=>{
  const f=fixture({text:'synthetic private body',elements:2,scripts:3}), chapter=f.makeChapter(342);
  await f.drain(chapter.init());
  assert.equal(f.state.frames.length,2);
  const waitedMs=f.state.waits.reduce((total,ms)=>total+ms,0);
  assert(waitedMs>=85000 && waitedMs<=95000,'timeout cooldown retains its sampled +/-5s range');
  const retry=events(f).find(event=>event.event==='retry_scheduled');
  assert.equal(retry.baseWaitMs,90000); assert.equal(retry.waitMs,waitedMs);
  const errors=events(f).filter(event=>event.event==='attempt_error');
  assert.equal(errors.length,2);
  assert(errors.every(event=>event.errorName==='QidianPageTimeoutError'));
  assert(errors.every(event=>event.frameState.addressKind==='requested'));
  const metadata=JSON.stringify(errors);
  assert(!metadata.includes('synthetic private body'));
  assert(!metadata.includes('must-not-be-logged'));
  assert.equal(chapter.qidianFailureKind,'page');
  assert.equal(f.window.stopFlag.aborted,false);
});
test('actual access evidence continues to pause immediately without any timeout retry', async()=>{
  const f=fixture({waf:true});
  await f.drain(f.makeChapter(343).init());
  assert.equal(f.state.frames.length,1);
  assert.equal(f.state.now,0);
  assert.equal(f.state.removed,1);
  assert.equal(f.state.timers.size,0);
  assert.equal(f.window.stopFlag.aborted,true);
  assert.equal(f.state.waits.length,0);
});
test('an incomplete free source reports not compared without pretending cleanup mismatched', async()=>{
  const f=freeFunctions.fixture({expected:5000});
  await assert.rejects(f.parse(),error=>error.name==='QidianContentError');
  const diagnostic=f.events().find(event=>event.event==='content_check');
  assert.equal(diagnostic.quality.complete,false);
  assert.equal(diagnostic.quality.reason,'below_expected_length');
  assert.equal(diagnostic.rawMainChars,2000);
  assert.equal(diagnostic.quality.actualChars,2000);
  assert.equal(diagnostic.removedDuringCleanup,0);
  assert.equal(diagnostic.sourceMatched,null);
  assert.equal(f.state.htmlRequests,1);
  assert.equal(f.state.ocrCalls,0);
});
test('a complete free source retains true only after the actual canonical comparison matches', async()=>{
  const f=freeFunctions.fixture();
  await f.parse();
  const diagnostic=f.events().find(event=>event.event==='content_check');
  assert.equal(diagnostic.quality.complete,true);
  assert.equal(diagnostic.sourceMatched,true);
  assert.equal(f.state.htmlRequests,1);
});
test('a real reordered cleanup retains false and the exact source is still recovered', async()=>{
  const reordered=freeFunctions.bodyWith(['乙'.repeat(1000),'甲'.repeat(1000)]);
  const f=freeFunctions.fixture({cleanedDOM:reordered.main,cleanedText:reordered.main.textContent});
  const result=await f.parse();
  const diagnostic=f.events().find(event=>event.event==='content_check');
  assert.equal(diagnostic.quality.complete,true);
  assert.equal(diagnostic.sourceMatched,false);
  assert.equal(result.contentText.replace(/\s/g,''),'甲'.repeat(1000)+'乙'.repeat(1000));
  assert.equal(f.state.htmlRequests,1);
  assert.equal(f.state.ocrCalls,0);
});
(async()=>{
  let failed=0;
  for(const {name,run} of tests) {
    try {await run(); console.log('PASS',name);}
    catch(error) {failed++; console.error('FAIL',name,'\n',error.stack??error);}
  }
  console.log(`${tests.length-failed}/${tests.length} structured frame-state checks passed`);
  if(failed)process.exitCode=1;
})();
