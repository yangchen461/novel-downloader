const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const source = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
function between(start, end) {
  const a = source.indexOf(start), b = source.indexOf(end, a);
  assert.ok(a >= 0 && b > a, `missing source range: ${start}`);
  return source.slice(a, b);
}
const reportSource = between('function qidianReportProgress(', 'function qidianStageMetadata(');
const attemptSource = between('function qidianAttemptScope(', 'async function qidianStage(');
const stageSource = between('async function qidianStage(', 'function qidianStageSync(');
const uiSource = between('function formatETA(', 'app.config.compilerOptions');
let now = 1000;
let timerStarts = 0, timerStops = 0;
const timers = new Map();
class TestDate extends Date { static now() { return now; } }
const context = vm.createContext({
  Date: TestDate,
  window: {},
  qidianDebugEvent() {},
  qidianStageMetadata: ctx => ({ title: ctx.chapterName }),
  qidianErrorDiagnostic: error => ({ reason: error.message }),
  external_Vue_: { createApp: options => options },
  ui_progress: '',
  setInterval(fn) { const id = ++timerStarts; timers.set(id, fn); return id; },
  clearInterval(id) { timerStops++; timers.delete(id); }
});
vm.runInContext(reportSource + attemptSource + stageSource + uiSource + '\nglobalThis.uiOptions = app;', context);
const options = context.uiOptions;
const state = options.data();
for (const [key, method] of Object.entries(options.methods)) state[key] = method.bind(state);
for (const [key, getter] of Object.entries(options.computed)) {
  Object.defineProperty(state, key, { get: getter.bind(state) });
}
context.window.qidianProgressSink = state.applyQidianProgress;
function report(...args) { return context.qidianReportProgress(...args); }

(async () => {
  assert.equal(vm.runInNewContext(reportSource + '; qidianReportProgress("paused")'), null,
    'headless parser has no window and progress must remain optional');
  context.window.qidianProgressSink = () => { throw new Error('UI removed'); };
  assert.doesNotThrow(() => report('starting'));
  context.window.qidianProgressSink = state.applyQidianProgress;
  report('reset');

  const chapter = { chapterName: '第216章 测试', options: {} };
  await context.qidianStage(chapter, 'chapter_parse', async () => {
    assert.equal(state.qidianLiveStatus.state, 'chapter_parse');
    await context.qidianStage(chapter, 'page_load', async () => {
      assert.equal(state.qidianStageText, '等待阅读页加载');
      now += 12000;
      state.qidianClock = now;
      assert.match(state.qidianStageText, /已用 12s/);
    });
    assert.equal(state.qidianLiveStatus.state, 'chapter_parse', 'inner stage restores outer stage');
  });
  assert.equal(state.qidianLiveStatus.state, 'processing');
  assert.equal(state.qidianLiveStatus.title, chapter.chapterName);

  let finishPage;
  const running = context.qidianStage(chapter, 'page_load', () => new Promise(resolve => { finishPage = resolve; }));
  report('paused', '', 0, '检测到网站安全验证，请在起点页面手动完成验证。');
  finishPage('page ready');
  await running;
  report('cooling', '后续章', 60000, 'late cooldown');
  report('stopped');
  assert.equal(state.qidianLiveStatus.state, 'paused', 'late stage/cooldown/abort cannot erase verification pause');
  assert.match(state.qidianLiveStatus.reason, /手动完成验证/);
  assert.equal(state.qidianLiveStatus.title, chapter.chapterName);

  state.isQidianRun = true;
  state.totalChapterNumber = 749;
  state.finishedChapterNumber = 215;
  state.totalRequestTime = 500000;
  assert.equal(state.etaText, '', 'pause hides stale ETA');
  report('starting');
  state.qidianTimingContaminated = false;
  state.qidianDiscardNextGap = false;
  for (let i = 0; i < 5; i++) state.updateQidianTiming(8000, 15000, true);
  assert.match(state.etaText, /^~/);
  report('failed', chapter.chapterName, 0, '页面超时');
  assert.equal(state.etaText, '', 'errors hide ETA immediately');
  assert.equal(state.qidianStartGaps.length, 0, 'error timings are discarded');
  report('cooling', chapter.chapterName, 90000, '页面超时，等待后重试');
  now += 30000;
  state.qidianClock = now;
  assert.equal(state.qidianStageText, '冷却中（剩余 1m）');
  assert.equal(state.etaText, '', 'cooldown never projects its delay across remaining chapters');
  report('page_load', chapter.chapterName);
  state.updateQidianTiming(180000, 250000, true);
  assert.equal(state.qidianChapterTimes.length, 0, 'first recovery sample contains retry costs and is excluded');
  state.updateQidianTiming(8000, 250000, true);
  assert.equal(state.qidianStartGaps.length, 0, 'first new gap still includes cooldown and is excluded');
  for (let i = 0; i < 4; i++) state.updateQidianTiming(8000, 15000, true);
  assert.equal(state.qidianStartGaps.length, 4);
  assert.match(state.etaText, /^~/, 'ETA resumes after enough new successful samples');
  state.updateQidianTiming(500000, 600000, false);
  assert.equal(state.qidianChapterTimes.length, 0, 'failed chapter cannot become a timing sample');

  options.watch.ntProgressSeen.call(state, true);
  options.watch.ntProgressSeen.call(state, true);
  assert.equal(timerStarts, 1, 'one clock per mounted progress display');
  now += 1000;
  for (const callback of timers.values()) callback();
  assert.equal(state.qidianClock, now);
  state.reset();
  assert.equal(timerStops, 1, 'reset releases progress clock');
  assert.equal(timers.size, 0);
  assert.equal(state.qidianLiveStatus.state, undefined);
  assert.equal(context.window.qidianProgressState.state, '');
  options.watch.ntProgressSeen.call(state, true);
  options.beforeUnmount.call(state);
  assert.equal(timers.size, 0, 'unmount also releases the clock');
  assert.equal(context.window.qidianProgressSink, null, 'unmount detaches sink');
  console.log('PASS V33 live progress: nested stages, sticky verification pause, countdown, ETA recovery, clock cleanup');
})().catch(error => { console.error(error); process.exitCode = 1; });
