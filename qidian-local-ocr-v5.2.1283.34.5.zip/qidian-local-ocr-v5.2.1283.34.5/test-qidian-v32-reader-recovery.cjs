// Exercise the shipped parser and readiness functions with synthetic DOM trees.
// Only HTML/frame transport and OCR boundaries are replaced; no network or novel text.
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const directory = path.resolve(process.argv[2] || __dirname);
const source = fs.readFileSync(path.join(directory, 'novel-downloader-qidian-range.user.js'), 'utf8');
function take(a, b, from = 0) {
  const start = source.indexOf(a, from), end = source.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing shipped implementation: ${a}`);
  return source.slice(start, end);
}
const fixtureSource = fs.readFileSync(path.join(directory, 'test-qidian-v24-parser-accuracy.cjs'), 'utf8');
const fixtureEnd = fixtureSource.indexOf('const tests=[];');
assert(fixtureEnd > 0);
const free = vm.runInNewContext(fixtureSource.slice(0, fixtureEnd) + '\n({fixture,bodyWith,ElementNode})',
  {require,__dirname:directory,AbortController,URL,console,process});
const canonical = value => String(value ?? '').replace(/\s/g, '');
function readerDocument(main, config = {}) {
  const body = new free.ElementNode('body');
  if (config.outside) body.appendChild(config.outside);
  if (main) body.appendChild(main);
  const doc = {URL:'https://www.qidian.com/chapter/1/39/',readyState:'complete',title:config.title ?? '第39章 测试',body,
    defaultView:{getComputedStyle(node) { return config.style?.(node) ?? {display:'block',visibility:'visible'}; }},
    querySelector(selector) { return this.querySelectorAll(selector)[0] ?? null; },
    querySelectorAll(selector) {
      const found = [];
      for (const raw of selector.split(',')) {
        const part = raw.trim();
        let nodes;
        if (part === 'main') nodes = main ? [main] : [];
        else if (part === 'h1.title') nodes = [new free.ElementNode('h1','第39章 测试',{class:'title'})];
        else if (part.startsWith('main ')) nodes = main?.querySelectorAll(part.slice(5)) ?? [];
        else nodes = body.querySelectorAll(part);
        for (const node of nodes) if (!found.includes(node)) found.push(node);
      }
      return found;
    }};
  function adopt(node) { node.ownerDocument = doc; for (const child of node.childNodes ?? []) adopt(child); }
  adopt(body);
  return doc;
}
function fixture(config = {}) {
  const staticMain = config.staticMain ?? free.bodyWith(['甲'.repeat(2064)]).main;
  const f = free.fixture({main:staticMain,expected:config.expected ?? 7000});
  const staticDoc = readerDocument(staticMain);
  const docs = config.docs ?? [readerDocument(free.bodyWith(['甲'.repeat(2100),'乙'.repeat(2100)]).main)];
  f.state.readiness = [];
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.pG = async () => { f.state.htmlRequests++; return staticDoc; };
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.Q2 = async (_url, predicate, _sandbox, _timeout, frameOptions) => {
    f.state.frameRequests++;
    f.state.frameOptions = frameOptions;
    let removed = false;
    const frame = {contentWindow:{document:docs[0]},remove() { if (!removed) { removed = true; f.state.framesRemoved++; } }};
    try {
      for (const doc of docs) {
        frame.contentWindow.document = doc;
        const ready = predicate(frame);
        f.state.readiness.push(ready);
        if (ready) return frame;
      }
      const last = docs[docs.length - 1];
      const error = Error('Frame Timeout!');
      error.frameState = {addressKind:'requested',readyState:'complete',bodyPresent:true,
        bodyTextLength:last.body.innerText.length,contentPresent:!!last.querySelector('.content-text'),
        mainParagraphs:last.querySelector('main')?.querySelectorAll('p').length ?? 0};
      throw error;
    } catch (error) { frame.remove(); throw error; }
  };
  f.parseAttempt = (attempt = 0) => new f.ctx.Qidian().chapterParse(
    'https://www.qidian.com/chapter/1/39/','第39章 测试',false,true,'UTF-8',f.options,attempt);
  return f;
}
const tests = [];
const test = (name, run) => tests.push({name,run});
test('short static source fails, then the rendered retry recovers a complete free body without OCR', async () => {
  const f = fixture();
  await assert.rejects(f.parseAttempt(0), error => error.name === 'QidianContentError');
  assert.equal(f.options.qidianValidation.actualChars,2064);
  assert.equal(f.options.qidianValidation.minimumChars,3500);
  assert.equal(f.state.frameRequests,0);
  const result = await f.parseAttempt(1);
  assert.equal(canonical(result.contentText),'甲'.repeat(2100)+'乙'.repeat(2100));
  assert.equal(f.options.qidianValidation.complete,true);
  assert.equal(f.state.htmlRequests,1); assert.equal(f.state.frameRequests,1);
  assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,1);
  assert.equal(f.state.frameOptions.signal,f.window.stopFlag);
  assert(f.events().some(event => event.event === 'reader_fallback'));
});
test('rendered fallback remains selected when a later recovery round resets retryAttempt to zero', async () => {
  const f = fixture();
  await assert.rejects(f.parseAttempt(0), error => error.name === 'QidianContentError');
  await f.parseAttempt(1);
  assert.equal(f.options.qidianUseRenderedReader,true);
  const result = await f.parseAttempt(0);
  assert.equal(canonical(result.contentText).length,4200);
  assert.equal(f.state.htmlRequests,1); assert.equal(f.state.frameRequests,2);
  assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,2);
});
test('a static shell without main switches to a rendered reader in deferred recovery even with retryAttempt zero', async () => {
  const f = fixture();
  f.ctx._lib_http__WEBPACK_IMPORTED_MODULE_2__.pG = async () => {
    f.state.htmlRequests++;
    return readerDocument(null);
  };
  await assert.rejects(f.parseAttempt(0), error => error.name === 'QidianChapterPageError');
  assert.equal(f.state.htmlRequests,1); assert.equal(f.state.frameRequests,0);
  assert.equal(f.options.qidianUseRenderedReader,undefined);
  f.options.qidianRecoveryRound = 1;
  const result = await f.parseAttempt(0);
  assert.equal(canonical(result.contentText),'甲'.repeat(2100)+'乙'.repeat(2100));
  assert.equal(f.options.qidianUseRenderedReader,true);
  assert.equal(f.options.qidianValidation.complete,true);
  assert.equal(f.state.htmlRequests,1); assert.equal(f.state.frameRequests,1);
  assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,1);
});
test('empty and partially rendered content roots wait for a full body within the same frame request', async () => {
  const docs = ['', '甲'.repeat(2064), '甲'.repeat(4200)].map(text => readerDocument(free.bodyWith([text]).main));
  const f = fixture({docs});
  const result = await f.parseAttempt(1);
  assert.deepEqual(f.state.readiness,[false,false,true]);
  assert.equal(canonical(result.contentText).length,4200);
  assert.equal(f.state.htmlRequests,0); assert.equal(f.state.frameRequests,1); assert.equal(f.state.ocrCalls,0);
});
test('a persistently short rendered source never becomes a successful chapter', async () => {
  const f = fixture({docs:[readerDocument(free.bodyWith(['甲'.repeat(2064)]).main)]});
  await assert.rejects(f.parseAttempt(1), error => error.name === 'QidianPageTimeoutError');
  assert.deepEqual(f.state.readiness,[false]);
  assert.equal(f.options.qidianValidation,undefined);
  assert.equal(f.state.htmlRequests,0); assert.equal(f.state.frameRequests,1);
  assert.equal(f.state.cleanCalls.length,0); assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,1);
  assert.equal(f.window.stopFlag.aborted,false);
});
for (const point of [0xe123,0xfffd]) test(`rendered free text still rejects unresolved U+${point.toString(16)} after length readiness`, async () => {
  const f = fixture({docs:[readerDocument(free.bodyWith(['甲'.repeat(4200)+String.fromCodePoint(point)]).main)]});
  await assert.rejects(f.parseAttempt(1), error => error.name === 'QidianContentError');
  assert.deepEqual(f.state.readiness,[true]);
  assert.equal(f.options.qidianValidation.complete,false);
  assert.match(f.options.qidianValidation.reason,/private_use|replacement/);
  assert.equal(f.state.frameRequests,1); assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,1);
});
test('a free fallback with an explicit purchase gate is classified as unsubscribed without OCR or another request', async () => {
  const main = free.bodyWith(['']).main;
  main.appendChild(new free.ElementNode('div','订阅本章后阅读',{class:'vip-limit-wrap'}));
  const f = fixture({docs:[readerDocument(main)]});
  await assert.rejects(f.parseAttempt(1), error => error.name === 'QidianUnsubscribedError');
  assert.equal(f.options.qidianAccessEvidence,'vip_limit_wrap');
  assert.equal(f.state.frameRequests,1); assert.equal(f.state.htmlRequests,0);
  assert.equal(f.state.cleanCalls.length,0); assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,1);
  assert.equal(f.window.stopFlag.aborted,false);
});
for (const title of ['请先登录','安全验证','WAF拦截页面']) test(`rendered fallback pauses on ${title} before cleaner or further requests`, async () => {
  const f = fixture({docs:[readerDocument(free.bodyWith(['']).main,{title})]});
  await assert.rejects(f.parseAttempt(1), error => error.name === 'QidianAccessError');
  assert.equal(f.window.stopFlag.aborted,true);
  assert.equal(f.state.frameRequests,1); assert.equal(f.state.htmlRequests,0);
  assert.equal(f.state.cleanCalls.length,0); assert.equal(f.state.ocrCalls,0); assert.equal(f.state.framesRemoved,1);
});
test('readiness excludes unrelated page and navigation text instead of accepting an empty content root', () => {
  const main = free.bodyWith(['']).main;
  main.appendChild(new free.ElementNode('nav','甲'.repeat(5000)));
  const doc = readerDocument(main,{outside:new free.ElementNode('aside','乙'.repeat(5000))});
  const f = fixture();
  assert.equal(f.ctx.qidianReaderBodyIsReady(doc,4013,false),false);
  assert.equal(f.ctx.qidianReaderBodyIsReady(readerDocument(null,{outside:new free.ElementNode('div','甲'.repeat(5000))}),4013,false),false);
});
test('live CSS-hidden first content root is excluded and the readable root is preserved exactly', async () => {
  const hidden = free.bodyWith(['隐藏副本'.repeat(1000)]), live = free.bodyWith(['甲'.repeat(2100),'乙'.repeat(2100)]);
  hidden.content.setAttribute('class','content-text hidden-by-stylesheet');
  hidden.main.appendChild(live.content);
  const doc = readerDocument(hidden.main,{style:node => ({display:node.className.includes('hidden-by-stylesheet')?'none':'block',visibility:'visible'})});
  const f = fixture({docs:[doc]});
  const result = await f.parseAttempt(1);
  assert.equal(canonical(result.contentText),'甲'.repeat(2100)+'乙'.repeat(2100));
  const check = f.events().find(event => event.event === 'content_check');
  assert.equal(check.rootSelection.contentRootCount,2); assert.equal(check.rootSelection.eligibleRootCount,1);
  assert.equal(f.state.frameRequests,1); assert.equal(f.state.ocrCalls,0);
});
test('two independent visible roots are not silently joined or accepted for readiness', () => {
  const a = free.bodyWith(['甲'.repeat(4200)]), b = free.bodyWith(['乙'.repeat(4200)]);
  a.main.appendChild(b.content);
  const f = fixture();
  assert.equal(f.ctx.qidianReaderBodyIsReady(readerDocument(a.main),4013,false),false);
});
test('VIP structural readiness allows encoded glyphs, leaving decoding and integrity checks to the parser', () => {
  const f = fixture();
  assert.equal(f.ctx.qidianReaderBodyIsReady(readerDocument(free.bodyWith(['\ue123'.repeat(4200)]).main),4013,true),true);
  assert.equal(f.ctx.qidianReaderBodyIsReady(readerDocument(free.bodyWith(['\ue123'.repeat(100)]).main),4013,true),false);
});
// Reuse the deterministic timer/iframe boundary from the v31 suite, but load
// the current shipped iframe helper. Assertions below cover real AbortSignal cleanup.
const frameSource = fs.readFileSync(path.join(directory,'test-qidian-v31-readiness-scope.cjs'),'utf8');
const frameStart = frameSource.indexOf('function frameFixture('), frameEnd = frameSource.indexOf("\ntest(",frameStart);
assert(frameStart >= 0 && frameEnd > frameStart);
const frameFixture = vm.runInNewContext(frameSource.slice(frameStart,frameEnd)+'\nframeFixture',{vm,assert,take,URL,console});
const abortListeners = signal => require('node:events').getEventListeners(signal,'abort').length;
test('cancelling a pending reader wait removes its frame, timers and all signal listeners immediately', async () => {
  const f = frameFixture({load:false}), controller = new AbortController();
  let checks = 0;
  const pending = f.request(() => { checks++; return false; },{checkOnLoad:true,signal:controller.signal});
  assert.equal(abortListeners(controller.signal),1);
  assert.equal(f.state.frames.length,1);
  controller.abort();
  await assert.rejects(pending,error => error.name === 'AbortError');
  assert.equal(f.state.now,0); assert.equal(f.state.removed,1); assert.equal(f.state.timers.size,0);
  assert.equal(abortListeners(controller.signal),0);
  assert.equal([...f.state.frames[0].listeners.values()].reduce((sum,set)=>sum+set.size,0),0);
  for (const callback of f.state.queued) callback();
  assert.equal(checks,0); assert.equal(f.state.removed,1);
});
test('an already cancelled reader creates no timers or readiness checks', async () => {
  const f = frameFixture(), controller = new AbortController(); controller.abort();
  let checks = 0;
  await assert.rejects(f.request(() => { checks++; return true; },{checkOnLoad:true,signal:controller.signal}),
    error => error.name === 'AbortError');
  assert.equal(checks,0); assert.equal(f.state.timers.size,0); assert.equal(f.state.removed,1);
  assert.equal(f.state.queued.length,0); assert.equal(abortListeners(controller.signal),0);
});
test('successful readiness detaches cancellation so a later abort cannot remove a frame used by parsing', async () => {
  const f = frameFixture(), controller = new AbortController();
  await f.drain(f.request(() => true,{checkOnLoad:true,signal:controller.signal}));
  assert.equal(abortListeners(controller.signal),0);
  controller.abort();
  assert.equal(f.state.removed,0); assert.equal(f.state.timers.size,0);
});
(async () => {
  let failed = 0;
  for (const {name,run} of tests) {
    try { await run(); console.log('PASS',name); }
    catch (error) { failed++; console.error('FAIL',name,'\n',error.stack ?? error); }
  }
  console.log(`${tests.length-failed}/${tests.length} v32 rendered reader recovery checks passed`);
  if (failed) process.exitCode = 1;
})();
