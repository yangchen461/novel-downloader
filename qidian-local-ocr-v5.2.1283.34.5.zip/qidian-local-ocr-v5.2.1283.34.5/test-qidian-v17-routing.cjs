// Extract the shipped implementation; replace only browser/network/OCR boundaries.
const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');
const path = require('node:path');
const src = fs.readFileSync(path.join(__dirname, 'novel-downloader-qidian-range.user.js'), 'utf8');
const take = (a, b, from = 0) => {
  const start = src.indexOf(a, from), end = src.indexOf(b, start);
  assert(start >= 0 && end > start, `Missing source boundary: ${a}`);
  return src.slice(start, end);
};
const status = { pending:0, downloading:1, failed:2, finished:3, aborted:4, saved:5 };
const globals = take('function qidianContentIsComplete(', '/******/ \tvar __webpack_modules__');
const chapterCode = take('class ChapterAbortError', '\n\n/***/ },');
const scheduler = take('  async initChapters(book,', '\n  postHook()');
const parse = take('  async chapterParse(', '\n}\n\n\n/***/', src.indexOf('class Qidian extends'));
const saveCode = take('  async addChapter(chapter) {', '\n  async save()', src.indexOf('class SaveBook'));
// Extract filtering only; v26 full-run tests cover the instrumented export.
const validation = take('      if (/^(www|book)\\.qidian\\.com$/.test(document.location.hostname)) {', '      // Export lifecycle begins after per-chapter filtering.', src.indexOf('await self.initChapters(self.book'));
const progressCode = take('function formatETA(', 'app.config.compilerOptions');
const progressOptions = vm.runInNewContext(progressCode + '\napp', { external_Vue_: { createApp:o=>o }, ui_progress:'' });
function node(tag='div') { return { tag, children:[], appendChild(child) { this.children.push(child); return child; } }; }
function fixture(configs) {
  const state = { now:1000, starts:[], waits:[], clean:[], ocr:[], persist:0, removed:0, active:0, maxActive:0, onSleep:null, onClean:null, notices:[], logs:[], timer:0, attempts:new Map() };
  const window = { stopController:new AbortController(), failedCount:0 };
  window.stopFlag = window.stopController.signal;
  const configsById = new Map(configs.map(c=>[c.id,c]));
  const progress = progressOptions.data(); Object.assign(progress, progressOptions.methods);
  const log = { info:x=>state.logs.push(String(x)), warn:x=>state.logs.push(String(x)), error(){}, trace(){}, debug(){} };
  const sleep = async ms => { state.waits.push(ms); state.now += ms; if (state.onSleep) state.onSleep(ms); };
  const docFor = (cfg, attempt) => {
    const text = cfg.shortFirst && attempt === 1 ? '短文' : `第${cfg.id}章正文` + '正文'.repeat(1000);
    const main = { id:cfg.id, cfg, textContent:cfg.vip ? `第${cfg.id}章正文` + '正文'.repeat(1000) : text, ocrText:text, querySelectorAll:()=>Array(5) };
    const doc = { title:cfg.block ? 'WAF拦截页面' : `第${cfg.id}章`, body:{textContent:cfg.block ? '403 您的请求已中断' : text}, querySelector(s) {
      if (s === 'main') return main;
      if (s === 'h1.title') return {innerText:`第${cfg.id}章`};
      if (s === '.vip-limit-wrap') return cfg.locked ? {} : null;
      if (s === '.content-text, .vip-limit-wrap') return main;
      return null;
    }};
    return doc;
  };
  const request = async (route, url, predicate) => {
    const id = Number(url.split('/').at(-1)), cfg = configsById.get(id);
    assert(cfg, `unexpected chapter request ${id}`);
    const attempt = (state.attempts.get(id) || 0) + 1; state.attempts.set(id,attempt);
    state.starts.push({id,route,at:state.now,attempt});
    state.now += cfg.pageMs ?? 1000;
    if (cfg.requestError) throw new Error('HTTP 403');
    const doc = docFor(cfg,attempt);
    if (route === 'html') return doc;
    let removed = false;
    const frame = { contentWindow:{document:doc}, remove() { if(!removed){removed=true;state.removed++;} } };
    try { assert.equal(predicate(frame),true); } catch(e) { frame.remove(); throw e; }
    return frame;
  };
  const ctx = vm.createContext({
    window, document:{location:{hostname:'www.qidian.com'}, createElement:node}, Date:{now:()=>state.now}, Math:Object.assign(Object.create(Math),{random:()=>0}),
    setTimeout:()=>++state.timer, clearTimeout(){}, AbortController, console:log, alert:x=>state.notices.push(x),
    _main__WEBPACK_IMPORTED_MODULE_3__:{nW:status}, main:{nW:status,K5:Error},
    _log__WEBPACK_IMPORTED_MODULE_1___default:()=>log, _log__WEBPACK_IMPORTED_MODULE_6___default:()=>log, loglevel_default:()=>log,
    _lib_misc__WEBPACK_IMPORTED_MODULE_0__:{yy:sleep}, misc:{yy:sleep}, setting:{Zz:{value:false},Nw:{value:false}}, progress:{vm:progress}, log:{M6(){}},
    _lib_http__WEBPACK_IMPORTED_MODULE_2__:{pG:async url=>request('html',url),Q2:async(url,predicate)=>request('frame',url,predicate)},
    _lib_dom__WEBPACK_IMPORTED_MODULE_4__:{rm(){},Sf(){}},
    _lib_cleanDOM__WEBPACK_IMPORTED_MODULE_1__:{async an(main) { assert.equal(main.cfg.vip,false,'VIP body must not use cleanDOM fallback'); state.clean.push(main.id); if(state.onClean)state.onClean(main.id); return {dom:node(),text:main.textContent,images:[]}; },is(){}},
    async ocrContent(main) { assert.equal(main.cfg.vip,true,'free HTML must not use OCR'); state.ocr.push(main.id); state.now += main.cfg.ocrMs ?? 6000; if(main.cfg.glyphFail){const e=new Error('local glyph recovery exhausted');e.name='QidianGlyphError';throw e;} return {contentText:main.ocrText,contentHTML:node()}; },
    qidianGlyphCache:new Map([['fixture','字']]), async qidianPersistGlyphCache(){state.persist++;}
  });
  vm.runInContext(globals + chapterCode + '\nclass Rule {'+scheduler+'}\nclass Qidian {'+parse+'}\nclass Save {'+saveCode+'}\nthis.Chapter=Chapter;this.Rule=Rule;this.Qidian=Qidian;this.Save=Save;this.validate=self=>{let qidianCompletionMessage;'+validation+'return self.book;};',ctx);
  const parser = new ctx.Qidian(), chapters = configs.map(cfg=>new ctx.Chapter({
    bookUrl:'https://www.qidian.com/book/1/', chapterUrl:`https://www.qidian.com/chapter/1/${cfg.id}`, chapterNumber:cfg.id+1, chapterName:`第${cfg.id}章`,
    isVIP:cfg.vip, isPaid:cfg.paid, charset:'UTF-8', options:{expectedChars:2000},
    chapterParse:async(...args)=>{state.active++;state.maxActive=Math.max(state.maxActive,state.active);try{return await parser.chapterParse(...args);}finally{state.active--;}}
  }));
  const rule=new ctx.Rule();rule.concurrencyLimit=1;rule.sleepTime=8000;rule.maxSleepTime=20000;
  const saver=new ctx.Save();saver.saveType={txt:true,epub:true};saver.epub={addChapter(){throw Error('EPUB must remain disabled');}};
  const book={chapters};
  return {state,window,progress,ctx,chapters,book,async run(){try{await rule.initChapters(book,saver);}catch(e){if(!window.stopFlag.aborted)throw e;}return book;},validate:()=>ctx.validate({book,postHook(){}})};
}
const tests=[];const test=(name,fn)=>tests.push({name,fn});
const ids=f=>f.state.starts.map(x=>x.id);

test('free HTML keeps upstream cadence and never calls frame, OCR or glyph persistence',async()=>{
  const f=fixture([{id:1,vip:false,paid:false},{id:2,vip:false,paid:true},{id:3,vip:false,paid:false}]);await f.run();
  assert.deepEqual(f.state.starts.map(x=>x.route),['html','html','html']);
  assert.deepEqual(f.state.waits,[50,100]);assert.deepEqual(f.state.clean,[1,2,3]);assert.deepEqual(f.state.ocr,[]);assert.equal(f.state.persist,0);assert.equal(f.state.removed,0);
  assert(f.chapters.every(c=>c.status===status.saved));assert.equal(f.state.maxActive,1);
});

test('VIP route depends on isVIP, not paid status, and retains OCR plus cache calls',async()=>{
  const f=fixture([{id:101,vip:true,paid:true},{id:102,vip:true,paid:false}]);await f.run();
  assert.deepEqual(f.state.starts.map(x=>x.route),['frame','frame']);assert.deepEqual(f.state.ocr,[101,102]);assert.deepEqual(f.state.clean,[]);assert.equal(f.state.persist,2);assert.equal(f.state.removed,2);
  assert.deepEqual(f.state.waits,Array(13).fill(1000));assert.equal(f.state.starts[1].at-f.state.starts[0].at,10000);assert(f.chapters.every(c=>c.status===status.saved));
});

test('mixed sequence stays serial, keeps transitions protected, then resumes free cadence',async()=>{
  const f=fixture([{id:1,vip:false},{id:2,vip:false},{id:3,vip:true},{id:4,vip:true,ocrMs:12000},{id:5,vip:false},{id:6,vip:false}]);await f.run();
  assert.deepEqual(ids(f),[1,2,3,4,5,6]);assert.equal(f.state.maxActive,1);
  const starts=f.state.starts;for(const i of [2,3,4])assert(starts[i].at-starts[i-1].at>=10000,`protected transition before ${i+1}`);
  assert.equal(starts[5].at-starts[4].at,1250);assert(!f.state.waits.includes(0));
  assert.deepEqual(f.state.clean,[1,2,5,6]);assert.deepEqual(f.state.ocr,[3,4]);
  assert.deepEqual(f.validate().chapters.map(c=>c.chapterName),['第1章','第2章','第3章','第4章','第5章','第6章']);
  assert.equal(f.progress.qidianOtherTypePending,false);assert.equal(f.progress.qidianChapterTimes.length,2,'final free segment resets VIP ETA samples');
});

test('next VIP is paced from the final free retry request, not the original attempt',async()=>{
  const f=fixture([{id:10,vip:false,shortFirst:true},{id:11,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[10,10,11]);assert.equal(f.state.starts[2].at-f.state.starts[1].at,10000);assert.equal(f.chapters[0].retryTime,1);
  assert.equal(f.chapters[0].qidianRequestStartedAt,f.state.starts[1].at);assert(f.chapters.every(c=>c.status===status.saved));
});

test('VIP retry also preserves the last request timestamp and avoids raw fallback',async()=>{
  const f=fixture([{id:20,vip:true,shortFirst:true,ocrMs:0},{id:21,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[20,20,21]);assert.equal(f.state.starts[2].at-f.state.starts[1].at,10000);assert.deepEqual(f.state.clean,[]);assert.equal(f.state.removed,3);
});

for(const vip of [false,true])test(`${vip?'VIP':'free'} WAF response pauses with partial-save report and no following request`,async()=>{
  const f=fixture([{id:30,vip:false},{id:31,vip,block:true},{id:32,vip:true}]);await f.run();
  assert.deepEqual(ids(f),[30,31]);assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[1].retryTime,1);
  const book=f.validate();assert.deepEqual(book.chapters.map(c=>c.chapterName),['第30章']);assert.equal(book.downloadReport.selectedCount,3);assert.equal(book.downloadReport.savedCount,1);
  assert.equal(book.downloadReport.missing.length,2);assert.match(book.downloadReport.missing[0].reason,/拦截/);assert.match(book.downloadReport.missing[1].reason,/尚未处理/);
});

test('free request failure stops immediately instead of aggressively retrying',async()=>{
  const f=fixture([{id:40,vip:false,requestError:true},{id:41,vip:true}]);await f.run();assert.deepEqual(ids(f),[40]);assert.equal(f.window.stopFlag.aborted,true);assert.equal(f.chapters[0].retryTime,1);
});

test('stop while transitioning from free to VIP sends no VIP request and preserves free TXT body',async()=>{
  const f=fixture([{id:50,vip:false},{id:51,vip:true},{id:52,vip:false}]);f.state.onSleep=()=>f.window.stopController.abort();await f.run();
  assert.deepEqual(ids(f),[50]);assert.equal(f.validate().downloadReport.savedCount,1);assert.equal(f.book.chapters[0].contentHTML,null);assert.match(f.book.chapters[0].contentText,/正文/);
});

test('an already-stopped free-only run has zero requests despite zero first delay',async()=>{
  const f=fixture([{id:60,vip:false}]);f.window.stopController.abort();await f.run();assert.deepEqual(ids(f),[]);assert.deepEqual(f.state.waits,[]);
});

test('stop during free cleanup prevents subsequent requests and does not commit the cancelled unvalidated body',async()=>{
  const f=fixture([{id:70,vip:false},{id:71,vip:true}]);f.state.onClean=()=>f.window.stopController.abort();await f.run();assert.deepEqual(ids(f),[70]);assert(!f.chapters[0].contentText);const report=f.validate().downloadReport;assert.equal(report.savedCount,0);assert.equal(report.missing.length,2);
});

test('unresolved VIP glyph records a missing chapter and receives only bounded deferred recovery without HTML fallback',async()=>{
  const f=fixture([{id:80,vip:false},{id:81,vip:true,glyphFail:true},{id:82,vip:true}]);await f.run();assert.deepEqual(ids(f),[80,81,82,81,81]);assert.deepEqual(f.state.clean,[80]);assert.equal(f.state.removed,4);assert.equal(f.chapters[1].retryTime,1);
  const book=f.validate();assert.deepEqual(book.chapters.map(c=>c.chapterName),['第80章','第82章']);assert.equal(book.downloadReport.missing[0].title,'第81章');assert.equal(f.window.stopFlag.aborted,false);
});

test('unsubscribed locked VIP skips once without free HTML or raw-text fallback',async()=>{
  const f=fixture([{id:90,vip:true,paid:false,locked:true}]);await f.run();assert.deepEqual(f.state.starts.map(x=>x.route),['frame']);assert.deepEqual(f.state.clean,[]);assert.deepEqual(f.state.ocr,[]);assert.equal(f.state.removed,1);assert.equal(f.chapters[0].status,status.aborted);assert.equal(f.chapters[0].qidianSkipReason,'unsubscribed');assert.equal(f.chapters[0].retryTime,0);assert.equal(f.window.failedCount,0);assert.equal(f.chapters[0].contentText,null);
});

test('isVIP and isPaid serialize independently for all four combinations',async()=>{
  const f=fixture([{id:1,vip:false,paid:false},{id:2,vip:false,paid:true},{id:3,vip:true,paid:false},{id:4,vip:true,paid:true}]);
  for(const c of f.chapters){const json=c.toJSON();assert.equal(json.isVIP,c.isVIP);assert.equal(json.isPaid,c.isPaid);}
});

test('title-number range keeps mixed chapter order and exports TXT without EPUB work',async()=>{
  const f=fixture([{id:100,vip:false},{id:101,vip:false},{id:102,vip:true,paid:true},{id:103,vip:false},{id:104,vip:true}]);
  vm.runInContext(take('function parseQidianChapterNumber(', 'const filterOptionDict ='),f.ctx);
  const selected=f.ctx.createChapterNumberFilter('101-103');
  f.book.chapters=f.book.chapters.filter(selected);
  await f.run();assert.deepEqual(ids(f),[101,102,103]);
  const book=f.validate();Object.assign(book,{author:'fixture',bookname:'mixed',downloadSuffix:' [101-103]'});
  let output;
  class Options {
    genMetaDateTxt(){return 'fixture';} getchapterName(c){return c.chapterName;}
    genSectionText(s){return s;} genChapterText(n,t){return n+'\n'+t;}
    chapterSort(a,b){return a.chapterNumber-b.chapterNumber;}
  }
  const txtContext=vm.createContext({Options,Blob,setting:{Nw:{value:false}},loglevel_default:()=>({debug(){},info(){}}),FileSaver_min:{saveAs:(blob,name)=>{output={blob,name};}}});
  vm.runInContext(globals + take('class TXT extends Options', ';// ./src/save/raw.ts')+'\nthis.TXT=TXT;',txtContext);
  new txtContext.TXT(book).saveTxt();
  const text=await output.blob.text();assert.match(output.name,/101-103.*\.txt$/);
  assert(text.indexOf('第101章')<text.indexOf('第102章'));assert(text.indexOf('第102章')<text.indexOf('第103章'));
  assert(!text.includes('第100章'));assert(!text.includes('第104章'));assert(!output.name.includes('部分下载'));
  assert.equal(book.downloadReport.savedCount,3);
});

(async()=>{let failed=0;for(const {name,fn} of tests){try{await fn();console.log('PASS',name);}catch(e){failed++;console.error('FAIL',name,e);}}console.log(`${tests.length-failed}/${tests.length} v17 routing checks passed`);if(failed)process.exitCode=1;})();
