const fs = require('node:fs');
const vm = require('node:vm');
const assert = require('node:assert/strict');

const script = fs.readFileSync('novel-downloader-qidian-range.user.js', 'utf8');
const helperStart = script.indexOf('async function qidianRecoverUnmappedGlyph(');
const helperEnd = script.indexOf('function extractRenderedText(', helperStart);
const mapStart = script.indexOf('async function buildFontDecodeMap(ownerDoc, ownerWin, fontFamily, uniqueChars) {');
assert.ok(helperStart > mapStart && helperEnd > helperStart);
const attemptStart = script.indexOf('function qidianAttemptScope(');
const attemptEnd = script.indexOf('async function qidianStage(', attemptStart);
assert.ok(attemptStart >= 0 && attemptEnd > attemptStart);
const attemptHelpers = script.slice(attemptStart, attemptEnd);

const logger = () => ({info() {}, warn() {}, error() {}});
function canvasFixture() {
  const canvas = {width: 0, height: 0, drawn: []};
  const ctx = {
    setTransform() {},
    fillRect() { canvas.drawn = []; },
    fillText(ch) { canvas.drawn.push(ch); }
  };
  return {canvas, ctx};
}

async function testCorroboratedAnchors() {
  const {canvas,ctx} = canvasFixture();
  const rendered = {A:'的',B:'人',C:'是',D:'不',X:'罕'};
  const anchors = [['A','的'], ['B','人'], ['C','是'], ['D','不']];
  let contexts = 0;
  const engine = {
    async decode() {return null;}, // Reproduce the two failed isolated reads in debug(4).log.
    async decodeFullText(data) {
      const raw = Buffer.from(data).toString('utf8');
      if ([...raw].length === 1) return ''; // Isolated reads fail; test the anchored path.
      contexts++;
      return [...raw].map(ch => rendered[ch]).join('');
    }
  };
  const recover = vm.runInNewContext(script.slice(helperStart,helperEnd) + '\nqidianRecoverUnmappedGlyph', {
    canvasToUint8Array: c => Buffer.from(c.drawn.join('')),
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger
  });
  assert.equal(await recover(canvas,ctx,'X','test',engine,anchors),'罕');
  assert.equal(contexts,2,'two correctly read anchor contexts must agree');

  let soloCalls = 0;
  engine.decodeFullText = async data => {
    const raw = Buffer.from(data).toString('utf8');
    if ([...raw].length !== 1) throw Error('anchored OCR should not run');
    soloCalls++;
    return '罕';
  };
  assert.equal(await recover(canvas,ctx,'X','test',engine,anchors),'罕',
    'two larger isolated renderings can recover the glyph without context');
  assert.equal(soloCalls,2);
  engine.decode = async () => null;

  contexts = 0;
  engine.decodeFullText = async data => {
    const raw = Buffer.from(data).toString('utf8');
    if ([...raw].length === 1) return '';
    contexts++;
    const result = [...raw].map(ch => rendered[ch]);
    result[1] = contexts % 2 ? '罕' : '汉';
    return result.join('');
  };
  assert.equal(await recover(canvas,ctx,'X','test',engine,anchors),null,
    'conflicting middle characters must not silently complete a chapter');
  engine.decodeFullText = async () => '错罕错';
  assert.equal(await recover(canvas,ctx,'X','test',engine,anchors),null,
    'OCR context must match both decoded anchors');
}

async function testMapIntegration() {
  const code = script.slice(mapStart,helperStart);
  const cache = new Map([['fp甲','的'], ['fp乙','人']]);
  let recovered = 0;
  const context = {
    qidianNormalizeGlyphReading: vm.runInNewContext(
      script.slice(script.indexOf('function qidianNormalizeGlyphReading('), script.indexOf('async function ocrSingleChar(', helperStart)) + '\nqidianNormalizeGlyphReading'
    ),
    qidianRestoreGlyphCache() {},
    qidianGlyphCache: cache,
    qidianGlyphFingerprints(_ctx,chars) {return new Map(chars.map(ch => [ch, 'fp'+ch]));},
    window: {},
    qidianOcrDecoder: {async decodeFullText() {return ''; }},
    ocrSingleChar: async () => null,
    qidianRecoverUnmappedGlyph: async () => {recovered++;return '罕';},
    QIDIAN_GLYPH_CACHE_LIMIT: 30000,
    qidianNewGlyphsSincePersist: 0,
    canvasToUint8Array: () => new Uint8Array([1]),
    _log__WEBPACK_IMPORTED_MODULE_6___default: logger
  };
  const fn = vm.runInNewContext(attemptHelpers+code+'\nbuildFontDecodeMap',context);
  const ownerDoc = {createElement: () => {
    const {canvas,ctx} = canvasFixture();
    canvas.getContext = () => ctx;
    return canvas;
  }};
  const map = await fn(ownerDoc,{},'test',['甲','乙','丙']);
  assert.equal(recovered,1);
  assert.equal(map.size,3);
  assert.equal(map.get('丙'),'罕');
  assert.equal(cache.get('fp丙'),'罕');
  assert.equal(context.qidianNewGlyphsSincePersist,1);

  context.qidianRecoverUnmappedGlyph = async () => null;
  const failed = await fn(ownerDoc,{},'test',['甲','乙','丁']);
  assert.equal(failed.has('丁'),false,'uncertain glyph must keep the chapter incomplete');
  assert.equal(cache.has('fp丁'),false,'uncertain glyph must never enter persistent cache');
}

(async () => {
  await testCorroboratedAnchors();
  await testMapIntegration();
  console.log('PASS Qidian rare glyph recovery: local anchored OCR, agreement required, unresolved glyph rejected');
})().catch(error => {console.error(error);process.exitCode=1;});
